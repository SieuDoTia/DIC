/*
 *  DIC
 *
 *  2017.12.03
 */


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "FFT_Moi.h"
#include "PNG.h"
#include "HangSo.h"

SoPhuc *doiAnhBGRO_sangDoXamSoPhuc( unsigned char *anhBGRO, unsigned int beRong, unsigned int beCao );
void taoTenAnhKetQua( char *tenAnhSuKhacBiet,  char *tenAnh0, char *tenAnh1 );
SoPhuc *tinhFFT_anhXam( SoPhuc *anhSoThat, unsigned int beRongAnh, unsigned int beCaoAnh,
                             unsigned int *beRongFFT, unsigned int *beCaoFFT );
SoPhuc *tinhFFT_nghich( SoPhuc *anhSoThat, unsigned int beRongAnh, unsigned int beCaoAnh );
unsigned char *doiSoPhucSangAnhBGRO( SoPhuc *duLieuSoPhuc, unsigned int beRongAnh, unsigned int beCaoAnh );
unsigned char *doiSoPhuc_DoLon_SangAnhBGRO( SoPhuc *duLieuSoPhuc, unsigned int beRongAnh, unsigned int beCaoAnh );

int main( int argc, char **argv ) {
   
   if( argc > 2 ) {
      unsigned int beRongAnh0;
      unsigned int beCaoAnh0;
      unsigned char canLatMauAnh0;

      unsigned char *anh0 = docPNG_BGRO( argv[1], &beRongAnh0, &beCaoAnh0, &canLatMauAnh0 );
      
      unsigned int beRongAnh1;
      unsigned int beCaoAnh1;
      unsigned char canLatMauAnh1;
      
      unsigned char *anh1 = docPNG_BGRO( argv[2], &beRongAnh1, &beCaoAnh1, &canLatMauAnh1 );
      
      if( (beRongAnh0 == beRongAnh1) && (beCaoAnh0 == beCaoAnh1) ) {
         
         SoPhuc *anh0_xam = doiAnhBGRO_sangDoXamSoPhuc( anh0, beRongAnh0, beCaoAnh0 );
         SoPhuc *anh1_xam = doiAnhBGRO_sangDoXamSoPhuc( anh1, beRongAnh1, beCaoAnh1 );
         
         // ---- biến đổi Fourier hai ảnh
         unsigned int beRongAnh0_FFT;
         unsigned int beCaoAnh0_FFT;
         unsigned int beRongAnh1_FFT;
         unsigned int beCaoAnh1_FFT;
         SoPhuc *anh0_xamFFT = tinhFFT_anhXam( anh0_xam, beRongAnh0, beCaoAnh0, &beRongAnh0_FFT, &beCaoAnh0_FFT );
         SoPhuc *anh1_xamFFT = tinhFFT_anhXam( anh1_xam, beRongAnh1, beCaoAnh1, &beRongAnh1_FFT, &beCaoAnh1_FFT );
         

         // ---- nhân hai ảnh sau biến đổi Fourier
         SoPhuc *ketQuaNhanAnh = malloc( beRongAnh0_FFT*beCaoAnh0_FFT * sizeof( SoPhuc ) );
         
         // ---- nhân hai ảnh FFT
         unsigned int diaChiAnh = 0;
         unsigned int soHang = 0;
         while( soHang < beCaoAnh0_FFT ) {
            unsigned int soCot = 0;
            while( soCot < beRongAnh0_FFT ) {
               ketQuaNhanAnh[diaChiAnh].t = anh0_xamFFT[diaChiAnh].t*anh1_xamFFT[diaChiAnh].t - anh0_xamFFT[diaChiAnh].a*anh1_xamFFT[diaChiAnh].a;
               ketQuaNhanAnh[diaChiAnh].a = anh0_xamFFT[diaChiAnh].t*anh1_xamFFT[diaChiAnh].a + anh0_xamFFT[diaChiAnh].a*anh1_xamFFT[diaChiAnh].t;
               diaChiAnh++;
               soCot++;
            }
            soHang++;
         }

         SoPhuc *ketQuaNghichFFT = tinhFFT_nghich( ketQuaNhanAnh, beRongAnh0_FFT, beCaoAnh0_FFT );
 
         unsigned char *anhKetQua = doiSoPhucSangAnhBGRO( ketQuaNghichFFT, beRongAnh0_FFT, beCaoAnh0_FFT );
 
 //        SoPhuc *ketQuaNghichFFT = tinhFFT_nghich( anh0_xamFFT, beRongAnh0_FFT, beCaoAnh0_FFT );  // <---- bỏ sau thử nghiệm
 //        unsigned char *anhKetQua = doiSoPhucSangAnhBGRO( ketQuaNghichFFT, beRongAnh0_FFT, beCaoAnh0_FFT );  // <---- bỏ sau thử nghiệm
         
         char tenAnhketQua[255];
         taoTenAnhKetQua( tenAnhketQua, argv[1], argv[2] );
         printf( "Ten anh: %s\n", tenAnhketQua );
         luuAnhPNG( tenAnhketQua, anhKetQua, beRongAnh0_FFT, beCaoAnh0_FFT );

         //         free( anhBoLoc2 );
         free( anh0_xamFFT );
         free( anh1_xamFFT );
         free( ketQuaNhanAnh );
//         free( ketQuaNghichFFT );
         free( anhKetQua );
      }
      else {
         // ---- phàn nàn không có hình
         printf( "Làm ơn gõ tên hai tệp PNG BGRO khác nào, cỡ kích bằng nhau.\n" );
         printf( "  %s  %d x %d\n  %s  %d x %x\n", argv[1], beRongAnh0, beCaoAnh0, argv[2], beRongAnh1, beCaoAnh1 );
      }
      
      free( anh0 );
      free( anh1 );
   }
   
   return 1;
}


// nhận ảnh số nguyên 8 bit, Rec 709,  phạm vi 0,00 đến 1,00
SoPhuc *doiAnhBGRO_sangDoXamSoPhuc( unsigned char *anhBGRO, unsigned int beRong, unsigned int beCao ) {
   
   SoPhuc *anhDoXam = malloc( beRong * beCao * sizeof( SoPhuc ) );
   unsigned int diaChiTrongAnhSoPhuc = 0;
   unsigned int diaChiTrongAnhBGRO = 0;
   
   unsigned int soHang = 0;
   while( soHang < beCao ) {

      unsigned soCot = 0;
      while( soCot < beRong ) {
         // ---- tính độ xám
         float doXam = anhBGRO[diaChiTrongAnhBGRO]*0.072192f
               + anhBGRO[diaChiTrongAnhBGRO+1]*0.715169f
               + anhBGRO[diaChiTrongAnhBGRO+2]*0.212639f;
         doXam /= 255.0f;
         float doDuc = anhBGRO[diaChiTrongAnhBGRO+3]/255.0f;
         // ---- chỉnh độ xám tùy độ đục: (1,0 - độĐục) + độĐục*độXám
         anhDoXam[diaChiTrongAnhSoPhuc].t = (1.0  - doDuc) + doDuc*doXam;
         anhDoXam[diaChiTrongAnhSoPhuc].a = 0.0f;

         soCot++;
         diaChiTrongAnhSoPhuc++;
         diaChiTrongAnhBGRO += 4;
      }

      soHang++;
   }
   
   return anhDoXam;
}

// tạo tên ảnh kết qủa
void taoTenAnhKetQua( char *tenAnhKetQua, char *tenAnh0, char *tenAnh1 ) {

   // ---- lưu sự khác
   char *dauTen = tenAnhKetQua;
   unsigned char chiSo = 0;
   while( tenAnh0[chiSo] != 0x00 ) {
      *dauTen = tenAnh0[chiSo];
      dauTen++;
      chiSo++;
   }
   // ---- bỏ đuôi
   dauTen -= 4;
   *dauTen = '_';
   dauTen++;
   *dauTen = '_';
   dauTen++;
   chiSo = 0;
   while( tenAnh1[chiSo] != 0x00 ) {
      *dauTen = tenAnh1[chiSo];
      dauTen++;
      chiSo++;
   }
   *dauTen = 0x00;

}

#pragma mark ---- Tính FFT
SoPhuc *tinhFFT_anhXam( SoPhuc *anh, unsigned int beRongAnh, unsigned int beCaoAnh,
                             unsigned int *beRongFFT, unsigned int *beCaoFFT ) {

   // ==== KIỂM TRA VÀ SỬA CỮ KÍCH ====
   // ---- bề rộng
   unsigned char muSoHai_beRong = 0;
   unsigned int ketQua = beRongAnh >> 1;    // chia 2 trước
   
   while( ketQua > 0 ) {
      muSoHai_beRong++;             // cộng lên mũ
      ketQua >>= 1;  // chia 2
   }
   *beRongFFT = 1 << muSoHai_beRong;
   if( beRongAnh != *beRongFFT )
      *beRongFFT <<= 1;
   
   // ---- bề cao
   unsigned char muSoHai_beCao = 0;
   ketQua = beCaoAnh >> 1;    // chia 2 trước
   
   while( ketQua > 0 ) {
      muSoHai_beCao++;             // cộng lên mũ
      ketQua >>= 1;  // chia 2
   }
   
   *beCaoFFT = 1 << muSoHai_beCao;
   if( beCaoAnh != *beCaoFFT )
      *beCaoFFT <<= 1;
   
   printf( "Sửa cỡ kích ảnh: %d %d -> %d %d\n", beRongAnh, beCaoAnh, *beRongFFT, *beCaoFFT );

   SoPhuc *anhFFT = calloc( *beRongFFT* *beCaoFFT, sizeof( SoPhuc) );
   
   // ==== BIẾN ĐỔi CÁC HÀNG
   // ..................
   // ******************
   // ..................
   // ..................
   SoPhuc *hangSoPhuc = calloc( *beRongFFT, sizeof( SoPhuc ) );
   unsigned int soHang = 0;
   unsigned int diaChiTrongAnh = 0;
   while( soHang < beCaoAnh ) {
//      printf( "--- %2d: ", soHang );
      // ---- giữ này để chép dữ liệu biến đổi trong ảnhFFT
      unsigned int diaChiBatDauHang = diaChiTrongAnh;
      // ---- rút hàng
      unsigned int soCot = 0;

      while( soCot < beRongAnh ) {
         hangSoPhuc[soCot].t = anh[diaChiTrongAnh].t;
         hangSoPhuc[soCot].a = anh[diaChiTrongAnh].a;
//         printf( "%5.3f ", hangSoPhuc[soCot].t );
         soCot++;
         diaChiTrongAnh++;
      }
//      printf( "\n" );

      // ---- tính FFT hàng
      SoPhuc *fft_hangAnh = FFT( hangSoPhuc, *beRongFFT );

      // ---- chép hàng vào mảnh Ảnh FFT
      diaChiTrongAnh = diaChiBatDauHang;
      soCot = 0;
      while( soCot < beRongAnh ) {
         anhFFT[diaChiTrongAnh].t = fft_hangAnh[soCot].t;
         anhFFT[diaChiTrongAnh].a = fft_hangAnh[soCot].a;
//         printf( "%5.3f + %5.3fi ", fft_hangAnh[soCot].t, fft_hangAnh[soCot].a );
         diaChiTrongAnh++;
         soCot++;
      }
//      printf( "\n" );
      // ---- hàng tiếp
      soHang++;
   }
   free( hangSoPhuc );

   // ==== BIẾN ĐỔi CÁC CỘT
   // ......*...........
   // ......*...........
   // ......*...........
   // ......*...........
   SoPhuc *cotSoPhuc = calloc( *beCaoFFT, sizeof( SoPhuc ) );

   unsigned int soCot = 0;
   
   // ---- dùng dữ liệu từ ảnh FFT sau biến hóa các hàng
   while( soCot < *beRongFFT ) {
      diaChiTrongAnh = soCot;
      // ---- rút cột
      unsigned int soHang = 0;
      while( soHang < beCaoAnh ) {

         // ---- lần này dùng dữ liệu biến hóa Fourier
         cotSoPhuc[soHang].t = anhFFT[diaChiTrongAnh].t;
         cotSoPhuc[soHang].a = anhFFT[diaChiTrongAnh].a;
         diaChiTrongAnh += *beRongFFT;
         soHang++;
      }
      
      // ---- tính FFT cột
      SoPhuc *fft_cotAnh = FFT( cotSoPhuc, *beCaoFFT );
 
      // ---- chép cột vào mảnh Ảnh FFT
      diaChiTrongAnh = soCot;
      soHang = 0;
      while( soHang < beCaoAnh ) {
         anhFFT[diaChiTrongAnh].t = fft_cotAnh[soHang].t;
         anhFFT[diaChiTrongAnh].a = fft_cotAnh[soHang].a;
         diaChiTrongAnh+= *beRongFFT;
         soHang++;
      }
      
      // --- cột tiếp
      soCot++;
   }
   free( cotSoPhuc );
   
   return anhFFT;
   
}


// không nên cần chỉnh sửa bề rộng hay bề cao tại sau dùng biến đổi Fuurier nên có cỡ kích đúng
SoPhuc *tinhFFT_nghich( SoPhuc *anhFFT, unsigned int beRongAnh, unsigned int beCaoAnh ) {

   SoPhuc *anh = calloc( beRongAnh*beCaoAnh, sizeof( SoPhuc) );
   // ==== BIẾN ĐỔi CÁC CỘT
   // ......*...........
   // ......*...........
   // ......*...........
   // ......*...........
   SoPhuc *cotSoPhuc = calloc( beCaoAnh, sizeof( SoPhuc ) );
   
   unsigned int soCot = 0;
   
   while( soCot < beRongAnh ) {
      unsigned int diaChiTrongAnh = soCot;
      // ---- giữ này để chép dữ liệu biến đổi trong ảnhFFT
//      printf( "---- %d: ", soCot );
      // ---- rút cột
      unsigned int soHang = 0;
      while( soHang < beCaoAnh ) {
         cotSoPhuc[soHang].t = anhFFT[diaChiTrongAnh].t;
         cotSoPhuc[soHang].a = anhFFT[diaChiTrongAnh].a;
         diaChiTrongAnh += beRongAnh;
         soHang++;
      }
//      printf( "\n" );

      // ---- tính FFT cột
      SoPhuc *fft_cotAnh = FFT_nghich( cotSoPhuc, beCaoAnh );
      
      // ---- chép cột vào mảnh Ảnh FFT
      diaChiTrongAnh = soCot;
      soHang = 0;
      while( soHang < beCaoAnh ) {
         anh[diaChiTrongAnh].t = fft_cotAnh[soHang].t;
         anh[diaChiTrongAnh].a = fft_cotAnh[soHang].a;
         diaChiTrongAnh+= beRongAnh;
         soHang++;
      }

      // --- cột tiếp
      soCot++;
   }
   free( cotSoPhuc );

   
   // ==== BIẾN ĐỔi CÁC HÀNG
   // ..................
   // ******************
   // ..................
   // ..................
   SoPhuc *hangSoPhuc = calloc( beRongAnh, sizeof( SoPhuc ) );
   unsigned int soHang = 0;
   unsigned int diaChiTrongAnh = 0;
   while( soHang < beCaoAnh ) {

      // ---- giữ này để chép dữ liệu biến đổi trong ảnhFFT
      unsigned int diaChiBatDauHang = diaChiTrongAnh;
      // ---- rút hàng
      unsigned int soCot = 0;
      
      while( soCot < beRongAnh ) {
         hangSoPhuc[soCot].t = anh[diaChiTrongAnh].t;
         hangSoPhuc[soCot].a = anh[diaChiTrongAnh].a;

         soCot++;
         diaChiTrongAnh++;
      }

      // ---- tính FFT hàng
      SoPhuc *fft_hangAnh = FFT_nghich( hangSoPhuc, beRongAnh );
      
      // ---- chép hàng vào mảnh Ảnh FFT
      diaChiTrongAnh = diaChiBatDauHang;
      soCot = 0;
      while( soCot < beRongAnh ) {
         anh[diaChiTrongAnh].t = fft_hangAnh[soCot].t;
         anh[diaChiTrongAnh].a = fft_hangAnh[soCot].a;

         diaChiTrongAnh++;
         soCot++;
      }

      // ---- hàng tiếp
      soHang++;
   }
   free( hangSoPhuc );


   
   return anh;
   
}


// ---- LƯU Ý: Nó xuất ảnh độ xám
unsigned char *doiSoPhucSangAnhBGRO( SoPhuc *duLieuSoPhuc, unsigned int beRongAnh, unsigned int beCaoAnh ) {
   
   unsigned int chiSoCuoi = beRongAnh * beCaoAnh << 2;
   unsigned char *anhBGRO = malloc( chiSoCuoi );
   
   if( anhBGRO ) {
      unsigned int diaChiTrongAnh_soPhuc = 0;
      unsigned int diaChiTrongAnhBGRO = 0;
      
      while( diaChiTrongAnhBGRO < chiSoCuoi) {
         // ---- rút giá trị số thực
         float giaTriSoThat = duLieuSoPhuc[diaChiTrongAnh_soPhuc].t;
         
         // ---- nhân 255 vvà chép cùnh giá trị để tạo ảnh độ xám
         anhBGRO[diaChiTrongAnhBGRO] = giaTriSoThat*255.0f;
         anhBGRO[diaChiTrongAnhBGRO+1] = giaTriSoThat*255.0f;
         anhBGRO[diaChiTrongAnhBGRO+2] = giaTriSoThat*255.0f;
         anhBGRO[diaChiTrongAnhBGRO+3] = 0xff;
         
         // ---- điểm ảnh tiếp
         diaChiTrongAnhBGRO += 4;
         diaChiTrongAnh_soPhuc++;
      }
   }
   else {
      printf( "doiSoPhucSangAnhBGRO: Vấn đề dành trí nhớ cho ảnhBGRO\n" );
   }
   
   return anhBGRO;
}

// ---- LƯU Ý: Nó xuất ảnh độ xám
unsigned char *doiSoPhuc_DoLon_SangAnhBGRO( SoPhuc *duLieuSoPhuc, unsigned int beRongAnh, unsigned int beCaoAnh ) {
   
   unsigned int chiSoCuoiSoPhuc = beRongAnh * beCaoAnh;
   unsigned int chiSoCuoiBGRO = chiSoCuoiSoPhuc << 2;

   unsigned char *anhBGRO = malloc( chiSoCuoiBGRO );
   float *anhSoThat = malloc( chiSoCuoiSoPhuc * sizeof( float ) );

   if( anhBGRO && anhSoThat ) {
      unsigned int diaChiTrongAnh_soPhuc = 0;
      unsigned int diaChiTrongAnhBGRO = 0;
      float doLon = 0.0f;

      while( diaChiTrongAnh_soPhuc < chiSoCuoiSoPhuc) {
         // ---- rút giá trị số thực
         float giaTriDoLon = sqrtf( duLieuSoPhuc[diaChiTrongAnh_soPhuc].t * duLieuSoPhuc[diaChiTrongAnh_soPhuc].t + duLieuSoPhuc[diaChiTrongAnh_soPhuc].a * duLieuSoPhuc[diaChiTrongAnh_soPhuc].a );
         
         giaTriDoLon = logf( 1.0f + giaTriDoLon );
         anhSoThat[diaChiTrongAnh_soPhuc] = giaTriDoLon;
         
         if( giaTriDoLon > doLon )
            doLon = giaTriDoLon;
            
         // ---- điểm ảnh tiếp
         diaChiTrongAnh_soPhuc++;
      }
      
      // ---- đơn vị hóa LƯU Ý nên làm khi tính giá trị 8 bit
      diaChiTrongAnhBGRO = 0;
      diaChiTrongAnh_soPhuc = 0;
//      printf( "DoLon %5.3f\n", doLon );
      
      while( diaChiTrongAnhBGRO < chiSoCuoiBGRO) {
         float giaTri = anhSoThat[diaChiTrongAnh_soPhuc]*255.0f/doLon;
         anhBGRO[diaChiTrongAnhBGRO] = giaTri;
         anhBGRO[diaChiTrongAnhBGRO+1] = giaTri;
         anhBGRO[diaChiTrongAnhBGRO+2] = giaTri;
         anhBGRO[diaChiTrongAnhBGRO+3] = 0xff;

         // ---- điểm ảnh tiếp
         diaChiTrongAnhBGRO += 4;
        diaChiTrongAnh_soPhuc++;
      }

   }
   else {
      printf( "doiSoPhucSangAnhBGRO: Vấn đề dành trí nhớ cho ảnhBGRO\n" );
   }
   
   return anhBGRO;
}
