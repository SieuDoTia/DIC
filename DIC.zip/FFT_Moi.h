#pragma once


/* Số Phức */
typedef struct {
   float t;   // phần số thật
   float a;   // phần số ảo
} SoPhuc;


#define kPI 3.141592654
#define kHAI_PI 6.283185307

SoPhuc *FFT( SoPhuc *tinHieu, unsigned int soLuongMauVat );
SoPhuc *FFT_nghich( SoPhuc *tinHieu, unsigned int soLuongMauVat );
