/* PNG.h 
 *
 * 2010.11.22
 *
 */


#pragma once


/* đọc tệp PNG BGRO */
unsigned char *docPNG_BGRO( char *duongTapTin, unsigned int *beRong, unsigned int *beCao, unsigned char *canLatMau );


/* Lưu ảnh PNG BGRO */
void luuAnhPNG( char *tenTep, unsigned char *suKhacBiet, unsigned int beRong, unsigned int beCao );

