/* BộLọcTringBình.c */

#include <stdio.h>
#include <stdlib.h>

#pragma mark ---- Bộ Lọc Trung Bình
// Nếu dùng bộ lọc phần tử số chẳng,  * * * * o * * *  <---- thiếu một phân tử bên phải
unsigned char *boLocTrungBinh( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned short beRongBoLoc ) {

   // ---- không cho bộ lọc qúa to
   if( (beRongBoLoc > beRong) || (beRongBoLoc> beCao) ) {
      if( beRong > beCao )
         beRongBoLoc = beRong;
      else
         beRongBoLoc = beCao;
   }

   // ---- bề rộng bộ lọc phải lẻ
   if( (beRongBoLoc & 0x01) == 0 )
      beRongBoLoc++;

//   printf( "beRongBoLoc %d\n", beRongBoLoc );
   
   // ---- mẫu số để "đơn vị hóa" giá trị từ bộ lọc (0 đến 255)
   unsigned char *anhBoLoc = malloc( beRong*beCao << 2 );
   unsigned char *anhBoLoc1 = malloc( beRong*beCao << 2 );
   
   // ---- xóa ảnh bộ lọc
/*   unsigned int chiSo = 0;
   unsigned int chiSoCuoi = beRong*beCao << 2;
   while( chiSo < chiSoCuoi ) {
      anhBoLoc[chiSo] = 0xff;
      anhBoLoc1[chiSo] = 0xff;
      chiSo++;
   } */
   
   if( anhBoLoc && anhBoLoc1 ) {
      
      unsigned short phanNuaBoLoc = beRongBoLoc >> 1;

      // ================ bộ lọc hượng ngang
      unsigned int soHang = 0;
      unsigned int soHangCuoi = beCao;
      
      // ---- địa chỉ đầu hảng trong ảnh
      int diaChiAnh = 0;
      
      while( soHang < soHangCuoi ) {
         // ==== dùng điểm ảnh đầu cho phần bộ lọc ở ngoài ảnh
         //         +---------------------  ảnh
         //           ^
         //           |
         //      +----+----+  bộ lọc
         unsigned char giaTriAnhCanhTrai = anh[diaChiAnh];
         unsigned int soCot = 0;
         while( soCot < phanNuaBoLoc ) {
            unsigned short soLuongDiemAnhNgoai = (phanNuaBoLoc - soCot);
            unsigned int giaTriLocXanh = soLuongDiemAnhNgoai*giaTriAnhCanhTrai;
            unsigned int giaTriLocLuc = soLuongDiemAnhNgoai*giaTriAnhCanhTrai;
            unsigned int giaTriLocDo = soLuongDiemAnhNgoai*giaTriAnhCanhTrai;
            
            // ---- chỉ số trong bộ lọc (phạm vi trong 0 tới beRongBoLoc)
            short chiSoCotBoLoc = phanNuaBoLoc - soCot;
            
            // ---- địa chỉ trong ảnh để bắt đầu bộ lọc
            int diaChiDeBoLoc = diaChiAnh - (soCot << 2);
            
 //           printf( "N soHang  %d/%d  soCot %d giaTriAnhCanhTrai %d  soLuongDiemAnhNgoai %d  diaChiAnh %d\n", soHang, soHangCuoi, soCot, giaTriAnhCanhTrai, soLuongDiemAnhNgoai, diaChiAnh  );
            while( chiSoCotBoLoc < beRongBoLoc ) {

               giaTriLocDo += anh[diaChiDeBoLoc];
               giaTriLocLuc += anh[diaChiDeBoLoc+1];
               giaTriLocXanh += anh[diaChiDeBoLoc+2];
               chiSoCotBoLoc++;
               diaChiDeBoLoc += 4;
            }
            
            anhBoLoc[diaChiAnh] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc[diaChiAnh+2] = giaTriLocDo/beRongBoLoc;
            anhBoLoc[diaChiAnh+3] = 0xff;
            
            diaChiAnh += 4;
            soCot++;
         }

         // ==== trong ảnh có đủ điểm ảnh
         unsigned short soCotCuoi = beRong - phanNuaBoLoc;
         soCot = phanNuaBoLoc;
         // ---- áp dụng bộ lọc
         diaChiAnh = (beRong*soHang + soCot) << 2;
         
         while( soCot < soCotCuoi ) {

 //           printf( " ngang: giua: soCot %d phanNuaBoLoc %d  beCao %d\n", soCot, phanNuaBoLoc, beCao );
            unsigned int giaTriLocXanh = 0;
            unsigned int giaTriLocLuc = 0;
            unsigned int giaTriLocDo = 0;
            
            // ---- chỉ số trong bộ lọc
            short chiSoCotBoLoc = 0;
            // ---- cột tương đối với điểm ảnh
            short cotTuongDoi = -phanNuaBoLoc;
            // ---- tính địa chỉ đổ bộ lọc trong ảnh
            int diaChiDeBoLoc = diaChiAnh + (cotTuongDoi << 2);
            
            while( chiSoCotBoLoc < beRongBoLoc ) {
               giaTriLocDo += anh[diaChiDeBoLoc];
               giaTriLocLuc += anh[diaChiDeBoLoc+1];
               giaTriLocXanh += anh[diaChiDeBoLoc+2];
               chiSoCotBoLoc++;
               diaChiDeBoLoc += 4;
            }
//            if( diaChiCuoi < diaChiDeBoLoc ) {
//               printf( " soCot %d soHang %d  phanNuaBoLoc %d  beCao %d diaChiDeBoLoc %d  diaChiAnh %d diaChiCuoi %d\n", soCot, soHang, phanNuaBoLoc, beCao, diaChiDeBoLoc, diaChiAnh, diaChiCuoi );
//               exit(9);
//            }
            //           printf( "%d  diaChiAnh %d\n",  soCot, diaChiAnh  );
            anhBoLoc[diaChiAnh] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc[diaChiAnh+2] = giaTriLocDo/beRongBoLoc;
            anhBoLoc[diaChiAnh+3] = 0xff;
            
            // ---- điểm ảnh tiếp
            soCot++;
            diaChiAnh += 4;
         };
         
         // ==== dùng điểm ảnh đầu cho phân` bộ lọc ở ngoài ảnh
         //  ------------+  ảnh
         //           ^
         //           |
         //      +----+----+  bộ lọc
         unsigned char giaTriAnhCanhPhai = anh[((soHang+1)*beRong - 1) << 2];
         while( soCot < beRong ) {
//            printf( " DC_anh %d\n", diaChiAnh );

//            printf( " ngang: cuoi: soCot %d/%d  soHang %d/%d  diaChiCuoi %d\n", soCot, beRong, soHang, beCao, diaChiCuoi );
            unsigned short soLuongDiemAnhNgoai = phanNuaBoLoc - (beRong - soCot - 1);
            unsigned int giaTriLocXanh = soLuongDiemAnhNgoai*giaTriAnhCanhPhai;
            unsigned int giaTriLocLuc = soLuongDiemAnhNgoai*giaTriAnhCanhPhai;
            unsigned int giaTriLocDo = soLuongDiemAnhNgoai*giaTriAnhCanhPhai;
            
            // ---- chỉ số trong bộ lọc (phạm vi trong 0 tới beRongBoLoc)
            short chiSoCotBoLoc = 0;
            
            // ---- cột tương đối với điểm ảnh
            short cotTuongDoi = -phanNuaBoLoc;
            int diaChiDeBoLoc = diaChiAnh + (cotTuongDoi << 2);
            
            while( chiSoCotBoLoc < beRongBoLoc - soLuongDiemAnhNgoai ) {
//               printf( " DC_boLoc %d\n", diaChiDeBoLoc );
               giaTriLocDo += anh[diaChiDeBoLoc];
               giaTriLocLuc += anh[diaChiDeBoLoc+1];
               giaTriLocXanh += anh[diaChiDeBoLoc+2];
  //                         printf( "   chiSoCotBoLoc %d diaChiDeBoLoc %d  anh[diaChiDeBoLoc] %d\n", chiSoCotBoLoc, diaChiDeBoLoc, anh[diaChiDeBoLoc] );
               chiSoCotBoLoc++;
               diaChiDeBoLoc += 4;
            }
            
            anhBoLoc[diaChiAnh] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc[diaChiAnh+2] = giaTriLocDo/beRongBoLoc;
            anhBoLoc[diaChiAnh+3] = 0xff;
            diaChiAnh += 4;
            soCot++;
            
         }
         
         soHang++;
      }

      // ================ bộ lọc hướng dọc
      int cachMotHang = beRong << 2;   // số lượng byte giữa các hàng, cùng cột
      
      diaChiAnh = 0;
      soHang = 0;

      while( soHang < phanNuaBoLoc ) {
 //        printf( " doc dau: soHang %d/%d\n", soHang, beCao );

         unsigned short soCot = 0;
         int diaChiAnh = beRong*soHang << 2;
         while( soCot < beRong ) {

            unsigned char giaTriAnhCanhDuoi = anhBoLoc[soCot << 2];
            unsigned short soLuongDiemAnhNgoai = (phanNuaBoLoc - soHang);
            unsigned int giaTriLocXanh = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            unsigned int giaTriLocLuc = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            unsigned int giaTriLocDo = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
//            printf( "D soHang  %d/%d  soCot %d giaTriAnhCanhDuoi %d  soLuongDiemAnhNgoai %d  diaChiAnh %d\n", soHang, soHangCuoi, soCot, giaTriAnhCanhDuoi, soLuongDiemAnhNgoai, diaChiAnh  );
            // ---- chỉ số trong bộ lọc (phạm vi trong 0 tới beRongBoLoc)
            short chiSoHangBoLoc = 0;
            
            // ---- địa chỉ trong ảnh để bắt đầu bộ lọc
            int diaChiDeBoLoc = soCot << 2;
            
            while( chiSoHangBoLoc < beRongBoLoc - soLuongDiemAnhNgoai ) {

               giaTriLocDo += anhBoLoc[diaChiDeBoLoc];
               giaTriLocLuc += anhBoLoc[diaChiDeBoLoc+1];
               giaTriLocXanh += anhBoLoc[diaChiDeBoLoc+2];
               //               printf( "   chiSoHangBoLoc %d diaChiDeBoLoc %d\n", chiSoHangBoLoc, diaChiDeBoLoc );
               chiSoHangBoLoc++;
               diaChiDeBoLoc += cachMotHang;
            }
            
            anhBoLoc1[diaChiAnh] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc1[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc1[diaChiAnh+2] = giaTriLocDo/beRongBoLoc;
            anhBoLoc1[diaChiAnh+3] = 0xff;
            
            soCot++;
            diaChiAnh += 4;
         }
         
         soHang++;
      }

      soHangCuoi = beCao - phanNuaBoLoc;

      while( soHang < soHangCuoi ) {
  //      printf( " doc giua: soHang %d/%d\n", soHang, beCao );
         
         unsigned short soCot = 0;
         int diaChiAnh = (beRong*soHang + soCot) << 2;
         
         while( soCot < beRong ) {
//            printf( " DC_anh %d\n", diaChiAnh );
            // ---- áp dụng bộ lọc
            unsigned int giaTriLocXanh = 0;
            unsigned int giaTriLocLuc = 0;
            unsigned int giaTriLocDo = 0;
            
            // ---- chỉ số trong bộ lọc
            short chiSoHangBoLoc = 0;
            // ---- cột tương đối với điểm ảnh
            short hangTuongDoi = -phanNuaBoLoc;
            // ---- tính địa chỉ đổ bộ lọc trong ảnh
            int diaChiDeBoLoc = diaChiAnh + (hangTuongDoi*beRong << 2);
            
            while( chiSoHangBoLoc < beRongBoLoc ) {
//               printf( " DC_boLoc %d\n", diaChiDeBoLoc );
               giaTriLocDo += anhBoLoc[diaChiDeBoLoc];
               giaTriLocLuc += anhBoLoc[diaChiDeBoLoc+1];
               giaTriLocXanh += anhBoLoc[diaChiDeBoLoc+2];
               chiSoHangBoLoc++;
               diaChiDeBoLoc += cachMotHang;
            }
            
            anhBoLoc1[diaChiAnh] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc1[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc1[diaChiAnh+2] = giaTriLocDo/beRongBoLoc;
            anhBoLoc1[diaChiAnh+3] = 0xff;
            
            // ---- điểm ảnh tiếp
            soCot++;
            diaChiAnh += 4;
         };
         soHang++;
      }

      unsigned int diaChiHangCuoi = ((beCao - 1)*beRong << 2);
      while( soHang < beCao ) {

         unsigned short soCot = 0;
         int diaChiAnh = beRong*soHang << 2;
         while( soCot < beRong ) {

//         printf( " doc cuoi: soCot %d/%d soHang %d/%d  diaChiCuoi %d\n", soCot, beRong, soHang, beCao, diaChiCuoi );
            unsigned char giaTriAnhCanhDuoi = anhBoLoc[diaChiHangCuoi + (soCot << 2)];
            unsigned short soLuongDiemAnhNgoai = phanNuaBoLoc - (beCao - soHang - 1);
            unsigned int giaTriLocXanh = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            unsigned int giaTriLocLuc = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            unsigned int giaTriLocDo = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            // ---- chỉ số trong bộ lọc (phạm vi trong 0 tới beRongBoLoc)
            short chiSoHangBoLoc = 0;
            
            // ---- địa chỉ trong ảnh để bắt đầu bộ lọc
            short hangTuongDoi = -phanNuaBoLoc;
            int diaChiDeBoLoc = diaChiAnh + (hangTuongDoi*beRong << 2);
            
            while( chiSoHangBoLoc < beRongBoLoc - soLuongDiemAnhNgoai ) {

               giaTriLocDo += anhBoLoc[diaChiDeBoLoc];
               giaTriLocLuc += anhBoLoc[diaChiDeBoLoc+1];
               giaTriLocXanh += anhBoLoc[diaChiDeBoLoc+2];
//                                        printf( "   chiSoHangBoLoc %d diaChiDeBoLoc %d  anh[diaChiDeBoLoc] %d\n", chiSoHangBoLoc, diaChiDeBoLoc, anh[diaChiDeBoLoc] );

               chiSoHangBoLoc++;
               diaChiDeBoLoc += cachMotHang;
            }
            
            anhBoLoc1[diaChiAnh] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc1[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc1[diaChiAnh+2] = giaTriLocDo/beRongBoLoc;
            anhBoLoc1[diaChiAnh+3] = 0xff;
            
            soCot++;
            diaChiAnh += 4;
         }
         
         soHang++;
      }
      
      free( anhBoLoc );
   }
   else {
      printf( "Sự khác: boLocTrungBinh: Vấn đệ tạo đệm cho sự khác biệt\n" );
   }

   return anhBoLoc1;
}

unsigned char *boLocTrungBinhDoc( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned short beRongBoLoc ) {

   // ---- không cho bộ lọc qúa to
   if( (beRongBoLoc > beRong) || (beRongBoLoc> beCao) ) {
      if( beRong > beCao )
         beRongBoLoc = beRong;
      else
         beRongBoLoc = beCao;
   }
   
   // ---- bề rộng bộ lọc phải chẳng
   if( (beRongBoLoc & 0x01) == 0 )
      beRongBoLoc++;

   // ---- mẫu số để "đơn vị hóa" giá trị từ bộ lọc (0 đến 255)
   unsigned char *anhBoLoc = malloc( beRong*beCao << 2 );
   unsigned short phanNuaBoLoc = beRongBoLoc >> 1;
   
   unsigned int chiSo = 0;
   unsigned int chiSoCuoi = beRong*beCao << 2;
   while( chiSo < chiSoCuoi ) {
      anhBoLoc[chiSo] = 0xff;
      chiSo++;
   }
   
   if( anhBoLoc ) {
      
      int cachMotHang = beRong << 2;   // số lượng byte giữa các hàng, cùng cột
      unsigned int diaChiAnh = 0;
      unsigned int soHang = 0;
      
      while( soHang < phanNuaBoLoc ) {
         
         unsigned short soCot = 0;
         int diaChiAnh = beRong*soHang << 2;
         while( soCot < beRong ) {
            unsigned char giaTriAnhCanhDuoi = anh[soCot << 2];
            unsigned short soLuongDiemAnhNgoai = (phanNuaBoLoc - soHang);
            unsigned int giaTriLocDo = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            unsigned int giaTriLocLuc = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            unsigned int giaTriLocXanh = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            
            // ---- chỉ số trong bộ lọc (phạm vi trong 0 tới beRongBoLoc)
            short chiSoHangBoLoc = 0;
            
            // ---- địa chỉ trong ảnh để bắt đầu bộ lọc
            int diaChiDeBoLoc = soCot << 2;
            
            while( chiSoHangBoLoc < beRongBoLoc - soLuongDiemAnhNgoai ) {
               giaTriLocDo += anh[diaChiDeBoLoc];
               giaTriLocLuc += anh[diaChiDeBoLoc+1];
               giaTriLocXanh += anh[diaChiDeBoLoc+2];
               //               if( soCot == 0 )
               //              printf( "%d  anh[diaChiDeBoLoc] %d   diaChiDeBoLoc %d   giaTriLocDo %d\n", chiSoHangBoLoc, anh[diaChiDeBoLoc], diaChiDeBoLoc, giaTriLocDo );
               
               chiSoHangBoLoc++;
               diaChiDeBoLoc += cachMotHang;
            }
            
            anhBoLoc[diaChiAnh] = giaTriLocDo/beRongBoLoc;
            anhBoLoc[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc[diaChiAnh+2] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc[diaChiAnh+3] = 0xff;
            
            soCot++;
            diaChiAnh += 4;
         }
         soHang++;
      }
      
      // ==== bộ lọc hượng dọc
      unsigned int soHangCuoi = beCao - phanNuaBoLoc;
      
      while( soHang < soHangCuoi ) {
         
         unsigned short soCot = 0;
         int diaChiAnh = (beRong*soHang + soCot) << 2;
         
         while( soCot < beRong ) {
            
            // ---- áp dụng bộ lọc
            unsigned int giaTriLocDo = 0;
            unsigned int giaTriLocLuc = 0;
            unsigned int giaTriLocXanh = 0;
            
            // ---- chỉ quét một dòng
            short chiSoHangBoLoc = 0;
            short hangTuongDoi = -phanNuaBoLoc;
            // ---- tính địa chỉ đổ bộ lọc trong ảnh
            int diaChiDeBoLoc = diaChiAnh + (hangTuongDoi*beRong << 2);
            
            while( chiSoHangBoLoc < beRongBoLoc ) {
               giaTriLocDo += anh[diaChiDeBoLoc];
               giaTriLocLuc += anh[diaChiDeBoLoc+1];
               giaTriLocXanh += anh[diaChiDeBoLoc+2];
               chiSoHangBoLoc++;
               diaChiDeBoLoc += cachMotHang;
            }
            
            anhBoLoc[diaChiAnh] = giaTriLocDo/beRongBoLoc;
            anhBoLoc[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc[diaChiAnh+2] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc[diaChiAnh+3] = 0xff;
            // ---- điểm ảnh tiếp
            soCot++;
            diaChiAnh += 4;
         };
         soHang++;
      }
      
      unsigned int diaChiHangCuoi = ((beCao - 1)*beRong << 2);
      while( soHang < beCao ) {
         
         unsigned short soCot = 0;
         int diaChiAnh = beRong*soHang << 2;
         while( soCot < beRong ) {
            unsigned char giaTriAnhCanhDuoi = anh[diaChiHangCuoi + (soCot << 2)];
            unsigned short soLuongDiemAnhNgoai = phanNuaBoLoc - (beCao - soHang - 1);
            unsigned int giaTriLocDo = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            unsigned int giaTriLocLuc = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            unsigned int giaTriLocXanh = soLuongDiemAnhNgoai*giaTriAnhCanhDuoi;
            // ---- chỉ số trong bộ lọc (phạm vi trong 0 tới beRongBoLoc)
            short chiSoHangBoLoc = 0;
            
            // ---- địa chỉ trong ảnh để bắt đầu bộ lọc
            short hangTuongDoi = -phanNuaBoLoc;
            int diaChiDeBoLoc = diaChiAnh + (hangTuongDoi*beRong << 2);
            
            while( chiSoHangBoLoc < beRongBoLoc - soLuongDiemAnhNgoai ) {
               giaTriLocDo += anh[diaChiDeBoLoc];
               giaTriLocLuc += anh[diaChiDeBoLoc+1];
               giaTriLocXanh += anh[diaChiDeBoLoc+2];
               
               chiSoHangBoLoc++;
               diaChiDeBoLoc += cachMotHang;
            }
            
            anhBoLoc[diaChiAnh] = giaTriLocDo/beRongBoLoc;
            anhBoLoc[diaChiAnh+1] = giaTriLocLuc/beRongBoLoc;
            anhBoLoc[diaChiAnh+2] = giaTriLocXanh/beRongBoLoc;
            anhBoLoc[diaChiAnh+3] = 0xff;
            
            soCot++;
            diaChiAnh += 4;
         }
         
         soHang++;
      }
      
      
   }
   else {
      printf( "Sự khác: boLocTrungBinh: Vấn đệ tạo đệm cho sự khác biệt\n" );
   }

   return anhBoLoc;
}
