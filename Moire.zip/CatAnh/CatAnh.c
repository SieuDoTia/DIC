/* CắtẢnh.c */

#pragma mark ---- Tìm Mặt Na
// Tìm khu vực sáng trong ảnh
// Dùng mặtNạBit để biết phần nào sáng
// Dùng sốLượngBiếnĐổiChếĐộ để hàng cgất trường số lượng cột sáng liên tiếp rất ít (số lượng biến đổi nên ≤ 2)

//    toàn bộ sáng                 một bên sáng (trái)        một bên sáng (phải)                sáng giữa
// +-----------------+ 0x1 (0)   +----------+------+ 0x1 (1)   +-----+-----------+ 0x2 (1)   +-----------------+ 0x0 (2)
// |                 | 0x1 (0)   |   sáng   |      | 0x1 (1)   |     |   sáng    | 0x2 (1)   |  +----------+   | 0x2 (2)
// |    sáng         | 0x1 (0)   |          |      | 0x1 (1)   |     |           | 0x2 (1)   |  |   sáng   |   | 0x2 (2)
// |                 | 0x1 (0)   +----------+      | 0x1 (1)   |     +-----------+ 0x2 (1)   |  |          |   | 0x2 (2)
// |                 | 0x1 (0)   |       tối       | 0x0 (0)   |       tối       | 0x0 (0)   |  +----------+   | 0x2 (2)
// |                 | 0x1 (0)   |                 | 0x0 (0)   |                 | 0x0 (0)   |      tối        | 0x0 (0)
// +-----------------+ 0x1 (0)   +-----------------+ 0x0 (0)   +-----------------+ 0x0 (0)   +-----------------+ 0x0 (0)

// mặt nạ 0x1 hay 0x2

// Vài trường hợp sai lầm
// +-----------------+ 0x0 (0)   +-----+-----+-----+ 0x5 (2)   +-----+---+-----+-+ 0x5 (3)   +-+----+----+-----+ 0x6 (3)
// |                 | 0x0 (0)   |sáng |     |sáng | 0x5 (2)   |sáng |   |sáng | | 0x5 (3)   | |sáng|    |sáng | 0x6 (3)
// |     tối         | 0x0 (0)   |     |     |     | 0x5 (2)   |     |   |     | | 0x5 (3)   | |    |    |     | 0x6 (3)
// |                 | 0x0 (0)   +-----+     +-----+ 0x5 (2)   +-----+   +-----+ | 0x5 (3)   + -----+    +-----+ 0x6 (3)
// |                 | 0x0 (0)   |      tối        | 0x0 (0)   |      tối        | 0x0 (0)   |      tối        | 0x0 (0)
// |                 | 0x0 (0)   |                 | 0x0 (0)   |                 | 0x0 (0)   |                 | 0x0 (0)
// +-----------------+ 0x0 (0)   +-----------------+ 0x0 (0)   +-----------------+ 0x0 (0)   +-----------------+ 0x0 (0)

// ranh khu vực sáng có thể nghiên  /   \ nữa

#include <stdio.h>
#include <stdlib.h>
#include "../ChuNhat.h"
#include "../HangSo.h"


#define kCHE_DO__TOI  0
#define kCHE_DO__SANG 1

ChuNhat timKhungAnhSang( unsigned char *anhMatNa, unsigned int beRong, unsigned int beCao, unsigned char gioiHanDoSang ) {
   
   // ---- quét dòng và tìm hàng các hàng có giá trị hơn giới hạn
   unsigned int soHang = 0;
 //  int batDauMatNa = -1;
 //  int ketThucMatNa = -1;
   
   // ---- đếm số lượng hàng sáng
   unsigned int soLuongHangSangLienTiep = 0;
   unsigned int soHangBatDauSangLienTiep = 0;

   // ---- cho giữ vị tri doàn sáng lớn nhất
   unsigned int soHangDoanSangLonNhat = 0;
   unsigned int soLuongSangLonNhat = 0;
   
   unsigned int benTraiLonNhat_doanHienTai = 0;
   unsigned int benPhaiNhoNhat_doanHienTai = beRong;
   
   unsigned int benTraiLonNhat_doanLonNhat = 0;
   unsigned int benPhaiNhoNhat_doanLonNhat = beRong;
   
   // ---- mảng biến đổi - chỉ cần hai biến đổi đầu, nếu có biến đổi nhiều hơn sẽ không nhận hàng đó
   unsigned int mangSoCotBienDoiCheDo[2];
   
   unsigned char cheDo = kCHE_DO__TOI;
   
   while( soHang < beCao ) {
//      printf( "soHang %d\n", soHang );
      unsigned char matNaBit = 0x00;
      unsigned char soLuongBienDoiCheDo = 0;

      unsigned int soLuongDiemAnh = 0;   // số lượng điểm ảnh tối hay sáng
      unsigned int diaChiCot = soHang*beRong << 2;
      unsigned int soCot = 0;
      unsigned char hetHonGioiHan = kDUNG;  // BOOL, hết hơn giới hạn
      while( soCot < beRong ) {
         //        printf( "%d doSang %d\n", soCot, soHang );
         if( anhMatNa[diaChiCot] >= gioiHanDoSang ) {
            if( cheDo == kCHE_DO__TOI ) {
//               printf( "   soCotHetToi %d (TOI) soLuongDiemAnhTruoc %d\n", soCot, soLuongDiemAnh );
               cheDo = kCHE_DO__SANG;
               soLuongDiemAnh = 0;
               
               // ---- chỉ giữ hai biến đổi chế độ đầu tiên
               if( soLuongBienDoiCheDo < 2 )
                  mangSoCotBienDoiCheDo[soLuongBienDoiCheDo] = soCot;

               // ---- chỉ lảm nếu không ở cột 0
               if( soCot ) {
                  soLuongBienDoiCheDo++;
               }
            }
            else
               soLuongDiemAnh++;

         }
         else {
            if( cheDo == kCHE_DO__SANG ) {
//               printf( "   soCotHetSang %d (SANG) soLuongDiemAnhTruoc %d\n", soCot, soLuongDiemAnh );
               cheDo = kCHE_DO__TOI;
               soLuongDiemAnh = 0;
               
               // ---- chỉ giữ hai biến đổi chế độ đầu tiên
               if( soLuongBienDoiCheDo < 2 )
                  mangSoCotBienDoiCheDo[soLuongBienDoiCheDo] = soCot;

               // ---- chỉ lảm nếu không ở cột 0
               if( soCot ) {
                  matNaBit |= kCHE_DO__SANG << soLuongBienDoiCheDo;  // không làm cho chế độ tối
                  soLuongBienDoiCheDo++;
               }
            }
            else
               soLuongDiemAnh++;
   
         }
         soCot++;
         diaChiCot += 4;
      }
      
      // ---- hết hàng, đật lại số lượng điểm ảnh nhưng đừng đổi chế độ
      if( cheDo == kCHE_DO__TOI ) {
    //     printf( "   soCotHetToi %d (TOI) soLuongTruoc %d\n", soCot-1, soLuongDiemAnh );
         soLuongDiemAnh = 0;
      }
      else {
   //      printf( "   soCotHetSang %d (SANG) soLuongTruoc %d\n", soCot-1, soLuongDiemAnh );
         soLuongDiemAnh = 0;
         matNaBit |= kCHE_DO__SANG << soLuongBienDoiCheDo;
      }
      
      // ----
      if( (matNaBit == 0x1) || (matNaBit == 0x02) ) {   // tối -> sáng  hay toàn hàng sáng
         soLuongHangSangLienTiep++;
         
         // ---- phân tích số lượng điểm ảnh tối bên trái và phải của hàng này
         // 0                                            bề rộng
         // +------------+--------------------------+------------+
         // |              |                           |         |
         // |   tối      |          sáng           |      tối    |
         // |           |                             |          |    <----- hàng hiện tại
         //                          ...
         //             ^                             ^
         //             |                             |
         //         bên trái lớn                bên phải nhỏ
      
         unsigned int benTraiLon = 0;    // số cột lớn nhất đến điểm ảnh sáng (hơn giới hạn)
         unsigned int benPhaiNho = beRong;  // số cột nhỏ nhất sau đến điểm ảnh tối (ít giới hạn)
            
         if( matNaBit == 0x01 ) {
            // ---- đặt lại cho đoán mới
            // benTraiToi = 0;
            if( soLuongBienDoiCheDo )
               benPhaiNho = mangSoCotBienDoiCheDo[0];
        //    else
        //       benPhaiNhoNhat = 0;
         }
         else {  // ( matNaBit = 0x02 ) {
            benTraiLon = mangSoCotBienDoiCheDo[0];
            
            if( soLuongBienDoiCheDo == 2 )
               benPhaiNho = mangSoCotBienDoiCheDo[1];
  //          else
  //             benPhaiNhoNhat = 0;
         }
   
   //      printf( "   benTraiLon %d  benPhaiNho %d\n", benTraiLon, benPhaiNho );
 
         
         // ---- tìm được đoàn mới
         if( soLuongHangSangLienTiep == 1 ) {
//            printf( "****** batDoanMoi: soCotBienDoi %d\n", mangSoCotBienDoiCheDo[0] );
            soHangBatDauSangLienTiep = soHang;
            benTraiLonNhat_doanHienTai = benTraiLon;
            benPhaiNhoNhat_doanHienTai = benPhaiNho;
         }
         else {
            if( benTraiLonNhat_doanHienTai < benTraiLon )
               benTraiLonNhat_doanHienTai = benTraiLon;
            if( benPhaiNhoNhat_doanHienTai > benPhaiNho )
               benPhaiNhoNhat_doanHienTai = benPhaiNho;
         }
         
         // ---- xem nếu đoàn sáng này lớn hơn đoán trước
         if( soLuongHangSangLienTiep > soLuongSangLonNhat ) {
//            printf( "soCotBienDoi %d %d\n", mangSoCotBienDoiCheDo[0], mangSoCotBienDoiCheDo[1] );
            soHangDoanSangLonNhat = soHangBatDauSangLienTiep;
            soLuongSangLonNhat = soLuongHangSangLienTiep;
            
            // ---- giử kỷ lục của đoán sáng lớn nhất
            benTraiLonNhat_doanLonNhat = benTraiLonNhat_doanHienTai;
            benPhaiNhoNhat_doanLonNhat = benPhaiNhoNhat_doanHienTai;
         }
         

//         printf( " ------------ batDau %d  soLan %d soLuongSangLonNhat %d traiLonNhatDoanHT %d  phaiNhoNhatDoanHT %d  ", soHangBatDauSangLienTiep, soLuongHangSangLienTiep,
//                soLuongSangLonNhat, benTraiLonNhat_doanLonNhat, benPhaiNhoNhat_doanLonNhat );
      }
      else {
         soLuongHangSangLienTiep = 0;
         benTraiLonNhat_doanHienTai = 0;
         benPhaiNhoNhat_doanHienTai = beRong;
      }

      soHang++;
   }

   if( soHangDoanSangLonNhat < 100 ) {
      printf( "TimNaMat: không thể tìm khu vực sáng rộng hơn 100 hàng mà sáng hơn %d độ sáng\n", gioiHanDoSang );
      exit(0);
   }


   ChuNhat khungAnhSang;
   khungAnhSang.trai = benTraiLonNhat_doanLonNhat;
   khungAnhSang.phai = benPhaiNhoNhat_doanLonNhat;
   khungAnhSang.duoi = soHangDoanSangLonNhat;
   khungAnhSang.tren = soHangDoanSangLonNhat + soLuongSangLonNhat - 1;
//   printf( "TimKhungAngSang: khung anh %d %d  %d %d\n", khungAnhSang.trai, khungAnhSang.phai, khungAnhSang.duoi, khungAnhSang.tren );
   return khungAnhSang;
}

unsigned char *catAnh( unsigned char *anhGoc, unsigned int beRongGoc, unsigned int beCaoGoc, ChuNhat *matNa ) {
   
   unsigned int beRongCat = matNa->phai - matNa->trai;
   unsigned int beCaoCat = matNa->tren - matNa->duoi;
   unsigned char *anhCat = malloc(beRongCat*beCaoCat << 2);
   
   if( anhCat ) {
      unsigned int soHangGoc = matNa->duoi;
      unsigned int diaChiAnhCat = 0;
      while( soHangGoc < matNa->tren ) {

         unsigned int soCotGoc = matNa->trai;
         unsigned int diaChiAnhGoc = (soHangGoc*beRongGoc + soCotGoc) << 2;

         while( soCotGoc < matNa->phai ) {
            anhCat[diaChiAnhCat] = anhGoc[diaChiAnhGoc];
            anhCat[diaChiAnhCat+1] = anhGoc[diaChiAnhGoc+1];
            anhCat[diaChiAnhCat+2] = anhGoc[diaChiAnhGoc+2];
            anhCat[diaChiAnhCat+3] = anhGoc[diaChiAnhGoc+3];
            diaChiAnhGoc += 4;
            diaChiAnhCat += 4;
            soCotGoc++;
         }
         soHangGoc++;
      }
   }
   else {
      printf( "catAnh: vấn đề dành trí nhớ cho ảnh cắt\n" );
      return NULL;
   }
   
   return anhCat;
}
