/* CắtẢnh.h */

#pragma once
#include "../ChuNhat.h"

ChuNhat timKhungAnhSang( unsigned char *anhMatNa, unsigned int beRong, unsigned int beCao, unsigned char gioiHanDoSang );
unsigned char *catAnh( unsigned char *anhGoc, unsigned int beRongGoc, unsigned int beCaoGoc, ChuNhat *matNa );
