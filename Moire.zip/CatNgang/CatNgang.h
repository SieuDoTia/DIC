/* CắtNgang.h */


#pragma once

unsigned char *veAnhDoSanhVaCatNgang( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhCatNgang, unsigned int *beCaoAnhCatNgang );

void luuCatNgangMotTamChoAnh( char *tenAnhCatNgang, unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHangCatNgang );
unsigned char *toMauDoSangAnh( unsigned char *anh, unsigned int beRong, unsigned int beCao );
