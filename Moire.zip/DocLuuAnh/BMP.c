/* BMP.c */

#include <stdio.h>
#include <stdlib.h>
#include "BMP.h"
#include "../HangSo.h"

#pragma mark ==== Tệp BMP
// ---- thứ dữ liệu màu trong tập tin
//#define kMAU_XAM        0x00  // màu xám
//#define kBANG_MAU_XAM  0x01  // có bảng màu xám
#define kRGB            0x02  // màu đỏ, lục, xanh
//#define kBANG_MAU       0x03  // có bảng màu đỏ, lục, xanh
//#define kMAU_XAM_DUC    0x04  // màu xám, đục
//#define kBANG_MAU_XAM_DUC 0x05  // có bảng màu xám đục
#define kRGBO           0x06  // màu đỏ, lục, xanh, đục <------- chỉ xài cái này
//#define kBANG_MAU_DUC     0x07  // có bảng màu đỏ, lục, xanh, đục



#define kCO_THUOC_TOI_DA_IDAT  8192   // cờ thước tối đa khi chẻ thành phần IDAT
#define kKHO_ANH_TOI_DA 8192   // khổ điểm ảnh lớn tối đa



/*
// ==== LƯU BMP
void luuAnhBMP_BGRO( char *tenTep, unsigned char *duLieuAnh, unsigned int beRong, unsigned int beCao ) {
 
 CHƯA CẦN
} */


// ==== ĐỌC BMP
unsigned char *docTapTinBMP( FILE *dongTapTin, unsigned int *beRong, unsigned int *beCao, unsigned char *bitChoDiemAnh, unsigned int *doDaiDuLieuDaDoc );
void docDauTapTinBMP_tuDuLieu( FILE *dongDuLieu, unsigned int *beRong, unsigned int *beCao, unsigned char *bitChoDiemAnh, unsigned int *dichDenDuLieuAnh );


#pragma mark ---- Đọc tập tin PNG BGRO (32 bit)
unsigned char *docBMP_BGRO( char *duongTapTin, unsigned int *beRong, unsigned int *beCao, unsigned char *canLatMau) {
   
   if( duongTapTin ) {

      FILE *dongTapTin = fopen( duongTapTin, "rb" );
      
      if( dongTapTin != NULL ) {
         // ---- dấu hiệu (hai byte)
         unsigned short dauHieu = fgetc(dongTapTin) << 8 | fgetc(dongTapTin);
         if( dauHieu == 0x424d ) {
            
            // ---- bè dài tập tin
            unsigned char bitChoDiemAnh;    // số lượng bit cho một điểm ảnh
            unsigned int dichDenDuLieuAnh;  // dịch đến dữ liệu ảnh
            
            docDauTapTinBMP_tuDuLieu( dongTapTin, beRong, beCao, &bitChoDiemAnh, &dichDenDuLieuAnh );
            
            if( bitChoDiemAnh != 24 ) {
               printf( "DocBMP: Chỉ hỗ trợ ảnh BMP 24 bit\n" );
               exit(0);
            }
            
            // ==== đóc dữ liệu ảnh
            // ---- nhảy đến dữ liệu ảnh
            fseek( dongTapTin, dichDenDuLieuAnh, SEEK_SET );
            
            printf( "DocBMP: beRong %d  beCao %d  bit %d  dịch đến dữ liệu ảnh %d\n", *beRong, *beCao, bitChoDiemAnh, dichDenDuLieuAnh );
            // ---- dữ liệu BMP không nén nhưng néu một hàng không chẵn 4 byte, nó có 1, 2, 3 byte dư (nên bỏ nó)
            unsigned char soLuongByteDu = *beRong % 4;
            
            // ---- thứ tự RGB
            unsigned char *duLieuAnh = malloc( *beRong * *beCao << 2);
            if( duLieuAnh ) {
               unsigned int diaChiAnh = 0;
               unsigned int soHang = 0;

               while( soHang < *beCao ) {
                  unsigned int soCot = 0;
                  while( soCot < *beRong ) {
                     duLieuAnh[diaChiAnh] = fgetc( dongTapTin );
                     duLieuAnh[diaChiAnh+1] = fgetc( dongTapTin );
                     duLieuAnh[diaChiAnh+2] = fgetc( dongTapTin );
                     duLieuAnh[diaChiAnh+3] = 0xff;
                     
                     diaChiAnh += 4;
                     soCot++;
                  }
                  
                  unsigned char soByte = 0;
                  while( soByte < soLuongByteDu ) {
                     fgetc( dongTapTin );
                     soByte++;
                  }
                  
                  soHang++;
               }
               
               return duLieuAnh;
            }
            else {
               printf( "DocBMP_BGRO: Không thể giành trí nhớ để đọc tập tin: %s\n", duongTapTin );
               exit(0);
            }
         }
         else {
            printf( "DocBMP_BGRO: Không thể mở tệp %s, dẫu hiểu sai: %04x (nên == 0x424d)\n", duongTapTin, dauHieu );
            exit(0);
         }
      }
      else {
         printf( "DocBMP_BGRO: Không thể mở tệp %s\n", duongTapTin );
         exit(0);
      }
   }
   return NULL;
}

#pragma mark ---- Đọc Đầu Tập Tin
void docDauTapTinBMP_tuDuLieu( FILE *dongDuLieu, unsigned int *beRong, unsigned int *beCao, unsigned char *bitChoDiemAnh, unsigned int *dichDenDuLieuAnh ) {
   
   // ----  toàn bộ tệp gổm đầu và ký hiệu
   unsigned int beDaiTep = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
 
   // ---- bỏ qua 4 byte
   fgetc( dongDuLieu );
   fgetc( dongDuLieu );
   fgetc( dongDuLieu );
   fgetc( dongDuLieu );
   
   // ---- dịch đến dữ liệu ảnh
   *dichDenDuLieuAnh = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   
   // ---- bề dài đầu tập tin
   unsigned int beDaiDau = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   
   // ----
   *beRong = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   *beCao = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

   // ---- nên == 1
   unsigned short matPhangMau = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8;
   
   *bitChoDiemAnh = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8;
   
   // ---- phương pháp nén
   unsigned int phuongPhapNen = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   
   // ---- kích thước ảnh (byte)
   unsigned int kichThuocAnh = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   
   // ---- phân giải ngang (điểm ản/mét)
   unsigned int phanGiaiNgang = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

   // ---- phân giải dộc (điểm ản/mét)
   unsigned int phanGiaiDoc = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

   // ---- số lượng màu tron bảng màu (nếu == 0, nghĩa là 2^n, n là bit cho một điểm ảnh)
   unsigned int soLuongMauTrongBangMau = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

   // ---- số lượng màu quan trọn - không xài
   unsigned int soLuongMauQuanTron = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

}


