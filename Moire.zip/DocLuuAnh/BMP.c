/* BMP.c */

#include <stdio.h>
#include <stdlib.h>
#include "BMP.h"
#include "../HangSo.h"

#pragma mark ==== Tệp BMP
// ---- thứ dữ liệu màu trong tập tin
//#define kMAU_XAM        0x00  // màu xám
//#define kBANG_MAU_XAM  0x01  // có bảng màu xám
#define kRGB            0x02  // màu đỏ, lục, xanh
//#define kBANG_MAU       0x03  // có bảng màu đỏ, lục, xanh
//#define kMAU_XAM_DUC    0x04  // màu xám, đục
//#define kBANG_MAU_XAM_DUC 0x05  // có bảng màu xám đục
#define kRGBO           0x06  // màu đỏ, lục, xanh, đục <------- chỉ xài cái này
//#define kBANG_MAU_DUC     0x07  // có bảng màu đỏ, lục, xanh, đục



#define kCO_THUOC_TOI_DA_IDAT  8192   // cờ thước tối đa khi chẻ thành phần IDAT
#define kKHO_ANH_TOI_DA 8192   // khổ điểm ảnh lớn tối đa



/*
// ==== LƯU BMP
void luuAnhBMP_BGRO( char *tenTep, unsigned char *duLieuAnh, unsigned int beRong, unsigned int beCao ) {
   // ---- lọc các hàng ảnh
   unsigned int beDaiDuLieuAnhLoc;
   unsigned char *duLieuAnhLoc = locDuLieuAnh_32bit( duLieuAnh, beRong, beCao, &beDaiDuLieuAnhLoc );
   
   if( duLieuAnhLoc ) {
      // ---- dùng zlib để nén dữ liệu
      int err;
      z_stream c_stream; // cấu trúc cho nén dữ liệu
      
      c_stream.zalloc = (alloc_func)0;
      c_stream.zfree = (free_func)0;
      c_stream.opaque = (voidpf)0;
      
      // ---- xem nếu chuẩn bị có sai lầm nào
      err = deflateInit(&c_stream, kZLIB_MUC_NEN);
      
      if( err != Z_OK ) {
         printf( "LuuTapTinPNG: WritePNG: SAI LẦM deflateInit %d (%x) c_stream.avail_in %d\n", err, err, c_stream.avail_out );
      }
      
      // ---- cho dữ liệu cần nén
      c_stream.next_in = duLieuAnhLoc;
      c_stream.avail_in = beDaiDuLieuAnhLoc;
      
      // ---- dự đoán trí nhớ cần cho nén dữ liệu
      unsigned int idat_chunkDataLength = (unsigned int)deflateBound(&c_stream, beDaiDuLieuAnhLoc );
      // 8 bytes for idat length, mã thành phần (tên). Cần mã thành phần cho tính crc
      unsigned char *idat_chunkData = malloc( idat_chunkDataLength + 4);
      
      // ---- đệm cho chứa dữ liệu nén
      c_stream.next_out  = &(idat_chunkData[4]);
      c_stream.avail_out = idat_chunkDataLength;
      
      err = deflate(&c_stream, Z_FINISH);
      
      if( err != Z_STREAM_END ) {
         printf( "LuuTapTinPNG: luuPNG: SAI LẦM deflate %d (%x) c_stream.avail_out %d c_stream.total_out %ld c_stream.avail_in %d\n",
                err, err, c_stream.avail_out, c_stream.total_out, c_stream.avail_in );
      }
      
      // ---- không cần dữ liệu lọc nữa
      free( duLieuAnhLoc );
      
      // ==== LƯU
      FILE *dongTapTin = fopen( tenTep, "wb" );
      
      if( dongTapTin != NULL ) {
         // ---- ký hiệu tấp tin PNG
         fputc( 0x89, dongTapTin );
         fputc( 0x50, dongTapTin );
         fputc( 0x4e, dongTapTin );
         fputc( 0x47, dongTapTin );
         fputc( 0x0d, dongTapTin );
         fputc( 0x0a, dongTapTin );
         fputc( 0x1a, dongTapTin );
         fputc( 0x0a, dongTapTin );
         
         // ---- kèm thành phần IHDR
         kemThanhPhanIHDRChoDong( dongTapTin, beRong, beCao, kRGBO, 8 );
         
         // ----
         unsigned int beDaiDuLieuAnhNen = c_stream.total_out;
         unsigned int diaChiDuLieuAnhNen = 0;
         while( diaChiDuLieuAnhNen < beDaiDuLieuAnhNen ) {
            unsigned int beDaiDuLieuThanhPhan = beDaiDuLieuAnhNen - diaChiDuLieuAnhNen;
            if( beDaiDuLieuThanhPhan > kCO_THUOC_TOI_DA_IDAT )
               beDaiDuLieuThanhPhan = kCO_THUOC_TOI_DA_IDAT;
            
            //            printf( "beDaiDuLieuThanhPhan %d   diaChiDuLieuAnhNen %d\n", beDaiDuLieuThanhPhan, diaChiDuLieuAnhNen );
            kemThanhPhanIDATChoDong( dongTapTin, &(idat_chunkData[diaChiDuLieuAnhNen]), beDaiDuLieuThanhPhan );
            diaChiDuLieuAnhNen += kCO_THUOC_TOI_DA_IDAT;
         }
         
         
         // ---- kèm thời gian
         kemThanhPhanTIMEChoDong( dongTapTin, 2017, 03, 14, 10, 26, 0);
         
         // ---- kèm kết thúc
         kemThanhPhanIENDChoDong( dongTapTin);
         
         fclose( dongTapTin );
      }
      else {
         printf( "DocPNG: luuAnhPNG: Vấn đề tạo tệp %s\n", tenTep );
      }
      // ---- không cần dữ liệu nén nữa
      free( idat_chunkData );
      
      // ---- bỏ c_stream
      deflateEnd( &c_stream );
   }
   
} */


// ==== ĐỌC BMP
unsigned char *docTapTinBMP( FILE *dongTapTin, unsigned int *beRong, unsigned int *beCao, unsigned char *bitChoDiemAnh, unsigned int *doDaiDuLieuDaDoc );
void docDauTapTinBMP_tuDuLieu( FILE *dongDuLieu, unsigned int *beRong, unsigned int *beCao, unsigned char *bitChoDiemAnh, unsigned int *dichDenDuLieuAnh );


#pragma mark ---- Đọc tập tin PNG BGRO (32 bit)
unsigned char *docBMP_BGRO( char *duongTapTin, unsigned int *beRong, unsigned int *beCao, unsigned char *canLatMau) {
   
   if( duongTapTin ) {

      FILE *dongTapTin = fopen( duongTapTin, "rb" );
      
      if( dongTapTin != NULL ) {
         // ---- dấu hiệu (hai byte)
         unsigned short dauHieu = fgetc(dongTapTin) << 8 | fgetc(dongTapTin);
         if( dauHieu == 0x424d ) {
            
            // ---- bè dài tập tin
            unsigned char bitChoDiemAnh;    // số lượng bit cho một điểm ảnh
            unsigned int dichDenDuLieuAnh;  // dịch đến dữ liệu ảnh
            
            docDauTapTinBMP_tuDuLieu( dongTapTin, beRong, beCao, &bitChoDiemAnh, &dichDenDuLieuAnh );
            
            if( bitChoDiemAnh != 24 ) {
               printf( "DocBMP: Chỉ hỗ trợ ảnh BMP 24 bit\n" );
               exit(0);
            }
            
            // ==== đóc dữ liệu ảnh
            // ---- nhảy đến dữ liệu ảnh
            fseek( dongTapTin, dichDenDuLieuAnh, SEEK_SET );
            
            printf( "DocBMP: beRong %d  beCao %d  bit %d  dichDenAnh %d\n", *beRong, *beCao, bitChoDiemAnh, dichDenDuLieuAnh );
            // ---- dữ liệu BMP không nén nhưng néu một hàng không chẵn 4 byte, nó có 1, 2, 3 byte dư (nên bỏ nó)
            unsigned char soLuongByteDu = *beRong % 4;
            
            // ---- thứ tự RGB
            unsigned char *duLieuAnh = malloc( *beRong * *beCao << 2);
            if( duLieuAnh ) {
               unsigned int diaChiAnh = 0;
               unsigned int soHang = 0;

               while( soHang < *beCao ) {
                  unsigned int soCot = 0;
                  while( soCot < *beRong ) {
                     duLieuAnh[diaChiAnh] = fgetc( dongTapTin );
                     duLieuAnh[diaChiAnh+1] = fgetc( dongTapTin );
                     duLieuAnh[diaChiAnh+2] = fgetc( dongTapTin );
                     duLieuAnh[diaChiAnh+3] = 0xff;
                     
                     diaChiAnh += 4;
                     soCot++;
                  }
                  
                  unsigned char soByte = 0;
                  while( soByte < soLuongByteDu ) {
                     fgetc( dongTapTin );
                     soByte++;
                  }
                  
                  soHang++;
               }
               
               return duLieuAnh;
            }
            else {
               printf( "DocBMP_BGRO: Không thể giành trí nhớ để đọc tập tin: %s\n", duongTapTin );
               exit(0);
            }
         }
         else {
            printf( "DocBMP_BGRO: Không thể mở tệp %s, dẫu hiểu sai: %04x (nên == 0x424d)\n", duongTapTin, dauHieu );
            exit(0);
         }
      }
      else {
         printf( "DocBMP_BGRO: Không thể mở tệp %s\n", duongTapTin );
         exit(0);
      }
   }
   return NULL;
}

#pragma mark ---- Đọc Đầu Tập Tin
void docDauTapTinBMP_tuDuLieu( FILE *dongDuLieu, unsigned int *beRong, unsigned int *beCao, unsigned char *bitChoDiemAnh, unsigned int *dichDenDuLieuAnh ) {
   
   // ----  toàn bộ tệp gổm đầu và ký hiệu
   unsigned int beDaiTep = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   printf( "beDaiTep %d\n", beDaiTep );
   // ---- bỏ qua 4 byte
   fgetc( dongDuLieu );
   fgetc( dongDuLieu );
   fgetc( dongDuLieu );
   fgetc( dongDuLieu );
   
   // ---- dịch đến dữ liệu ảnh
   *dichDenDuLieuAnh = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   
   // ---- bề dài đầu tập tin
   unsigned int beDaiDau = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   
   // ----
   *beRong = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   *beCao = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

   // ---- nên == 1
   unsigned short matPhangMau = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8;
   
   *bitChoDiemAnh = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8;
   
   // ---- phương pháp nén
   unsigned int phuongPhapNen = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   
   // ---- kích thước ảnh (byte)
   unsigned int kichThuocAnh = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;
   
   // ---- phân giải ngang (điểm ản/mét)
   unsigned int phanGiaiNgang = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

   // ---- phân giải dộc (điểm ản/mét)
   unsigned int phanGiaiDoc = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

   // ---- số lượng màu tron bảng màu (nếu == 0, nghĩa là 2^n, n là bit cho một điểm ảnh)
   unsigned int soLuongMauTrongBangMau = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

   // ---- số lượng màu quan trọn - không xài
   unsigned int soLuongMauQuanTron = fgetc( dongDuLieu ) | fgetc( dongDuLieu ) << 8 | fgetc( dongDuLieu ) << 16 | fgetc( dongDuLieu ) << 24;

}


