/* BMP.h */

#pragma once

/* đọc tệp BMP BGRO */
unsigned char *docBMP_BGRO( char *duongTapTin, unsigned int *beRong, unsigned int *beCao, unsigned char *canLatMau );

/* Lưu ảnh BMP */
//void luuAnhPNG_BMP( char *tenTep, unsigned char *suKhacBiet, unsigned int beRong, unsigned int beCao );

