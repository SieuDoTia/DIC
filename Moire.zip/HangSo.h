/* HằngSố.h */

#pragma once

#define kXAU_PHIEN_BAN "0.9"

#define kSAI  0
#define kDUNG 1

#define kLOAI_THAP 0
#define kLOAI_CAO 1

#define kVO_CUC 1.0e9f 

/* Lề cho ảnh xuất */
#define kLE_TRAI__ANH_TO 200  // điểm ảnh
#define kLE_PHAI__ANH_TO 100  // điểm ảnh
#define kLE_DUOI__ANH_TO 100  // điểm ảnh
#define kLE_TREN__ANH_TO 100  // điểm ảnh
