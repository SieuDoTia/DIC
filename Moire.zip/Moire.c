/* Moire.c */

#include <stdio.h>
#include <stdlib.h>

#include "SuKhacBiet/SuKhacBiet.h"
#include "BoLoc/BoLocTrungBinh.h"
#include "CatAnh/CatAnh.h"
#include "NghiengCuu/CatNgang.h"
#include "NghiengCuu/TuongQuan.h"
#include "ToMauAnh/ToMauAnh.h"
#include "PNG/PNG.h"
#include "HangSo.h"

/* ghép tên ảnh */
void ghepTenAnh( char *tenAnh, char *tenGhep0, char *tenGhep1 );

int main( int argc, char **argv ) {

   if( argc > 2 ) {
      unsigned int beRongTep0;
      unsigned int beCaoTep0;
      unsigned char canLatMauTep0;
      
      unsigned char *duLieuTep0 = docPNG_BGRO( argv[1], &beRongTep0, &beCaoTep0, &canLatMauTep0 );
      if( duLieuTep0 == NULL ) {
         printf( "Vận đề mở tệp %s. Có lẻ gõ tên không đúng hay loạt ảnh không đúng\n", argv[1] );
         exit(0);
      }

      
      unsigned int beRongTep1;
      unsigned int beCaoTep1;
      unsigned char canLatMauTep1;
      
      unsigned char *duLieuTep1 = docPNG_BGRO( argv[2], &beRongTep1, &beCaoTep1, &canLatMauTep1 );
      if( duLieuTep0 == NULL ) {
         printf( "Vận đề mở tệp %s. Có lẻ gõ tên không đúng hay loạt ảnh không đúng\n", argv[2] );
         exit(0);
      }


      if( (beRongTep0 == beRongTep1) && (beCaoTep0 == beCaoTep1) ) {
         // ---- ghép tên ảnh
         char tenAnhToMau[254];
         printf( "1.0\n" );
         ghepTenAnh( tenAnhToMau, argv[1], argv[2] );

         // ---- tính sự khác giữa hai ảnh
         printf( "2.0  Đang tính sự khác\n" );
         unsigned char *anhSuKhacBiet = tinhSuKhacBietXam( duLieuTep0, duLieuTep1, beRongTep0, beCaoTep0, kDUNG );

         // ---- tìm mặt nạ: bộ l ̣c trung bình trước, sau tìm chổ trong ảnh ≥ giới hạn
         printf( "3.0  Đang tìm mặt nạ ảnh\n" );
         unsigned char *anhMatNa0 = boLocTrungBinh( duLieuTep0, beRongTep0, beCaoTep0, 21 );
         printf( "3.5\n" );
         unsigned char *anhMatNa1 = boLocTrungBinh( duLieuTep1, beRongTep1, beCaoTep1, 21 );
         unsigned char gioiHanDoSang = 100;
          printf( "4.0\n" );
         ChuNhat matNa0 = timKhungAnhSang( anhMatNa0, beRongTep0, beCaoTep0, gioiHanDoSang );  // <---- dùng nữa bộ lọc để mịn hoá ảng sự khạc biệt
         printf( "4.5\n" );
         ChuNhat matNa1 = timKhungAnhSang( anhMatNa1, beRongTep1, beCaoTep1, gioiHanDoSang );
         // ---- ảnh hơi mờ ở cạnh dưới và trên từ bộ lọc, cắt bớt một chút
         matNa0.tren -= 10;
         matNa0.duoi += 10;
         matNa1.tren -= 10;
         matNa1.duoi += 10;

         printf( "5.0  Mặt nạ ảnh %s: t %d p %d d %d t %d\n", argv[1], matNa0.trai, matNa0.phai, matNa0.duoi, matNa0.tren );
         printf( "     Mặt nạ ảnh %s: t %d p %d d %d t %d\n", argv[2], matNa1.trai, matNa1.phai, matNa1.duoi, matNa1.tren );

         // ---- giao hai mặt nạ
         ChuNhat matNaGiao;
         if( matNa0.trai < matNa1.trai )
            matNaGiao.trai = matNa1.trai;
         else
            matNaGiao.trai = matNa0.trai;
         // ----
         if( matNa0.phai < matNa1.phai )
            matNaGiao.phai = matNa0.phai;
         else
            matNaGiao.phai = matNa1.phai;
         // ----
         if( matNa0.duoi < matNa1.duoi )
            matNaGiao.duoi = matNa1.duoi;
         else
            matNaGiao.duoi = matNa0.duoi;
         
         if( matNa0.tren < matNa1.tren )
            matNaGiao.tren = matNa0.tren;
         else
            matNaGiao.tren = matNa1.tren;

         printf( "     Mặt nạ giao hai ảnh: t %d p %d d %d t %d\n", matNaGiao.trai, matNaGiao.phai, matNaGiao.duoi, matNaGiao.tren );

         // ==== CẮT ẢNH
         printf( "     CatAnh\n" );
         unsigned char *anhCat = catAnh( anhSuKhacBiet, beRongTep0, beCaoTep0, &matNaGiao );
         printf( "6.0  CatAnh \n" );
         unsigned short beRongAnhCat = matNaGiao.phai - matNaGiao.trai;
         unsigned short beCaoAnhCat = matNaGiao.tren - matNaGiao.duoi;
         printf( "     %d x %d\n", beRongAnhCat, beCaoAnhCat );
  
         // ==== BỘ LỌC ẢNH
         printf( "     Đang bộ lọc ảnh cắt: trungBinh\n" );
         unsigned char *anhBoLocTrungBinh = boLocTrungBinh( anhCat, beRongAnhCat, beCaoAnhCat, 75 );
         printf( "7.0  Đang bộ lọc ảnh cắt: trungBinhDoc\n" );
         unsigned char *anhBoLocTrungBinhDoc = boLocTrungBinhDoc( anhBoLocTrungBinh, beRongAnhCat, beCaoAnhCat, 70  );
         printf( "7.5\n" );
         char tenAnhBoLoc[256];
         sprintf( tenAnhBoLoc, "%s_%s", "AnhBoLoc\x00", tenAnhToMau );
         luuAnhPNG_BGRO( tenAnhBoLoc, anhBoLocTrungBinhDoc, beRongAnhCat, beCaoAnhCat );
         
         // ==== NGHIÊNG CỨU
         //         tinhPhanPhoiAnh( anhBoLocTrungBinhDoc, beRongAnhCat, beCaoAnhCat );
         unsigned int beRongAnhCatNgang = 0;
         unsigned int beCaoAnhCatNgang = 0;
         unsigned char *anhCatNgang = veAnhDoSang( anhBoLocTrungBinhDoc, beRongAnhCat, beCaoAnhCat, &beRongAnhCatNgang, &beCaoAnhCatNgang );
         
         printf( "8.0\n" );
         if( anhCatNgang ) {
            char tenAnhCatNgang[256];
            sprintf( tenAnhCatNgang, "%s_%s", "AnhCatNgang\x00", tenAnhToMau );
            luuAnhPNG_BGRO( tenAnhCatNgang, anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang );
            free( anhCatNgang );
         }
         
         
         unsigned int beRongAnhTuongQuan = 0;
         unsigned int beCaoAnhTuongQuan = 0;
         unsigned char *anhTuongQuan = veAnhTuongQuan( anhBoLocTrungBinhDoc, beRongAnhCat, beCaoAnhCat, &beRongAnhTuongQuan, &beCaoAnhTuongQuan );
         
         if( anhTuongQuan ) {
            char tenAnhTuongQuan[256];
            sprintf( tenAnhTuongQuan, "%s_%s", "AnhTuongQuan\x00", tenAnhToMau );
            luuAnhPNG_BGRO( tenAnhTuongQuan, anhTuongQuan, beRongAnhTuongQuan, beCaoAnhTuongQuan );
         }
      
         // ==== TÔ MÀU ẢNH
         printf( "9.0  Tô màu ảnh cắt\n" );
         unsigned int beRongAnhTo;
         unsigned int beCaoAnhTo;
         unsigned char *anhToMau = toMauAnh( anhBoLocTrungBinhDoc, beRongAnhCat, beCaoAnhCat, &beRongAnhTo, &beCaoAnhTo );
         if( anhToMau != NULL ) {
            luuAnhPNG_BGRO( tenAnhToMau, anhToMau, beRongAnhTo, beCaoAnhTo );
            free( anhToMau );
         }
         printf( "10.0\n" );
         free( anhSuKhacBiet );
         free( anhBoLocTrungBinh );
         free( anhBoLocTrungBinhDoc );
      }
      
      free( duLieuTep0 );
      free( duLieuTep1 );
   }
   else {
      // ---- phàn nàn không có hình
      printf( "Làm ơn gõ tên hai tệp PNG BGRO khác nào, cỡ kích bằng nhau.\n" );
   }
   return 1;
}


void ghepTenAnh( char *tenAnh, char *tenGhep0, char *tenGhep1 ) {
   
   
   char *dauTen = tenAnh;
   unsigned char chiSo = 0;
   while( tenGhep0[chiSo] != 0x00 ) {
      *dauTen = tenGhep0[chiSo];
      dauTen++;
      chiSo++;
   }
   // ---- bỏ đuôi
   dauTen -= 4;
   *dauTen = '_';
   dauTen++;
   *dauTen = '_';
   dauTen++;
   chiSo = 0;
   while( tenGhep1[chiSo] != 0x00 ) {
      *dauTen = tenGhep1[chiSo];
      dauTen++;
      chiSo++;
   }
   *dauTen = 0x00;
   
}
