/* Moire.c */

#include <stdio.h>
#include <stdlib.h>

#include "SuKhacBiet/SuKhacBiet.h"
#include "BoLoc/BoLocTrungBinh.h"
#include "CatAnh/CatAnh.h"
#include "NghiengCuu/CatNgang.h"
#include "NghiengCuu/TuongQuan.h"
#include "ToMauAnh/ToMauAnh.h"
#include "DocLuuAnh/BMP.h"
#include "DocLuuAnh/PNG.h"
#include "HangSo.h"


#define kLOAI_ANH__KHONG_BIET 0
#define kLOAI_ANH__PNG 1
#define kLOAI_ANH__BMP 2

/* xem đuôi tệp */
unsigned char xemDuoiTep( char *tenAnh );

/* ghép tên ảnh */
void ghepTenAnh( char *tenAnh, char *tenGhep0, char *tenGhep1 );

int main( int argc, char **argv ) {

   unsigned char *anhBoLocTrungBinhDoc = NULL;
   unsigned int beRongAnhBoLoc = 0;
   unsigned int beCaoAnhBoLoc = 0;
   char tenGhep[256];
   
   // ---- chiếu phiên bản
   printf( "Moire %s\n", kXAU_PHIEN_BAN );
   
   // ---- có ảnh bộ lọc sẵn,
   if( argc == 2 ) {
      unsigned char canLatMauTep;
      // ---- xem đuôi tệp
      unsigned char loaiAnh = xemDuoiTep( argv[1] );

      if( loaiAnh == kLOAI_ANH__PNG )
         anhBoLocTrungBinhDoc = docPNG_BGRO( argv[1], &beRongAnhBoLoc, &beCaoAnhBoLoc, &canLatMauTep );
      else if( loaiAnh == kLOAI_ANH__BMP )
         anhBoLocTrungBinhDoc = docBMP_BGRO( argv[1], &beRongAnhBoLoc, &beCaoAnhBoLoc, &canLatMauTep );
      
 /*     unsigned int diaChiAnh = 0;
      unsigned char so = 0;
      while( diaChiAnh < beRongAnhBoLoc*beCaoAnhBoLoc << 2 ) {
         printf( "%d,", anhBoLocTrungBinhDoc[diaChiAnh] );
         so++;
         if( so == 48 ) {
            so = 0;
            printf( "\n" );
         }
            
         diaChiAnh++;
      }
      exit(9); */
         
      if( anhBoLocTrungBinhDoc == NULL ) {
         printf( "Moire: Vận đề mở tệp %s. Có lẻ gõ tên không đúng hay loạt ảnh không đúng\n", argv[1] );
         exit(0);
      }
      // ---- ghép tên ảnh
      ghepTenAnh( tenGhep, argv[1], "BL.png" );
   }
   // ---- có hai ảnh và phài trừ, cắt và bộ lọc nó trước có ảnh để phân tích
   else if( argc > 2 ) {
      
      // ==== ẢNH 0
      unsigned int beRongTep0;
      unsigned int beCaoTep0;
      unsigned char canLatMauTep0;
      
      // ---- xem đuôi tệp
      unsigned char loaiAnh = xemDuoiTep( argv[1] );
      
      unsigned char *duLieuTep0 = NULL;
      
      if( loaiAnh == kLOAI_ANH__PNG )
         duLieuTep0 = docPNG_BGRO( argv[1], &beRongTep0, &beCaoTep0, &canLatMauTep0 );
      else if( loaiAnh == kLOAI_ANH__BMP )
         duLieuTep0 = docBMP_BGRO( argv[1], &beRongTep0, &beCaoTep0, &canLatMauTep0 );
      
      if( duLieuTep0 == NULL ) {
         printf( "Moire: Vận đề mở tệp %s. Có lẻ gõ tên không đúng hay loại ảnh không đúng\n", argv[1] );
         exit(0);
      }

      // ==== ẢNH 1
      unsigned int beRongTep1;
      unsigned int beCaoTep1;
      unsigned char canLatMauTep1;
      
      // ---- xem đuôi tệp
      loaiAnh = xemDuoiTep( argv[2] );
      
      unsigned char *duLieuTep1 = NULL;
      
      if( loaiAnh == kLOAI_ANH__PNG )
         duLieuTep1 = docPNG_BGRO( argv[2], &beRongTep1, &beCaoTep1, &canLatMauTep1 );
      else if( loaiAnh == kLOAI_ANH__BMP )
         duLieuTep1 = docBMP_BGRO( argv[2], &beRongTep1, &beCaoTep1, &canLatMauTep1 );
   
      if( duLieuTep1 == NULL ) {
         printf( "Moire: Vận đề mở tệp %s. Có lẻ gõ tên không đúng hay loạt ảnh không đúng\n", argv[2] );
         exit(0);
      }

      if( (beRongTep0 == beRongTep1) && (beCaoTep0 == beCaoTep1) ) {
         // ---- ghép tên ảnh
         ghepTenAnh( tenGhep, argv[1], argv[2] );

         // ---- tính sự khác giữa hai ảnh

         unsigned char *anhSuKhacBiet = tinhSuKhacBietXam( duLieuTep0, duLieuTep1, beRongTep0, beCaoTep0, kDUNG );

         // ---- tìm mặt nạ: bộ l ̣c trung bình trước, sau tìm chổ trong ảnh ≥ giới hạn
         printf( "3.0  Đang tìm mặt nạ ảnh\n" );
         unsigned char *anhMatNa0 = boLocTrungBinh( duLieuTep0, beRongTep0, beCaoTep0, 21 );
         printf( "3.5\n" );
         unsigned char *anhMatNa1 = boLocTrungBinh( duLieuTep1, beRongTep1, beCaoTep1, 21 );
         unsigned char gioiHanDoSang = 100;
          printf( "4.0\n" );
         ChuNhat matNa0 = timKhungAnhSang( anhMatNa0, beRongTep0, beCaoTep0, gioiHanDoSang );  // <---- dùng nữa bộ lọc để mịn hoá ảng sự khạc biệt
         printf( "4.5\n" );
         ChuNhat matNa1 = timKhungAnhSang( anhMatNa1, beRongTep1, beCaoTep1, gioiHanDoSang );
         // ---- ảnh hơi mờ ở cạnh dưới và trên từ bộ lọc, cắt bớt một chút
         matNa0.tren -= 10;
         matNa0.duoi += 10;
         matNa1.tren -= 10;
         matNa1.duoi += 10;

         printf( "5.0  Mặt nạ ảnh %s: t %d p %d d %d t %d\n", argv[1], matNa0.trai, matNa0.phai, matNa0.duoi, matNa0.tren );
         printf( "     Mặt nạ ảnh %s: t %d p %d d %d t %d\n", argv[2], matNa1.trai, matNa1.phai, matNa1.duoi, matNa1.tren );

         // ---- giao hai mặt nạ
         ChuNhat matNaGiao;
         if( matNa0.trai < matNa1.trai )
            matNaGiao.trai = matNa1.trai;
         else
            matNaGiao.trai = matNa0.trai;
         // ----
         if( matNa0.phai < matNa1.phai )
            matNaGiao.phai = matNa0.phai;
         else
            matNaGiao.phai = matNa1.phai;
         // ----
         if( matNa0.duoi < matNa1.duoi )
            matNaGiao.duoi = matNa1.duoi;
         else
            matNaGiao.duoi = matNa0.duoi;
         
         if( matNa0.tren < matNa1.tren )
            matNaGiao.tren = matNa0.tren;
         else
            matNaGiao.tren = matNa1.tren;

//         printf( "     Mặt nạ giao hai ảnh: t %d p %d d %d t %d\n", matNaGiao.trai, matNaGiao.phai, matNaGiao.duoi, matNaGiao.tren );

         // ==== CẮT ẢNH
//         printf( "     CatAnh\n" );
         unsigned char *anhCat = catAnh( anhSuKhacBiet, beRongTep0, beCaoTep0, &matNaGiao );
//         printf( "6.0  CatAnh \n" );
         unsigned short beRongAnhCat = matNaGiao.phai - matNaGiao.trai;
         unsigned short beCaoAnhCat = matNaGiao.tren - matNaGiao.duoi;
//         printf( "     %d x %d\n", beRongAnhCat, beCaoAnhCat );
  
         // ==== BỘ LỌC ẢNH
//         printf( "     Đang bộ lọc ảnh cắt: trungBinh\n" );
         unsigned char *anhBoLocTrungBinh = boLocTrungBinh( anhCat, beRongAnhCat, beCaoAnhCat, 75 );
//         printf( "7.0  Đang bộ lọc ảnh cắt: trungBinhDoc\n" );
         // ---- bộ lọc ảnh một lần nữa nhưng chỉ làm hướng dộc
         anhBoLocTrungBinhDoc = boLocTrungBinhDoc( anhBoLocTrungBinh, beRongAnhCat, beCaoAnhCat, 70  );
//         printf( "7.5\n" );
         char tenAnhBoLoc[256];
//         sprintf( tenAnhBoLoc, "AnhBoLoc_%s", tenGhep );
         luuAnhPNG_BGRO( tenAnhBoLoc, anhBoLocTrungBinhDoc, beRongAnhCat, beCaoAnhCat );
         
         beRongAnhBoLoc = beRongAnhCat;
         beCaoAnhBoLoc = beCaoAnhCat;
         
         // ---- dọn dẹp trước đi phân tích ảnh
         free( anhSuKhacBiet );
         free( anhBoLocTrungBinh );
         free( duLieuTep0 );
         free( duLieuTep1 );
      }
      else {
         // ---- phàn nàn không có hai ảnh cỡ kích bằng nhau và nghỉ
         printf( "Làm ơn gõ tên hai tệp BMP hay PNG RGBO khác nào, cỡ kích bằng nhau.\n" );
         exit(0);
      }
   }
   else {
      // ---- hàn nàn không có ảnh và nghỉ
      printf( "Làm ơn gõ tên một hay hai tệp ảnh BMP hay PNG RGBO (cỡ kích bằng nhau cho hai ảnh).\n" );
      exit(0);
   }
         
   // ==== NGHIÊNG CỨU
/*   unsigned char soLanCatNgang = 10;
   unsigned char soLanCatDoc = 20;
   unsigned int beRongAnhCatNgang = 0;
   unsigned int beCaoAnhCatNgang = 0;
   unsigned char *anhCatNgang = veAnhDoSang( anhBoLocTrungBinhDoc, beRongAnhBoLoc, beCaoAnhBoLoc, &beRongAnhCatNgang, &beCaoAnhCatNgang, soLanCatNgang, soLanCatDoc );
   
   printf( "8.0  Đang phân tích, chờ một chút...\n" );
   if( anhCatNgang ) {
      char tenAnhCatNgang[256];
      sprintf( tenAnhCatNgang, "AnhCatNgang%02dx%02d__%s", soLanCatNgang, soLanCatDoc, tenGhep );
      luuAnhPNG_BGRO( tenAnhCatNgang, anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang );
      free( anhCatNgang );
       printf( "  Lưu ảnh: %s\n", tenAnhCatNgang );
   }
   */
   // ==== NGHIÊN CỨU TƯƠNG QUAN
   /*         unsigned short beRongSongTuongQuan = 301;
    unsigned int beRongAnhTuongQuan = 0;
    unsigned int beCaoAnhTuongQuan = 0;
    unsigned char *anhTuongQuan = veAnhTuongQuanSong( anhBoLocTrungBinhDoc, beRongAnhCat, beCaoAnhCat, &beRongAnhTuongQuan, &beCaoAnhTuongQuan, beRongSongTuongQuan );
    
    if( anhTuongQuan ) {
    char tenAnhTuongQuan[256];
    sprintf( tenAnhTuongQuan, "%s_%d_%s", "AnhTuongQuan\x00",  beRongSongTuongQuan, tenAnhToMau );
    luuAnhPNG_BGRO( tenAnhTuongQuan, anhTuongQuan, beRongAnhTuongQuan, beCaoAnhTuongQuan );
    } */
   
   // ==== TÔ MÀU ẢNH
   printf( "9.0  Tô màu ảnh cắt\n" );
   unsigned int beRongAnhTo;
   unsigned int beCaoAnhTo;
   unsigned char *anhToMau = toMauAnh( anhBoLocTrungBinhDoc, beRongAnhBoLoc, beCaoAnhBoLoc, &beRongAnhTo, &beCaoAnhTo );
   if( anhToMau != NULL ) {
      char tenAnhToMau[256];
      sprintf( tenAnhToMau, "AnhToMau__%s", tenGhep );
      luuAnhPNG_BGRO( tenAnhToMau, anhToMau, beRongAnhTo, beCaoAnhTo );
      free( anhToMau );
      printf( "Lưu ảnh %s\n", tenAnhToMau );
   }


   free( anhBoLocTrungBinhDoc );

   return 1;
}

/* Xem Đuôi Ảnh */
unsigned char xemDuoiTep( char *tenAnh ) {
   
   printf( "TênTệp: %s\n", tenAnh );
   char *dauTenTep = tenAnh;
   unsigned char soLuongKyTu = 0;
   
   while( *(tenAnh++) != 0x00 )
      soLuongKyTu++;
   
   // --- ba ký tự của đuôi
   char kyTu0 = dauTenTep[soLuongKyTu-3];
   char kyTu1 = dauTenTep[soLuongKyTu-2];
   char kyTu2 = dauTenTep[soLuongKyTu-1];
//   printf( "%c%c%c\n", kyTu0, kyTu1, kyTu2 );
   
   // ----
   if( (kyTu0 == 'b') && (kyTu1 == 'm') && (kyTu2 == 'p') )
      return kLOAI_ANH__BMP;
   else  if( (kyTu0 == 'B') && (kyTu1 == 'M') && (kyTu2 == 'P') )
      return kLOAI_ANH__BMP;
   else if( (kyTu0 == 'p') && (kyTu1 == 'n') && (kyTu2 == 'g') )
      return kLOAI_ANH__PNG;
   else if( (kyTu0 == 'P') && (kyTu1 == 'N') && (kyTu2 == 'G') )
      return kLOAI_ANH__PNG;
  
   return kLOAI_ANH__KHONG_BIET;
}

/* Ghép Tên Ảnh */
void ghepTenAnh( char *tenAnh, char *tenGhep0, char *tenGhep1 ) {
   
   
   char *dauTen = tenAnh;
   unsigned char chiSo = 0;
   while( tenGhep0[chiSo] != 0x00 ) {
      *dauTen = tenGhep0[chiSo];
      dauTen++;
      chiSo++;
   }
   // ---- bỏ đuôi
   dauTen -= 4;
   *dauTen = '_';
   dauTen++;
   *dauTen = '_';
   dauTen++;
   chiSo = 0;
   while( tenGhep1[chiSo] != 0x00 ) {
      *dauTen = tenGhep1[chiSo];
      dauTen++;
      chiSo++;
   }
   *dauTen = 0x00;
   
}
