/* CắtNgang.c */

// TOÀN BỘ NÀY ĐỂ NGHIÊN CỨU - KHÔNG CẦN CHO CHƯƠNG TRÌNH ĐỂ HOẠT ĐỘNG

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CatNgang.h"
#include "../HangSo.h"
#include "../PNG/PNG.h"
#include "../VeVatThe/ChepAnh.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../ToMauAnh/Diem.h"
#include "../TimNet/TimNet.h"
#include "../TimNet/Bezier.h"
#include "../TimNet/MaTran.h"

//#include "FFT_Moi.h"

#pragma mark ---- Cắt Ngang (CHO NGHIÊNG CỨU ẢNH)
//        |<------ r ------>|  |<------ r ------>|
//    +---------------------------------------------+
//    |                                             |
//    |                                             |
//    |                                             |
//    |                                             |
//    |                                             |
//    |                                             |
//  - |  +------------------+  +----+ +----+ +----+ |
//  ^ |  |                  |  |    | |    | |    | |
//  c |  |                  |  |    | |    | |    | |
//  v |  |                  |  |    | |    | |    | |
//  - |  +------------------+  +----+ +----+ +----+ |
//    |  +------------------+                       |
//    |  |                  |                       |
//    |  +------------------+                       |
//    |  +------------------+                       |
//    |  |                  |                       |
//    |  +------------------+                       |
//    |         ...                                  |
//    +---------------------------------------------+
//       |<256>||<256>||<256>|


/*
 Quét ngang +x và tìm điểm thấp và cao
 • Điểm thấp là màu giữa đoạn màu, điểm cao là kết thúc đoạn màu này và đầu đoạn màu tiếp
 • tô màu trong đoạn tùy vị trí tương đối với điểm thấp và điểm cao và giá trị đồ sáng của điểm ảnh
 • Đơn vị hóa độ cao và biến độ sáng dạng sin sang hàm bật một
 • chụ ý cách giữa điểm cao để biết khi nào cần lệt hướng tô màu?
 
 • sự di chuyển vị trí của điểm cao
 +---------------------+
 |                     |
 +------------->       |
 |                     |
 |                     |
 +---------------------+
 */

#define kCACH_GIUA 100 // cách giữa (điểm ảnh)

#define kANH_DO_SANG   0
#define kANH_CAT_NGANG 1
#define kANH_CAT_DOC   6
#define kSO_LUONG_ANH 11

//#define kTAN_SO_TOI_DA 20  // cho FFT

unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang );
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot );

void veAnhCatNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang,
                   unsigned short soHangCat, unsigned short x, unsigned y );

void veAnhCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                 unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang,
                 unsigned short soCotCat, unsigned short x, unsigned y );


void veDiemThichThuNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhNgang,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soHang );

void veDiemThichThuDoc( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soCot );


void bezierToiUuChoCatNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                            unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soHang );
void bezierToiUuChoCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot );


void veAnh3D( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRong, unsigned int beCao,
             unsigned char giaTriToiNhat, unsigned char giaTriSangNhat, unsigned short x, unsigned short y );

unsigned char *veAnhDoSang( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhXuat, unsigned int *beCaoAnhXuat,
                           unsigned char soLuongCatNgang, unsigned short soLuongCatDoc ) {

   *beRongAnhXuat = beRong + kCACH_GIUA*(soLuongCatDoc + 2) + 256*soLuongCatDoc;
   *beCaoAnhXuat = (beCao << 2) + (2 + kCACH_GIUA + 256)*soLuongCatNgang;
   
   unsigned char *anhCatXuat = malloc( *beRongAnhXuat * *beCaoAnhXuat << 2);
   
   if( anhCatXuat != NULL ) {
      
      // ---- cho giữ vị trí các ảnh, giúp vẽ điểm thích thú trên sơ đồ
      Diem mangGocAnh[256];
   
      // ---- độ sáng
      unsigned char giaTriToiNhat;
      unsigned char giaTriSangNhat;
      unsigned char *anhDoSang = toMauDoSangAnhVaKiemGiaTriCuc( anhGoc, beRong, beCao, &giaTriToiNhat, &giaTriSangNhat );
      
      if( anhDoSang ) {
         
         mangGocAnh[kANH_DO_SANG].x = kCACH_GIUA;
         mangGocAnh[kANH_DO_SANG].y = kCACH_GIUA*(soLuongCatNgang + 1) + 256*soLuongCatNgang;
  
         // ----  cắt ngang
         unsigned short x = kCACH_GIUA;
         unsigned short y = kCACH_GIUA;
         unsigned short soHangCat = 0;
         unsigned short buocCat = beCao/soLuongCatNgang;

         unsigned char soCatNgang = 0;
         while( soCatNgang < soLuongCatNgang ) {
            mangGocAnh[kANH_CAT_NGANG+soCatNgang].x = x;
            mangGocAnh[kANH_CAT_NGANG+soCatNgang].y = y;
  
            veAnhCatNgang( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, anhGoc, anhDoSang, beRong, beCao, soHangCat, x, y );
            
            // ---- điểm thích thú
            veDiemThichThuNgang( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+soCatNgang], anhGoc, anhDoSang, beRong, beCao, soHangCat );

            bezierToiUuChoCatNgang( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+soCatNgang], anhGoc, anhDoSang, beRong, beCao, soHangCat );

            y += 256 + kCACH_GIUA;
            soHangCat += buocCat;
            soCatNgang++;
         }

         // ----  cắt dộc
         x = (kCACH_GIUA << 1) + beRong;
         y = kCACH_GIUA*(soLuongCatNgang + 1) + 256*soLuongCatNgang;
         unsigned short soCotCat = 0;
         buocCat = beRong/soLuongCatDoc;

         unsigned char soCatDoc = 0;
         while( soCatDoc < soLuongCatDoc ) {
            mangGocAnh[kANH_CAT_DOC+soCatDoc].x = x;
            mangGocAnh[kANH_CAT_DOC+soCatDoc].y = y;
            
            veAnhCatDoc( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, anhGoc, anhDoSang, beRong, beCao, soCotCat, x, y );
            
            // ---- điểm thích thú
            veDiemThichThuDoc( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_DOC+soCatDoc], anhGoc, anhDoSang, beRong, beCao, soCotCat );

            // ---- vẽ cong Bezier tương đương
            bezierToiUuChoCatDoc( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], x, y, anhGoc, anhDoSang, beRong, beCao, soCotCat );

            x += 256 + kCACH_GIUA;
            soCotCat += buocCat;
            soCatDoc++;
         }



         // ---- chép ảnh độ sáng tô màu
         x =  mangGocAnh[kANH_DO_SANG].x;
         y =  mangGocAnh[kANH_DO_SANG].y;
         chepAnhVaoAnh( anhDoSang, beRong, beCao, anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG].x, mangGocAnh[kANH_DO_SANG].y );
         veSoCai( "光度", x, y - 32, anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat );
         
         // ---- ảnh 3 chiểu
         x = kCACH_GIUA << 1;
         y = kCACH_GIUA*(soLuongCatNgang + 2) + 256*soLuongCatNgang + beCao;
         veAnh3D( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, anhGoc, anhDoSang, beRong, beCao, giaTriToiNhat, giaTriSangNhat, x, y );
         veSoCai( "光度3维", x, y + 300 + beCao, anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat );

      }
   }
   else {
      printf( "veAnhDoSang: SAI LẦM giành trí nhớ cho ảnh cắt nganh\n" );
   }
   return anhCatXuat;

}

void veAnhCatNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang,
                   unsigned short soHangCat, unsigned short x, unsigned y ) {
   
   Diem diem0;
   Diem diem1;
   diem0.x = 0;
   diem0.y = soHangCat;
   diem1.x = beRongAnhDoSang-1;
   diem1.y = soHangCat;

   // ---- vẽ nét trên ảnh sáng tô màu
         veDuong( anhDoSangToMau, beRongAnhDoSang, beCaoAnhDoSang, diem0, diem1, 0x80808080 );
   
   
   // ---- vẽ ảnh cắt ngang
   unsigned char *anhCatNgang = taoAnhDoSangChoHangCuaAnh( anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soHangCat );
   if( anhCatNgang ) {
      chepAnhVaoAnh( anhCatNgang, beRongAnhDoSang, 256, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y );
      free( anhCatNgang );

      // ---- vẽ vị trí cắt
      veSoCai( "↔︎切画", x, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      veSoThapPhan( soHangCat, x + (beRongAnhDoSang >> 1) - 32, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   }

   // ---- tìm điểm thích thú
}


void veAnhCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang,
                   unsigned short soCotCat, unsigned short x, unsigned y ) {
   
   Diem diem0;
   Diem diem1;
   diem0.x = soCotCat;
   diem0.y = 0;
   diem1.x = soCotCat;
   diem1.y = beCaoAnhDoSang - 1;
   
   // ---- vẽ nét trên ảnh sáng tô màu
   veDuong( anhDoSangToMau, beRongAnhDoSang, beCaoAnhDoSang, diem0, diem1, 0x80808080 );
   
   // ---- vẽ ảnh cắt ngang
   unsigned char *anhCatDoc = taoAnhDoSangChoCotCuaAnh( anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soCotCat );
   if( anhCatDoc ) {
      chepAnhVaoAnh( anhCatDoc, 256, beCaoAnhDoSang, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y );
      free( anhCatDoc );
      
      // ---- vẽ vị trí cắt
      veSoCai( "↕︎切画", x, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      veSoThapPhan( soCotCat, x + 128 - 32, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   }
   
   // ---- tìm điểm thích thú
}


/* Để làm video cắt ngang
void luuCatNgangToanBoChoAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao ) {
   
   unsigned char *anhCatNgangTruoc = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, 0 );   // 256 << 2
   
   unsigned int soHangAnhGoc = 0;
   while( soHangAnhGoc < beCao ) {
      unsigned char *anhCatNgangSau = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangAnhGoc );   // 256 << 2
      
      char tenAnh[256];
      sprintf( tenAnh, "AnhCatNgang_%03d.png", soHangAnhGoc );
      //      printf( "Phân tích vận tốc trong ảnh: %s\n", tenAnh );
      //      phanTichVanTocGiuaHaiAnh( anhCatNgangTruoc, anhCatNgangSau, beRong, beCao );
      
      luuAnhPNG_BGRO( tenAnh, anhCatNgangSau, beRong, 256 );
      printf( "Luu anh: %s\n", tenAnh );
      soHangAnhGoc++;
      free( anhCatNgangSau );
   }
   printf( "kích cỡ: %d %d\n", beRong, 256 );
   
   free( anhCatNgangTruoc );
}

void luuCatNgangMotTamChoAnh( char *tenAnhCatNgang, unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHangCatNgang ) {
   
   unsigned char *anhCatNgang = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCatNgang );   // 256 << 2
   
   luuAnhPNG_BGRO( tenAnhCatNgang, anhCatNgang, beRong, 256 );
   
   free( anhCatNgang );
} */

// ---- tạoẢnhĐộSángChoHàngCủaẢnh
//      các ngang (hướng trái phải)
unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang ) {
   
   unsigned char *anhCatNgang = malloc( beRong << 10 );   // * 256 << 2 = << 10
   
   if( anhCatNgang ) {
      unsigned int diaChiAnhGoc = beRong*soHang << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soCot = 0;
      while( soCot < beRong ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soCot << 2;
         unsigned int soHangAnhLuu = 0;
         while( soHangAnhLuu < giaTriAnhGoc ) {
            anhCatNgang[diaChiAnhLuu] = soHangAnhLuu << 3;
            anhCatNgang[diaChiAnhLuu+1] = soHangAnhLuu;
            anhCatNgang[diaChiAnhLuu+2] = soHangAnhLuu << 1;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         while( soHangAnhLuu < 256 ) {
            anhCatNgang[diaChiAnhLuu] = 0xff;
            anhCatNgang[diaChiAnhLuu+1] = 0xff;
            anhCatNgang[diaChiAnhLuu+2] = 0xff;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += 4;
         soCot++;
      }
   }
   else {
      printf( "taoAnhDoSangChoHangCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatNgang;
}

// ---- tạoẢnhĐộSángChoCộtCủaẢnh
//      các dộc (hướng dưới trên)
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot ) {
   
   unsigned char *anhCatDoc = malloc( beCao << 10 );   // * 256 << 2 = << 10
   
   if( anhCatDoc ) {

      unsigned int diaChiAnhGoc = soCot << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soHang = 0;
      while( soHang < beCao ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soHang << 10;
         unsigned int soCotAnhLuu = 0;
         while( soCotAnhLuu < giaTriAnhGoc ) {
            anhCatDoc[diaChiAnhLuu] = soCotAnhLuu << 3;
            anhCatDoc[diaChiAnhLuu+1] = soCotAnhLuu;
            anhCatDoc[diaChiAnhLuu+2] = soCotAnhLuu << 1;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         while( soCotAnhLuu < 256 ) {
            anhCatDoc[diaChiAnhLuu] = 0xff;
            anhCatDoc[diaChiAnhLuu+1] = 0xff;
            anhCatDoc[diaChiAnhLuu+2] = 0xff;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += beRong << 2;
         soHang++;
      }
   }
   else {
      printf( "taoAnhDoSangChoCotCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatDoc;
}


// tôMàuĐộSángẢnh
unsigned char *toMauDoSangAnhVaKiemGiaTriCuc( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char *giaTriToiNhat, unsigned char *giaTriSangNhat ) {
   
   *giaTriToiNhat = 255;
   *giaTriSangNhat = 0;
   unsigned int diaChiCuoi = beRong*beCao << 2;
   unsigned char *anhToMau = malloc( diaChiCuoi );
   
   if( anhToMau ) {
      
      unsigned int diaChiAnh = 0;
      
      while( diaChiAnh < diaChiCuoi ) {
         // ---- lấy gíá trị từ kênh đỏ
         unsigned char doSang = anh[diaChiAnh];
         // ---- tô màu ảnh
         anhToMau[diaChiAnh] = doSang << 3;
         anhToMau[diaChiAnh+1] = doSang;
         anhToMau[diaChiAnh+2] = doSang << 1;
         anhToMau[diaChiAnh+3] = 0xff;
         
         // ---- kiếm giá trị cực
         if( doSang < *giaTriToiNhat )
            *giaTriToiNhat = doSang;
         if( doSang > *giaTriSangNhat )
            *giaTriSangNhat = doSang;
         
         diaChiAnh += 4;
      }
   }
   else {
      printf( "toMauDoSangAnh: vấn đề tạo tô màu\n" );
   }
   
   return anhToMau;
}

void veDiemThichThuNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhNgang,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soHang ) {
   
   unsigned int mau = 0x404040b0;
   unsigned short banKinh = 8;

   Diem mangDiemThichThu[512];
   unsigned char soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += gocAnhDoSang.x;
      tamVongTron.y += gocAnhDoSang.y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += gocAnhNgang.x;
      tamVongTron.y = gocAnhNgang.y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );

}

void veDiemThichThuDoc( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soCot ) {

   unsigned int mau = 0x404040b0;
   unsigned short banKinh = 8;

   Diem mangDiemThichThu[512];
   unsigned char soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += gocAnhDoSang.x;
      tamVongTron.y += gocAnhDoSang.y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = gocAnhDoc.x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += gocAnhDoc.y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soCot );
}



void bezierToiUuChoCatNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhNgang,
                            unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soHang ) {

   unsigned int mauVongTronDo = 0xff0000b0;
   unsigned int mauVongTronXanh = 0x0000ffb0;
   unsigned int mauNet = 0x000000b0;
   unsigned short banKinh = 6;
   
   unsigned short soLuongCong = beRongAnhBoLoc/200;
   unsigned short soLuongDiemAnhChoCong = beRongAnhBoLoc/soLuongCong;
   
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }

//   printf( " khoMaTran %d soLuongCong %d\n", khoMaTran, soLuongCong );

   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranCongToiUuB3_doanHang( maTran4x4, maTran4x2, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
//      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );

      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }

//   chieuMaTran( maTranGop, khoMaTran, khoMaTran );
//   chieuMaTran( vectoGop, 2, khoMaTran );
   // ---- giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
//      chiSo = 0;
//      while( chiSo < khoMaTran ) {
//         printf( "%d  %5.3f %5.3f\n", chiSo, vectoGop[mangThuTu[chiSo] << 1], vectoGop[(mangThuTu[chiSo] << 1) + 1] );
//         chiSo++;
//      }
      
      // ---- vẽ đường Bezier
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ giải
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0000f;
         bezier.diemQuanTri[0].y = 0.0f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.3333f;
         bezier.diemQuanTri[1].y = 0.0f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.6667f;
         bezier.diemQuanTri[2].y = 0.0f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;

         bezier.diemQuanTri[3].x = 1.0000f;
         bezier.diemQuanTri[3].y = 0.0f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         
         Vecto mangDiem3C[128];
         float thamSo = 0.0f;
         float buocThamSo = 0.03125f;
         unsigned char soLuongDiem = 0;
         while( thamSo <= 1.0f ) {
            mangDiem3C[soLuongDiem] = tinhViTriCongBezier3C_B3( &bezier, thamSo );
//            printf( " thamSo %5.3f:  %5.3f; %5.3f; %5.3f\n", thamSo, mangDiem3C[soLuongDiem].x, mangDiem3C[soLuongDiem].y, mangDiem3C[soLuongDiem].z );
            thamSo += buocThamSo;
            soLuongDiem++;
         }
         
//         printf( " soLuongDiem %d\n", soLuongDiem );
         
         Diem diemDau;
         Diem diemCuoi;
         unsigned short dichX = gocAnhNgang.x + soCong*soLuongDiemAnhChoCong;
         diemDau.x = soLuongDiemAnhChoCong*mangDiem3C[0].x + dichX;
         diemDau.y = 255.0f*mangDiem3C[0].z + gocAnhNgang.y;

         unsigned char soDiem = 1;
         while( soDiem < soLuongDiem ) {
            diemCuoi.x = soLuongDiemAnhChoCong*mangDiem3C[soDiem].x + dichX;
            diemCuoi.y = 255.0f*mangDiem3C[soDiem].z + gocAnhNgang.y;
//            printf( "soDiem %d  (%d; %d) --> (%d; %d)\n", soDiem, diemDau.x, diemDau.y , diemCuoi.x, diemCuoi.y );
            veDuong( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, diemDau, diemCuoi, mauNet );
            diemDau = diemCuoi;
            soDiem++;
         }
         
         // ---- tìm điểm nghiệm (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z_B3( &bezier, &nghiem0, &nghiem1 );
//         printf( "soLuongNghiem %d  %5.3f %5.3f\n", soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem == 1 ) {
            Diem tamVongTronChoAnhNgang;
            tamVongTronChoAnhNgang.x = nghiem0*soLuongDiemAnhChoCong + dichX;
            tamVongTronChoAnhNgang.y = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem0 ).z + gocAnhNgang.y;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = soHang + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang, banKinh, mauVongTronDo );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang, banKinh, mauVongTronXanh );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang, banKinh, mauVongTronXanh );
            }
         }
         if( soLuongNghiem == 2 ) {
            Diem tamVongTronChoAnhNgang;
            tamVongTronChoAnhNgang.x = nghiem1*soLuongDiemAnhChoCong + dichX;
            tamVongTronChoAnhNgang.y = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem1 ).z + gocAnhNgang.y;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = soHang + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem1 );
            if( doCong > 0.0f ) {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang, banKinh, mauVongTronDo );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang, banKinh, mauVongTronXanh );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang, banKinh, mauVongTronXanh );
            }
            
         }
         soCong++;
      }
      
   }

   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );
}


void bezierToiUuChoCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot ) {
   
   unsigned int mauVongTronDo = 0xff0000b0;
   unsigned int mauVongTronXanh = 0x0000ffb0;
   unsigned int mauNet = 0x000000b0;
   unsigned short banKinh = 6;

   unsigned short soLuongCong = beCaoAnhBoLoc/200;
   unsigned short soLuongDiemAnhChoCong = beCaoAnhBoLoc/soLuongCong;
 
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }

//   printf( " khoMaTran %d soLuongCong %d\n", khoMaTran, soLuongCong );
   
   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranCongToiUuB3_doanCot( maTran4x4, maTran4x2, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
//      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );
      
      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }
   
   // ---- giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
      // ---- vẽ đường Bezier
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ giải
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0f;
         bezier.diemQuanTri[0].y = 0.0000f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.0f;
         bezier.diemQuanTri[1].y = 0.3333f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.0f;
         bezier.diemQuanTri[2].y = 0.6667f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[3].x = 0.0f;
         bezier.diemQuanTri[3].y = 1.0000f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         
         Vecto mangDiem3C[128];
         float thamSo = 0.0f;
         float buocThamSo = 0.03125f;
         unsigned char soLuongDiem = 0;
         while( thamSo <= 1.0f ) {
            mangDiem3C[soLuongDiem] = tinhViTriCongBezier3C_B3( &bezier, thamSo );
//            printf( " thamSo %5.3f:  %5.3f; %5.3f; %5.3f\n", thamSo, mangDiem3C[soLuongDiem].x, mangDiem3C[soLuongDiem].y, mangDiem3C[soLuongDiem].z );
            thamSo += buocThamSo;
            soLuongDiem++;
         }
         
         Diem diemDau;
         Diem diemCuoi;
         unsigned short dichY = y + soCong*soLuongDiemAnhChoCong;
         diemDau.x = 255.0f*mangDiem3C[0].z + x;
         diemDau.y = soLuongDiemAnhChoCong*mangDiem3C[0].y + dichY;

         unsigned char soDiem = 1;
         while( soDiem < soLuongDiem ) {
            diemCuoi.x = 255.0f*mangDiem3C[soDiem].z + x;
            diemCuoi.y = soLuongDiemAnhChoCong*mangDiem3C[soDiem].y + dichY;
//            printf( "soDiem %d  (%d; %d) --> (%d; %d)\n", soDiem, diemDau.x, diemDau.y , diemCuoi.x, diemCuoi.y );
            veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, mauNet );
            diemDau = diemCuoi;
            soDiem++;
         }

         // ---- tìm điểm nghiệm (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z_B3( &bezier, &nghiem0, &nghiem1 );
//         printf( "soLuongNghiem %d  %5.3f %5.3f\n", soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem == 1 ) {
 
            Diem tamVongTronChoAnhDoc;
            tamVongTronChoAnhDoc.x = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem0 ).z + x;
            tamVongTronChoAnhDoc.y = nghiem0*soLuongDiemAnhChoCong + dichY;
//            printf( "nghiem0 %5.3f  soLuongDiemAnh %d  dichY %d\n", nghiem0, soLuongDiemAnhChoCong, dichY );
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = soCot + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.y;
//            printf( "tamVongTronChoAnhDoc %d %d   anhXuat beRong %d  beCao %d\n", tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, beRongAnhXuat, beCaoAnhXuat );
//            printf( "tamVongTronChoAnhDoSang %d %d  anhDoSang beRong %d  beCao %d  soCot %d  gocAnhDoSang.x %d\n", tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, beRongAnhBoLoc, beCaoAnhBoLoc,
//                   soCong, gocAnhDoSang.x );

            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc, banKinh, mauVongTronDo );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc, banKinh, mauVongTronXanh );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang, banKinh, mauVongTronXanh );
            }
         }

         if( soLuongNghiem == 2 ) {
            Diem tamVongTronChoAnhDoc;
            tamVongTronChoAnhDoc.x = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem1 ).z + x;
            tamVongTronChoAnhDoc.y = nghiem1*soLuongDiemAnhChoCong + dichY;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = soCot + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem1 );
            if( doCong > 0.0f ) {
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc, banKinh, mauVongTronDo );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc, banKinh, mauVongTronXanh );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang, banKinh, mauVongTronXanh );
            }
            
         }

         soCong++;
      }
   }

   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );
}


#pragma mark ---- VẼ ẢNH 3 CHIỀU
void veChuNhatCungDoCao( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY, float doCao,
                        float *diem0, float *diem1, float *diem2, float *diem3, float *maTranBienHoa );
void veNetGiuaHaiDiem( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY,
                      float *diem0, float *diem1, float *maTranBienHoa, unsigned int mauNet );

void veAnh3D( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRong, unsigned int beCao,
        unsigned char giaTriToiNhat, unsigned char giaTriSangNhat, unsigned short x, unsigned short y ) {

   unsigned char chenhLechDoSang = giaTriSangNhat - giaTriToiNhat;
   
   // ---- không chênh lệch cho nó qúa nhỏ
   if( chenhLechDoSang < 10 )
      chenhLechDoSang = 10;
   
//   printf( " giaTriToiNhat %d  sangNhat %d  chenLech %d\n", giaTriToiNhat, giaTriSangNhat, chenhLechDoSang );
   
   // ---- tính biến hóa
   float phongToZ = 200.0f/chenhLechDoSang;

   float maTranPhongTo[16] = {1.5f, 0.0f, 0.0f, 0.0f,   0.0f, 2.0f, 0.0f, 0.0f,   0.0f, 0.0f, phongToZ, 0.0f,  0.0f, 0.0f, 0.0f, 1.0f};
   float maTranXoayTrucX[16];
   float maTranXoayTrucZ[16];
   float maTranBienHoa0[16];
   float maTranBienHoa1[16];
   
   maTranQuayQuanhTrucZ( maTranXoayTrucZ, 3.14159f*0.1f );
   maTranQuayQuanhTrucX( maTranXoayTrucX, 3.14159f*0.33333f );
   nhanMaTranVoiMaTranVaBoVaoKetQua( maTranXoayTrucZ, maTranXoayTrucX, maTranBienHoa0 );
   nhanMaTranVoiMaTranVaBoVaoKetQua( maTranPhongTo, maTranBienHoa0, maTranBienHoa1 );
   
   // ---- vẽ khung đấy không gian
   float diem0[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
   float diem1[4] = { beRong, 0.0f, 0.0f, 1.0f };
   float diem2[4] = { 0.0f, beCao, 0.0f, 1.0f };
   float diem3[4] = { beRong, beCao, 0.0f, 1.0f };
   
   veChuNhatCungDoCao( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, giaTriToiNhat, diem0, diem1, diem2, diem3, maTranBienHoa1 );
   
   // ----
   diem2[2] = giaTriToiNhat;
   float diemCao2[4] = { diem2[0], diem2[1], giaTriSangNhat, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diemCao2, maTranBienHoa1, 0x30303080 );
   
   diem3[2] = giaTriToiNhat;
   float diemCao3[4] = { diem3[0], diem3[1], giaTriSangNhat, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem3, diemCao3, maTranBienHoa1, 0x30303080 );


   // ---- các nét đang sau
   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );

   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );

   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );


   // ---- vẽ ảnh 3 chiều
   chepAnhVaoAnhVoiMaTran( anhDoSang, anhDoSangToMau, beRong, beCao, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, maTranBienHoa1 );
   
   veChuNhatCungDoCao( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, giaTriSangNhat, diem0, diem1, diem2, diem3, maTranBienHoa1 );
   
   diem0[2] = giaTriToiNhat;
   float diemCao0[4] = { diem0[0], diem0[1], giaTriSangNhat, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diemCao0, maTranBienHoa1, 0x30303080 );
   
   diem1[2] = giaTriToiNhat;
   float diemCao1[4] = { diem1[0], diem1[1], giaTriSangNhat, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem1, diemCao1, maTranBienHoa1, 0x30303080 );
}

void veChuNhatCungDoCao( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY, float doCao,
                        float *diem0, float *diem1, float *diem2, float *diem3, float *maTranBienHoa ) {
   
   diem0[2] = doCao;
   diem1[2] = doCao;
   diem2[2] = doCao;
   diem3[2] = doCao;
   
   float diemBienHoa0[4];
   float diemBienHoa1[4];
   float diemBienHoa2[4];
   float diemBienHoa3[4];
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem0, maTranBienHoa, diemBienHoa0 );
   diemBienHoa0[0] += dichX;
   diemBienHoa0[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem1, maTranBienHoa, diemBienHoa1 );
   diemBienHoa1[0] += dichX;
   diemBienHoa1[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem2, maTranBienHoa, diemBienHoa2 );
   diemBienHoa2[0] += dichX;
   diemBienHoa2[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem3, maTranBienHoa, diemBienHoa3 );
   diemBienHoa3[0] += dichX;
   diemBienHoa3[1] += dichY;
   
   // ----
   unsigned int mauNet = 0x30303080;
   Diem diemDauNet;
   Diem diemCuoiNet;
   //
   diemDauNet.x = diemBienHoa0[0];
   diemDauNet.y = diemBienHoa0[1];
   diemCuoiNet.x = diemBienHoa1[0];
   diemCuoiNet.y = diemBienHoa1[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa3[0];
   diemCuoiNet.y = diemBienHoa3[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa2[0];
   diemCuoiNet.y = diemBienHoa2[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa0[0];
   diemCuoiNet.y = diemBienHoa0[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
}

void veNetGiuaHaiDiem( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY,
                        float *diem0, float *diem1, float *maTranBienHoa, unsigned int mauNet ) {
   

   
   float diemBienHoa0[4];
   float diemBienHoa1[4];
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem0, maTranBienHoa, diemBienHoa0 );
   diemBienHoa0[0] += dichX;
   diemBienHoa0[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem1, maTranBienHoa, diemBienHoa1 );
   diemBienHoa1[0] += dichX;
   diemBienHoa1[1] += dichY;
   
   // ----
   Diem diemDauNet;
   Diem diemCuoiNet;
   //
   diemDauNet.x = diemBienHoa0[0];
   diemDauNet.y = diemBienHoa0[1];
   diemCuoiNet.x = diemBienHoa1[0];
   diemCuoiNet.y = diemBienHoa1[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
}


void hamX( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot ) {
   
}
