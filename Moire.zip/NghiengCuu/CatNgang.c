/* CắtNgang.c */

// TOÀN BỘ NÀY ĐỂ NGHIÊN CỨU - KHÔNG CẦN CHO CHƯƠNG TRÌNH ĐỂ HOẠT ĐỘNG

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CatNgang.h"
#include "../HangSo.h"
#include "../PNG/PNG.h"
#include "../VeVatThe/ChepAnh.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../ToMauAnh/Diem.h"
#include "../TimNet/TimNet.h"
//#include "FFT_Moi.h"

#pragma mark ---- Cắt Ngang (CHO NGHIÊNG CỨU ẢNH)
//        |<------ r ------>|  |<------ r ------>|
//    +--------------------------------------------+
//  - |  +------------------+  +-----------------+ |
//  ^ |  |                  |  +-----------------+ |
//  c |  |                  |  +-----------------+ |
//  v |  |                  |  +-----------------+ |
//  - |  +------------------+  +-----------------+ |
//    |  +----+ +----+ +----+                      |
//    |  |    | |    | |    |                      |
//    |  |    | |    | |    |                      |
//    |  |    | |    | |    |                      |
//    |  +----+ +----+ +----+                      |
//    +--------------------------------------------+
//       |<256>||<256>||<256>|


/*
 Quét ngang +x và tìm điểm thấp và cao
 • Điểm thấp là màu giữa đoạn màu, điểm cao là kết thúc đoạn màu này và đầu đoạn màu tiếp
 • tô màu trong đoạn tùy vị trí tương đối với điểm thấp và điểm cao và giá trị đồ sáng của điểm ảnh
 • Đơn vị hóa độ cao và biến độ sáng dạng sin sang hàm bật một
 • chụ ý cách giữa điểm cao để biết khi nào cần lệt hướng tô màu?
 
 • sự di chuyển vị trí của điểm cao
 +---------------------+
 |                     |
 +------------->       |
 |                     |
 |                     |
 +---------------------+
 */

#define kCACH_GIUA 100 // cách giữa (điểm ảnh)

#define kANH_DO_SANG   0
#define kANH_CAT_NGANG 1
#define kANH_CAT_DOC   6
#define kSO_LUONG_ANH 11

//#define kTAN_SO_TOI_DA 20  // cho FFT

unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang );
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot );
void veDiemThichThu( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem *mangGocAnh,
                    unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc );

unsigned char *veAnhDoSang( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhCatNgang, unsigned int *beCaoAnhCatNgang ) {

   *beRongAnhCatNgang = (beRong << 1) + 3*kCACH_GIUA;
   *beCaoAnhCatNgang = (beCao << 1) + 3*kCACH_GIUA;
   
   unsigned char *anhCatNgang = malloc( *beRongAnhCatNgang * *beCaoAnhCatNgang << 2);
   
   if( anhCatNgang != NULL ) {
      
      // ---- cho giữ vị trí các ảnh, giúp vẽ điểm thích thú trên sơ đồ
      Diem mangGocAnh[kSO_LUONG_ANH];
   
      // ---- độ sáng
      unsigned char *anhDoSang = toMauDoSangAnh( anhGoc, beRong, beCao );
      if( anhDoSang ) {
         unsigned short x = kCACH_GIUA;
         unsigned short y = (kCACH_GIUA << 1) + beCao;
         mangGocAnh[kANH_DO_SANG].x = x;
         mangGocAnh[kANH_DO_SANG].y = y;

         // ---- vẽ các đường cắt ngang
         Diem diem0;
         Diem diem1;
         diem0.x = 0;
         diem0.y = 0;
         diem1.x = beRong-1;
         diem1.y = 0;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.y = beCao >> 2;
         diem1.y = diem0.y;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.y = beCao >> 1;
         diem1.y = diem0.y;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.y = (beCao >> 2)*3;
         diem1.y = diem0.y;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.y = beCao - 1;
         diem1.y = diem0.y;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         
         // ---- vẽ các đường cắt dộc
         diem0.x = 0;
         diem0.y = 0;
         diem1.x = 0;
         diem1.y = beCao - 1;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.x = beRong >> 2;
         diem1.x = diem0.x;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.x = beRong >> 1;
         diem1.x = diem0.x;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.x = (beRong >> 2)*3;
         diem1.x = diem0.x;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.x = beRong - 1;
         diem1.x = diem0.x;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );

         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSang, beRong, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );

         // ---- thông tin về cột cắt ảnh
         unsigned short soCot = 0;
         veSoThapPhan( soCot, x - 8, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soCot = beRong >> 2;
         veSoThapPhan( soCot, x - 24 + soCot, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soCot = beRong >> 1;
         veSoThapPhan( beRong >> 1, x - 24 + soCot, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soCot = (beRong >> 2)*3;
         veSoThapPhan( soCot, x - 24 + soCot, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soCot = beRong-1;
         veSoThapPhan( soCot, x - 24 + soCot, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         
         // ---- thông tin về hàng cắt ảnh
         unsigned short soHang = 0;
         veSoThapPhan( 0, x - 24, y - 8, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soHang = beCao >> 2;
         veSoThapPhan( soHang, x - 54, y - 8 + soHang, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soHang = (beCao >> 1);
         veSoThapPhan( soHang, x - 54, y - 8 + soHang, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soHang = (beCao >> 2)*3;
         veSoThapPhan( soHang, x - 54, y - 8 + soHang, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soHang = beCao - 1;
         veSoThapPhan( soHang, x - 54, y - 8 + soHang, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
      }

      // ----  cắt ngang
      unsigned short x = (kCACH_GIUA << 1) + beRong;
      unsigned short y = kCACH_GIUA;
      mangGocAnh[kANH_CAT_NGANG].x = x;
      mangGocAnh[kANH_CAT_NGANG].y = y;
   
      unsigned short soHangCat = 0;
      unsigned char *anhCatNgang0 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang0 ) {
         chepAnhVaoAnh( anhCatNgang0, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang0 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         y += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_NGANG+1].x = x;
      mangGocAnh[kANH_CAT_NGANG+1].y = y;
   
      soHangCat = beCao >> 2;
      unsigned char *anhCatNgang1 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang1 ) {
         chepAnhVaoAnh( anhCatNgang1, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang1 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         y += 256 + kCACH_GIUA;
      }
   
      mangGocAnh[kANH_CAT_NGANG+2].x = x;
      mangGocAnh[kANH_CAT_NGANG+2].y = y;

      soHangCat = beCao >> 1;
      unsigned char *anhCatNgang2 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang2 ) {
         chepAnhVaoAnh( anhCatNgang2, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang2 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         y += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_NGANG+3].x = x;
      mangGocAnh[kANH_CAT_NGANG+3].y = y;

      soHangCat = (beCao >> 2)*3;
      unsigned char *anhCatNgang3 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang3 ) {
         chepAnhVaoAnh( anhCatNgang3, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang3 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         y += 256 + kCACH_GIUA;
      }

      mangGocAnh[kANH_CAT_NGANG+4].x = x;
      mangGocAnh[kANH_CAT_NGANG+4].y = y;

      soHangCat = beCao-1;
      unsigned char *anhCatNgang4 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang4 ) {
         chepAnhVaoAnh( anhCatNgang4, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang4 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
      }

      // ----  cắt dộc
      x = kCACH_GIUA;
      y = kCACH_GIUA;
      mangGocAnh[kANH_CAT_DOC].x = x;
      mangGocAnh[kANH_CAT_DOC].y = y;
      
      unsigned short soCotCat = 0;
      unsigned char *anhCatCot0 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot0 ) {
         chepAnhVaoAnh( anhCatCot0, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot0 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         x += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_DOC+1].x = x;
      mangGocAnh[kANH_CAT_DOC+1].y = y;

      soCotCat = beRong >> 2;
      unsigned char *anhCatCot1 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot1 ) {
         chepAnhVaoAnh( anhCatCot1, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot1 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         x += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_DOC+2].x = x;
      mangGocAnh[kANH_CAT_DOC+2].y = y;

      soCotCat = beRong >> 1;
      unsigned char *anhCatCot2 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot2 ) {
         chepAnhVaoAnh( anhCatCot2, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot2 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         x += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_DOC+3].x = x;
      mangGocAnh[kANH_CAT_DOC+3].y = y;
      
      soCotCat = (beRong >> 2)*3;
      unsigned char *anhCatCot3 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot3 ) {
         chepAnhVaoAnh( anhCatCot3, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot3 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         x += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_DOC+4].x = x;
      mangGocAnh[kANH_CAT_DOC+4].y = y;
      
      soCotCat = beRong-1;
      unsigned char *anhCatCot4 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot4 ) {
         chepAnhVaoAnh( anhCatCot4, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot4 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
      }
      
      // ---- điểm thích thú
      veDiemThichThu( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh, anhGoc, beRong, beCao );
      
      // ==== FFT
/*      // chép hàng
      SoPhuc *hangAnh = malloc( sizeof(SoPhuc)*beRong );
      if( hangAnh ) {
         soHangCat = 0;
         unsigned int soCot = 0;
         unsigned int diaChiAnhGoc = beRong*soHangCat;
         while( soCot < beRong ) {
            hangAnh[soCot].t = anhGoc[diaChiAnhGoc];
            hangAnh[soCot].a = 0.0f;
            diaChiAnhGoc += 4;
            soCot++;
         }
         unsigned int beDaiFFT;
         SoPhuc *mangFFT = FFT( hangAnh, beRong, &beDaiFFT );
         if( mangFFT ) {
            float triSoDonViHoa = sqrtf( mangFFT[0].t * mangFFT[0].t + mangFFT[0].a * mangFFT[0].a );
            unsigned char soTanSo = 0;

            while( soTanSo < kTAN_SO_TOI_DA ) {
               float thuc = mangFFT[soTanSo].t;
               float ao = mangFFT[soTanSo].a;
               float doLon = sqrtf( thuc*thuc + ao*ao );
               if( soTanSo )
                  printf( "%d %5.4f %d\n", soTanSo, doLon/triSoDonViHoa, beDaiFFT/soTanSo );
               else
                  printf( "%d %5.4f ---\n", soTanSo, doLon/triSoDonViHoa );
               soTanSo++;
            }
         }
      } */

   
   }
   else {
      printf( "veAnhDoSang: SAI LẦM giành trí nhớ cho ảnh cắt nganh\n" );
   }
   return anhCatNgang;

}

/* Để làm video cắt ngang
void luuCatNgangToanBoChoAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao ) {
   
   unsigned char *anhCatNgangTruoc = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, 0 );   // 256 << 2
   
   unsigned int soHangAnhGoc = 0;
   while( soHangAnhGoc < beCao ) {
      unsigned char *anhCatNgangSau = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangAnhGoc );   // 256 << 2
      
      char tenAnh[256];
      sprintf( tenAnh, "AnhCatNgang_%03d.png", soHangAnhGoc );
      //      printf( "Phân tích vận tốc trong ảnh: %s\n", tenAnh );
      //      phanTichVanTocGiuaHaiAnh( anhCatNgangTruoc, anhCatNgangSau, beRong, beCao );
      
      luuAnhPNG_BGRO( tenAnh, anhCatNgangSau, beRong, 256 );
      printf( "Luu anh: %s\n", tenAnh );
      soHangAnhGoc++;
      free( anhCatNgangSau );
   }
   printf( "kích cỡ: %d %d\n", beRong, 256 );
   
   free( anhCatNgangTruoc );
}

void luuCatNgangMotTamChoAnh( char *tenAnhCatNgang, unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHangCatNgang ) {
   
   unsigned char *anhCatNgang = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCatNgang );   // 256 << 2
   
   luuAnhPNG_BGRO( tenAnhCatNgang, anhCatNgang, beRong, 256 );
   
   free( anhCatNgang );
} */

// ---- tạoẢnhĐộSángChoHàngCủaẢnh
//      các ngang (hướng trái phải)
unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang ) {
   
   unsigned char *anhCatNgang = malloc( beRong << 10 );   // * 256 << 2 = << 10
   
   if( anhCatNgang ) {
      unsigned int diaChiAnhGoc = beRong*soHang << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soCot = 0;
      while( soCot < beRong ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soCot << 2;
         unsigned int soHangAnhLuu = 0;
         while( soHangAnhLuu < giaTriAnhGoc ) {
            anhCatNgang[diaChiAnhLuu] = soHangAnhLuu << 3;
            anhCatNgang[diaChiAnhLuu+1] = soHangAnhLuu;
            anhCatNgang[diaChiAnhLuu+2] = soHangAnhLuu << 1;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         while( soHangAnhLuu < 256 ) {
            anhCatNgang[diaChiAnhLuu] = 0xff;
            anhCatNgang[diaChiAnhLuu+1] = 0xff;
            anhCatNgang[diaChiAnhLuu+2] = 0xff;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += 4;
         soCot++;
      }
   }
   else {
      printf( "taoAnhDoSangChoHangCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatNgang;
}

// ---- tạoẢnhĐộSángChoCộtCủaẢnh
//      các dộc (hướng dưới trên)
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot ) {
   
   unsigned char *anhCatDoc = malloc( beCao << 10 );   // * 256 << 2 = << 10
   
   if( anhCatDoc ) {

      unsigned int diaChiAnhGoc = soCot << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soHang = 0;
      while( soHang < beCao ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soHang << 10;
         unsigned int soCotAnhLuu = 0;
         while( soCotAnhLuu < giaTriAnhGoc ) {
            anhCatDoc[diaChiAnhLuu] = soCotAnhLuu << 3;
            anhCatDoc[diaChiAnhLuu+1] = soCotAnhLuu;
            anhCatDoc[diaChiAnhLuu+2] = soCotAnhLuu << 1;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         while( soCotAnhLuu < 256 ) {
            anhCatDoc[diaChiAnhLuu] = 0xff;
            anhCatDoc[diaChiAnhLuu+1] = 0xff;
            anhCatDoc[diaChiAnhLuu+2] = 0xff;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += beRong << 2;
         soHang++;
      }
   }
   else {
      printf( "taoAnhDoSangChoCotCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatDoc;
}


// tôMàuĐộSángẢnh
unsigned char *toMauDoSangAnh( unsigned char *anh, unsigned int beRong, unsigned int beCao ) {
   
   unsigned int diaChiCuoi = beRong*beCao << 2;
   unsigned char *anhToMau = malloc( diaChiCuoi );
   
   if( anhToMau ) {
      
      unsigned int diaChiAnh = 0;
      
      while( diaChiAnh < diaChiCuoi ) {
         unsigned char doSang = anh[diaChiAnh];
         anhToMau[diaChiAnh] = doSang << 3;
         anhToMau[diaChiAnh+1] = doSang;
         anhToMau[diaChiAnh+2] = doSang << 1;
         anhToMau[diaChiAnh+3] = 0xff;
         diaChiAnh += 4;
      }
   }
   else {
      printf( "toMauDoSangAnh: vấn đề tạo tô màu\n" );
   }
   
   return anhToMau;
}

void veDiemThichThu( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem *mangGocAnh, unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc ) {
   
   unsigned int mau = 0x404040b0;
   unsigned short banKinh = 8;

   Diem mangDiemThichThu[512];
   unsigned short soHang = 0;
   unsigned char soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soHang = beCaoAnhBoLoc >> 2;
   soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG+1].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG+1].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soHang = beCaoAnhBoLoc >> 1;
   soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG+2].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG+2].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soHang = (beCaoAnhBoLoc >> 2)*3;
   soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG+3].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG+3].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soHang = beCaoAnhBoLoc - 1;
   soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG+4].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG+4].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );

   // ====
   unsigned short soCot = 0;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soCot = beRongAnhBoLoc >> 2;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC+1].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC+1].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soCot = beRongAnhBoLoc >> 1;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC+2].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC+2].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );

   soCot = (beRongAnhBoLoc >> 2)*3;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC+3].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC+3].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soCot = beRongAnhBoLoc - 1;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC+4].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC+4].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
}
