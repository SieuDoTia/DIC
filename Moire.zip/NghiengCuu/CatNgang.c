/* CắtNgang.c */

// TOÀN BỘ NÀY ĐỂ NGHIÊN CỨU - KHÔNG CẦN CHO CHƯƠNG TRÌNH ĐỂ HOẠT ĐỘNG

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CatNgang.h"
#include "../HangSo.h"
#include "../PNG/PNG.h"
#include "../VeVatThe/ChepAnh.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../ToMauAnh/Diem.h"
#include "../TimNet/TimNet.h"
#include "../TimNet/Bezier.h"
#include "../TimNet/MaTran.h"

//#include "FFT_Moi.h"

#pragma mark ---- Cắt Ngang (CHO NGHIÊNG CỨU ẢNH)
//        |<------ r ------>|  |<------ r ------>|
//    +---------------------------------------------+
//    |                                             |
//    |                                             |
//    |                Ảnh 3 Chiều                  |
//    |                                             |
//    |                                             |
//    |                                             |
//  - |  +------------------+  +----+ +----+ +----+ |
//  ^ |  |                  |  |    | |    | |    | |
//  c |  |                  |  |    | |    | |    | |
//  v |  |                  |  |    | |    | |    | |
//  - |  +------------------+  +----+ +----+ +----+ |
//    |  +------------------+                       |
//    |  |                  |                       |
//    |  +------------------+                       |
//    |  +------------------+                       |
//    |  |                  |                       |
//    |  +------------------+                       |
//    |         ...                                  |
//    +---------------------------------------------+
//       |<256>||<256>||<256>|


/*
 Quét ngang +x và tìm điểm thấp và cao
 • Điểm thấp là màu giữa đoạn màu, điểm cao là kết thúc đoạn màu này và đầu đoạn màu tiếp
 • tô màu trong đoạn tùy vị trí tương đối với điểm thấp và điểm cao và giá trị đồ sáng của điểm ảnh
 • Đơn vị hóa độ cao và biến độ sáng dạng sin sang hàm bật một
 • chụ ý cách giữa điểm cao để biết khi nào cần lệt hướng tô màu?
 
 • sự di chuyển vị trí của điểm cao
 +---------------------+
 |                     |
 +------------->       |
 |                     |
 |                     |
 +---------------------+
 */

#define kCACH_GIUA 100 // cách giữa (điểm ảnh)

#define kANH_DO_SANG   0
#define kANH_CAT_NGANG 1
#define kANH_CAT_DOC   6
#define kSO_LUONG_ANH 11

//#define kTAN_SO_TOI_DA 20  // cho FFT

unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang );
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot );

void veAnhCatNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, Diem gocAnhDoSang,
                   unsigned short soHangCat, unsigned short x, unsigned y ) ;

void veAnhCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                 unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, Diem gocAnhDoSang,
                 unsigned short soCotCat, unsigned short x, unsigned y );


void veDiemThichThuNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhNgang,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soHang );

void veDiemThichThuDoc( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soCot );


void bezierToiUuChoCatNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                            unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soHang );
void bezierToiUuChoCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot );


// ---- tính ma trận
Vecto tinhPhepTuyenMatPhangToiUu( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem );
void tinhDoCongMatBezierToiUu_B2_quangDiem( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem,
                                           float *doCong_x, float *doCong_y);

// ---- vẽ ảnh 3 chiều
void veAnh3Chieu( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRong, unsigned int beCao,
             unsigned char giaTriToiNhat, unsigned char giaTriSangNhat, unsigned short x, unsigned short y );

unsigned char *veAnhDoSang( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int *beRongAnhXuat, unsigned int *beCaoAnhXuat,
                           unsigned char soLuongCatNgang, unsigned short soLuongCatDoc ) {

   *beRongAnhXuat = beRongAnhBoLoc + kCACH_GIUA*(soLuongCatDoc + 3) + 256*(soLuongCatDoc + 1);
   *beCaoAnhXuat = (beCaoAnhBoLoc << 2) + kCACH_GIUA*(soLuongCatNgang + 3) + 256*(soLuongCatNgang + 1);
   
   unsigned char *anhCatXuat = malloc( *beRongAnhXuat * *beCaoAnhXuat << 2);
   
   if( anhCatXuat != NULL ) {
      
      // ---- cho giữ vị trí các ảnh, giúp vẽ điểm thích thú trên sơ đồ
      Diem mangGocAnh[64];
   
      // ---- độ sáng
      unsigned char giaTriToiNhat;
      unsigned char giaTriSangNhat;
      unsigned char *anhDoSang = toMauDoSangAnhVaKiemGiaTriCuc( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, &giaTriToiNhat, &giaTriSangNhat );
      
      if( anhDoSang ) {
         
         // ---- chép ảnh độ sáng tô màu
         mangGocAnh[kANH_DO_SANG].x = kCACH_GIUA;
         mangGocAnh[kANH_DO_SANG].y = kCACH_GIUA*(soLuongCatNgang + 2) + 256*(soLuongCatNgang + 1);

         unsigned short x =  mangGocAnh[kANH_DO_SANG].x;
         unsigned short y =  mangGocAnh[kANH_DO_SANG].y;
         chepAnhVaoAnh( anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG].x, mangGocAnh[kANH_DO_SANG].y );
         veSoCai( "光度", x + 48, y + beCaoAnhBoLoc + 32, anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat );
  
         // ----  cắt ngang
         x = kCACH_GIUA;
         y = kCACH_GIUA;
         unsigned short soHangCat = 0;
         unsigned short buocCat = beCaoAnhBoLoc/soLuongCatNgang;

         unsigned char soCatNgang = 0;
         while( soCatNgang < soLuongCatNgang + 1 ) {
            mangGocAnh[kANH_CAT_NGANG+soCatNgang].x = x;
            mangGocAnh[kANH_CAT_NGANG+soCatNgang].y = y;
  
            veAnhCatNgang( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, mangGocAnh[kANH_DO_SANG], soHangCat, x, y );
            
            // ---- điểm thích thú
            veDiemThichThuNgang( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+soCatNgang], anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, soHangCat );

            bezierToiUuChoCatNgang( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+soCatNgang], anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, soHangCat );

            y += 256 + kCACH_GIUA;
            soHangCat += buocCat;
            soCatNgang++;
         }

         // ---- cắt dộc
         x = (kCACH_GIUA << 1) + beRongAnhBoLoc;
         y = kCACH_GIUA*(soLuongCatNgang + 2) + 256*(soLuongCatNgang + 1);
         unsigned short soCotCat = 0;
         buocCat = beRongAnhBoLoc/soLuongCatDoc;

         unsigned char soCatDoc = 0;
         while( soCatDoc < soLuongCatDoc + 1 ) {
            mangGocAnh[kANH_CAT_DOC+soCatDoc].x = x;
            mangGocAnh[kANH_CAT_DOC+soCatDoc].y = y;
            
            veAnhCatDoc( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, mangGocAnh[kANH_DO_SANG], soCotCat, x, y );
            
            // ---- điểm thích thú
            veDiemThichThuDoc( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_DOC+soCatDoc], anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, soCotCat );

            // ---- vẽ cong Bezier tương đương
            bezierToiUuChoCatDoc( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], x, y, anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, soCotCat );

            x += 256 + kCACH_GIUA;
            soCotCat += buocCat;
            soCatDoc++;
         }
         
         // ---- ảnh 3 chiểu
         x = kCACH_GIUA << 1;
         y = kCACH_GIUA*(soLuongCatNgang + 3) + 256*soLuongCatNgang + (beCaoAnhBoLoc << 1);
         veAnh3Chieu( anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, giaTriToiNhat, giaTriSangNhat, x, y );
         veSoCai( "光度3维", x, y + 300 + beCaoAnhBoLoc, anhCatXuat, *beRongAnhXuat, *beCaoAnhXuat );
         
         // ----
/*         unsigned int diaChiAnh = 0;
    
         unsigned char *anhThuNghiem = malloc( 200*200 << 2 );
         unsigned short soHang = 0;
         while( soHang < 200 ) {
            unsigned short soCot = 0;
            while( soCot < 200 ) {
               unsigned char giaTri = (soHang >> 1) + (soCot >> 1);
               anhThuNghiem[diaChiAnh] = giaTri;
               anhThuNghiem[diaChiAnh + 1] = giaTri;
               anhThuNghiem[diaChiAnh + 2] = giaTri;
               anhThuNghiem[diaChiAnh + 3] = 0xff;
               diaChiAnh += 4;
               soCot++;
            }
            soHang++;
         }
         luuAnhPNG_BGRO( "anhThuNghiem", anhThuNghiem, 200, 200 );
         
         x = 100;
         y = 100;
         tinhMatBezierToiUu_B2_quangDiem( anhThuNghiem, 200, 200, x, y, 75 );
         exit(0); */
      }
   }
   else {
      printf( "veAnhDoSang: SAI LẦM giành trí nhớ cho ảnh cắt nganh\n" );
   }
   return anhCatXuat;

}

void veAnhCatNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, Diem gocAnhDoSang,
                   unsigned short soHangCat, unsigned short x, unsigned y ) {
   
   Diem diem0;
   Diem diem1;
   diem0.x = 0;
   diem0.y = soHangCat;
   diem1.x = beRongAnhDoSang-1;
   diem1.y = soHangCat;

   // ---- vẽ nét trên ảnh sáng tô màu
   veDuong( anhDoSangToMau, beRongAnhDoSang, beCaoAnhDoSang, diem0, diem1, 0x80808080 );
   diem0.x += gocAnhDoSang.x;
   diem0.y += gocAnhDoSang.y;
   diem1.x += gocAnhDoSang.x;
   diem1.y += gocAnhDoSang.y;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diem0, diem1, 0x80808080 );
   
   // ---- vẽ số hàng cắt
   char dichNguocX = 8;
   if( soHangCat < 10 )
      dichNguocX += 16;
   else if( soHangCat < 100 )
      dichNguocX += 32;
   else if( soHangCat < 1000 )
      dichNguocX += 48;
   else
      dichNguocX += 64;
   veSoThapPhan( soHangCat, gocAnhDoSang.x - dichNguocX, gocAnhDoSang.y + soHangCat - 8, anhXuat, beRongAnhXuat, beCaoAnhXuat );

   // ---- vẽ ảnh cắt ngang
   unsigned char *anhCatNgang = taoAnhDoSangChoHangCuaAnh( anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soHangCat );
   if( anhCatNgang ) {
      chepAnhVaoAnh( anhCatNgang, beRongAnhDoSang, 256, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y );
      free( anhCatNgang );

      // ---- vẽ vị trí cắt
      veSoCai( "↔︎切画", x, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      veSoThapPhan( soHangCat, x + (beRongAnhDoSang >> 1) - 32, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   }

   // ---- tìm điểm thích thú
}


void veAnhCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, Diem gocAnhDoSang,
                   unsigned short soCotCat, unsigned short x, unsigned y ) {
   
   Diem diem0;
   Diem diem1;
   diem0.x = soCotCat;
   diem0.y = 0;
   diem1.x = soCotCat;
   diem1.y = beCaoAnhDoSang - 1;

   // ---- vẽ nét trên ảnh sáng tô màu
   veDuong( anhDoSangToMau, beRongAnhDoSang, beCaoAnhDoSang, diem0, diem1, 0x80808080 );
   diem0.x += gocAnhDoSang.x;
   diem0.y += gocAnhDoSang.y;
   diem1.x += gocAnhDoSang.x;
   diem1.y += gocAnhDoSang.y;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diem0, diem1, 0x80808080 );

   // ---- vẽ số hàng cắt
   char dichNguocX = 8;
   if( soCotCat < 10 )
      dichNguocX += 8;
   else if( soCotCat < 100 )
      dichNguocX += 32;
   else if( soCotCat < 1000 )
      dichNguocX += 48;
   else
      dichNguocX += 64;
   veSoThapPhan( soCotCat, gocAnhDoSang.x + soCotCat - dichNguocX, gocAnhDoSang.y - 40, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   
   // ---- vẽ ảnh cắt ngang
   unsigned char *anhCatDoc = taoAnhDoSangChoCotCuaAnh( anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soCotCat );
   if( anhCatDoc ) {
      chepAnhVaoAnh( anhCatDoc, 256, beCaoAnhDoSang, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y );
      free( anhCatDoc );
      
      // ---- vẽ vị trí cắt
      veSoCai( "↕︎切画", x, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      veSoThapPhan( soCotCat, x + 128 - 32, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   }
   
   // ---- tìm điểm thích thú
}


/* Để làm video cắt ngang, ĐỪNG BỎ CÁI NÀY
void luuCatNgangToanBoChoAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao ) {
   
   unsigned char *anhCatNgangTruoc = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, 0 );   // 256 << 2
   
   unsigned int soHangAnhGoc = 0;
   while( soHangAnhGoc < beCao ) {
      unsigned char *anhCatNgangSau = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangAnhGoc );   // 256 << 2
      
      char tenAnh[256];
      sprintf( tenAnh, "AnhCatNgang_%03d.png", soHangAnhGoc );
      //      printf( "Phân tích vận tốc trong ảnh: %s\n", tenAnh );
      //      phanTichVanTocGiuaHaiAnh( anhCatNgangTruoc, anhCatNgangSau, beRong, beCao );
      
      luuAnhPNG_BGRO( tenAnh, anhCatNgangSau, beRong, 256 );
      printf( "Luu anh: %s\n", tenAnh );
      soHangAnhGoc++;
      free( anhCatNgangSau );
   }
   printf( "kích cỡ: %d %d\n", beRong, 256 );
   
   free( anhCatNgangTruoc );
}

void luuCatNgangMotTamChoAnh( char *tenAnhCatNgang, unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHangCatNgang ) {
   
   unsigned char *anhCatNgang = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCatNgang );   // 256 << 2
   
   luuAnhPNG_BGRO( tenAnhCatNgang, anhCatNgang, beRong, 256 );
   
   free( anhCatNgang );
} */

// ---- tạoẢnhĐộSángChoHàngCủaẢnh
//      các ngang (hướng trái phải)
unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang ) {
   
   unsigned char *anhCatNgang = malloc( beRong << 10 );   // * 256 << 2 = << 10
   
   if( anhCatNgang ) {
      unsigned int diaChiAnhGoc = beRong*soHang << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soCot = 0;
      while( soCot < beRong ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soCot << 2;
         unsigned int soHangAnhLuu = 0;
         while( soHangAnhLuu < giaTriAnhGoc ) {
            anhCatNgang[diaChiAnhLuu] = soHangAnhLuu << 3;
            anhCatNgang[diaChiAnhLuu+1] = soHangAnhLuu;
            anhCatNgang[diaChiAnhLuu+2] = soHangAnhLuu << 1;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         while( soHangAnhLuu < 256 ) {
            anhCatNgang[diaChiAnhLuu] = 0xff;
            anhCatNgang[diaChiAnhLuu+1] = 0xff;
            anhCatNgang[diaChiAnhLuu+2] = 0xff;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += 4;
         soCot++;
      }
   }
   else {
      printf( "taoAnhDoSangChoHangCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatNgang;
}

// ---- tạoẢnhĐộSángChoCộtCủaẢnh
//      các dộc (hướng dưới trên)
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot ) {
   
   unsigned char *anhCatDoc = malloc( beCao << 10 );   // * 256 << 2 = << 10
   
   if( anhCatDoc ) {

      unsigned int diaChiAnhGoc = soCot << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soHang = 0;
      while( soHang < beCao ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soHang << 10;
         unsigned int soCotAnhLuu = 0;
         while( soCotAnhLuu < giaTriAnhGoc ) {
            anhCatDoc[diaChiAnhLuu] = soCotAnhLuu << 3;
            anhCatDoc[diaChiAnhLuu+1] = soCotAnhLuu;
            anhCatDoc[diaChiAnhLuu+2] = soCotAnhLuu << 1;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         while( soCotAnhLuu < 256 ) {
            anhCatDoc[diaChiAnhLuu] = 0xff;
            anhCatDoc[diaChiAnhLuu+1] = 0xff;
            anhCatDoc[diaChiAnhLuu+2] = 0xff;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += beRong << 2;
         soHang++;
      }
   }
   else {
      printf( "taoAnhDoSangChoCotCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatDoc;
}


// tôMàuĐộSángẢnh
unsigned char *toMauDoSangAnhVaKiemGiaTriCuc( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char *giaTriToiNhat, unsigned char *giaTriSangNhat ) {
   
   *giaTriToiNhat = 255;
   *giaTriSangNhat = 0;
   unsigned int diaChiCuoi = beRong*beCao << 2;
   unsigned char *anhToMau = malloc( diaChiCuoi );
   
   if( anhToMau ) {
      
      unsigned int diaChiAnh = 0;
      
      while( diaChiAnh < diaChiCuoi ) {
         // ---- lấy gíá trị từ kênh đỏ
         unsigned char doSang = anh[diaChiAnh];
         // ---- tô màu ảnh
         anhToMau[diaChiAnh] = doSang << 3;
         anhToMau[diaChiAnh+1] = doSang;
         anhToMau[diaChiAnh+2] = doSang << 1;
         anhToMau[diaChiAnh+3] = 0xff;
         
         // ---- kiếm giá trị cực
         if( doSang < *giaTriToiNhat )
            *giaTriToiNhat = doSang;
         if( doSang > *giaTriSangNhat )
            *giaTriSangNhat = doSang;
         
         diaChiAnh += 4;
      }
   }
   else {
      printf( "toMauDoSangAnh: vấn đề tạo tô màu\n" );
   }
   
   return anhToMau;
}

void veDiemThichThuNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, Diem gocAnhNgang,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soHang ) {
   
   unsigned int mau = 0x404040b0;
   unsigned short banKinh = 8;

   Diem mangDiemThichThu[512];
   unsigned char soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      short x = tamVongTron.x;
      short y = tamVongTron.y;
      
      // ---- vẽ vòng tròn trên ảnh độ sáng màu
      char xauTenDiem[256];
      sprintf( xauTenDiem, "↕︎%d-%d\n", soHang, soDiem );
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, x, y, banKinh, mau );
      veSoCai( xauTenDiem, tamVongTron.x + 16, tamVongTron.y - 16, anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc );
      
      // ---- vẽ vòng tròn trên ảnh độ sáng màu trong ảnh xuất
      x += gocAnhDoSang.x;
      y += gocAnhDoSang.y;
      veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, banKinh, mau );
      veSoCai( xauTenDiem, x + 16, y - 16, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      
      // ---- tính độ cong quanh điểm
      unsigned char cachXaQuanhDiem = 75;
      float doCongX;
      float doCongY;
      tinhDoCongMatBezierToiUu_B2_quangDiem( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, mangDiemThichThu[soDiem].x, mangDiemThichThu[soDiem].y, cachXaQuanhDiem, &doCongX, &doCongY );
      
      // ---- trính phép tuyến cho mặt phẳng tuyến điểm này
      cachXaQuanhDiem = 20;
      Vecto phepTuyen = tinhPhepTuyenMatPhangToiUu( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, mangDiemThichThu[soDiem].x, mangDiemThichThu[soDiem].y, cachXaQuanhDiem );
      x = tamVongTron.x + 20 + gocAnhDoSang.x;
      y = tamVongTron.y + 4 + gocAnhDoSang.y;
      char xauDoCong[256];
      sprintf( xauDoCong, "⌒ %5.3f; %5.3f\n", doCongX, doCongY );
      veSoCaiNho( xauDoCong, x, y, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      y += 10;
      sprintf( xauDoCong, "↑ %5.3f; %5.3f %5.3f\n", phepTuyen.x, phepTuyen.y, phepTuyen.z );
      veSoCaiNho( xauDoCong, x, y, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      y += 10;
      sprintf( xauDoCong, "光 %d\n", mangDiemThichThu[soDiem].doSang );
      veSoCaiNho( xauDoCong, x, y, anhXuat, beRongAnhXuat, beCaoAnhXuat );

      // ---- vẽ vòng tròn trên ảnh cắt ngang trong ảnh xuất
      tamVongTron = mangDiemThichThu[soDiem];
      x = gocAnhNgang.x + mangDiemThichThu[soDiem].x;
      y = gocAnhNgang.y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, banKinh, mau );
      printf( "%d  gocAnhNgang %d %d\n", soHang, gocAnhNgang.x, gocAnhNgang.y );
      veSoThapPhan( soDiem, x - 8, y + 12, anhXuat, beRongAnhXuat, beCaoAnhXuat );

      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );

}

void veDiemThichThuDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, Diem gocAnhDoc,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soCot ) {

   unsigned int mau = 0x404040b0;
   unsigned short banKinh = 8;

   Diem mangDiemThichThu[512];
   unsigned char soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      short x = tamVongTron.x;
      short y = tamVongTron.y;
      
      // ---- vẽ vòng tròn trên ảnh độ sáng màu
      char xauTenDiem[256];
      sprintf( xauTenDiem, "↕︎%d-%d\n", soCot, soDiem );
      veSoCai( xauTenDiem, tamVongTron.x + 16, tamVongTron.y - 16, anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc );
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, x, y, banKinh, mau );

      // ---- vẽ vòng tròn trên ảnh độ sáng màu trong ảnh xuất
      x += gocAnhDoSang.x;
      y += gocAnhDoSang.y;
      veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, banKinh, mau );
      veSoCai( xauTenDiem, x + 16, y - 16, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      
      // ---- vẽ vòng tròn trên ảnh cắt độc trong ảnh xuất
      x = gocAnhDoc.x + mangDiemThichThu[soDiem].doSang;
      y = gocAnhDoc.y + mangDiemThichThu[soDiem].y;
      veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, banKinh, mau );
      veSoThapPhan( soDiem, x + 12, y - 8, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soCot );
}



void bezierToiUuChoCatNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhNgang,
                            unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soHang ) {

   unsigned int mauVongTronDo = 0xff0000b0;
   unsigned int mauVongTronXanh = 0x0000ffb0;
   unsigned int mauNet = 0x000000b0;
   unsigned short banKinh = 6;
   
   unsigned short soLuongCong = beRongAnhBoLoc/200;
   unsigned short soLuongDiemAnhChoCong = beRongAnhBoLoc/soLuongCong;
   
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }

//   printf( " khoMaTran %d soLuongCong %d\n", khoMaTran, soLuongCong );

   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranCongToiUuB3_doanHang( maTran4x4, maTran4x2, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
//      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );

      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }

//   chieuMaTran( maTranGop, khoMaTran, khoMaTran );
//   chieuMaTran( vectoGop, 2, khoMaTran );
   // ---- giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
//      chiSo = 0;
//      while( chiSo < khoMaTran ) {
//         printf( "%d  %5.3f %5.3f\n", chiSo, vectoGop[mangThuTu[chiSo] << 1], vectoGop[(mangThuTu[chiSo] << 1) + 1] );
//         chiSo++;
//      }
      
      // ---- vẽ đường Bezier
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ giải
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0000f;
         bezier.diemQuanTri[0].y = 0.0f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.3333f;
         bezier.diemQuanTri[1].y = 0.0f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.6667f;
         bezier.diemQuanTri[2].y = 0.0f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;

         bezier.diemQuanTri[3].x = 1.0000f;
         bezier.diemQuanTri[3].y = 0.0f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         
         Vecto mangDiem3C[128];
         float thamSo = 0.0f;
         float buocThamSo = 0.03125f;
         unsigned char soLuongDiem = 0;
         while( thamSo <= 1.0f ) {
            mangDiem3C[soLuongDiem] = tinhViTriCongBezier3C_B3( &bezier, thamSo );
//            printf( " thamSo %5.3f:  %5.3f; %5.3f; %5.3f\n", thamSo, mangDiem3C[soLuongDiem].x, mangDiem3C[soLuongDiem].y, mangDiem3C[soLuongDiem].z );
            thamSo += buocThamSo;
            soLuongDiem++;
         }
         
//         printf( " soLuongDiem %d\n", soLuongDiem );
         
         Diem diemDau;
         Diem diemCuoi;
         unsigned short dichX = gocAnhNgang.x + soCong*soLuongDiemAnhChoCong;
         diemDau.x = soLuongDiemAnhChoCong*mangDiem3C[0].x + dichX;
         diemDau.y = 255.0f*mangDiem3C[0].z + gocAnhNgang.y;

         unsigned char soDiem = 1;
         while( soDiem < soLuongDiem ) {
            diemCuoi.x = soLuongDiemAnhChoCong*mangDiem3C[soDiem].x + dichX;
            diemCuoi.y = 255.0f*mangDiem3C[soDiem].z + gocAnhNgang.y;
//            printf( "soDiem %d  (%d; %d) --> (%d; %d)\n", soDiem, diemDau.x, diemDau.y , diemCuoi.x, diemCuoi.y );
            veDuong( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, diemDau, diemCuoi, mauNet );
            diemDau = diemCuoi;
            soDiem++;
         }
         
         // ---- tìm điểm nghiệm (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z_B3( &bezier, &nghiem0, &nghiem1 );
//         printf( "soLuongNghiem %d  %5.3f %5.3f\n", soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem == 1 ) {
            Diem tamVongTronChoAnhNgang;
            tamVongTronChoAnhNgang.x = nghiem0*soLuongDiemAnhChoCong + dichX;
            tamVongTronChoAnhNgang.y = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem0 ).z + gocAnhNgang.y;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = soHang + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronDo );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronXanh );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhNgang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronXanh );
            }
         }
         if( soLuongNghiem == 2 ) {
            Diem tamVongTronChoAnhNgang;
            tamVongTronChoAnhNgang.x = nghiem1*soLuongDiemAnhChoCong + dichX;
            tamVongTronChoAnhNgang.y = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem1 ).z + gocAnhNgang.y;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = soHang + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem1 );
            if( doCong > 0.0f ) {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronDo );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhNgang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronXanh );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronXanh );
            }
            
         }
         soCong++;
      }
      
   }

   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );
}


void bezierToiUuChoCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot ) {
   
   unsigned int mauVongTronDo = 0xff0000b0;
   unsigned int mauVongTronXanh = 0x0000ffb0;
   unsigned int mauNet = 0x000000b0;
   unsigned short banKinh = 6;

   unsigned short soLuongCong = beCaoAnhBoLoc/200;
   unsigned short soLuongDiemAnhChoCong = beCaoAnhBoLoc/soLuongCong;
 
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }

//   printf( " khoMaTran %d soLuongCong %d\n", khoMaTran, soLuongCong );
   
   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranCongToiUuB3_doanCot( maTran4x4, maTran4x2, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
//      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );
      
      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }
   
   // ---- giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
      // ---- vẽ đường Bezier
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ giải
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0f;
         bezier.diemQuanTri[0].y = 0.0000f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.0f;
         bezier.diemQuanTri[1].y = 0.3333f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.0f;
         bezier.diemQuanTri[2].y = 0.6667f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[3].x = 0.0f;
         bezier.diemQuanTri[3].y = 1.0000f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         
         Vecto mangDiem3C[128];
         float thamSo = 0.0f;
         float buocThamSo = 0.03125f;
         unsigned char soLuongDiem = 0;
         while( thamSo <= 1.0f ) {
            mangDiem3C[soLuongDiem] = tinhViTriCongBezier3C_B3( &bezier, thamSo );
//            printf( " thamSo %5.3f:  %5.3f; %5.3f; %5.3f\n", thamSo, mangDiem3C[soLuongDiem].x, mangDiem3C[soLuongDiem].y, mangDiem3C[soLuongDiem].z );
            thamSo += buocThamSo;
            soLuongDiem++;
         }
         
         Diem diemDau;
         Diem diemCuoi;
         unsigned short dichY = y + soCong*soLuongDiemAnhChoCong;
         diemDau.x = 255.0f*mangDiem3C[0].z + x;
         diemDau.y = soLuongDiemAnhChoCong*mangDiem3C[0].y + dichY;

         unsigned char soDiem = 1;
         while( soDiem < soLuongDiem ) {
            diemCuoi.x = 255.0f*mangDiem3C[soDiem].z + x;
            diemCuoi.y = soLuongDiemAnhChoCong*mangDiem3C[soDiem].y + dichY;
//            printf( "soDiem %d  (%d; %d) --> (%d; %d)\n", soDiem, diemDau.x, diemDau.y , diemCuoi.x, diemCuoi.y );
            veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, mauNet );
            diemDau = diemCuoi;
            soDiem++;
         }

         // ---- tìm điểm nghiệm (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z_B3( &bezier, &nghiem0, &nghiem1 );
//         printf( "soLuongNghiem %d  %5.3f %5.3f\n", soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem == 1 ) {
 
            Diem tamVongTronChoAnhDoc;
            tamVongTronChoAnhDoc.x = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem0 ).z + x;
            tamVongTronChoAnhDoc.y = nghiem0*soLuongDiemAnhChoCong + dichY;
//            printf( "nghiem0 %5.3f  soLuongDiemAnh %d  dichY %d\n", nghiem0, soLuongDiemAnhChoCong, dichY );
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = soCot + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.y;
//            printf( "tamVongTronChoAnhDoc %d %d   anhXuat beRong %d  beCao %d\n", tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, beRongAnhXuat, beCaoAnhXuat );
//            printf( "tamVongTronChoAnhDoSang %d %d  anhDoSang beRong %d  beCao %d  soCot %d  gocAnhDoSang.x %d\n", tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, beRongAnhBoLoc, beCaoAnhBoLoc,
//                   soCong, gocAnhDoSang.x );

            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronDo );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronXanh );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronXanh );
            }
         }

         if( soLuongNghiem == 2 ) {
            Diem tamVongTronChoAnhDoc;
            tamVongTronChoAnhDoc.x = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem1 ).z + x;
            tamVongTronChoAnhDoc.y = nghiem1*soLuongDiemAnhChoCong + dichY;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = soCot + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem1 );
            if( doCong > 0.0f ) {
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronDo );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronXanh );
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronXanh );
            }
            
         }

         soCong++;
      }
   }

   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );
}

#pragma mark ---- Mắt Phẳng Tối Ưu

// - Cộng thức cho mắt phẳng
// Ax + By + Cz = D
// đặt C = 1
// Ax + By + z = D
// Ax + By + z – D = 0

/*
 - Hàm sai lầm
 E(A, B, D) = ++{i = 0 → m} A•x_i + B•y_i – D + z_i
 
 - Hàm sai lầm bình phương
 E(A, B, D) = [++{i = 0 → m} A•x_i + B•y_i – D + z_i]²
 
 - Đạo hàm sai lầm bình phương A, B, C, D
 ∂E/∂A = 2[++{i = 0 → m} A•x_i + B•y_i – D + z_i]•x_i = 0
 ∂E/∂B = 2[++{i = 0 → m} A•x_i + B•y_i – D + z_i]•y_i = 0
 ∂E/∂D = –2[++{i = 0 → m} A•x_i + B•y_i – D + z_i]•1 = 0
 
 - Rút gọn:
 ∂E/∂A = [++{i = 0 → m} A•x_i + B•y_i – D + z_i]•x_i = 0
 ∂E/∂B = [++{i = 0 → m} A•x_i + B•y_i – D + z_i]•y_i = 0
 ∂E/∂D = –[++{i = 0 → m} A•x_i + B•y_i – D + z_i] = 0
 */

Vecto tinhPhepTuyenMatPhangToiUu( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem ) {

   Vecto phepTuyen;
   phepTuyen.x = 0.0f;
   phepTuyen.y = 0.0f;
   phepTuyen.z = 0.0f;

   if( x > beRongAnhBoLoc ) {
      printf( "CatNgang: tinhMatPhangToiUu: x ở ngoài phạm vi (%d > %d)\n", x, beRongAnhBoLoc );
      return phepTuyen;
   }
   else if( x < 0 ) {
      printf( "CatNgang: tinhMatPhangToiUu: x ở ngoài phạm vi (%d < 0)\n", x );
      return phepTuyen;
   }
   
   if( y > beCaoAnhBoLoc ) {
      printf( "CatNgang: tinhMatPhangToiUu: y ở ngoài phạm vi (%d > %d)\n", y, beCaoAnhBoLoc );
      return phepTuyen;
   }
   else if( y < 0 ) {
      printf( "CatNgang: tinhMatPhangToiUu: x ở ngoài phạm vi (%d < 0)\n", y );
      return phepTuyen;
   }

   // ---- tính cột và hàng quanh điểm
   short soCotDau = x - cachQuanhDiem;
   short soCotCuoi = x + cachQuanhDiem + 1;
   short soHangDau = y - cachQuanhDiem;
   short soHangCuoi = y + cachQuanhDiem + 1;
   
   // ---- không cho ra ngoài phạm vi ảnh
   if( soCotDau < 0 )
      soCotDau = 0;
   if( soCotCuoi >= beRongAnhBoLoc )
      soCotCuoi = beRongAnhBoLoc - 1;
   
   if( soHangDau < 0 )
      soHangDau = 0;
   if( soHangCuoi >= beCaoAnhBoLoc )
      soHangCuoi = beCaoAnhBoLoc - 1;

   // ---- tính ma trận
   float heSoDonViHoa_x = 1.0f/(soCotCuoi - soCotDau);  // trừ một cho t đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_y = 1.0f/(soHangCuoi - soHangDau);  // trừ một cho u đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_z = 1.0f/255.0f;

   float maTranMatPhang[9] = {0.0f, 0.0f, 0.0f,  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
   float vectoGiai[3] = {0.0f, 0.0f, 0.0f};

   
   // ---- tính ma trận
   unsigned short soHang = soHangDau;
   while( soHang < soHangCuoi ) {
  
      float y = (float)(soHang - soHangDau)*heSoDonViHoa_y;
      
      unsigned short soCot = soCotDau;
      unsigned int diaChiAnh = (soHang*beRongAnhBoLoc + soCot) << 2;

      while( soCot < soCotCuoi ) {
         float x = (float)(soCot - soCotDau)*heSoDonViHoa_x;
         float z = anhBoLoc[diaChiAnh]*heSoDonViHoa_z;
  
         maTranMatPhang[0] += x*x;
         maTranMatPhang[1] += x*y;
         maTranMatPhang[2] -= x;
         
         maTranMatPhang[3] += y*x;
         maTranMatPhang[4] += y*y;
         maTranMatPhang[5] -= y;
         
         maTranMatPhang[6] -= x;
         maTranMatPhang[7] -= y;
         maTranMatPhang[8] += 1;
         
         vectoGiai[0] -= z*x;
         vectoGiai[1] -= z*y;
         vectoGiai[2] += z;

         diaChiAnh += 4;
         soCot++;
      }

      soHang++;
   }


//   chieuMaTran( maTranMatPhang, 3, 3 );
   
   unsigned char mangThuTu[3] = {0, 1, 2};
   unsigned char coNghiem = khuMaTran( maTranMatPhang, 3, 3, vectoGiai, 3, 1, mangThuTu );

   if( coNghiem ) {
      tinhNghiem( maTranMatPhang, 3, 3, vectoGiai, 3, 1, mangThuTu );
      
      // ---- nghiệm: A, B, D  -> Ax + By + 1z – D = 0
      float nghiem[3];
      nghiem[0] =  vectoGiai[mangThuTu[0]]*(soCotCuoi - soCotDau);
      nghiem[1] =  vectoGiai[mangThuTu[1]]*(soHangCuoi - soHangDau);
      nghiem[2] =  vectoGiai[mangThuTu[2]]*255.0f;

//      printf( "CatNgang: tinhMatPhangToiUu: nghiệm %5.3f %5.3f %5.3f\n", nghiem[0], nghiem[1], nghiem[2] );
      // ---- phép tuyến

      phepTuyen.x = nghiem[0];
      phepTuyen.y = nghiem[1];
      phepTuyen.z = 1.0f;
      
      float doLon = sqrtf( phepTuyen.x*phepTuyen.x + phepTuyen.y*phepTuyen.y + phepTuyen.z*phepTuyen.z );
      if( doLon != 0.0f ) {
         phepTuyen.x = phepTuyen.x/doLon;
         phepTuyen.y = phepTuyen.y/doLon;
         phepTuyen.z = phepTuyen.z/doLon;
      }
//      printf( "CatNgang: tinhMatPhangToiUu: độLớn %5.3f  phép tuyến %5.3f %5.3f %5.3f\n", doLon, phepTuyen.x, phepTuyen.y, phepTuyen.z );
      

   }
   else
      printf( "CatNgang: tinhMatPhangToiUu: SAI LẦM ma trận không có nghiệm\n" );
   
   return phepTuyen;
}


#pragma mark ---- Mặt Bezier Tối Ưu
void tinhDoCongMatBezierToiUu_B2_quangDiem( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem,
                                           float *doCong_x, float *doCong_y) {
   
   if( x > beRongAnhBoLoc ) {
      printf( "CatNgang: mat Bezier B2: x ở ngoài phạm vi (%d > %d)\n", x, beRongAnhBoLoc );
      return;
   }
   else if( x < 0 ) {
      printf( "CatNgang: mat Bezier B2: x ở ngoài phạm vi (%d < 0)\n", x );
      return;
   }
   
   if( y > beCaoAnhBoLoc ) {
      printf( "CatNgang: mat Bezier B2: y ở ngoài phạm vi (%d > %d)\n", y, beCaoAnhBoLoc );
      return;
   }
   else if( y < 0 ) {
      printf( "CatNgang: mat Bezier B2: x ở ngoài phạm vi (%d < 0)\n", y );
      return;
   }

   unsigned char mangThuTu[] = {0, 1, 2, 3, 4, 5, 6, 7, 8};
   float maTranBezier[81];
   float vectoGiai[27];
   
   // ---- tính cột và hàng quanh điểm
   short soCotDau = x - cachQuanhDiem;
   short soCotCuoi = x + cachQuanhDiem + 1;
   short soHangDau = y - cachQuanhDiem;
   short soHangCuoi = y + cachQuanhDiem + 1;

   // ---- không cho ra ngoài phạm vi ảnh
   if( soCotDau < 0 )
      soCotDau = 0;
   if( soCotCuoi >= beRongAnhBoLoc )
      soCotCuoi = beRongAnhBoLoc - 1;
   
   if( soHangDau < 0 )
      soHangDau = 0;
   if( soHangCuoi >= beCaoAnhBoLoc )
      soHangCuoi = beCaoAnhBoLoc - 1;

   tinhMaTranMatToiUuB2_choDienTich( maTranBezier, vectoGiai, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCotDau, soCotCuoi, soHangDau, soHangCuoi );
//   chieuMaTran( maTranBezier, 9, 9 );
//   chieuMaTran( vectoGiai, 3, 9 );

   unsigned char coNghiem = khuMaTran( maTranBezier, 9, 9, vectoGiai, 9, 3, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranBezier, 9, 9, vectoGiai, 9, 3, mangThuTu );
      
      MatBezierB2 matBezierB2;
      matBezierB2.diemQuanTri[0].x = vectoGiai[mangThuTu[0]*3];
      matBezierB2.diemQuanTri[0].y = vectoGiai[mangThuTu[0]*3+1];
      matBezierB2.diemQuanTri[0].z = vectoGiai[mangThuTu[0]*3+2];
      
      matBezierB2.diemQuanTri[1].x = vectoGiai[mangThuTu[1]*3];
      matBezierB2.diemQuanTri[1].y = vectoGiai[mangThuTu[1]*3+1];
      matBezierB2.diemQuanTri[1].z = vectoGiai[mangThuTu[1]*3+2];
      
      matBezierB2.diemQuanTri[2].x = vectoGiai[mangThuTu[2]*3];
      matBezierB2.diemQuanTri[2].y = vectoGiai[mangThuTu[2]*3+1];
      matBezierB2.diemQuanTri[2].z = vectoGiai[mangThuTu[2]*3+2];
      
      // ----
      matBezierB2.diemQuanTri[3].x = vectoGiai[mangThuTu[3]*3];
      matBezierB2.diemQuanTri[3].y = vectoGiai[mangThuTu[3]*3+1];
      matBezierB2.diemQuanTri[3].z = vectoGiai[mangThuTu[3]*3+2];
      
      matBezierB2.diemQuanTri[4].x = vectoGiai[mangThuTu[4]*3];
      matBezierB2.diemQuanTri[4].y = vectoGiai[mangThuTu[4]*3+1];
      matBezierB2.diemQuanTri[4].z = vectoGiai[mangThuTu[4]*3+2];
      
      matBezierB2.diemQuanTri[5].x = vectoGiai[mangThuTu[5]*3];
      matBezierB2.diemQuanTri[5].y = vectoGiai[mangThuTu[5]*3+1];
      matBezierB2.diemQuanTri[5].z = vectoGiai[mangThuTu[5]*3+2];
      
      // ----
      matBezierB2.diemQuanTri[6].x = vectoGiai[mangThuTu[6]*3];
      matBezierB2.diemQuanTri[6].y = vectoGiai[mangThuTu[6]*3+1];
      matBezierB2.diemQuanTri[6].z = vectoGiai[mangThuTu[6]*3+2];
      
      matBezierB2.diemQuanTri[7].x = vectoGiai[mangThuTu[7]*3];
      matBezierB2.diemQuanTri[7].y = vectoGiai[mangThuTu[7]*3+1];
      matBezierB2.diemQuanTri[7].z = vectoGiai[mangThuTu[7]*3+2];
      
      matBezierB2.diemQuanTri[8].x = vectoGiai[mangThuTu[8]*3];
      matBezierB2.diemQuanTri[8].y = vectoGiai[mangThuTu[8]*3+1];
      matBezierB2.diemQuanTri[8].z = vectoGiai[mangThuTu[8]*3+2];
      
//      printf( "tinhMatBezierToiUu_B2_quangDiem:\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n   %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n",
//             matBezierB2.diemQuanTri[0].x, matBezierB2.diemQuanTri[0].y, matBezierB2.diemQuanTri[0].z,
//             matBezierB2.diemQuanTri[1].x, matBezierB2.diemQuanTri[1].y, matBezierB2.diemQuanTri[1].z,
//             matBezierB2.diemQuanTri[2].x, matBezierB2.diemQuanTri[2].y, matBezierB2.diemQuanTri[2].z,
//             matBezierB2.diemQuanTri[3].x, matBezierB2.diemQuanTri[3].y, matBezierB2.diemQuanTri[3].z,
//             matBezierB2.diemQuanTri[4].x, matBezierB2.diemQuanTri[4].y, matBezierB2.diemQuanTri[4].z,
//             matBezierB2.diemQuanTri[5].x, matBezierB2.diemQuanTri[5].y, matBezierB2.diemQuanTri[5].z,
//             matBezierB2.diemQuanTri[6].x, matBezierB2.diemQuanTri[6].y, matBezierB2.diemQuanTri[6].z,
//             matBezierB2.diemQuanTri[7].x, matBezierB2.diemQuanTri[7].y, matBezierB2.diemQuanTri[7].z,
//             matBezierB2.diemQuanTri[8].x, matBezierB2.diemQuanTri[8].y, matBezierB2.diemQuanTri[8].z
 //            );
   
      
      float t = (float)x/(float)(soCotCuoi- soCotDau);
      float u = (float)y/(float)(soHangCuoi- soHangDau);
      tinhDoCongTaiHaiThamSo_z_B2( &matBezierB2, t, u, doCong_x, doCong_y );
      
//      printf( "  B2 doCong %5.3f %5.3f -> doLon %5.3f\n", doCong_t, doCong_u, sqrtf(doCong_t*doCong_t + doCong_u*doCong_u ));

   }
}

/* #pragma mark ---- Mặt Bezier Tối Ưu Bật 2
 #define kCACH_GOP_DIEM 20

void tinhDoCongTaiDiem( unsigned char *anh, unsigned int beRong, unsigned int beCao ) {
   
   float maTranMatBezier[81];
   float vectoGiai[27];
   tinhMaTranMatToiUuB2_chiDienTich( maTranMatBezier, fvectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCotDau, unsigned int soCotCuoi, unsigned int soHangDau, unsigned int soHangCuoi )
}
 */

#pragma mark ---- VẼ ẢNH 3 CHIỀU
void veChuNhatCungDoCao( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY, float doCao,
                        float *diem0, float *diem1, float *diem2, float *diem3, float *maTranBienHoa );
void veNetGiuaHaiDiem( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY,
                      float *diem0, float *diem1, float *maTranBienHoa, unsigned int mauNet );

void veAnh3Chieu( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRong, unsigned int beCao,
        unsigned char giaTriToiNhat, unsigned char giaTriSangNhat, unsigned short x, unsigned short y ) {

   unsigned char chenhLechDoSang = giaTriSangNhat - giaTriToiNhat;
   
   // ---- không chênh lệch cho nó qúa nhỏ
   if( chenhLechDoSang < 10 )
      chenhLechDoSang = 10;
   
//   printf( " giaTriToiNhat %d  sangNhat %d  chenLech %d\n", giaTriToiNhat, giaTriSangNhat, chenhLechDoSang );
   
   // ---- tính biến hóa
   float phongToZ = 200.0f/chenhLechDoSang;

   float maTranPhongTo[16] = {1.5f, 0.0f, 0.0f, 0.0f,   0.0f, 2.0f, 0.0f, 0.0f,   0.0f, 0.0f, phongToZ, 0.0f,  0.0f, 0.0f, 0.0f, 1.0f};
   float maTranXoayTrucX[16];
   float maTranXoayTrucZ[16];
   float maTranBienHoa0[16];
   float maTranBienHoa1[16];
   
   maTranQuayQuanhTrucZ( maTranXoayTrucZ, 3.14159f*0.1f );
   maTranQuayQuanhTrucX( maTranXoayTrucX, 3.14159f*0.33333f );
   nhanMaTranVoiMaTranVaBoVaoKetQua4x4( maTranXoayTrucZ, maTranXoayTrucX, maTranBienHoa0 );
   nhanMaTranVoiMaTranVaBoVaoKetQua4x4( maTranPhongTo, maTranBienHoa0, maTranBienHoa1 );
   
   // ---- vẽ khung đấy không gian
   float diem0[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
   float diem1[4] = { beRong, 0.0f, 0.0f, 1.0f };
   float diem2[4] = { 0.0f, beCao, 0.0f, 1.0f };
   float diem3[4] = { beRong, beCao, 0.0f, 1.0f };
   
   veChuNhatCungDoCao( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, 0, diem0, diem1, diem2, diem3, maTranBienHoa1 );
   
   // ---- vẽ nét khung phía sau
   diem2[2] = 0.0f;
   float diemCao2[4] = { diem2[0], diem2[1], 255.0f, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diemCao2, maTranBienHoa1, 0x30303080 );
   
   diem3[2] = 0.0f;
   float diemCao3[4] = { diem3[0], diem3[1], 255.0f, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem3, diemCao3, maTranBienHoa1, 0x30303080 );


   // ---- các nét mức cao ớ phía sau
   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );

   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );

   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );


   // ---- vẽ ảnh 3 chiều
   chepAnhVaoAnhVoiMaTran_dungDoSangChoZ( anhDoSang, anhDoSangToMau, beRong, beCao, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, maTranBienHoa1 );

   // ----
   veChuNhatCungDoCao( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, 255, diem0, diem1, diem2, diem3, maTranBienHoa1 );
   
   diem0[2] = 0;
   float diemCao0[4] = { diem0[0], diem0[1], 255.0f, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diemCao0, maTranBienHoa1, 0x30303080 );
   
   diem1[2] = 0;
   float diemCao1[4] = { diem1[0], diem1[1], 255.0f, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem1, diemCao1, maTranBienHoa1, 0x30303080 );

}

void veChuNhatCungDoCao( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY, float doCao,
                        float *diem0, float *diem1, float *diem2, float *diem3, float *maTranBienHoa ) {
   
   diem0[2] = doCao;
   diem1[2] = doCao;
   diem2[2] = doCao;
   diem3[2] = doCao;
   
   float diemBienHoa0[4];
   float diemBienHoa1[4];
   float diemBienHoa2[4];
   float diemBienHoa3[4];
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem0, maTranBienHoa, diemBienHoa0 );
   diemBienHoa0[0] += dichX;
   diemBienHoa0[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem1, maTranBienHoa, diemBienHoa1 );
   diemBienHoa1[0] += dichX;
   diemBienHoa1[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem2, maTranBienHoa, diemBienHoa2 );
   diemBienHoa2[0] += dichX;
   diemBienHoa2[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem3, maTranBienHoa, diemBienHoa3 );
   diemBienHoa3[0] += dichX;
   diemBienHoa3[1] += dichY;
   
   // ----
   unsigned int mauNet = 0x30303080;
   Diem diemDauNet;
   Diem diemCuoiNet;
   //
   diemDauNet.x = diemBienHoa0[0];
   diemDauNet.y = diemBienHoa0[1];
   diemCuoiNet.x = diemBienHoa1[0];
   diemCuoiNet.y = diemBienHoa1[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa3[0];
   diemCuoiNet.y = diemBienHoa3[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa2[0];
   diemCuoiNet.y = diemBienHoa2[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa0[0];
   diemCuoiNet.y = diemBienHoa0[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
}

void veNetGiuaHaiDiem( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY,
                        float *diem0, float *diem1, float *maTranBienHoa, unsigned int mauNet ) {
   

   
   float diemBienHoa0[4];
   float diemBienHoa1[4];
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem0, maTranBienHoa, diemBienHoa0 );
   diemBienHoa0[0] += dichX;
   diemBienHoa0[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem1, maTranBienHoa, diemBienHoa1 );
   diemBienHoa1[0] += dichX;
   diemBienHoa1[1] += dichY;
   
   // ----
   Diem diemDauNet;
   Diem diemCuoiNet;
   //
   diemDauNet.x = diemBienHoa0[0];
   diemDauNet.y = diemBienHoa0[1];
   diemCuoiNet.x = diemBienHoa1[0];
   diemCuoiNet.y = diemBienHoa1[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
}


void hamX( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot ) {
   
}
