/* CắtNgang.c */

// TOÀN BỘ NÀY ĐỂ NGHIÊN CỨU - KHÔNG CẦN CHO CHƯƠNG TRÌNH ĐỂ HOẠT ĐỘNG

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CatNgang.h"
#include "../HangSo.h"
#include "../PNG/PNG.h"
#include "../VeVatThe/ChepAnh.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../ToMauAnh/Diem.h"
#include "../TimNet/TimNet.h"
#include "../TimNet/Bezier.h"
#include "../TimNet/MaTran.h"

//#include "FFT_Moi.h"

#pragma mark ---- Cắt Ngang (CHO NGHIÊNG CỨU ẢNH)
//        |<------ r ------>|  |<------ r ------>|
//    +--------------------------------------------+
//    |                                            |
//    |                                            |
//    |                                            |
//    |                                            |
//    |                                            |
//    |                                            |
//  - |  +------------------+  +-----------------+ |
//  ^ |  |                  |  +-----------------+ |
//  c |  |                  |  +-----------------+ |
//  v |  |                  |  +-----------------+ |
//  - |  +------------------+  +-----------------+ |
//    |  +----+ +----+ +----+                      |
//    |  |    | |    | |    |                      |
//    |  |    | |    | |    |                      |
//    |  |    | |    | |    |                      |
//    |  +----+ +----+ +----+                      |
//    +--------------------------------------------+
//       |<256>||<256>||<256>|


/*
 Quét ngang +x và tìm điểm thấp và cao
 • Điểm thấp là màu giữa đoạn màu, điểm cao là kết thúc đoạn màu này và đầu đoạn màu tiếp
 • tô màu trong đoạn tùy vị trí tương đối với điểm thấp và điểm cao và giá trị đồ sáng của điểm ảnh
 • Đơn vị hóa độ cao và biến độ sáng dạng sin sang hàm bật một
 • chụ ý cách giữa điểm cao để biết khi nào cần lệt hướng tô màu?
 
 • sự di chuyển vị trí của điểm cao
 +---------------------+
 |                     |
 +------------->       |
 |                     |
 |                     |
 +---------------------+
 */

#define kCACH_GIUA 100 // cách giữa (điểm ảnh)

#define kANH_DO_SANG   0
#define kANH_CAT_NGANG 1
#define kANH_CAT_DOC   6
#define kSO_LUONG_ANH 11

//#define kTAN_SO_TOI_DA 20  // cho FFT

unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang );
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot );
void veDiemThichThu( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem *mangGocAnh,
                    unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc );
void bezierToiUuChoCatNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                            unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soHang );
void bezierToiUuChoCatDoc( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhNgang,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot );

void veAnh3D( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRong, unsigned int beCao,
        unsigned char giaTriToiNhat, unsigned char giaTriSangNhat );

unsigned char *veAnhDoSang( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhCatNgang, unsigned int *beCaoAnhCatNgang ) {

   *beRongAnhCatNgang = (beRong << 1) + 3*kCACH_GIUA;
   *beCaoAnhCatNgang = (beCao << 2) + (kCACH_GIUA << 2);
   
   unsigned char *anhCatNgang = malloc( *beRongAnhCatNgang * *beCaoAnhCatNgang << 2);
   
   if( anhCatNgang != NULL ) {
      
      // ---- cho giữ vị trí các ảnh, giúp vẽ điểm thích thú trên sơ đồ
      Diem mangGocAnh[kSO_LUONG_ANH];
   
      // ---- độ sáng
      unsigned char giaTriToiNhat;
      unsigned char giaTriSangNhat;
      unsigned char *anhDoSang = toMauDoSangAnhVaKiemGiaTriCuc( anhGoc, beRong, beCao, &giaTriToiNhat, &giaTriSangNhat );
      
      if( anhDoSang ) {
         unsigned short x = kCACH_GIUA;
         unsigned short y = (kCACH_GIUA << 1) + beCao;
         mangGocAnh[kANH_DO_SANG].x = x;
         mangGocAnh[kANH_DO_SANG].y = y;

         // ---- vẽ các đường cắt ngang
         Diem diem0;
         Diem diem1;
         diem0.x = 0;
         diem0.y = 0;
         diem1.x = beRong-1;
         diem1.y = 0;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.y = beCao >> 2;
         diem1.y = diem0.y;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.y = beCao >> 1;
         diem1.y = diem0.y;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.y = (beCao >> 2)*3;
         diem1.y = diem0.y;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.y = beCao - 1;
         diem1.y = diem0.y;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         
         // ---- vẽ các đường cắt dộc
         diem0.x = 0;
         diem0.y = 0;
         diem1.x = 0;
         diem1.y = beCao - 1;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.x = beRong >> 2;
         diem1.x = diem0.x;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.x = beRong >> 1;
         diem1.x = diem0.x;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.x = (beRong >> 2)*3;
         diem1.x = diem0.x;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );
         diem0.x = beRong - 1;
         diem1.x = diem0.x;
         veDuong( anhDoSang, beRong, beCao, diem0, diem1, 0x80808080 );

         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSang, beRong, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );

         // ---- thông tin về cột cắt ảnh
         unsigned short soCot = 0;
         veSoThapPhan( soCot, x - 8, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soCot = beRong >> 2;
         veSoThapPhan( soCot, x - 24 + soCot, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soCot = beRong >> 1;
         veSoThapPhan( beRong >> 1, x - 24 + soCot, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soCot = (beRong >> 2)*3;
         veSoThapPhan( soCot, x - 24 + soCot, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soCot = beRong-1;
         veSoThapPhan( soCot, x - 24 + soCot, y - 24, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         
         // ---- thông tin về hàng cắt ảnh
         unsigned short soHang = 0;
         veSoThapPhan( 0, x - 24, y - 8, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soHang = beCao >> 2;
         veSoThapPhan( soHang, x - 54, y - 8 + soHang, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soHang = (beCao >> 1);
         veSoThapPhan( soHang, x - 54, y - 8 + soHang, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soHang = (beCao >> 2)*3;
         veSoThapPhan( soHang, x - 54, y - 8 + soHang, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         soHang = beCao - 1;
         veSoThapPhan( soHang, x - 54, y - 8 + soHang, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
      }

      // ----  cắt ngang
      unsigned short x = (kCACH_GIUA << 1) + beRong;
      unsigned short y = kCACH_GIUA;
      mangGocAnh[kANH_CAT_NGANG].x = x;
      mangGocAnh[kANH_CAT_NGANG].y = y;
   
      unsigned short soHangCat = 0;
      unsigned char *anhCatNgang0 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang0 ) {
         chepAnhVaoAnh( anhCatNgang0, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang0 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         y += 256 + kCACH_GIUA;
      }

      // ----
      mangGocAnh[kANH_CAT_NGANG+1].x = x;
      mangGocAnh[kANH_CAT_NGANG+1].y = y;
   
      soHangCat = beCao >> 2;
      unsigned char *anhCatNgang1 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang1 ) {
         chepAnhVaoAnh( anhCatNgang1, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang1 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         y += 256 + kCACH_GIUA;
      }
   
      // ----
      mangGocAnh[kANH_CAT_NGANG+2].x = x;
      mangGocAnh[kANH_CAT_NGANG+2].y = y;

      soHangCat = beCao >> 1;
      unsigned char *anhCatNgang2 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang2 ) {
         chepAnhVaoAnh( anhCatNgang2, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang2 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         y += 256 + kCACH_GIUA;
      }

      // ----
      mangGocAnh[kANH_CAT_NGANG+3].x = x;
      mangGocAnh[kANH_CAT_NGANG+3].y = y;

      soHangCat = (beCao >> 2)*3;
      unsigned char *anhCatNgang3 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang3 ) {
         chepAnhVaoAnh( anhCatNgang3, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang3 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         y += 256 + kCACH_GIUA;
      }

      // ----
      mangGocAnh[kANH_CAT_NGANG+4].x = x;
      mangGocAnh[kANH_CAT_NGANG+4].y = y;

      soHangCat = beCao-1;
      unsigned char *anhCatNgang4 = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCat );
      if( anhCatNgang4 ) {
         chepAnhVaoAnh( anhCatNgang4, beRong, 256, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatNgang4 );
         // ---- in số hàng cắt ngang
         veSoThapPhan( soHangCat, x + (beRong >> 1) - 32, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
      }

      // ----  cắt dộc
      x = kCACH_GIUA;
      y = kCACH_GIUA;
      mangGocAnh[kANH_CAT_DOC].x = x;
      mangGocAnh[kANH_CAT_DOC].y = y;
      
      unsigned short soCotCat = 0;
      unsigned char *anhCatCot0 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot0 ) {
         chepAnhVaoAnh( anhCatCot0, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot0 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         x += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_DOC+1].x = x;
      mangGocAnh[kANH_CAT_DOC+1].y = y;

      soCotCat = beRong >> 2;
      unsigned char *anhCatCot1 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot1 ) {
         chepAnhVaoAnh( anhCatCot1, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot1 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         x += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_DOC+2].x = x;
      mangGocAnh[kANH_CAT_DOC+2].y = y;

      soCotCat = beRong >> 1;
      unsigned char *anhCatCot2 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot2 ) {
         chepAnhVaoAnh( anhCatCot2, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot2 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         x += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_DOC+3].x = x;
      mangGocAnh[kANH_CAT_DOC+3].y = y;
      
      soCotCat = (beRong >> 2)*3;
      unsigned char *anhCatCot3 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot3 ) {
         chepAnhVaoAnh( anhCatCot3, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot3 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
         x += 256 + kCACH_GIUA;
      }
      
      mangGocAnh[kANH_CAT_DOC+4].x = x;
      mangGocAnh[kANH_CAT_DOC+4].y = y;
      
      soCotCat = beRong-1;
      unsigned char *anhCatCot4 = taoAnhDoSangChoCotCuaAnh( anhGoc, beRong, beCao, soCotCat );
      if( anhCatCot4 ) {
         chepAnhVaoAnh( anhCatCot4, 256, beCao, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, x, y );
         free( anhCatCot4 );
         // ---- in số cột cắt dộc
         veSoThapPhan( soCotCat, x + 116, y - 32, anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang );
      }
      
      // ---- điểm thích thú
      veDiemThichThu( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh, anhGoc, anhDoSang, beRong, beCao );
      
      // ---- vẽ cong Bezier tương đương
      bezierToiUuChoCatNgang( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG], anhGoc, anhDoSang, beRong, beCao, 0 );
      bezierToiUuChoCatNgang( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+1], anhGoc, anhDoSang, beRong, beCao, beCao >> 2 );
      bezierToiUuChoCatNgang( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+2], anhGoc, anhDoSang, beRong, beCao, beCao >> 1 );
      bezierToiUuChoCatNgang( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+3], anhGoc, anhDoSang, beRong, beCao, (beCao >> 2)*3 );
      bezierToiUuChoCatNgang( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+4], anhGoc, anhDoSang, beRong, beCao, beCao - 1 );
      
      bezierToiUuChoCatDoc( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_DOC], anhGoc, anhDoSang, beRong, beCao, 0 );
      bezierToiUuChoCatDoc( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_DOC+1], anhGoc, anhDoSang, beRong, beCao, beRong >> 2 );
      bezierToiUuChoCatDoc( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_DOC+2], anhGoc, anhDoSang, beRong, beCao, beRong >> 1 );
      bezierToiUuChoCatDoc( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_DOC+3], anhGoc, anhDoSang, beRong, beCao, (beRong >> 2)*3 );
      bezierToiUuChoCatDoc( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_DOC+4], anhGoc, anhDoSang, beRong, beCao, beRong - 1  );
      
      // ---- ảnh 3 chiểu
      veAnh3D( anhCatNgang, *beRongAnhCatNgang, *beCaoAnhCatNgang, anhGoc, anhDoSang, beRong, beCao, giaTriToiNhat, giaTriSangNhat );
   }
   else {
      printf( "veAnhDoSang: SAI LẦM giành trí nhớ cho ảnh cắt nganh\n" );
   }
   return anhCatNgang;

}



/* Để làm video cắt ngang
void luuCatNgangToanBoChoAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao ) {
   
   unsigned char *anhCatNgangTruoc = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, 0 );   // 256 << 2
   
   unsigned int soHangAnhGoc = 0;
   while( soHangAnhGoc < beCao ) {
      unsigned char *anhCatNgangSau = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangAnhGoc );   // 256 << 2
      
      char tenAnh[256];
      sprintf( tenAnh, "AnhCatNgang_%03d.png", soHangAnhGoc );
      //      printf( "Phân tích vận tốc trong ảnh: %s\n", tenAnh );
      //      phanTichVanTocGiuaHaiAnh( anhCatNgangTruoc, anhCatNgangSau, beRong, beCao );
      
      luuAnhPNG_BGRO( tenAnh, anhCatNgangSau, beRong, 256 );
      printf( "Luu anh: %s\n", tenAnh );
      soHangAnhGoc++;
      free( anhCatNgangSau );
   }
   printf( "kích cỡ: %d %d\n", beRong, 256 );
   
   free( anhCatNgangTruoc );
}

void luuCatNgangMotTamChoAnh( char *tenAnhCatNgang, unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHangCatNgang ) {
   
   unsigned char *anhCatNgang = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCatNgang );   // 256 << 2
   
   luuAnhPNG_BGRO( tenAnhCatNgang, anhCatNgang, beRong, 256 );
   
   free( anhCatNgang );
} */

// ---- tạoẢnhĐộSángChoHàngCủaẢnh
//      các ngang (hướng trái phải)
unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang ) {
   
   unsigned char *anhCatNgang = malloc( beRong << 10 );   // * 256 << 2 = << 10
   
   if( anhCatNgang ) {
      unsigned int diaChiAnhGoc = beRong*soHang << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soCot = 0;
      while( soCot < beRong ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soCot << 2;
         unsigned int soHangAnhLuu = 0;
         while( soHangAnhLuu < giaTriAnhGoc ) {
            anhCatNgang[diaChiAnhLuu] = soHangAnhLuu << 3;
            anhCatNgang[diaChiAnhLuu+1] = soHangAnhLuu;
            anhCatNgang[diaChiAnhLuu+2] = soHangAnhLuu << 1;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         while( soHangAnhLuu < 256 ) {
            anhCatNgang[diaChiAnhLuu] = 0xff;
            anhCatNgang[diaChiAnhLuu+1] = 0xff;
            anhCatNgang[diaChiAnhLuu+2] = 0xff;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += 4;
         soCot++;
      }
   }
   else {
      printf( "taoAnhDoSangChoHangCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatNgang;
}

// ---- tạoẢnhĐộSángChoCộtCủaẢnh
//      các dộc (hướng dưới trên)
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot ) {
   
   unsigned char *anhCatDoc = malloc( beCao << 10 );   // * 256 << 2 = << 10
   
   if( anhCatDoc ) {

      unsigned int diaChiAnhGoc = soCot << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soHang = 0;
      while( soHang < beCao ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soHang << 10;
         unsigned int soCotAnhLuu = 0;
         while( soCotAnhLuu < giaTriAnhGoc ) {
            anhCatDoc[diaChiAnhLuu] = soCotAnhLuu << 3;
            anhCatDoc[diaChiAnhLuu+1] = soCotAnhLuu;
            anhCatDoc[diaChiAnhLuu+2] = soCotAnhLuu << 1;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         while( soCotAnhLuu < 256 ) {
            anhCatDoc[diaChiAnhLuu] = 0xff;
            anhCatDoc[diaChiAnhLuu+1] = 0xff;
            anhCatDoc[diaChiAnhLuu+2] = 0xff;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += beRong << 2;
         soHang++;
      }
   }
   else {
      printf( "taoAnhDoSangChoCotCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatDoc;
}


// tôMàuĐộSángẢnh
unsigned char *toMauDoSangAnhVaKiemGiaTriCuc( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char *giaTriToiNhat, unsigned char *giaTriSangNhat ) {
   
   *giaTriToiNhat = 255;
   *giaTriSangNhat = 0;
   unsigned int diaChiCuoi = beRong*beCao << 2;
   unsigned char *anhToMau = malloc( diaChiCuoi );
   
   if( anhToMau ) {
      
      unsigned int diaChiAnh = 0;
      
      while( diaChiAnh < diaChiCuoi ) {
         // ---- lấy gíá trị từ kênh đỏ
         unsigned char doSang = anh[diaChiAnh];
         // ---- tô màu ảnh
         anhToMau[diaChiAnh] = doSang << 3;
         anhToMau[diaChiAnh+1] = doSang;
         anhToMau[diaChiAnh+2] = doSang << 1;
         anhToMau[diaChiAnh+3] = 0xff;
         
         // ---- kiếm giá trị cực
         if( doSang < *giaTriToiNhat )
            *giaTriToiNhat = doSang;
         if( doSang > *giaTriSangNhat )
            *giaTriSangNhat = doSang;
         
         diaChiAnh += 4;
      }
   }
   else {
      printf( "toMauDoSangAnh: vấn đề tạo tô màu\n" );
   }
   
   return anhToMau;
}

void veDiemThichThu( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem *mangGocAnh, unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc ) {
   
   unsigned int mau = 0x404040b0;
   unsigned short banKinh = 8;

   Diem mangDiemThichThu[512];
   unsigned short soHang = 0;
   unsigned char soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soHang = beCaoAnhBoLoc >> 2;
   soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG+1].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG+1].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soHang = beCaoAnhBoLoc >> 1;
   soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG+2].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG+2].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soHang = (beCaoAnhBoLoc >> 2)*3;
   soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG+3].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG+3].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soHang = beCaoAnhBoLoc - 1;
   soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x += mangGocAnh[kANH_CAT_NGANG+4].x;
      tamVongTron.y = mangGocAnh[kANH_CAT_NGANG+4].y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: NGANG - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );

   // ====
   unsigned short soCot = 0;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soCot = beRongAnhBoLoc >> 2;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC+1].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC+1].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soCot = beRongAnhBoLoc >> 1;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC+2].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC+2].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );

   soCot = (beRongAnhBoLoc >> 2)*3;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC+3].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC+3].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
   
   soCot = beRongAnhBoLoc - 1;
   soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTron, banKinh, mau );

      tamVongTron.x += mangGocAnh[kANH_DO_SANG].x;
      tamVongTron.y += mangGocAnh[kANH_DO_SANG].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      
      tamVongTron = mangDiemThichThu[soDiem];
      tamVongTron.x = mangGocAnh[kANH_CAT_DOC+4].x + mangDiemThichThu[soDiem].doSang;
      tamVongTron.y += mangGocAnh[kANH_CAT_DOC+4].y;
      veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTron, banKinh, mau );
      soDiem++;
   }
   printf( "veDiemThichThu: DOC - soLuongDiemThichThu %d tai soHang %d\n", soLuongDiemThichThu, soHang );
}


void bezierToiUuChoCatNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhNgang,
                            unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soHang ) {

   unsigned int mauVongTronDo = 0xff0000b0;
   unsigned int mauVongTronXanh = 0x0000ffb0;
   unsigned int mauNet = 0x000000b0;
   unsigned short banKinh = 6;
   
   unsigned short soLuongCong = beRongAnhBoLoc/200;
   unsigned short soLuongDiemAnhChoCong = beRongAnhBoLoc/soLuongCong;
   
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }

//   printf( " khoMaTran %d soLuongCong %d\n", khoMaTran, soLuongCong );

   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranToiUuDoanHang( maTran4x4, maTran4x2, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
//      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );

      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }

//   chieuMaTran( maTranGop, khoMaTran, khoMaTran );
//   chieuMaTran( vectoGop, 2, khoMaTran );
   // ---- giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
//      chiSo = 0;
//      while( chiSo < khoMaTran ) {
//         printf( "%d  %5.3f %5.3f\n", chiSo, vectoGop[mangThuTu[chiSo] << 1], vectoGop[(mangThuTu[chiSo] << 1) + 1] );
//         chiSo++;
//      }
      
      // ---- vẽ đường Bezier
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ giải
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0000f;
         bezier.diemQuanTri[0].y = 0.0f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.3333f;
         bezier.diemQuanTri[1].y = 0.0f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.6667f;
         bezier.diemQuanTri[2].y = 0.0f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;

         bezier.diemQuanTri[3].x = 1.0000f;
         bezier.diemQuanTri[3].y = 0.0f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         
         Vecto mangDiem3C[128];
         float thamSo = 0.0f;
         float buocThamSo = 0.03125f;
         unsigned char soLuongDiem = 0;
         while( thamSo <= 1.0f ) {
            mangDiem3C[soLuongDiem] = tinhViTriBezier3C( &bezier, thamSo );
//            printf( " thamSo %5.3f:  %5.3f; %5.3f; %5.3f\n", thamSo, mangDiem3C[soLuongDiem].x, mangDiem3C[soLuongDiem].y, mangDiem3C[soLuongDiem].z );
            thamSo += buocThamSo;
            soLuongDiem++;
         }
         
//         printf( " soLuongDiem %d\n", soLuongDiem );
         
         Diem diemDau;
         Diem diemCuoi;
         float dichX = gocAnhNgang.x + soCong*soLuongDiemAnhChoCong;
         diemDau.x = soLuongDiemAnhChoCong*mangDiem3C[0].x + dichX;
         diemDau.y = 255.0f*mangDiem3C[0].z + gocAnhNgang.y;

         unsigned char soDiem = 1;
         while( soDiem < soLuongDiem ) {
            diemCuoi.x = soLuongDiemAnhChoCong*mangDiem3C[soDiem].x + dichX;
            diemCuoi.y = 255.0f*mangDiem3C[soDiem].z + gocAnhNgang.y;
//            printf( "soDiem %d  (%d; %d) --> (%d; %d)\n", soDiem, diemDau.x, diemDau.y , diemCuoi.x, diemCuoi.y );
            veDuong( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, diemDau, diemCuoi, mauNet );
            diemDau = diemCuoi;
            soDiem++;
         }
         
         // ---- tìm điểm nghiệm (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z( &bezier, &nghiem0, &nghiem1 );
//         printf( "soLuongNghiem %d  %5.3f %5.3f\n", soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem == 1 ) {
            Diem tamVongTronChoAnhNgang;
            tamVongTronChoAnhNgang.x = nghiem0*soLuongDiemAnhChoCong + dichX;
            tamVongTronChoAnhNgang.y = 255.0f*tinhViTriBezier3C( &bezier, nghiem0 ).z + gocAnhNgang.y;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = soHang + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang, banKinh, mauVongTronDo );
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoSang, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang, banKinh, mauVongTronXanh );
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoSang, banKinh, mauVongTronXanh );
            }
         }
         if( soLuongNghiem == 2 ) {
            Diem tamVongTronChoAnhNgang;
            tamVongTronChoAnhNgang.x = nghiem1*soLuongDiemAnhChoCong + dichX;
            tamVongTronChoAnhNgang.y = 255.0f*tinhViTriBezier3C( &bezier, nghiem1 ).z + gocAnhNgang.y;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = soHang + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z(  &bezier, nghiem1 );
            if( doCong > 0.0f ) {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang, banKinh, mauVongTronDo );
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoSang, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhNgang, banKinh, mauVongTronXanh );
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoSang, banKinh, mauVongTronXanh );
            }
            
         }
         soCong++;
      }
      
   }

   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );
}


void bezierToiUuChoCatDoc( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot ) {
   
   unsigned int mauVongTronDo = 0xff0000b0;
   unsigned int mauVongTronXanh = 0x0000ffb0;
   unsigned int mauNet = 0x000000b0;
   unsigned short banKinh = 6;
   
   unsigned short soLuongCong = beCaoAnhBoLoc/200;
   unsigned short soLuongDiemAnhChoCong = beCaoAnhBoLoc/soLuongCong;
   
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }
   
//   printf( " khoMaTran %d soLuongCong %d\n", khoMaTran, soLuongCong );
   
   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranToiUuDoanCot( maTran4x4, maTran4x2, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
//      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );
      
      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }
   
   //   chieuMaTran( maTranGop, khoMaTran, khoMaTran );
   //   chieuMaTran( vectoGop, 2, khoMaTran );
   // ---- giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
      //      chiSo = 0;
      //      while( chiSo < khoMaTran ) {
      //         printf( "%d  %5.3f %5.3f\n", chiSo, vectoGop[mangThuTu[chiSo] << 1], vectoGop[(mangThuTu[chiSo] << 1) + 1] );
      //         chiSo++;
      //      }
      
      // ---- vẽ đường Bezier
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ giải
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0f;
         bezier.diemQuanTri[0].y = 0.0000f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.0f;
         bezier.diemQuanTri[1].y = 0.3333f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.0f;
         bezier.diemQuanTri[2].y = 0.6667f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[3].x = 0.0f;
         bezier.diemQuanTri[3].y = 1.0000f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         
         Vecto mangDiem3C[128];
         float thamSo = 0.0f;
         float buocThamSo = 0.03125f;
         unsigned char soLuongDiem = 0;
         while( thamSo <= 1.0f ) {
            mangDiem3C[soLuongDiem] = tinhViTriBezier3C( &bezier, thamSo );
            //            printf( " thamSo %5.3f:  %5.3f; %5.3f; %5.3f\n", thamSo, mangDiem3C[soLuongDiem].x, mangDiem3C[soLuongDiem].y, mangDiem3C[soLuongDiem].z );
            thamSo += buocThamSo;
            soLuongDiem++;
         }
         
         //         printf( " soLuongDiem %d\n", soLuongDiem );
         
         Diem diemDau;
         Diem diemCuoi;
         float dichY = gocAnhDoc.y + soCong*soLuongDiemAnhChoCong;
         diemDau.x = 255.0f*mangDiem3C[0].z + gocAnhDoc.x;
         diemDau.y = soLuongDiemAnhChoCong*mangDiem3C[0].y + dichY;
         
         unsigned char soDiem = 1;
         while( soDiem < soLuongDiem ) {
            diemCuoi.x = 255.0f*mangDiem3C[soDiem].z + gocAnhDoc.x;
            diemCuoi.y = soLuongDiemAnhChoCong*mangDiem3C[soDiem].y + dichY;
            //            printf( "soDiem %d  (%d; %d) --> (%d; %d)\n", soDiem, diemDau.x, diemDau.y , diemCuoi.x, diemCuoi.y );
            veDuong( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, diemDau, diemCuoi, mauNet );
            diemDau = diemCuoi;
            soDiem++;
         }
         
         // ---- tìm điểm nghiệm (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z( &bezier, &nghiem0, &nghiem1 );
//         printf( "soLuongNghiem %d  %5.3f %5.3f\n", soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem == 1 ) {
            Diem tamVongTronChoAnhDoc;
            tamVongTronChoAnhDoc.x = 255.0f*tinhViTriBezier3C( &bezier, nghiem0 ).z + gocAnhDoc.x;
            tamVongTronChoAnhDoc.y = nghiem0*soLuongDiemAnhChoCong + dichY;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = soCot + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoc, banKinh, mauVongTronDo );
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoSang, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoc, banKinh, mauVongTronXanh );
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoSang, banKinh, mauVongTronXanh );
            }
         }
         if( soLuongNghiem == 2 ) {
            Diem tamVongTronChoAnhDoc;
            tamVongTronChoAnhDoc.x = 255.0f*tinhViTriBezier3C( &bezier, nghiem1 ).z + gocAnhDoc.x;
            tamVongTronChoAnhDoc.y = nghiem1*soLuongDiemAnhChoCong + dichY;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = soCot + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong + gocAnhDoSang.y;
            
            float doCong = tinhDoCongTaiThamSo_z(  &bezier, nghiem1 );
            if( doCong > 0.0f ) {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoc, banKinh, mauVongTronDo );
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoSang, banKinh, mauVongTronDo );
            }
            else {
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoc, banKinh, mauVongTronXanh );
               veVongTron( anhCatNgang, beRongAnhCatNgang, beCaoAnhCatNgang, tamVongTronChoAnhDoSang, banKinh, mauVongTronXanh );
            }
            
         }
         soCong++;
      }
      
   }
   
   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );
   
}


#pragma mark ---- VẼ ẢNH 3 CHIỀU
void veChuNhatCungDoCao( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY, float doCao,
                        float *diem0, float *diem1, float *diem2, float *diem3, float *maTranBienHoa );
void veNetGiuaHaiDiem( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY,
                      float *diem0, float *diem1, float *maTranBienHoa, unsigned int mauNet );

void veAnh3D( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRong, unsigned int beCao,
        unsigned char giaTriToiNhat, unsigned char giaTriSangNhat ) {

   unsigned char chenhLechDoSang = giaTriSangNhat - giaTriToiNhat;
   printf( " giaTriToiNhat %d  sangNhat %d  chenLech %d\n", giaTriToiNhat, giaTriSangNhat, chenhLechDoSang );
   
   // ---- tính biến hóa
   float phongToZ = 200.0f/chenhLechDoSang;
   unsigned short x = kCACH_GIUA;
   unsigned short y = kCACH_GIUA*3 + (beCao << 1) - giaTriToiNhat;
   float maTranPhongTo[16] = {1.5f, 0.0f, 0.0f, 0.0f,   0.0f, 2.0f, 0.0f, 0.0f,   0.0f, 0.0f, phongToZ, 0.0f,  0.0f, 0.0f, 0.0f, 1.0f};
   float maTranXoayTrucX[16];
   float maTranXoayTrucZ[16];
   float maTranBienHoa0[16];
   float maTranBienHoa1[16];
   
   maTranQuayQuanhTrucZ( maTranXoayTrucZ, 3.14159f*0.1f );
   maTranQuayQuanhTrucX( maTranXoayTrucX, 3.14159f*0.33333f );
   nhanMaTranVoiMaTranVaBoVaoKetQua( maTranXoayTrucZ, maTranXoayTrucX, maTranBienHoa0 );
   nhanMaTranVoiMaTranVaBoVaoKetQua( maTranPhongTo, maTranBienHoa0, maTranBienHoa1 );
   
   // ---- vẽ khung đấy không gian
   float diem0[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
   float diem1[4] = { beRong, 0.0f, 0.0f, 1.0f };
   float diem2[4] = { 0.0f, beCao, 0.0f, 1.0f };
   float diem3[4] = { beRong, beCao, 0.0f, 1.0f };
   
   veChuNhatCungDoCao( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, giaTriToiNhat, diem0, diem1, diem2, diem3, maTranBienHoa1 );
   
   // ----
   diem2[2] = giaTriToiNhat;
   float diemCao2[4] = { diem2[0], diem2[1], giaTriSangNhat, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diemCao2, maTranBienHoa1, 0x30303080 );
   
   diem3[2] = giaTriToiNhat;
   float diemCao3[4] = { diem3[0], diem3[1], giaTriSangNhat, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem3, diemCao3, maTranBienHoa1, 0x30303080 );


   // ---- các nét đang sau
   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );

   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );

   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );


   // ---- vẽ ảnh 3 chiều
   chepAnhVaoAnhVoiMaTran( anhDoSang, anhDoSangToMau, beRong, beCao, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, maTranBienHoa1 );
   
   veChuNhatCungDoCao( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, giaTriSangNhat, diem0, diem1, diem2, diem3, maTranBienHoa1 );
   
   diem0[2] = giaTriToiNhat;
   float diemCao0[4] = { diem0[0], diem0[1], giaTriSangNhat, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diemCao0, maTranBienHoa1, 0x30303080 );
   
   diem1[2] = giaTriToiNhat;
   float diemCao1[4] = { diem1[0], diem1[1], giaTriSangNhat, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem1, diemCao1, maTranBienHoa1, 0x30303080 );
}

void veChuNhatCungDoCao( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY, float doCao,
                        float *diem0, float *diem1, float *diem2, float *diem3, float *maTranBienHoa ) {
   
   diem0[2] = doCao;
   diem1[2] = doCao;
   diem2[2] = doCao;
   diem3[2] = doCao;
   
   float diemBienHoa0[4];
   float diemBienHoa1[4];
   float diemBienHoa2[4];
   float diemBienHoa3[4];
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem0, maTranBienHoa, diemBienHoa0 );
   diemBienHoa0[0] += dichX;
   diemBienHoa0[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem1, maTranBienHoa, diemBienHoa1 );
   diemBienHoa1[0] += dichX;
   diemBienHoa1[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem2, maTranBienHoa, diemBienHoa2 );
   diemBienHoa2[0] += dichX;
   diemBienHoa2[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem3, maTranBienHoa, diemBienHoa3 );
   diemBienHoa3[0] += dichX;
   diemBienHoa3[1] += dichY;
   
   // ----
   unsigned int mauNet = 0x30303080;
   Diem diemDauNet;
   Diem diemCuoiNet;
   //
   diemDauNet.x = diemBienHoa0[0];
   diemDauNet.y = diemBienHoa0[1];
   diemCuoiNet.x = diemBienHoa1[0];
   diemCuoiNet.y = diemBienHoa1[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa3[0];
   diemCuoiNet.y = diemBienHoa3[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa2[0];
   diemCuoiNet.y = diemBienHoa2[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa0[0];
   diemCuoiNet.y = diemBienHoa0[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
}

void veNetGiuaHaiDiem( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY,
                        float *diem0, float *diem1, float *maTranBienHoa, unsigned int mauNet ) {
   

   
   float diemBienHoa0[4];
   float diemBienHoa1[4];
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem0, maTranBienHoa, diemBienHoa0 );
   diemBienHoa0[0] += dichX;
   diemBienHoa0[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua( diem1, maTranBienHoa, diemBienHoa1 );
   diemBienHoa1[0] += dichX;
   diemBienHoa1[1] += dichY;
   
   // ----
   Diem diemDauNet;
   Diem diemCuoiNet;
   //
   diemDauNet.x = diemBienHoa0[0];
   diemDauNet.y = diemBienHoa0[1];
   diemCuoiNet.x = diemBienHoa1[0];
   diemCuoiNet.y = diemBienHoa1[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
}
