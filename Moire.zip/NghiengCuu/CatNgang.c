/* CắtNgang.c */

// TOÀN BỘ NÀY ĐỂ NGHIÊN CỨU - KHÔNG CẦN CHO CHƯƠNG TRÌNH ĐỂ HOẠT ĐỘNG
// CHỈ DÙNG KÊNH ĐỎ CỦA ẢNH CÓ BỐN KÊNH RGBO (đỏ, lục, xanh, đục)

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CatNgang.h"
#include "../HangSo.h"
#include "../PNG/PNG.h"
#include "../VeVatThe/ChepAnh.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../ToMauAnh/Diem.h"
#include "../TimNet/TimNet.h"
#include "../TimNet/Bezier.h"
#include "../TimNet/MaTran.h"

//#include "FFT_Moi.h"

#pragma mark ---- Cắt Ngang (CHO NGHIÊNG CỨU ẢNH)
//        |<------ r ------>|  |<------ r ------>|
//    +---------------------------------------------+
//    |                                             |
//    |                                             |
//    |                Ảnh 3 Chiều                  |
//    |                                             |
//    |                                             |
//    |                                             |
//  - |  +------------------+  +----+ +----+ +----+ |
//  ^ |  |                  |  |    | |    | |    | |
//  c |  |                  |  |    | |    | |    | |
//  v |  |                  |  |    | |    | |    | |
//  - |  +------------------+  +----+ +----+ +----+ |
//    |  +------------------+                       |
//    |  |                  |                       |
//    |  +------------------+                       |
//    |  +------------------+                       |
//    |  |                  |                       |
//    |  +------------------+                       |
//    |         ...                                  |
//    +---------------------------------------------+
//       |<256>||<256>||<256>|


/*
 Quét ngang +x và tìm điểm thấp và cao
 • Điểm thấp là màu giữa đoạn màu, điểm cao là kết thúc đoạn màu này và đầu đoạn màu tiếp
 • tô màu trong đoạn tùy vị trí tương đối với điểm thấp và điểm cao và giá trị đồ sáng của điểm ảnh
 • Đơn vị hóa độ cao và biến độ sáng dạng sin sang hàm bật một
 • chụ ý cách giữa điểm cao để biết khi nào cần lệt hướng tô màu?
 
 • sự di chuyển vị trí của điểm cao
 +---------------------+
 |                     |
 +------------->       |
 |                     |
 |                     |
 +---------------------+
 */

#define kCACH_GIUA 100 // cách giữa (điểm ảnh)

#define kANH_DO_SANG   0
#define kANH_CAT_NGANG 1
#define kANH_CAT_DOC   6
#define kSO_LUONG_ANH 11


#define kPHONG_TO_PHAP_TUYEN      50
#define kCACH_XA_TINH_PHAP_TUYEN  20

//#define kTAN_SO_TOI_DA 20  // cho FFT

unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang );
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot );

void veAnhCatNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, Diem gocAnhDoSang,
                   unsigned short soHangCat, unsigned short x, unsigned y ) ;

void veAnhCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                 unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, Diem gocAnhDoSang,
                 unsigned short soCotCat, unsigned short x, unsigned y );


void veDiemThichThuNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhNgang,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soHang );

void veDiemThichThuDoc( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soCot );

void veSoDoPhanPhoiDoSang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, unsigned short x, unsigned short y );


void bezierToiUuChoCatNgang( unsigned char *anhCatNgang, unsigned int beRongAnhCatNgang, unsigned int beCaoAnhCatNgang, Diem gocAnhDoSang, Diem gocAnhDoc,
                            unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soHang );
void bezierToiUuChoCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot );


// ---- tính ma trận
Vecto tinhPhapTuyenMatPhangToiUu( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem );
void tinhDoCongMatBezierToiUu_B2_quangDiem( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem,
                                           float *doCong_x, float *doCong_y);

// ---- vẽ ảnh pháp tuyến
void veAnhPhapTuyen( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned int beRong, unsigned int beCao,
                    unsigned short dichX, unsigned short dichY, unsigned char soLanCatNgang, unsigned char soLangCatDoc );

// ---- vẽ ảnh độ cong
void veAnhDoCong( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned int beRong, unsigned int beCao,
                    unsigned short dichX, unsigned short dichY, unsigned char soLanCatNgang, unsigned char soLangCatDoc );

// ---- vẽ ảnh 3 chiều
void veAnh3Chieu( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRong, unsigned int beCao,
             unsigned char giaTriToiNhat, unsigned char giaTriSangNhat, unsigned short x, unsigned short y );

unsigned char *veAnhDoSang( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int *beRongAnhXuat, unsigned int *beCaoAnhXuat,
                           unsigned char soLuongCatNgang, unsigned short soLuongCatDoc ) {

   *beRongAnhXuat = beRongAnhBoLoc + kCACH_GIUA*(soLuongCatDoc + 3) + 256*(soLuongCatDoc + 1);
   *beCaoAnhXuat = (beCaoAnhBoLoc << 2) + kCACH_GIUA*(soLuongCatNgang + 3) + 256*(soLuongCatNgang + 1);
   
   unsigned char *anhXuat = malloc( *beRongAnhXuat * *beCaoAnhXuat << 2);
   
   if( anhXuat != NULL ) {
      
      // ---- cho giữ vị trí các ảnh, giúp vẽ điểm thích thú trên sơ đồ
      Diem mangGocAnh[64];
   
      // ---- độ sáng
      unsigned char giaTriToiNhat;
      unsigned char giaTriSangNhat;
      unsigned char *anhDoSang = toMauDoSangAnhVaKiemGiaTriCuc( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, &giaTriToiNhat, &giaTriSangNhat );
      
      if( anhDoSang ) {
         
         // ---- chép ảnh độ sáng tô màu
         mangGocAnh[kANH_DO_SANG].x = kCACH_GIUA;
         mangGocAnh[kANH_DO_SANG].y = kCACH_GIUA*(soLuongCatNgang + 2) + 256*(soLuongCatNgang + 1);

         unsigned short x =  mangGocAnh[kANH_DO_SANG].x;
         unsigned short y =  mangGocAnh[kANH_DO_SANG].y;
         chepAnhVaoAnh( anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, anhXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG].x, mangGocAnh[kANH_DO_SANG].y );
         veSoCai( "光度", x + 48, y + beCaoAnhBoLoc + 32, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );
         
         // ---- vẽ ảnh phép tuyến
         x = (kCACH_GIUA << 1) + beRongAnhBoLoc;
         y = kCACH_GIUA;
         chepAnhVaoAnh( anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, anhXuat, *beRongAnhXuat, *beCaoAnhXuat, x, y );
         veAnhPhapTuyen( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, x, y, 15, 30 );
  
         // ---- vẽ ảnh độ cong
         y += kCACH_GIUA + beCaoAnhBoLoc;
         chepAnhVaoAnh( anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, anhXuat, *beRongAnhXuat, *beCaoAnhXuat, x, y );
         veAnhDoCong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, x, y, 15, 30 );
         
         // ----  cắt ngang
         x = kCACH_GIUA;
         y = kCACH_GIUA;
         unsigned short soHangCat = 0;
         unsigned short buocCat = beCaoAnhBoLoc/soLuongCatNgang;

         unsigned char soCatNgang = 0;
         while( soCatNgang < soLuongCatNgang + 1 ) {
            mangGocAnh[kANH_CAT_NGANG+soCatNgang].x = x;
            mangGocAnh[kANH_CAT_NGANG+soCatNgang].y = y;
  
            veAnhCatNgang( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, mangGocAnh[kANH_DO_SANG], soHangCat, x, y );
            
            // ---- điểm thích thú
            veDiemThichThuNgang( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+soCatNgang], anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, soHangCat );

            bezierToiUuChoCatNgang( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_NGANG+soCatNgang], anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, soHangCat );

            y += 256 + kCACH_GIUA;
            soHangCat += buocCat;
            soCatNgang++;
         }

         // ---- cắt dộc
         x = (kCACH_GIUA << 1) + beRongAnhBoLoc;
         y = kCACH_GIUA*(soLuongCatNgang + 2) + 256*(soLuongCatNgang + 1);
         unsigned short soCotCat = 0;
         buocCat = beRongAnhBoLoc/soLuongCatDoc;

         unsigned char soCatDoc = 0;
         while( soCatDoc < soLuongCatDoc + 1 ) {
            mangGocAnh[kANH_CAT_DOC+soCatDoc].x = x;
            mangGocAnh[kANH_CAT_DOC+soCatDoc].y = y;
            
            veAnhCatDoc( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, mangGocAnh[kANH_DO_SANG], soCotCat, x, y );
            
            // ---- điểm thích thú
            veDiemThichThuDoc( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], mangGocAnh[kANH_CAT_DOC+soCatDoc], anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, soCotCat );

            // ---- vẽ cong Bezier tương đương
            bezierToiUuChoCatDoc( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, mangGocAnh[kANH_DO_SANG], x, y, anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, soCotCat );

            x += 256 + kCACH_GIUA;
            soCotCat += buocCat;
            soCatDoc++;
         }
         
         // ---- ảnh 3 chiểu
         x = kCACH_GIUA << 1;
         y = kCACH_GIUA*(soLuongCatNgang + 3) + 256*soLuongCatNgang + (beCaoAnhBoLoc << 1);
         veAnh3Chieu( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, anhDoSang, beRongAnhBoLoc, beCaoAnhBoLoc, giaTriToiNhat, giaTriSangNhat, x, y );
         veSoCai( "光度3维", x, y + 300 + beCaoAnhBoLoc, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );
         
         // ---- vẽ sơ đồ
         x += (kCACH_GIUA << 1) + (beRongAnhBoLoc << 1);
         veSoDoPhanPhoiDoSang( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, x, y );

         
/*         unsigned int diaChiAnh = 0;
    
         unsigned char *anhThuNghiem = malloc( 200*200 << 2 );
         unsigned short soHang = 0;
         while( soHang < 200 ) {
            unsigned short soCot = 0;
            while( soCot < 200 ) {
               unsigned char giaTri = (soHang >> 1) + (soCot >> 1);
               anhThuNghiem[diaChiAnh] = giaTri;
               anhThuNghiem[diaChiAnh + 1] = giaTri;
               anhThuNghiem[diaChiAnh + 2] = giaTri;
               anhThuNghiem[diaChiAnh + 3] = 0xff;
               diaChiAnh += 4;
               soCot++;
            }
            soHang++;
         }
         luuAnhPNG_BGRO( "anhThuNghiem", anhThuNghiem, 200, 200 );
         
         x = 100;
         y = 100;
         tinhMatBezierToiUu_B2_quangDiem( anhThuNghiem, 200, 200, x, y, 75 );
         exit(0); */
      }
   }
   else {
      printf( "CatNgang: veAnhDoSang: SAI LẦM giành trí nhớ cho ảnh cắt nganh\n" );
   }
   return anhXuat;

}

void veAnhCatNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, Diem gocAnhDoSang,
                   unsigned short soHangCat, unsigned short x, unsigned y ) {
   
   Diem diem0;
   Diem diem1;
   diem0.x = 0;
   diem0.y = soHangCat;
   diem1.x = beRongAnhDoSang-1;
   diem1.y = soHangCat;

   // ---- vẽ nét trên ảnh sáng tô màu
   veDuong( anhDoSangToMau, beRongAnhDoSang, beCaoAnhDoSang, diem0, diem1, 0x80808080 );
   diem0.x += gocAnhDoSang.x;
   diem0.y += gocAnhDoSang.y;
   diem1.x += gocAnhDoSang.x;
   diem1.y += gocAnhDoSang.y;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diem0, diem1, 0x80808080 );
   
   // ---- vẽ số hàng cắt
   char dichNguocX = 8;
   if( soHangCat < 10 )
      dichNguocX += 16;
   else if( soHangCat < 100 )
      dichNguocX += 32;
   else if( soHangCat < 1000 )
      dichNguocX += 48;
   else
      dichNguocX += 64;
   veSoThapPhan( soHangCat, gocAnhDoSang.x - dichNguocX, gocAnhDoSang.y + soHangCat - 8, anhXuat, beRongAnhXuat, beCaoAnhXuat );

   // ---- vẽ ảnh cắt ngang
   unsigned char *anhCatNgang = taoAnhDoSangChoHangCuaAnh( anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soHangCat );
   if( anhCatNgang ) {
      chepAnhVaoAnh( anhCatNgang, beRongAnhDoSang, 256, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y );
      free( anhCatNgang );

      // ---- vẽ vị trí cắt
      veSoCai( "↔︎切画", x, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      veSoThapPhan( soHangCat, x + (beRongAnhDoSang >> 1) - 32, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   }

   // ---- tìm điểm thích thú
}


void veAnhCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                   unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, Diem gocAnhDoSang,
                   unsigned short soCotCat, unsigned short x, unsigned y ) {
   
   Diem diem0;
   Diem diem1;
   diem0.x = soCotCat;
   diem0.y = 0;
   diem1.x = soCotCat;
   diem1.y = beCaoAnhDoSang - 1;

   // ---- vẽ nét trên ảnh sáng tô màu
   veDuong( anhDoSangToMau, beRongAnhDoSang, beCaoAnhDoSang, diem0, diem1, 0x80808080 );
   diem0.x += gocAnhDoSang.x;
   diem0.y += gocAnhDoSang.y;
   diem1.x += gocAnhDoSang.x;
   diem1.y += gocAnhDoSang.y;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diem0, diem1, 0x80808080 );

   // ---- vẽ số hàng cắt
   char dichNguocX = 8;
   if( soCotCat < 10 )
      dichNguocX += 8;
   else if( soCotCat < 100 )
      dichNguocX += 32;
   else if( soCotCat < 1000 )
      dichNguocX += 48;
   else
      dichNguocX += 64;
   veSoThapPhan( soCotCat, gocAnhDoSang.x + soCotCat - dichNguocX, gocAnhDoSang.y - 40, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   
   // ---- vẽ ảnh cắt ngang
   unsigned char *anhCatDoc = taoAnhDoSangChoCotCuaAnh( anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soCotCat );
   if( anhCatDoc ) {
      chepAnhVaoAnh( anhCatDoc, 256, beCaoAnhDoSang, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y );
      free( anhCatDoc );
      
      // ---- vẽ vị trí cắt
      veSoCai( "↕︎切画", x, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      veSoThapPhan( soCotCat, x + 128 - 32, y - 32, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   }
   
   // ---- tìm điểm thích thú
}


/* Để làm video cắt ngang, ĐỪNG BỎ CÁI NÀY
void luuCatNgangToanBoChoAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao ) {
   
   unsigned char *anhCatNgangTruoc = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, 0 );   // 256 << 2
   
   unsigned int soHangAnhGoc = 0;
   while( soHangAnhGoc < beCao ) {
      unsigned char *anhCatNgangSau = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangAnhGoc );   // 256 << 2
      
      char tenAnh[256];
      sprintf( tenAnh, "AnhCatNgang_%03d.png", soHangAnhGoc );
      //      printf( "Phân tích vận tốc trong ảnh: %s\n", tenAnh );
      //      phanTichVanTocGiuaHaiAnh( anhCatNgangTruoc, anhCatNgangSau, beRong, beCao );
      
      luuAnhPNG_BGRO( tenAnh, anhCatNgangSau, beRong, 256 );
      printf( "Luu anh: %s\n", tenAnh );
      soHangAnhGoc++;
      free( anhCatNgangSau );
   }
   printf( "kích cỡ: %d %d\n", beRong, 256 );
   
   free( anhCatNgangTruoc );
}

void luuCatNgangMotTamChoAnh( char *tenAnhCatNgang, unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHangCatNgang ) {
   
   unsigned char *anhCatNgang = taoAnhDoSangChoHangCuaAnh( anhGoc, beRong, beCao, soHangCatNgang );   // 256 << 2
   
   luuAnhPNG_BGRO( tenAnhCatNgang, anhCatNgang, beRong, 256 );
   
   free( anhCatNgang );
} */

// ---- tạoẢnhĐộSángChoHàngCủaẢnh
//      các ngang (hướng trái phải)
unsigned char *taoAnhDoSangChoHangCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHang ) {
   
   unsigned char *anhCatNgang = malloc( beRong << 10 );   // * 256 << 2 = << 10
   
   if( anhCatNgang ) {
      // ---- giữ trong phạm vi
      if( soHang >= beCao )
         soHang = beCao - 1;
   
      unsigned int diaChiAnhGoc = beRong*soHang << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soCot = 0;
      while( soCot < beRong ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soCot << 2;
         unsigned int soHangAnhLuu = 0;
         while( soHangAnhLuu < giaTriAnhGoc ) {
            anhCatNgang[diaChiAnhLuu] = soHangAnhLuu << 3;
            anhCatNgang[diaChiAnhLuu+1] = soHangAnhLuu;
            anhCatNgang[diaChiAnhLuu+2] = soHangAnhLuu << 1;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         while( soHangAnhLuu < 256 ) {
            anhCatNgang[diaChiAnhLuu] = 0xff;
            anhCatNgang[diaChiAnhLuu+1] = 0xff;
            anhCatNgang[diaChiAnhLuu+2] = 0xff;
            anhCatNgang[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += beRong << 2;
            soHangAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += 4;
         soCot++;
      }
   }
   else {
      printf( "taoAnhDoSangChoHangCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatNgang;
}

// ---- tạoẢnhĐộSángChoCộtCủaẢnh
//      các dộc (hướng dưới trên)
unsigned char *taoAnhDoSangChoCotCuaAnh( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soCot ) {
   
   unsigned char *anhCatDoc = malloc( beCao << 10 );   // * 256 << 2 = << 10
   
   if( anhCatDoc ) {
      // ---- giữ trong phạm vi
      if( soCot >= beRong )
         soCot = beRong - 1;

      unsigned int diaChiAnhGoc = soCot << 2;  // bỏ hàng đầu, đã lằm ở trên
      
      unsigned int soHang = 0;
      while( soHang < beCao ) {
         unsigned char giaTriAnhGoc = anhGoc[diaChiAnhGoc];
         
         unsigned int diaChiAnhLuu = soHang << 10;
         unsigned int soCotAnhLuu = 0;
         while( soCotAnhLuu < giaTriAnhGoc ) {
            anhCatDoc[diaChiAnhLuu] = soCotAnhLuu << 3;
            anhCatDoc[diaChiAnhLuu+1] = soCotAnhLuu;
            anhCatDoc[diaChiAnhLuu+2] = soCotAnhLuu << 1;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         while( soCotAnhLuu < 256 ) {
            anhCatDoc[diaChiAnhLuu] = 0xff;
            anhCatDoc[diaChiAnhLuu+1] = 0xff;
            anhCatDoc[diaChiAnhLuu+2] = 0xff;
            anhCatDoc[diaChiAnhLuu+3] = 0xff;
            diaChiAnhLuu += 4;
            soCotAnhLuu++;
         }
         
         // ---- tới đỉm ảnh tiếp
         diaChiAnhGoc += beRong << 2;
         soHang++;
      }
   }
   else {
      printf( "CatHang: taoAnhDoSangChoCotCuaAnh: vấn đề tạo ảnh\n" );
   }
   
   return anhCatDoc;
}


// tôMàuĐộSángẢnh
unsigned char *toMauDoSangAnhVaKiemGiaTriCuc( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char *giaTriToiNhat, unsigned char *giaTriSangNhat ) {
   
   *giaTriToiNhat = 255;
   *giaTriSangNhat = 0;
   unsigned int diaChiCuoi = beRong*beCao << 2;
   unsigned char *anhToMau = malloc( diaChiCuoi );
   
   if( anhToMau ) {
      
      unsigned int diaChiAnh = 0;
      
      while( diaChiAnh < diaChiCuoi ) {
         // ---- lấy gíá trị từ kênh đỏ
         unsigned char doSang = anh[diaChiAnh];
         // ---- tô màu ảnh
         anhToMau[diaChiAnh] = doSang << 3;
         anhToMau[diaChiAnh+1] = doSang;
         anhToMau[diaChiAnh+2] = doSang << 1;
         anhToMau[diaChiAnh+3] = 0xff;
         
         // ---- kiếm giá trị cực
         if( doSang < *giaTriToiNhat )
            *giaTriToiNhat = doSang;
         if( doSang > *giaTriSangNhat )
            *giaTriSangNhat = doSang;
         
         diaChiAnh += 4;
      }
   }
   else {
      printf( "CatNgang: toMauDoSangAnh: vấn đề tạo tô màu\n" );
   }
   
   return anhToMau;
}


#pragma mark ---- Vẽ Điểm Thích Thú
void veDiemThichThuNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, Diem gocAnhNgang,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soHang ) {
   
   unsigned int mau = 0x404040b0;
   unsigned short banKinh = 8;

   Diem mangDiemThichThu[512];
   unsigned char soLuongDiemThichThu = timCacDiemThichThuNgang( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang );
   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      short x = tamVongTron.x;
      short y = tamVongTron.y;
      
      // ---- vẽ vòng tròn trên ảnh độ sáng màu
      char xauTenDiem[256];
      sprintf( xauTenDiem, "↔︎%d-%d\n", soHang, soDiem );
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, x, y, banKinh, mau );
      veSoCai( xauTenDiem, tamVongTron.x + 16, tamVongTron.y - 16, anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc );
      
      // ---- vẽ vòng tròn trên ảnh độ sáng màu trong ảnh xuất
      x += gocAnhDoSang.x;
      y += gocAnhDoSang.y;
      veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, banKinh, mau );
      veSoCai( xauTenDiem, x + 16, y - 16, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      
      // ---- tính độ cong quanh điểm
      unsigned char cachXaQuanhDiem = 75;
      float doCongX;
      float doCongY;
      tinhDoCongMatBezierToiUu_B2_quangDiem( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, mangDiemThichThu[soDiem].x, mangDiemThichThu[soDiem].y, cachXaQuanhDiem, &doCongX, &doCongY );
      
      // ---- trính phép tuyến cho mặt phẳng tuyến điểm này
      Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, mangDiemThichThu[soDiem].x, mangDiemThichThu[soDiem].y, kCACH_XA_TINH_PHAP_TUYEN );
      // ---- vẽ phép tuyến
      Diem diem0;
      Diem diem1;
      diem0.x = tamVongTron.x + gocAnhDoSang.x;
      diem0.y = tamVongTron.y + gocAnhDoSang.y;
      diem1.x = diem0.x + kPHONG_TO_PHAP_TUYEN*phapTuyen.x;
      diem1.y = diem0.y + kPHONG_TO_PHAP_TUYEN*phapTuyen.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diem0, diem1, 0x000000ff );
      
      x = tamVongTron.x + 20 + gocAnhDoSang.x;
      y = tamVongTron.y + 4 + gocAnhDoSang.y;
      char xauDoCong[256];
      sprintf( xauDoCong, "⌒ %5.3f; %5.3f\n", doCongX, doCongY );
      veSoCaiNho( xauDoCong, x, y, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      y += 10;
      sprintf( xauDoCong, "↑ %5.3f; %5.3f %5.3f\n", phapTuyen.x, phapTuyen.y, phapTuyen.z );
      veSoCaiNho( xauDoCong, x, y, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      y += 10;
      sprintf( xauDoCong, "光 %d\n", mangDiemThichThu[soDiem].doSang );
      veSoCaiNho( xauDoCong, x, y, anhXuat, beRongAnhXuat, beCaoAnhXuat );

      // ---- vẽ vòng tròn trên ảnh cắt ngang trong ảnh xuất
      tamVongTron = mangDiemThichThu[soDiem];
      x = gocAnhNgang.x + mangDiemThichThu[soDiem].x;
      y = gocAnhNgang.y + mangDiemThichThu[soDiem].doSang;
      veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, banKinh, mau );
//      printf( "CatNgang: VeDiemThichThuNgang: %d  gocAnhNgang %d %d\n", soHang, gocAnhNgang.x, gocAnhNgang.y );
      veSoThapPhan( soDiem, x - 8, y + 12, anhXuat, beRongAnhXuat, beCaoAnhXuat );

      soDiem++;
   }

}

void veDiemThichThuDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, Diem gocAnhDoc,
                         unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc,
                         unsigned short soCot ) {

   unsigned int mau = 0x404040b0;
   unsigned short banKinh = 8;

   Diem mangDiemThichThu[512];
   unsigned char soLuongDiemThichThu = timCacDiemThichThuDoc( mangDiemThichThu, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot );
   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      Diem tamVongTron = mangDiemThichThu[soDiem];
      short x = tamVongTron.x;
      short y = tamVongTron.y;
      
      // ---- trính phép tuyến cho mặt phẳng tuyến điểm này
      Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, mangDiemThichThu[soDiem].x, mangDiemThichThu[soDiem].y, kCACH_XA_TINH_PHAP_TUYEN );
   
      // ---- vẽ pháp tuyến
      Diem diem0;
      Diem diem1;
      diem0.x = tamVongTron.x + gocAnhDoSang.x;
      diem0.y = tamVongTron.y + gocAnhDoSang.y;
      diem1.x = diem0.x + kPHONG_TO_PHAP_TUYEN*phapTuyen.x;
      diem1.y = diem0.y + kPHONG_TO_PHAP_TUYEN*phapTuyen.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diem0, diem1, 0x000000ff );

      // ---- vẽ vòng tròn trên ảnh độ sáng màu
      char xauTenDiem[256];
      sprintf( xauTenDiem, "↕︎%d-%d\n", soCot, soDiem );
      veSoCai( xauTenDiem, tamVongTron.x + 16, tamVongTron.y - 16, anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc );
      veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, x, y, banKinh, mau );

      // ---- vẽ vòng tròn trên ảnh độ sáng màu trong ảnh xuất
      x += gocAnhDoSang.x;
      y += gocAnhDoSang.y;
      veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, banKinh, mau );
      veSoCai( xauTenDiem, x + 16, y - 16, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      
      // ---- vẽ vòng tròn trên ảnh cắt độc trong ảnh xuất
      x = gocAnhDoc.x + mangDiemThichThu[soDiem].doSang;
      y = gocAnhDoc.y + mangDiemThichThu[soDiem].y;
      veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, banKinh, mau );
      veSoThapPhan( soDiem, x + 12, y - 8, anhXuat, beRongAnhXuat, beCaoAnhXuat );
      soDiem++;
   }

}

#pragma mark ---- Vẽ Sơ Đồ Phân Phối Độ Sáng
#define kBE_CAO__SO_DO 200

void veSoDoPhanPhoiDoSang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, unsigned short x, unsigned short y ) {
   
   unsigned int mangPhanPhoi[256];
   
   // ---- xóa mảng phân phối
   short chiSo = 0;
   while( chiSo < 256 ) {
      mangPhanPhoi[chiSo] = 0;
      chiSo++;
   }
   
   // ---- đếm các giá trị
   unsigned int diaChiAnh = 0;
   unsigned int diaChiAnhCuoi = beRongAnhDoSang*beCaoAnhDoSang << 2;

   while( diaChiAnh < diaChiAnhCuoi ) {
      unsigned char giaTri = anhDoSang[diaChiAnh];
      mangPhanPhoi[giaTri] += 1;

      diaChiAnh += 4;
   }

   // ---- tìm giá trị tối đa
   unsigned char giaTriToiDa = 0;
   unsigned int soLuongToiDa = 0;
   chiSo = 0;
   while( chiSo < 256 ) {
      unsigned int soLuong = mangPhanPhoi[chiSo];
      if( soLuong > soLuongToiDa ) {
         giaTriToiDa = chiSo;
         soLuongToiDa = soLuong;
      }

      chiSo++;
   }
   
   // ---- độ sáng cực đại
   unsigned int giaTriCucDai = 255;
   chiSo = 255;
   while( chiSo > -1 ) {
      unsigned int giaTri = mangPhanPhoi[chiSo];
      if( giaTri != 0 ) {
         giaTriCucDai = chiSo;
         chiSo = -1;
      }
      chiSo--;
   }
   
   // ---- độ sáng cực thiểu
   unsigned int giaTriCucThieu = 0;
   chiSo = 0;
   while( chiSo < 256 ) {
      unsigned int giaTri = mangPhanPhoi[chiSo];
      if( giaTri != 0 ) {
         giaTriCucThieu = chiSo;
         chiSo = 256;
      }
      chiSo++;
   }

   // ---- vẽ sơ đồ
   chiSo = 0;
   unsigned int soLuongDiemAnh = diaChiAnhCuoi >> 2;
   printf( "CatNgang: veSoDoPhanPhoiDoSang: soLuongDiemAnh %d\n", soLuongDiemAnh );
   while( chiSo < 256 ) {
      
      unsigned int soLuongDoSang = mangPhanPhoi[chiSo];
      
      // ---- màu cột
      unsigned char mauDo = chiSo << 3;
      unsigned char mauLuc = chiSo;
      unsigned char mauXanh = chiSo << 1;

      // ---- đơn vị hóa và phóng to để vẽ cột trong sơ đồ
      unsigned short beCaoCot = (soLuongDoSang * kBE_CAO__SO_DO) / soLuongToiDa;

//      printf( " %d soLuongDoSang %d\n", chiSo, soLuongDoSang );
      diaChiAnh = (beRongAnhXuat*y + x + chiSo) << 2;
      unsigned short chiSoDiemAnhCot = 0;
      while( chiSoDiemAnhCot < beCaoCot ) {
         anhXuat[diaChiAnh] = mauDo;
         anhXuat[diaChiAnh+1] = mauLuc;
         anhXuat[diaChiAnh+2] = mauXanh;
         anhXuat[diaChiAnh+3] = 0xff;
         chiSoDiemAnhCot++;
         diaChiAnh += beRongAnhXuat << 2;
      }
      
      while( chiSoDiemAnhCot < kBE_CAO__SO_DO ) {
         anhXuat[diaChiAnh] = 0xff;
         anhXuat[diaChiAnh+1] = 0xff;
         anhXuat[diaChiAnh+2] = 0xff;
         anhXuat[diaChiAnh+3] = 0xff;
         chiSoDiemAnhCot++;
         diaChiAnh += beRongAnhXuat << 2;
      }

      chiSo++;
   }
   
   // ---- số trục độ sáng (trục x)
   veSoThapPhan( 0, x - 8, y - 30, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   veSoThapPhan( 128, x + 96, y - 30, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   veSoThapPhan( 255, x + 224, y - 30, anhXuat, beRongAnhXuat, beCaoAnhXuat );

   Diem diemDau;
   Diem diemCuoi;
   diemDau.x = x;
   diemDau.y = y - 1;
   diemCuoi.x = x;
   diemCuoi.y = y - 8;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0xff );

   diemDau.x = x + 128;
   diemCuoi.x = x + 128;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0xff );
   
   diemDau.x = x + 255;
   diemCuoi.x = x + 255;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0xff );
   
   // ---- số trục số lương (trục y)
   veSoThapPhan( 0, x + 270, y - 8, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   veSoThapPhan( soLuongToiDa, x + 270, y - 8 + kBE_CAO__SO_DO, anhXuat, beRongAnhXuat, beCaoAnhXuat );

   diemDau.x = x + 256;
   diemDau.y = y;
   diemCuoi.x = x + 256 + 7;
   diemCuoi.y = y;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0xff );
   
   diemDau.y += kBE_CAO__SO_DO - 1;
   diemCuoi.y += kBE_CAO__SO_DO - 1;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0xff );

   // ---- các giạ trị cực
   veSoThapPhan( giaTriCucThieu, x - 16 + giaTriCucThieu, y + 8 + kBE_CAO__SO_DO, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   veSoThapPhan( giaTriCucDai, x - 16 + giaTriCucDai, y + 30 + kBE_CAO__SO_DO, anhXuat, beRongAnhXuat, beCaoAnhXuat );
   veSoThapPhan( giaTriToiDa, x - 16 + giaTriToiDa, y + 52 + kBE_CAO__SO_DO, anhXuat, beRongAnhXuat, beCaoAnhXuat );
}


#pragma mark ---- Cong Bezier Bình Phương Tối Thiểu
void bezierToiUuChoCatNgang( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, Diem gocAnhNgang,
                            unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soHang ) {

   unsigned int mauVongTronDo = 0xff0000b0;
   unsigned int mauVongTronXanh = 0x0000ffb0;
   unsigned int mauNet = 0x000000b0;
   unsigned short banKinh = 6;
   
   unsigned short soLuongCong = beRongAnhBoLoc/200;
   unsigned short soLuongDiemAnhChoCong = beRongAnhBoLoc/soLuongCong;
   
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }

//   printf( " khoMaTran %d soLuongCong %d\n", khoMaTran, soLuongCong );
   // ---- góp ma trận
   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranCongToiUuB3_doanHang( maTran4x4, maTran4x2, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soHang, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
//      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );

      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }

   // ---- giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
      // ---- vẽ đường Bezier
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ giải
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0000f;
         bezier.diemQuanTri[0].y = 0.0f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.3333f;
         bezier.diemQuanTri[1].y = 0.0f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.6667f;
         bezier.diemQuanTri[2].y = 0.0f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;

         bezier.diemQuanTri[3].x = 1.0000f;
         bezier.diemQuanTri[3].y = 0.0f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         
         Vecto mangDiem3C[128];
         float thamSo = 0.0f;
         float buocThamSo = 0.03125f;
         unsigned char soLuongDiem = 0;
         while( thamSo <= 1.0f ) {
            mangDiem3C[soLuongDiem] = tinhViTriCongBezier3C_B3( &bezier, thamSo );
//            printf( " thamSo %5.3f:  %5.3f; %5.3f; %5.3f\n", thamSo, mangDiem3C[soLuongDiem].x, mangDiem3C[soLuongDiem].y, mangDiem3C[soLuongDiem].z );
            thamSo += buocThamSo;
            soLuongDiem++;
         }
         
//         printf( " soLuongDiem %d\n", soLuongDiem );
         
         Diem diemDau;
         Diem diemCuoi;
         unsigned short dichX = gocAnhNgang.x + soCong*soLuongDiemAnhChoCong;
         diemDau.x = soLuongDiemAnhChoCong*mangDiem3C[0].x + dichX;
         diemDau.y = 255.0f*mangDiem3C[0].z + gocAnhNgang.y;

         unsigned char soDiem = 1;
         while( soDiem < soLuongDiem ) {
            diemCuoi.x = soLuongDiemAnhChoCong*mangDiem3C[soDiem].x + dichX;
            diemCuoi.y = 255.0f*mangDiem3C[soDiem].z + gocAnhNgang.y;
//            printf( "soDiem %d  (%d; %d) --> (%d; %d)\n", soDiem, diemDau.x, diemDau.y , diemCuoi.x, diemCuoi.y );
            veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, mauNet );
            diemDau = diemCuoi;
            soDiem++;
         }
         
         // ---- tìm điểm cực (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z_B3( &bezier, &nghiem0, &nghiem1 );
//         printf( "CatNgang: BezierToiUuNgang: soHang %d  soLuongNghiem %d  %5.3f %5.3f\n", soHang, soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem > 0 ) {
            Diem tamVongTronChoAnhNgang;
            tamVongTronChoAnhNgang.x = nghiem0*soLuongDiemAnhChoCong + dichX;
            tamVongTronChoAnhNgang.y = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem0 ).z + gocAnhNgang.y;
            
            Diem tamVongTronChoAnhDoSangGoc;
            tamVongTronChoAnhDoSangGoc.x = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong;
            tamVongTronChoAnhDoSangGoc.y = soHang;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = tamVongTronChoAnhDoSangGoc.x + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = tamVongTronChoAnhDoSangGoc.y + gocAnhDoSang.y;
            
            // ---- tính phép tuyến
            Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, kCACH_XA_TINH_PHAP_TUYEN );
            Diem dauPhapTuyen;
            dauPhapTuyen.x = tamVongTronChoAnhDoSang.x + kPHONG_TO_PHAP_TUYEN*phapTuyen.x;
            dauPhapTuyen.y = tamVongTronChoAnhDoSang.y + kPHONG_TO_PHAP_TUYEN*phapTuyen.y;

            // ---- tính độ cong để biết tô màu nào
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               // ---- vẽ trên ảnh cắt ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhNgang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronDo );
               // ---- vẽ trên ảnh sáng tô màu ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronDo );
               // ---- vẽ trên ảnh sáng tô màu góc để chiếu trong ảnh 3 chiều
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, banKinh, mauVongTronDo );
               // ---- vẽ phép tuyến
               veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang, dauPhapTuyen, mauVongTronDo );
            }
            else {
               // ---- vẽ trên ảnh cắt ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhNgang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronXanh );
               // ---- vẽ trên ảnh sáng tô màu ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronXanh );
               // ---- vẽ trên ảnh sáng tô màu góc để chiếu trong ảnh 3 chiều
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, banKinh, mauVongTronXanh );
               // ---- vẽ phép tuyến
               veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang, dauPhapTuyen, mauVongTronXanh );
            }
         }
         if( soLuongNghiem == 2 ) {
            Diem tamVongTronChoAnhNgang;
            tamVongTronChoAnhNgang.x = nghiem1*soLuongDiemAnhChoCong + dichX;
            tamVongTronChoAnhNgang.y = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem1 ).z + gocAnhNgang.y;

            Diem tamVongTronChoAnhDoSangGoc;
            tamVongTronChoAnhDoSangGoc.x = nghiem1*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong;
            tamVongTronChoAnhDoSangGoc.y = soHang;
      
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = tamVongTronChoAnhDoSangGoc.x + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = tamVongTronChoAnhDoSangGoc.y + gocAnhDoSang.y;

            // ---- tính phép tuyến
            Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, kCACH_XA_TINH_PHAP_TUYEN );
            Diem dauPhapTuyen;
            dauPhapTuyen.x = tamVongTronChoAnhDoSang.x + kPHONG_TO_PHAP_TUYEN*phapTuyen.x;
            dauPhapTuyen.y = tamVongTronChoAnhDoSang.y + kPHONG_TO_PHAP_TUYEN*phapTuyen.y;

            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem1 );
            if( doCong > 0.0f ) {
               // ---- vẽ trên ảnh cắt ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhNgang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronDo );
               // ---- vẽ trên ảnh sáng tô màu ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronDo );
               // ---- vẽ trên ảnh sáng tô màu góc để chiếu trong ảnh 3 chiều
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, banKinh, mauVongTronDo );
               // ---- vẽ phép tuyến
               veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang, dauPhapTuyen, mauVongTronDo );
            }
            else {
               // ---- vẽ trên ảnh cắt ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhNgang.x, tamVongTronChoAnhNgang.y, banKinh, mauVongTronXanh );
               // ---- vẽ trên ảnh sáng tô màu ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronXanh );
               // ---- vẽ trên ảnh sáng tô màu góc để chiếu trong ảnh 3 chiều
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, banKinh, mauVongTronXanh );
               // ---- vẽ phép tuyến
               veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang, dauPhapTuyen, mauVongTronXanh );
            }
            
         }
         soCong++;
      }
      
   }

   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );
}


void bezierToiUuChoCatDoc( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot ) {
   
   unsigned int mauVongTronDo = 0xff0000b0;
   unsigned int mauVongTronXanh = 0x0000ffb0;
   unsigned int mauNet = 0x000000b0;
   unsigned short banKinh = 6;

   unsigned short soLuongCong = beCaoAnhBoLoc/200;
   unsigned short soLuongDiemAnhChoCong = beCaoAnhBoLoc/soLuongCong;
 
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }

//   printf( " khoMaTran %d soLuongCong %d\n", khoMaTran, soLuongCong );
   
   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranCongToiUuB3_doanCot( maTran4x4, maTran4x2, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCot, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
//      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );
      
      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }
   
   // ---- giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
      // ---- vẽ đường Bezier
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ giải
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0f;
         bezier.diemQuanTri[0].y = 0.0000f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.0f;
         bezier.diemQuanTri[1].y = 0.3333f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.0f;
         bezier.diemQuanTri[2].y = 0.6667f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[3].x = 0.0f;
         bezier.diemQuanTri[3].y = 1.0000f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         
         Vecto mangDiem3C[128];
         float thamSo = 0.0f;
         float buocThamSo = 0.03125f;
         unsigned char soLuongDiem = 0;
         while( thamSo <= 1.0f ) {
            mangDiem3C[soLuongDiem] = tinhViTriCongBezier3C_B3( &bezier, thamSo );
//            printf( " thamSo %5.3f:  %5.3f; %5.3f; %5.3f\n", thamSo, mangDiem3C[soLuongDiem].x, mangDiem3C[soLuongDiem].y, mangDiem3C[soLuongDiem].z );
            thamSo += buocThamSo;
            soLuongDiem++;
         }
         
         Diem diemDau;
         Diem diemCuoi;
         unsigned short dichY = y + soCong*soLuongDiemAnhChoCong;
         diemDau.x = 255.0f*mangDiem3C[0].z + x;
         diemDau.y = soLuongDiemAnhChoCong*mangDiem3C[0].y + dichY;

         unsigned char soDiem = 1;
         while( soDiem < soLuongDiem ) {
            diemCuoi.x = 255.0f*mangDiem3C[soDiem].z + x;
            diemCuoi.y = soLuongDiemAnhChoCong*mangDiem3C[soDiem].y + dichY;
//            printf( "soDiem %d  (%d; %d) --> (%d; %d)\n", soDiem, diemDau.x, diemDau.y , diemCuoi.x, diemCuoi.y );
            veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, mauNet );
            diemDau = diemCuoi;
            soDiem++;
         }

         // ---- tìm điểm nghiệm (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z_B3( &bezier, &nghiem0, &nghiem1 );
//         printf( "soLuongNghiem %d  %5.3f %5.3f\n", soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem > 0 ) {
 
            Diem tamVongTronChoAnhDoc;
            tamVongTronChoAnhDoc.x = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem0 ).z + x;
            tamVongTronChoAnhDoc.y = nghiem0*soLuongDiemAnhChoCong + dichY;
//            printf( "nghiem0 %5.3f  soLuongDiemAnh %d  dichY %d\n", nghiem0, soLuongDiemAnhChoCong, dichY );
            Diem tamVongTronChoAnhDoSangGoc;
            tamVongTronChoAnhDoSangGoc.x = soCot;
            tamVongTronChoAnhDoSangGoc.y = nghiem0*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong;
            
            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = tamVongTronChoAnhDoSangGoc.x + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = tamVongTronChoAnhDoSangGoc.y + gocAnhDoSang.y;

            // ---- tính pháp tuyến
            Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, kCACH_XA_TINH_PHAP_TUYEN );
            Diem dauPhapTuyen;
            dauPhapTuyen.x = tamVongTronChoAnhDoSang.x + kPHONG_TO_PHAP_TUYEN*phapTuyen.x;
            dauPhapTuyen.y = tamVongTronChoAnhDoSang.y + kPHONG_TO_PHAP_TUYEN*phapTuyen.y;

            // ----
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               // ---- vẽ trên ảnh cắt ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronDo );
               // ---- vẽ trên ảnh sáng tô màu ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronDo );
               // ---- vẽ trên ảnh sáng tô màu góc để chiếu trong ảnh 3 chiều
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, banKinh, mauVongTronDo );
               // ---- vẽ phép tuyến
               veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang, dauPhapTuyen, mauVongTronDo );
            }
            else {
               // ---- vẽ trên ảnh cắt ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronXanh );
               // ---- vẽ trên ảnh sáng tô màu ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronXanh );
               // ---- vẽ trên ảnh sáng tô màu góc để chiếu trong ảnh 3 chiều
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, banKinh, mauVongTronXanh );
               // ---- vẽ phép tuyến
               veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang, dauPhapTuyen, mauVongTronXanh );
            }
         }

         if( soLuongNghiem == 2 ) {
            Diem tamVongTronChoAnhDoc;
            tamVongTronChoAnhDoc.x = 255.0f*tinhViTriCongBezier3C_B3( &bezier, nghiem1 ).z + x;
            tamVongTronChoAnhDoc.y = nghiem1*soLuongDiemAnhChoCong + dichY;
            
            Diem tamVongTronChoAnhDoSangGoc;
            tamVongTronChoAnhDoSangGoc.x = soCot;
            tamVongTronChoAnhDoSangGoc.y = nghiem1*soLuongDiemAnhChoCong + soCong*soLuongDiemAnhChoCong;

            Diem tamVongTronChoAnhDoSang;
            tamVongTronChoAnhDoSang.x = tamVongTronChoAnhDoSangGoc.x + gocAnhDoSang.x;
            tamVongTronChoAnhDoSang.y = tamVongTronChoAnhDoSangGoc.y + gocAnhDoSang.y;

            // ---- tính phép tuyến
            Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, kCACH_XA_TINH_PHAP_TUYEN );
            Diem dauPhapTuyen;
            dauPhapTuyen.x = tamVongTronChoAnhDoSang.x + kPHONG_TO_PHAP_TUYEN*phapTuyen.x;
            dauPhapTuyen.y = tamVongTronChoAnhDoSang.y + kPHONG_TO_PHAP_TUYEN*phapTuyen.y;

            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem1 );
            if( doCong > 0.0f ) {
               // ---- vẽ trên ảnh cắt ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronDo );
               // ---- vẽ trên ảnh sáng tô màu ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronDo );
               // ---- vẽ trên ảnh sáng tô màu góc để chiếu trong ảnh 3 chiều
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, banKinh, mauVongTronDo );
               // ---- vẽ phép tuyến
               veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang, dauPhapTuyen, mauVongTronDo );
            }
            else {
               // ---- vẽ trên ảnh cắt ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoc.x, tamVongTronChoAnhDoc.y, banKinh, mauVongTronXanh );
               // ---- vẽ trên ảnh sáng tô màu ngang trong ảnh xuất
               veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang.x, tamVongTronChoAnhDoSang.y, banKinh, mauVongTronXanh );
               // ---- vẽ trên ảnh sáng tô màu góc để chiếu trong ảnh 3 chiều
               veVongTron( anhDoSangToMau, beRongAnhBoLoc, beCaoAnhBoLoc, tamVongTronChoAnhDoSangGoc.x, tamVongTronChoAnhDoSangGoc.y, banKinh, mauVongTronXanh );
               // ---- vẽ phép tuyến
               veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, tamVongTronChoAnhDoSang, dauPhapTuyen, mauVongTronXanh );
            }
            
         }

         soCong++;
      }
   }

   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );
}

#pragma mark ---- Mắt Phẳng Tối Ưu

// - Cộng thức cho mắt phẳng
// Ax + By + Cz = D
// đặt C = 1
// Ax + By + z = D
// Ax + By + z – D = 0

/*
 - Hàm sai lầm
 E(A, B, D) = ++{i = 0 → m} A•x_i + B•y_i – D + z_i
 
 - Hàm sai lầm bình phương
 E(A, B, D) = [++{i = 0 → m} A•x_i + B•y_i – D + z_i]²
 
 - Đạo hàm sai lầm bình phương A, B, C, D
 ∂E/∂A = 2[++{i = 0 → m} A•x_i + B•y_i – D + z_i]•x_i = 0
 ∂E/∂B = 2[++{i = 0 → m} A•x_i + B•y_i – D + z_i]•y_i = 0
 ∂E/∂D = –2[++{i = 0 → m} A•x_i + B•y_i – D + z_i]•1 = 0
 
 - Rút gọn:
 ∂E/∂A = [++{i = 0 → m} A•x_i + B•y_i – D + z_i]•x_i = 0
 ∂E/∂B = [++{i = 0 → m} A•x_i + B•y_i – D + z_i]•y_i = 0
 ∂E/∂D = –[++{i = 0 → m} A•x_i + B•y_i – D + z_i] = 0
 */




#pragma mark ---- Mặt Bezier Tối Ưu
void tinhDoCongMatBezierToiUu_B2_quangDiem( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem,
                                           float *doCong_x, float *doCong_y) {
   
   if( x > beRongAnhBoLoc ) {
      printf( "CatNgang: mat Bezier B2: x ở ngoài phạm vi (%d > %d)\n", x, beRongAnhBoLoc );
      return;
   }
   else if( x < 0 ) {
      printf( "CatNgang: mat Bezier B2: x ở ngoài phạm vi (%d < 0)\n", x );
      return;
   }
   
   if( y > beCaoAnhBoLoc ) {
      printf( "CatNgang: mat Bezier B2: y ở ngoài phạm vi (%d > %d)\n", y, beCaoAnhBoLoc );
      return;
   }
   else if( y < 0 ) {
      printf( "CatNgang: mat Bezier B2: x ở ngoài phạm vi (%d < 0)\n", y );
      return;
   }

   unsigned char mangThuTu[] = {0, 1, 2, 3, 4, 5, 6, 7, 8};
   float maTranBezier[81];
   float vectoGiai[27];
   
   // ---- tính cột và hàng quanh điểm
   short soCotDau = x - cachQuanhDiem;
   short soCotCuoi = x + cachQuanhDiem + 1;
   short soHangDau = y - cachQuanhDiem;
   short soHangCuoi = y + cachQuanhDiem + 1;

   // ---- không cho ra ngoài phạm vi ảnh
   if( soCotDau < 0 )
      soCotDau = 0;
   if( soCotCuoi >= beRongAnhBoLoc )
      soCotCuoi = beRongAnhBoLoc - 1;
   
   if( soHangDau < 0 )
      soHangDau = 0;
   if( soHangCuoi >= beCaoAnhBoLoc )
      soHangCuoi = beCaoAnhBoLoc - 1;

   tinhMaTranMatToiUuB2_choDienTich( maTranBezier, vectoGiai, anhBoLoc, beRongAnhBoLoc, beCaoAnhBoLoc, soCotDau, soCotCuoi, soHangDau, soHangCuoi );
//   chieuMaTran( maTranBezier, 9, 9 );
//   chieuMaTran( vectoGiai, 3, 9 );

   unsigned char coNghiem = khuMaTran( maTranBezier, 9, 9, vectoGiai, 9, 3, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranBezier, 9, 9, vectoGiai, 9, 3, mangThuTu );
      
      MatBezierB2 matBezierB2;
      matBezierB2.diemQuanTri[0].x = vectoGiai[mangThuTu[0]*3];
      matBezierB2.diemQuanTri[0].y = vectoGiai[mangThuTu[0]*3+1];
      matBezierB2.diemQuanTri[0].z = vectoGiai[mangThuTu[0]*3+2];
      
      matBezierB2.diemQuanTri[1].x = vectoGiai[mangThuTu[1]*3];
      matBezierB2.diemQuanTri[1].y = vectoGiai[mangThuTu[1]*3+1];
      matBezierB2.diemQuanTri[1].z = vectoGiai[mangThuTu[1]*3+2];
      
      matBezierB2.diemQuanTri[2].x = vectoGiai[mangThuTu[2]*3];
      matBezierB2.diemQuanTri[2].y = vectoGiai[mangThuTu[2]*3+1];
      matBezierB2.diemQuanTri[2].z = vectoGiai[mangThuTu[2]*3+2];
      
      // ----
      matBezierB2.diemQuanTri[3].x = vectoGiai[mangThuTu[3]*3];
      matBezierB2.diemQuanTri[3].y = vectoGiai[mangThuTu[3]*3+1];
      matBezierB2.diemQuanTri[3].z = vectoGiai[mangThuTu[3]*3+2];
      
      matBezierB2.diemQuanTri[4].x = vectoGiai[mangThuTu[4]*3];
      matBezierB2.diemQuanTri[4].y = vectoGiai[mangThuTu[4]*3+1];
      matBezierB2.diemQuanTri[4].z = vectoGiai[mangThuTu[4]*3+2];
      
      matBezierB2.diemQuanTri[5].x = vectoGiai[mangThuTu[5]*3];
      matBezierB2.diemQuanTri[5].y = vectoGiai[mangThuTu[5]*3+1];
      matBezierB2.diemQuanTri[5].z = vectoGiai[mangThuTu[5]*3+2];
      
      // ----
      matBezierB2.diemQuanTri[6].x = vectoGiai[mangThuTu[6]*3];
      matBezierB2.diemQuanTri[6].y = vectoGiai[mangThuTu[6]*3+1];
      matBezierB2.diemQuanTri[6].z = vectoGiai[mangThuTu[6]*3+2];
      
      matBezierB2.diemQuanTri[7].x = vectoGiai[mangThuTu[7]*3];
      matBezierB2.diemQuanTri[7].y = vectoGiai[mangThuTu[7]*3+1];
      matBezierB2.diemQuanTri[7].z = vectoGiai[mangThuTu[7]*3+2];
      
      matBezierB2.diemQuanTri[8].x = vectoGiai[mangThuTu[8]*3];
      matBezierB2.diemQuanTri[8].y = vectoGiai[mangThuTu[8]*3+1];
      matBezierB2.diemQuanTri[8].z = vectoGiai[mangThuTu[8]*3+2];
      
//      printf( "tinhMatBezierToiUu_B2_quangDiem:\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n   %5.3f %5.3f %5.3f\n  %5.3f %5.3f %5.3f\n",
//             matBezierB2.diemQuanTri[0].x, matBezierB2.diemQuanTri[0].y, matBezierB2.diemQuanTri[0].z,
//             matBezierB2.diemQuanTri[1].x, matBezierB2.diemQuanTri[1].y, matBezierB2.diemQuanTri[1].z,
//             matBezierB2.diemQuanTri[2].x, matBezierB2.diemQuanTri[2].y, matBezierB2.diemQuanTri[2].z,
//             matBezierB2.diemQuanTri[3].x, matBezierB2.diemQuanTri[3].y, matBezierB2.diemQuanTri[3].z,
//             matBezierB2.diemQuanTri[4].x, matBezierB2.diemQuanTri[4].y, matBezierB2.diemQuanTri[4].z,
//             matBezierB2.diemQuanTri[5].x, matBezierB2.diemQuanTri[5].y, matBezierB2.diemQuanTri[5].z,
//             matBezierB2.diemQuanTri[6].x, matBezierB2.diemQuanTri[6].y, matBezierB2.diemQuanTri[6].z,
//             matBezierB2.diemQuanTri[7].x, matBezierB2.diemQuanTri[7].y, matBezierB2.diemQuanTri[7].z,
//             matBezierB2.diemQuanTri[8].x, matBezierB2.diemQuanTri[8].y, matBezierB2.diemQuanTri[8].z
 //            );
   
      
      float t = (float)x/(float)(soCotCuoi- soCotDau);
      float u = (float)y/(float)(soHangCuoi- soHangDau);
      tinhDoCongTaiHaiThamSo_z_B2( &matBezierB2, t, u, doCong_x, doCong_y );
      
//      printf( "  B2 doCong %5.3f %5.3f -> doLon %5.3f\n", doCong_t, doCong_u, sqrtf(doCong_t*doCong_t + doCong_u*doCong_u ));

   }
}

/* #pragma mark ---- Mặt Bezier Tối Ưu Bật 2
 #define kCACH_GOP_DIEM 20

void tinhDoCongTaiDiem( unsigned char *anh, unsigned int beRong, unsigned int beCao ) {
   
   float maTranMatBezier[81];
   float vectoGiai[27];
   tinhMaTranMatToiUuB2_chiDienTich( maTranMatBezier, fvectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCotDau, unsigned int soCotCuoi, unsigned int soHangDau, unsigned int soHangCuoi )
}
 */

#pragma mark ---- VẼ ẢNH PHÁP TUYẾN
void veAnhPhapTuyen( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang,
                    unsigned short dichX, unsigned short dichY, unsigned char soLanCatNgang, unsigned char soLangCatDoc ) {
   
   unsigned short buocHang = beCaoAnhDoSang/soLanCatNgang;
   unsigned short buocCot = beRongAnhDoSang/soLangCatDoc;
   
   unsigned short soHang = 0;
   while( soHang < beCaoAnhDoSang ) {

      unsigned short soCot = 0;
      while( soCot < beRongAnhDoSang ) {
         
         // ---- tính phép tuyến
         Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soCot, soHang, 20 );
         
         // ---- vẽ phép tuyến - tính điểm đầu va điểm cuối để vẽ phép tuyến
         Diem diemDau;
         diemDau.x = soCot + dichX;
         diemDau.y = soHang + dichY;
         Diem diemCuoi;
         diemCuoi.x = diemDau.x + 50*phapTuyen.x;
         diemCuoi.y = diemDau.y + 50*phapTuyen.y;
         veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x80808080 );
         
         // ---- vẽ vòng tròn
         // unsigned char *anh, unsigned int beRong, unsigned int beCao, short tamX, short tamY, short banKinh, unsigned int mau );
         veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau.x, diemDau.y, 8, 0x80808080 );
         
         char xauThongTin[256];
         sprintf( xauThongTin, "↑%5.3f\n %5.3f\n %5.3f", phapTuyen.x, phapTuyen.y, phapTuyen.z );
         veSoCaiNho( xauThongTin, diemDau.x, diemDau.y + 8, anhXuat, beRongAnhXuat, beCaoAnhXuat );

         soCot += buocCot;
      }

      soHang += buocHang;
   }
}

#pragma mark ---- VẼ ẢNH Độ CONG

#define kCACH_XA__TINH_DO_CONG 40
void veAnhDoCong( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang,
                    unsigned short dichX, unsigned short dichY, unsigned char soLanCatNgang, unsigned char soLangCatDoc ) {
   
   int buocHang = beCaoAnhDoSang/soLanCatNgang;
   int buocCot = beRongAnhDoSang/soLangCatDoc;
   
   int soHang = 0;
   while( soHang < beCaoAnhDoSang ) {
      
      int soCot = 0;
      while( soCot < beRongAnhDoSang ) {
         float maTranBezier[16];
         float vectoGiai[8];
         unsigned char mangThuTu[] = {0, 1, 2, 3};
         float doCongX;
         float doCongY;
         
         // ---- tính cong bezier hướng x
         int soCotDau = soCot - kCACH_XA__TINH_DO_CONG;
         int soCotCuoi = soCot + kCACH_XA__TINH_DO_CONG;

         if( soCotDau < 0 )
            soCotDau = 0;
         if( soCotCuoi >= beRongAnhDoSang )
            soCotCuoi = beRongAnhDoSang - 1;

         tinhMaTranCongToiUuB3_doanHang( maTranBezier, vectoGiai, anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soHang, soCotDau, soCotCuoi );
         unsigned char coNghiem = khuMaTran( maTranBezier, 4, 4, vectoGiai, 4, 2, mangThuTu );

         if( coNghiem ) {
            tinhNghiem( maTranBezier, 4, 4, vectoGiai, 4, 2, mangThuTu );
            
            Bezier bezier;
            bezier.diemQuanTri[0].z = vectoGiai[(mangThuTu[0] << 1) + 1];
            bezier.diemQuanTri[1].z = vectoGiai[(mangThuTu[1] << 1) + 1];
            bezier.diemQuanTri[2].z = vectoGiai[(mangThuTu[2] << 1) + 1];
            bezier.diemQuanTri[3].z = vectoGiai[(mangThuTu[3] << 1) + 1];
            
            float thamSo = (float)(soCot - soCotDau)/(float)(soCotCuoi - soCotDau);
            doCongX = tinhDoCongTaiThamSo_z_B3( &bezier, thamSo );
         }

         // ---- tính cong bezier hướng y
         int soHangDau = soHang - kCACH_XA__TINH_DO_CONG;
         int soHangCuoi = soHang + kCACH_XA__TINH_DO_CONG;

         if( soHangDau < 0 )
            soHangDau = 0;
         if( soHangCuoi >= beCaoAnhDoSang )
            soHangCuoi = beCaoAnhDoSang - 1;

         tinhMaTranCongToiUuB3_doanCot( maTranBezier, vectoGiai, anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soCot, soHangDau, soHangCuoi );
         coNghiem = khuMaTran( maTranBezier, 4, 4, vectoGiai, 4, 2, mangThuTu );
         
         if( coNghiem ) {
            tinhNghiem( maTranBezier, 4, 4, vectoGiai, 4, 2, mangThuTu );
            
            Bezier bezier;
            bezier.diemQuanTri[0].z = vectoGiai[(mangThuTu[0] << 1) + 1];
            bezier.diemQuanTri[1].z = vectoGiai[(mangThuTu[1] << 1) + 1];
            bezier.diemQuanTri[2].z = vectoGiai[(mangThuTu[2] << 1) + 1];
            bezier.diemQuanTri[3].z = vectoGiai[(mangThuTu[3] << 1) + 1];
   
            float thamSo = (float)(soHang - soHangDau)/(float)(soHangCuoi - soHangDau);
            doCongY = tinhDoCongTaiThamSo_z_B3( &bezier, thamSo );
         }

         // ---- vẽ chỗ tính độ cong
         Diem diemDau;
         diemDau.x = soCot + dichX - kCACH_XA__TINH_DO_CONG;
         diemDau.y = soHang + dichY;
         Diem diemCuoi;
         diemCuoi.x = soCot + dichX + kCACH_XA__TINH_DO_CONG;
         diemCuoi.y = soHang + dichY;
         veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x80808080 );

         diemDau.x = soCot + dichX;
         diemDau.y = soHang + dichY - kCACH_XA__TINH_DO_CONG;
         diemCuoi.x = soCot + dichX;
         diemCuoi.y = soHang + dichY + kCACH_XA__TINH_DO_CONG;
         veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x80808080 );
         
         
         char xauThongTin[256];
         sprintf( xauThongTin, "⌒%5.3f\n %5.3f\n", doCongX, doCongY );
         veSoCaiNho( xauThongTin, diemDau.x, diemDau.y + 8, anhXuat, beRongAnhXuat, beCaoAnhXuat );
         
         soCot += buocCot;
      }
      
      soHang += buocHang;
   }
}

#pragma mark ---- VẼ ẢNH 3 CHIỀU
void veChuNhatCungDoCao( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY, float doCao,
                        float *diem0, float *diem1, float *diem2, float *diem3, float *maTranBienHoa );
void veNetGiuaHaiDiem( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY,
                      float *diem0, float *diem1, float *maTranBienHoa, unsigned int mauNet );

void veAnh3Chieu( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anhDoSang, unsigned char *anhDoSangToMau, unsigned int beRong, unsigned int beCao,
        unsigned char giaTriToiNhat, unsigned char giaTriSangNhat, unsigned short x, unsigned short y ) {

   unsigned char chenhLechDoSang = giaTriSangNhat - giaTriToiNhat;
   
   // ---- không chênh lệch cho nó qúa nhỏ
   if( chenhLechDoSang < 10 )
      chenhLechDoSang = 10;
   
//   printf( " giaTriToiNhat %d  sangNhat %d  chenLech %d\n", giaTriToiNhat, giaTriSangNhat, chenhLechDoSang );
   
   // ---- tính biến hóa
   float phongToZ = 200.0f/chenhLechDoSang;

   float maTranPhongTo[16] = {1.5f, 0.0f, 0.0f, 0.0f,   0.0f, 2.0f, 0.0f, 0.0f,   0.0f, 0.0f, phongToZ, 0.0f,  0.0f, 0.0f, 0.0f, 1.0f};
   float maTranXoayTrucX[16];
   float maTranXoayTrucZ[16];
   float maTranBienHoa0[16];
   float maTranBienHoa1[16];
   
   maTranQuayQuanhTrucZ( maTranXoayTrucZ, 3.14159f*0.1f );
   maTranQuayQuanhTrucX( maTranXoayTrucX, 3.14159f*0.33333f );
   nhanMaTranVoiMaTranVaBoVaoKetQua4x4( maTranXoayTrucZ, maTranXoayTrucX, maTranBienHoa0 );
   nhanMaTranVoiMaTranVaBoVaoKetQua4x4( maTranPhongTo, maTranBienHoa0, maTranBienHoa1 );
   
   // ---- vẽ khung đấy không gian
   float diem0[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
   float diem1[4] = { beRong, 0.0f, 0.0f, 1.0f };
   float diem2[4] = { 0.0f, beCao, 0.0f, 1.0f };
   float diem3[4] = { beRong, beCao, 0.0f, 1.0f };
   
   veChuNhatCungDoCao( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, 0, diem0, diem1, diem2, diem3, maTranBienHoa1 );
   
   // ---- vẽ nét khung phía sau
   diem2[2] = 0.0f;
   float diemCao2[4] = { diem2[0], diem2[1], 255.0f, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diemCao2, maTranBienHoa1, 0x30303080 );
   
   diem3[2] = 0.0f;
   float diemCao3[4] = { diem3[0], diem3[1], 255.0f, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem3, diemCao3, maTranBienHoa1, 0x30303080 );


   // ---- các nét mức cao ớ phía sau
   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 2);
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );

   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 1);
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );

   diem0[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   diem2[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   diem3[2] = giaTriToiNhat + (chenhLechDoSang >> 2)*3;
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem2, diem3, maTranBienHoa1, 0xd0d0d0d0 );
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diem2, maTranBienHoa1, 0xd0d0d0d0 );


   // ---- vẽ ảnh 3 chiều
   chepAnhVaoAnhVoiMaTran_dungDoSangChoZ( anhDoSang, anhDoSangToMau, beRong, beCao, anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, maTranBienHoa1 );

   // ----
   veChuNhatCungDoCao( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, 255, diem0, diem1, diem2, diem3, maTranBienHoa1 );
   
   diem0[2] = 0;
   float diemCao0[4] = { diem0[0], diem0[1], 255.0f, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem0, diemCao0, maTranBienHoa1, 0x30303080 );
   
   diem1[2] = 0;
   float diemCao1[4] = { diem1[0], diem1[1], 255.0f, 1.0f};
   veNetGiuaHaiDiem( anhXuat, beRongAnhXuat, beCaoAnhXuat, x, y, diem1, diemCao1, maTranBienHoa1, 0x30303080 );

}

void veChuNhatCungDoCao( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY, float doCao,
                        float *diem0, float *diem1, float *diem2, float *diem3, float *maTranBienHoa ) {
   
   diem0[2] = doCao;
   diem1[2] = doCao;
   diem2[2] = doCao;
   diem3[2] = doCao;
   
   float diemBienHoa0[4];
   float diemBienHoa1[4];
   float diemBienHoa2[4];
   float diemBienHoa3[4];
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem0, maTranBienHoa, diemBienHoa0 );
   diemBienHoa0[0] += dichX;
   diemBienHoa0[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem1, maTranBienHoa, diemBienHoa1 );
   diemBienHoa1[0] += dichX;
   diemBienHoa1[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem2, maTranBienHoa, diemBienHoa2 );
   diemBienHoa2[0] += dichX;
   diemBienHoa2[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem3, maTranBienHoa, diemBienHoa3 );
   diemBienHoa3[0] += dichX;
   diemBienHoa3[1] += dichY;
   
   // ----
   unsigned int mauNet = 0x30303080;
   Diem diemDauNet;
   Diem diemCuoiNet;
   //
   diemDauNet.x = diemBienHoa0[0];
   diemDauNet.y = diemBienHoa0[1];
   diemCuoiNet.x = diemBienHoa1[0];
   diemCuoiNet.y = diemBienHoa1[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa3[0];
   diemCuoiNet.y = diemBienHoa3[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa2[0];
   diemCuoiNet.y = diemBienHoa2[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
   
   //
   diemDauNet = diemCuoiNet;
   diemCuoiNet.x = diemBienHoa0[0];
   diemCuoiNet.y = diemBienHoa0[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
   diemDauNet = diemCuoiNet;
}

void veNetGiuaHaiDiem( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned short dichX, unsigned short dichY,
                        float *diem0, float *diem1, float *maTranBienHoa, unsigned int mauNet ) {
   
   float diemBienHoa0[4];
   float diemBienHoa1[4];
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem0, maTranBienHoa, diemBienHoa0 );
   diemBienHoa0[0] += dichX;
   diemBienHoa0[1] += dichY;
   
   nhanVectVoiMaTranVaBoVaoKetQua4x4( diem1, maTranBienHoa, diemBienHoa1 );
   diemBienHoa1[0] += dichX;
   diemBienHoa1[1] += dichY;
   
   // ----
   Diem diemDauNet;
   Diem diemCuoiNet;
   //
   diemDauNet.x = diemBienHoa0[0];
   diemDauNet.y = diemBienHoa0[1];
   diemCuoiNet.x = diemBienHoa1[0];
   diemCuoiNet.y = diemBienHoa1[1];
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDauNet, diemCuoiNet, mauNet );
}


void hamX( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, Diem gocAnhDoSang, unsigned short x, unsigned short y,
                          unsigned char *anhBoLoc, unsigned char *anhDoSangToMau, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, unsigned int soCot ) {
   
}
