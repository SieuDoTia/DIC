/* CắtNgang.h */


#pragma once

unsigned char *veAnhDoSang( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhCatNgang, unsigned int *beCaoAnhCatNgang );

void luuCatNgangMotTamChoAnh( char *tenAnhCatNgang, unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int soHangCatNgang );
unsigned char *toMauDoSangAnhVaKiemGiaTriCuc( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char *giaTriToiNhat, unsigned char *giaTriSangNhat );
