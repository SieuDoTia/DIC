#pragma once

#include "SoPhuc.h"

#define kPI 3.141592654f
#define kHAI_PI 6.283185307f

SoPhuc *FFT( SoPhuc *tinHieu, unsigned int soLuongMauVat, unsigned int *beDaiFFT );
SoPhuc *FFT_nghich( SoPhuc *tinHieu, unsigned int soLuongMauVat, unsigned int *beDaiFFT );
