/* SốPhức.h */

#pragma once

/* Số Phức */
typedef struct {
   float t;   // phần số thật
   float a;   // phần số ảo
} SoPhuc;
