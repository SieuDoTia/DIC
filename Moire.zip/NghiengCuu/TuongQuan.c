/* TươngQuan.c */

// TOÀN BỘ NÀY ĐỂ NGHIÊN CỨU - KHÔNG CẦN CHO CHƯƠNG TRÌNH ĐỂ HOẠT ĐỘNG

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CatNgang.h"
#include "../HangSo.h"
#include "../DocLuuAnh/PNG.h"
#include "../VeVatThe/ChepAnh.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../ToMauAnh/Diem.h"
#include "../TimNet/TimNet.h"


#pragma mark ---- Cắt Ngang (CHO NGHIÊNG CỨU ẢNH)
//        |<------ r ------>|  |<------ r ------>|
//    +--------------------------------------------+
//    | ảnh sóng 1C +------------------+ ảnh sóng  |
//    |  +---       |                  |  2 chiều  |
//    |  |  |       |     ảnh gốc      | +---+     |
//    |  |  |       |                  | |   |     |
//    |  +--+       +------------------+ +---+     |
//    |  +------------------+  +-----------------+ |
//    |  |                  |  |                 | |
//    |  | tương quan ngang |  |   tương quan    | |
//    |  |     1 chiều      |  | √(ngang² + dộc²)| |
//    |  +------------------+  +-----------------+ |
//    |  +------------------+  +-----------------+ |
//    |  |                  |  |                 | |
//    |  |  tương quan dộc  |  |   tương quan    | |
//    |  |      1 chiều     |  |     2 chiều     | |
//    |  +------------------+  +-----------------+ |
//    +--------------------------------------------+
//

float *tuongQuanGiuaMangSong_ngang( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong );
float *tuongQuanGiuaMangSong_doc( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong );

float *tuongQuanGiuaMangSong_2Chieu( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong );

float tinhTrungBinhVaPhuongSai_doanHang( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned int soCot, unsigned int soHang, unsigned short beRongSong, float *phuongSai );

float *mauAnhNuiSin_1chieu_truTrungBinh( unsigned short beRong, float *phuongSai );
float *mauAnhNuiSin_2chieu_truTrungBinh( unsigned short beRong, float *phuongSai );


#define kCACH_GIUA 100 // cách giữa (điểm ảnh)

#define kANH_DO_SANG   0
#define kANH_CAT_NGANG 1
#define kANH_CAT_DOC   6
#define kSO_LUONG_ANH 11


// Vẽ ảnh tương quan sóng
//  Dùng tham số beRongAnhSong để chọn cỡ thước ảnh sóng cho tương quan

unsigned char *veAnhTuongQuanSong( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhTuongQuan, unsigned int *beCaoAnhTuongQuan, unsigned short beRongAnhSong ) {

   *beRongAnhTuongQuan = (beRong << 1) + 3*kCACH_GIUA;
   *beCaoAnhTuongQuan = (beCao*3) + (kCACH_GIUA << 2);
   
   unsigned char *anhTuongQuan = malloc( *beRongAnhTuongQuan * *beCaoAnhTuongQuan << 2);
   unsigned int diaChiAnh = 0;
   unsigned int diaChiAnhCuoi = (*beRongAnhTuongQuan * *beCaoAnhTuongQuan) << 2;
   while( diaChiAnh < diaChiAnhCuoi ) {
      anhTuongQuan[diaChiAnh] = 0xff;
      anhTuongQuan[diaChiAnh+1] = 0xff;
      anhTuongQuan[diaChiAnh+2] = 0xff;
      anhTuongQuan[diaChiAnh+3] = 0xff;
      diaChiAnh += 4;
   }
   
   if( anhTuongQuan != NULL ) {
      
      // ---- chép ảnh góc
      unsigned short x = ((*beRongAnhTuongQuan - beRong) >> 1);
      unsigned short y = (kCACH_GIUA*3) + (beCao << 1);
      // ---- chép vào ảnh cắt ngang
      chepAnhVaoAnh( anhGoc, beRong, beCao, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
      veXau( "原画", x, y - 20, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan );
      
      // ===== VẼ NÚI SIN ĐỀ LÀM TƯƠNG QUAN
      // ---- 1 chiều
      unsigned char *anhSin = malloc( beRongAnhSong << 10 );  // 256 << 2
      float buoc = 1.0f/(float)(beRongAnhSong-1);
      
      unsigned int diaChiAnh = 0;
      unsigned short chiSo = 0;
      while( chiSo < beRongAnhSong ) {
         unsigned char giaTri = -cosf( 3.14159*(chiSo*buoc + 0.5f) )*255;
         unsigned short soDiemAnh = 0;
         while( soDiemAnh < giaTri ) {
            anhSin[diaChiAnh] = 0x00;
            anhSin[diaChiAnh+1] = 0x00;
            anhSin[diaChiAnh+2] = 0x00;
            anhSin[diaChiAnh+3] = 0xff;
            diaChiAnh += beRongAnhSong << 2;
            soDiemAnh++;
         }
         
         while( soDiemAnh < 256 ) {
            anhSin[diaChiAnh] = 0xff;
            anhSin[diaChiAnh+1] = 0xff;
            anhSin[diaChiAnh+2] = 0xff;
            anhSin[diaChiAnh+3] = 0xff;
            diaChiAnh += beRongAnhSong << 2;
            soDiemAnh++;
         }
         diaChiAnh = chiSo << 2;
         chiSo++;
      }
      x = kCACH_GIUA;
      chepAnhVaoAnh( anhSin, beRongAnhSong, 256, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );

      char tuaAnh[256];
      sprintf( tuaAnh ,"山画1维%d画点", beRongAnhSong );
      veXau( tuaAnh, x, y - 30, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan );
      free( anhSin );
      
      // ---- 2 chiều
 
      diaChiAnh = 0;
      unsigned int diaChiAnhCuoi = beRongAnhSong*beRongAnhSong << 2;
      unsigned char *anhNuiSin = malloc( diaChiAnhCuoi );

      unsigned short soHang = 0;
      float viTriY = 0.0f;
      while( soHang < beRongAnhSong ) {
         unsigned short soCot = 0;
         float viTriX = 0.0f;
         while( soCot < beRongAnhSong ) {
            unsigned char giaTri = cosf( 3.14159f*(viTriX + 0.5f) )*cosf( 3.14159f*(viTriY + 0.5f) )*255.0f;
            anhNuiSin[diaChiAnh] = giaTri;
            anhNuiSin[diaChiAnh+1] = giaTri;
            anhNuiSin[diaChiAnh+2] = giaTri;
            anhNuiSin[diaChiAnh+3] = 0xff;
            viTriX += buoc;
            diaChiAnh += 4;
            soCot++;
         }
         viTriY += buoc;
         soHang++;
      }

      x = ((*beRongAnhTuongQuan - beRong) >> 1) + beRong + kCACH_GIUA;
      chepAnhVaoAnh( anhNuiSin, beRongAnhSong, beRongAnhSong, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
      sprintf( tuaAnh ,"山画2维%d×%d画点", beRongAnhSong, beRongAnhSong );
      veXau( tuaAnh, x, y - 30, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan );
      free( anhNuiSin );
     // =============

     float *duLieuTuongQuanNgang = tuongQuanGiuaMangSong_ngang( anhGoc, beRong, beCao, beRongAnhSong );
      
      if( duLieuTuongQuanNgang ) {
         
         unsigned char *anhDoSangTuongQuan = malloc( beRong*beCao << 2 );
         
         unsigned int diaChi = 0;
         unsigned int diaChiCuoi = beRong*beCao;
         while( diaChi < diaChiCuoi ) {
            float giaTriTuongQuan = duLieuTuongQuanNgang[diaChi];
            if( (giaTriTuongQuan < -1.0f) || (giaTriTuongQuan > 1.0f) ) {
               printf( "  diaChi %d  diaChiCuoi %d\n", diaChi, diaChiCuoi );
               exit(0);
            }
            
            unsigned char doSang = (unsigned char)(128.0f*giaTriTuongQuan) + 128;
//            printf( "  %5.3f  %d", giaTriTuongQuan, doSang );
            anhDoSangTuongQuan[diaChi << 2] = doSang;// << 3;
            anhDoSangTuongQuan[(diaChi << 2)+1] = doSang;
            anhDoSangTuongQuan[(diaChi << 2)+2] = doSang;// << 1;
            anhDoSangTuongQuan[(diaChi << 2)+3] = 0xff;
            diaChi++;
         }

         unsigned short x = kCACH_GIUA;
         unsigned short y = (kCACH_GIUA << 1) + beCao;
         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSangTuongQuan, beRong, beCao, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
         veXau( "1维相关1维↔︎", x, y - 30, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan );
      }
      
      float *duLieuTuongQuanDoc = tuongQuanGiuaMangSong_doc( anhGoc, beRong, beCao, beRongAnhSong );
      
      if( duLieuTuongQuanDoc ) {
         
         unsigned char *anhDoSangTuongQuan = malloc( beRong*beCao << 2 );
         
         unsigned int diaChi = 0;
         unsigned int diaChiCuoi = beRong*beCao;
         while( diaChi < diaChiCuoi ) {
            float giaTriTuongQuan = duLieuTuongQuanDoc[diaChi];
            if( (giaTriTuongQuan < -1.0f) || (giaTriTuongQuan > 1.0f) ) {
               printf( "  diaChi %d  diaChiCuoi %d\n", diaChi, diaChiCuoi );
               exit(0);
            }
            
            unsigned char doSang = (unsigned char)(128.0f*giaTriTuongQuan) + 128;
            //            printf( "  %5.3f  %d", giaTriTuongQuan, doSang );
            anhDoSangTuongQuan[diaChi << 2] = doSang;// << 3;
            anhDoSangTuongQuan[(diaChi << 2)+1] = doSang;
            anhDoSangTuongQuan[(diaChi << 2)+2] = doSang;// << 1;
            anhDoSangTuongQuan[(diaChi << 2)+3] = 0xff;
            diaChi++;
         }
         
         unsigned short x = kCACH_GIUA;
         unsigned short y = kCACH_GIUA;
         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSangTuongQuan, beRong, beCao, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
         veXau( "1维相关1维↕︎", x, y - 30, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan );
      }
      
      if( duLieuTuongQuanNgang && duLieuTuongQuanDoc ) {
         unsigned char *anhDoSangTuongQuan = malloc( beRong*beCao << 2 );
         
         unsigned int diaChi = 0;
         unsigned int diaChiCuoi = beRong*beCao;
         while( diaChi < diaChiCuoi ) {
            float giaTriTuongQuanNgang = duLieuTuongQuanNgang[diaChi];
            float giaTriTuongQuanDoc = duLieuTuongQuanDoc[diaChi];
            float giaTriTuongQuan = sqrtf( giaTriTuongQuanNgang*giaTriTuongQuanNgang + giaTriTuongQuanDoc*giaTriTuongQuanDoc );
            if( giaTriTuongQuan > 1.0f )
               giaTriTuongQuan = 1.0f;
            
            unsigned char doSang = (unsigned char)(128.0f*giaTriTuongQuan) + 128;
            //            printf( "  %5.3f  %d", giaTriTuongQuan, doSang );
            anhDoSangTuongQuan[diaChi << 2] = doSang;// << 3;
            anhDoSangTuongQuan[(diaChi << 2)+1] = doSang;
            anhDoSangTuongQuan[(diaChi << 2)+2] = doSang;// << 1;
            anhDoSangTuongQuan[(diaChi << 2)+3] = 0xff;
            diaChi++;
         }
         
         unsigned short x = (kCACH_GIUA << 1) + beRong;
         unsigned short y = (kCACH_GIUA << 1) + beCao;
         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSangTuongQuan, beRong, beCao, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
         veXau( "1维相关1维↔︎+↕︎", x, y - 30, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan );
      }
      
      free( duLieuTuongQuanNgang );
      free( duLieuTuongQuanDoc );
      
      float *tuongQuan = tuongQuanGiuaMangSong_2Chieu( anhGoc, beRong, beCao, beRongAnhSong );
 //     float *tuongQuan = tuongQuanGiuaMangSong_2Chieu( anhSin, beRong, beCao, beRongAnhSong );

      if( tuongQuan ) {
         unsigned char *anhDoSangTuongQuan = malloc( beRong*beCao << 2 );
         
         unsigned int diaChi = 0;
         unsigned int diaChiCuoi = beRong*beCao;
         while( diaChi < diaChiCuoi ) {
            float giaTriTuongQuan = tuongQuan[diaChi];
            
            unsigned char doSang = (unsigned char)(128.0f*giaTriTuongQuan) + 128;
            //            printf( "  %5.3f  %d", giaTriTuongQuan, doSang );
            anhDoSangTuongQuan[diaChi << 2] = doSang;// << 3;
            anhDoSangTuongQuan[(diaChi << 2)+1] = doSang;
            anhDoSangTuongQuan[(diaChi << 2)+2] = doSang;// << 1;
            anhDoSangTuongQuan[(diaChi << 2)+3] = 0xff;
            diaChi++;
         }
         
         unsigned short x = (kCACH_GIUA << 1) + beRong;
         unsigned short y = kCACH_GIUA ;
         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSangTuongQuan, beRong, beCao, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
         veXau( "2维相关", x, y - 30, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan );
      }
   }
   else {
      printf( "veAnhTuongQuan: SAI LẦM giành trí nhớ cho ảnh tương quan\n" );
   }
   return anhTuongQuan;
}

#pragma mark ==== Tương Quan 1 CHIỀU
// ---- cộng thức này không an toàn nhưng tính nhanh hơn
// t(xy) = [E(xy) - E(x)E(y)]/[sqrt(E(x²) - E²(x)) • sqrt(E(y²) - E²(y))]

// ---- cộng thức này an toàn hơn nhưng tính chậm hơn
// t(xy) = E((X - E(X))•E((Y - E(Y))/[√(E(X - E(X))²)•√(E(Y - E(Y)))²]
//


// lật ngược ảnh (gương) tại ranh giới
// chỉ dùng kinh đỏ

float *tuongQuanGiuaMangSong_ngang( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong ) {
   
   // ---- chỉ cần tính giá trị này một lần E(X²)
   float phuongSaiSin;
   float *mangSin = mauAnhNuiSin_1chieu_truTrungBinh( beRongSong, &phuongSaiSin );
   float sqrtfPhuongSaiSin = sqrtf( phuongSaiSin );
   
   float *tuongQuanNgang = malloc( beRongAnh*beCaoAnh*sizeof( float ) );
   
   // ---- mảng để kèm các điểm ảnh thêm cho có thể tính tương quan đến rành ảnh
   unsigned short nuaBeRongSong = beRongSong >> 1;
   float *mangMotHangAnhKem = malloc( (beRongAnh + (nuaBeRongSong << 1))*sizeof(float) );

   if( tuongQuanNgang && mangSin && mangMotHangAnhKem ) {
      
      // ================
      // ---- địa chỉ trong ảnh
      unsigned int diaChiTuongQuan = 0;
      
      unsigned int soHang = 0;
      while( soHang < beCaoAnh ) {

         // ---- chép và gương hàng ảnh
         unsigned int diaChiAnh = beRongAnh*soHang << 2;
         unsigned int diaChiMangKem = nuaBeRongSong;
         unsigned int chiSo = 0;
         // ---- chép ảnh
         while( chiSo < beRongAnh ) {
            // ---- chỉ chép kênh đỏ
            mangMotHangAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem++;
            diaChiAnh += 4;
            chiSo++;
         }
         
         // ---- chép gương phải
         diaChiAnh -= 4;
         chiSo = 0;
         while( chiSo < nuaBeRongSong ) {
            mangMotHangAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem++;
            diaChiAnh -= 4;
            chiSo++;
         }
         
         // ---- chép gương trái
         chiSo = 0;
         diaChiAnh = beRongAnh*soHang << 2;
         diaChiMangKem = nuaBeRongSong-1;
         while( chiSo < nuaBeRongSong ) {
            mangMotHangAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem--;
            diaChiAnh += 4;
            chiSo++;
         }

         // ==== tính tương quang hàng
         unsigned int soCot = 0;
         while( soCot < beRongAnh ) {
            
            // ---- tính trung bình đoàn ảnh
            float trungBinh = 0.0f;
            chiSo = 0;
            diaChiMangKem = soCot;
            while( chiSo < beRongSong ) {
               trungBinh += mangMotHangAnhKem[diaChiMangKem];
//               printf( " %d diaChiMangKem %d  mangMotHangAnhKem[diaChiMangKem] %5.3f\n", chiSo, diaChiMangKem, mangMotHangAnhKem[diaChiMangKem] );
               diaChiMangKem++;
               chiSo++;
            }
            
            trungBinh /= (float)beRongSong;
  
            
            // ---- tính phương sai và tương quang
            tuongQuanNgang[diaChiTuongQuan] = 0.0f;
            float phuongSaiAnh = 0.0f;
            chiSo = 0;
            diaChiMangKem = soCot;
            while( chiSo < beRongSong ) {
               float sai = mangMotHangAnhKem[diaChiMangKem] - trungBinh;
               phuongSaiAnh += sai*sai;
               // ---- tính trung bình cho đoạn hàng ảnh
               tuongQuanNgang[diaChiTuongQuan] += mangSin[chiSo]*sai;
//               printf( "   %d sai %5.3f  mangSin[chiSo]*sai %5.3f\n", chiSo, sai, mangSin[chiSo]*sai );
               diaChiMangKem++;
               chiSo++;
            }

            tuongQuanNgang[diaChiTuongQuan] /= sqrtfPhuongSaiSin;
            tuongQuanNgang[diaChiTuongQuan] /= sqrtf( phuongSaiAnh );
//            printf( "  %d %d  √PhuongSaiSin %5.3f  √phuongSaiAnh %5.3f  TQ %5.3f\n", soHang, soCot, sqrtfPhuongSaiSin, sqrtf( phuongSaiAnh ), tuongQuan0[diaChiTuongQuan] );
            soCot++;
            diaChiTuongQuan++;
         }
         soHang++;
      }
      
   }
   else {
      printf( "tuongQuanGiuaHaiAnh: SAI LẦM giành trí nhớ cho tuongQuan hay mangSin\n" );
   }
   
   if( mangSin )
      free( mangSin );
   if( mangMotHangAnhKem )
      free( mangMotHangAnhKem );
   
   return tuongQuanNgang;
}
      
float *tuongQuanGiuaMangSong_doc( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong ) {
   
   // ---- chỉ cần tính giá trị này một lần E(X²)
   float phuongSaiSin;
   float *mangSin = mauAnhNuiSin_1chieu_truTrungBinh( beRongSong, &phuongSaiSin );
   float sqrtfPhuongSaiSin = sqrtf( phuongSaiSin );
   
   float *tuongQuanDoc = malloc( beRongAnh*beCaoAnh*sizeof( float ) );
   
   // ---- mảng để kèm các điểm ảnh thêm cho có thể tính tương quan đến rành ảnh
   unsigned short nuaBeRongSong = beRongSong >> 1;
   float *mangMotCotAnhKem = malloc( (beCaoAnh + (nuaBeRongSong << 1))*sizeof(float) );
   
   if( tuongQuanDoc && mangSin && mangMotCotAnhKem )  {

      // =================
      unsigned int soCot = 0;
      while( soCot < beRongAnh ) {
         
         // ---- chép và gương hàng ảnh
         unsigned int diaChiAnh = soCot << 2;
         unsigned int diaChiMangKem = nuaBeRongSong;
         unsigned int chiSo = 0;
         // ---- chép ảnh
         while( chiSo < beCaoAnh ) {
            // ---- chỉ chép kênh đỏ
            mangMotCotAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem++;
            diaChiAnh += beRongAnh << 2;
            chiSo++;
         }
         
         // ---- chép gương phải
         diaChiAnh -= beRongAnh << 2;
         chiSo = 0;
         while( chiSo < nuaBeRongSong ) {
            mangMotCotAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem++;
            diaChiAnh -= beRongAnh << 2;
            chiSo++;
         }
         
         // ---- chép gương trái
         chiSo = 0;
         diaChiAnh = soCot << 2;
         diaChiMangKem = nuaBeRongSong-1;
         while( chiSo < nuaBeRongSong ) {
            mangMotCotAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem--;
            diaChiAnh += beRongAnh << 2;
            chiSo++;
         }
         
         // ==== tính tương quang hàng
         unsigned int diaChiTuongQuan = soCot;
         unsigned int soHang = 0;
         while( soHang < beCaoAnh ) {
           
            // ---- tính trung bình đoàn ảnh
            float trungBinh = 0.0f;
            chiSo = 0;
            diaChiMangKem = soHang;
            while( chiSo < beRongSong ) {
               trungBinh += mangMotCotAnhKem[diaChiMangKem];
         //      printf( " %d diaChiMangKem %d  mangMotCotAnhKem[diaChiMangKem] %5.3f\n", chiSo, diaChiMangKem, mangMotCotAnhKem[diaChiMangKem] );

               diaChiMangKem++;
               chiSo++;
            }
            
            trungBinh /= (float)beRongSong;
          
            // ---- tính phương sai và tương quang
            tuongQuanDoc[diaChiTuongQuan] = 0.0f;
            float phuongSaiAnh = 0.0f;
            chiSo = 0;
            diaChiMangKem = soHang;
            while( chiSo < beRongSong ) {
               float sai = mangMotCotAnhKem[diaChiMangKem] - trungBinh;
               phuongSaiAnh += sai*sai;
               // ---- tính trung bình cho đoạn hàng ảnh
               tuongQuanDoc[diaChiTuongQuan] += mangSin[chiSo]*sai;
               diaChiMangKem++;
               chiSo++;
            }
            tuongQuanDoc[diaChiTuongQuan] /= sqrtfPhuongSaiSin;
            tuongQuanDoc[diaChiTuongQuan] /= sqrtf( phuongSaiAnh );

 /*           if( soHang == beCaoAnh - 1 ) {
               printf( "soHang %d  trungBinh %5.3f  phuongSaiAnh %5.3f  tuongQuan %5.3f\n", soHang, trungBinh, phuongSaiAnh, tuongQuan1[diaChiTuongQuan] );
               exit(9);
            } */
            soHang++;
            diaChiTuongQuan += beRongAnh;
         }
  
         soCot++;
      }

   }
   else {
      printf( "tuongQuanGiuaHaiAnh: SAI LẦM giành trí nhớ cho tuongQuan hay mangSin\n" );
   }
   
   if( mangSin )
      free( mangSin );
   if( mangMotCotAnhKem )
      free( mangMotCotAnhKem );
   
   return tuongQuanDoc;
}

#pragma mark ---- Tính Trung Bình Và Phương Sai
// ham` này lật ngược ảnh tái rành giới
// hàm này tính trung bình quanh sốCột và sốHàng

float tinhTrungBinhVaPhuongSai_doanHang( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned int soCot, unsigned int soHang, unsigned short beRongDoanTrungBinh, float *phuongSai ) {
   
   return 0.0f;
}


/* Phiên bản này không cẩn chép các điểm ảnh ngoài ảnh,
  và nó làm gương cho các điểm ảnh ỡ ngoài
         ngoài ảnh  |<-------  ảnh-------->|  ngoài ảnh
 làm gương --> 45 34| 34 45 02       98 67 | 67 98 <-- làm gương
 
float tinhTrungBinhVaPhuongSai_doanHangGuong( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned int soCot, unsigned int soHang, unsigned short beRongDoanTrungBinh, float *phuongSai ) {
   
   unsigned short nuaBeRongTrungBinh = beRongDoanTrungBinh >> 1;

   *phuongSai = 0.0f;
   float trungBinh = 0.0f;
   //   beRongDoanTrungBinh
   // |<----------+---------->|
   //      +------o---+---------------
   if( soCot < nuaBeRongTrungBinh ) {
      unsigned int diaChiAnh = beRongAnh*soHang << 2;
      unsigned short soCotCuoi = soCot + nuaBeRongTrungBinh + 1;

      // ---- tính trung bình
      unsigned short chiSo = 0;
      while( chiSo < soCotCuoi ) {
         trungBinh += anh[diaChiAnh];
//         printf( "  0: %d trungBinh %5.3f  diaChiAnh %d  anh %d\n", chiSo, trungBinh, diaChiAnh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }

      // ---- cộng thêm lần nữa cho ảnh lất ngoài rành
      soCotCuoi = nuaBeRongTrungBinh - soCot;
      chiSo = 0;
      while( chiSo < soCotCuoi ) {
         trungBinh += anh[diaChiAnh];
//      printf( "  0: ++ %d trungBinh %5.3f  diaChiAnh %d  anh %d\n", chiSo, trungBinh, diaChiAnh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- chia bề rộng đoạn trung bình
      trungBinh /= (float)beRongDoanTrungBinh;
//      printf( "  0: trungBinh %5.3f\n", trungBinh );
      
      // ---- tính phương sai
      soCotCuoi = soCot + nuaBeRongTrungBinh + 1;
      chiSo = 0;
      diaChiAnh = beRongAnh*soHang << 2;
      while( chiSo < soCotCuoi ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
//         printf( "  0: %d *phuongSai %5.3f  sai %5.3f  diaChiAnh %d\n", chiSo, *phuongSai, sai, diaChiAnh );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- cộng thêm lần nữa cho ảnh lất ngoài rành
      soCotCuoi = nuaBeRongTrungBinh - soCot;
      chiSo = 0;
      while( chiSo < soCotCuoi ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
//         printf( "  0: ++ %d *phuongSai %5.3f  sai %5.3f  diaChiAnh %d\n", chiSo, *phuongSai, sai, diaChiAnh );
         diaChiAnh += 4;
         chiSo++;
      }
   }
   else if( soCot > beRongAnh - nuaBeRongTrungBinh - 1 ) {
      unsigned int diaChiAnh = (beRongAnh*soHang + soCot - nuaBeRongTrungBinh) << 2;
      
      // ---- tính trung bình
      unsigned short chiSo = soCot - nuaBeRongTrungBinh;
      while( chiSo < beRongAnh ) {
         trungBinh += anh[diaChiAnh];
//         printf( "  2: soCot %d %d trungBinh %5.3f  diaChiAnh %d  anh %d\n", soCot, chiSo, trungBinh, diaChiAnh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- cộng thêm lần nữa cho ảnh lất ngoài rành
      chiSo = (beRongAnh << 1) - (soCot + nuaBeRongTrungBinh + 1);
      diaChiAnh = (beRongAnh*soHang + chiSo) << 2;
      while( chiSo < beRongAnh ) {
         trungBinh += anh[diaChiAnh];
//         printf( "  2: ++ %d trungBinh %5.3f  diaChiAnh %d  anh %d\n", chiSo, trungBinh, diaChiAnh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- chia bề rộng đoạn trung bình
      trungBinh /= (float)beRongDoanTrungBinh;
//      printf( "  2: trungBinh %5.3f\n", trungBinh );
      
      // ---- tính phương sai
      chiSo = soCot - nuaBeRongTrungBinh;
      diaChiAnh = (beRongAnh*soHang + soCot - nuaBeRongTrungBinh) << 2;
      while( chiSo < beRongAnh ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
//         printf( "  2: %d *phuongSai %5.3f  sai %5.3f  diaChiAnh %d\n", chiSo, *phuongSai, sai, diaChiAnh );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- cộng thêm lần nữa cho ảnh lất ngoài rành
      chiSo = (beRongAnh << 1) - (soCot + nuaBeRongTrungBinh + 1);
      diaChiAnh = (beRongAnh*soHang + chiSo) << 2;
      while( chiSo < beRongAnh ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
//         printf( "  2: ++ %d *phuongSai %5.3f  sai %5.3f  diaChiAnh %d\n", chiSo, *phuongSai, sai, diaChiAnh );
         diaChiAnh += 4;
         chiSo++;
      }
   }
   else {
      unsigned int diaChiAnh = (beRongAnh*soHang + soCot - nuaBeRongTrungBinh) << 2;
      unsigned short soCotDau = soCot - nuaBeRongTrungBinh;
      unsigned short soCotCuoi = soCot + nuaBeRongTrungBinh + 1;

      unsigned short chiSo = soCotDau;
      while( chiSo < soCotCuoi ) {
         trungBinh += anh[diaChiAnh];
//      printf( "soCot %d  1: %d trungBinh %5.3f  anh %d\n", soCot, chiSo, trungBinh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }
      // ---- chia bề rộng đoạn trung bình
      trungBinh /= (float)beRongDoanTrungBinh;
//      printf( "  1: trungBinh %5.3f  anh %d\n", trungBinh, anh[diaChiAnh] );
      
      chiSo = soCotDau;
      diaChiAnh = (beRongAnh*soHang + soCot - nuaBeRongTrungBinh) << 2;
      while( chiSo < soCotCuoi ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
         diaChiAnh += 4;
         chiSo++;
      }
   }
   
   
   return trungBinh;
}
*/


#pragma mark ==== TƯƠNG QUAN 2 CHIỀU

//         nữa núi                           nữa núi
//        |<-sin->|<-----  bề rộng ảnh ---->|<-sin->|
//        +-------+-------------------------+-------+
//        |  ảnh  |                         |  ảnh  |
//        | gương |         ảnh gương       | gương |
//        +-------+-------------------------+-------+
//        |       |                         |       |
//        |  ảnh  |                         |  ảnh  |
//        | gương |            ảnh          | gương |
//        |       |                         |       |
//        |       |                         |       |
//    -   +-------+-------------------------+-------+
//    ^   |  ảnh  |                         |  ảnh  |
//    c   | gương |         ảnh gương       | gương |
//    -   +-------+-------------------------+-------+
//        |<-sin->|<-----  bề rộng ảnh ---->|<-sin->|
//         nữa núi                           nữa núi
// LƯƠ Ý: hàm này chỉ dùng kênh đỏ

float *tuongQuanGiuaMangSong_2Chieu( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong ) {
   
   // ---- chỉ cần tính giá trị này một lần E(X²)
   float phuongSaiNuiSin;
   float *mangNuiSin = mauAnhNuiSin_2chieu_truTrungBinh( beRongSong, &phuongSaiNuiSin );
   float sqrtfPhuongSaiNuiSin = sqrtf( phuongSaiNuiSin );
   
   float *tuongQuan = malloc( beRongAnh*beCaoAnh*sizeof( float ) );
   
   // ---- mảng để kèm các điểm ảnh thêm cho có thể tính tương quan đến rành ảnh
   unsigned short nuaBeRongSong = beRongSong >> 1;
   unsigned int beRongAnhKem = beRongAnh + (nuaBeRongSong << 1);
   unsigned int beCaoAnhKem = beCaoAnh + (nuaBeRongSong << 1);
   float *anhKem = malloc( beRongAnhKem*beCaoAnhKem*sizeof(float) );
   
   if( tuongQuan && mangNuiSin && anhKem )  {
      
      // ---- chép ảnh
      unsigned int soHang = 0;
      unsigned int diaChiAnh = 0;
      while( soHang < beCaoAnh ) {
         unsigned int diaChiAnhKem = (nuaBeRongSong + soHang)*beRongAnhKem + nuaBeRongSong;
         
         unsigned int soCot = 0;
         while( soCot < beRongAnh ) {
            anhKem[diaChiAnhKem] = (float)anh[diaChiAnh];
            diaChiAnh += 4;
            diaChiAnhKem++;
            soCot++;
         }

         soHang++;
      }
      
      // ---- gương ảnh trên
      diaChiAnh -= beRongAnh << 2;
      unsigned int chiSo = 0;
      while( chiSo < nuaBeRongSong ) {
         unsigned int diaChiAnhKem = (nuaBeRongSong + beCaoAnh + chiSo)*beRongAnhKem + nuaBeRongSong;
         unsigned int soCot = 0;
         while( soCot < beRongAnh ) {
            anhKem[diaChiAnhKem] = (float)anh[diaChiAnh];
            diaChiAnh += 4;
            diaChiAnhKem++;
            soCot++;
         }
         
         diaChiAnh -= beRongAnh << 3;
         chiSo++;
      }
      
      // ---- gương ảnh dưới
      diaChiAnh = 0;
      chiSo = 0;
      while( chiSo < nuaBeRongSong ) {
         unsigned int diaChiAnhKem = (nuaBeRongSong - 1 - chiSo)*beRongAnhKem + nuaBeRongSong;
         unsigned int soCot = 0;
         while( soCot < beRongAnh ) {
            anhKem[diaChiAnhKem] = (float)anh[diaChiAnh];
            diaChiAnh += 4;
            diaChiAnhKem++;
            soCot++;
         }

         chiSo++;
      }
  
      // ---- gương ảnh trái và phái, dùng ảnh kèm tự gương hai bên
      soHang = 0;
      while( soHang < beCaoAnhKem ) {
         
         unsigned int diaChiTrai = nuaBeRongSong + soHang*beRongAnhKem;
         unsigned int diaChiTraiGuong = nuaBeRongSong - 1 + soHang*beRongAnhKem;
         unsigned int diaChiPhai = nuaBeRongSong + beRongAnh - 1 + soHang*beRongAnhKem;
         unsigned int diaChiPhaiGuong = nuaBeRongSong + beRongAnh + soHang*beRongAnhKem;

         unsigned int soCot = 0;
         while( soCot < nuaBeRongSong ) {
            // ---- bên trái
            anhKem[diaChiTraiGuong] = anhKem[diaChiTrai];
            // ---- bên phải
            anhKem[diaChiPhaiGuong] = anhKem[diaChiPhai];
            
            diaChiTrai++;
            diaChiTraiGuong--;
            diaChiPhai--;
            diaChiPhaiGuong++;
            soCot++;
         }
         soHang++;
      }
      
      // ==== tương quan
      unsigned int diaChiTuongQuan = 0;
      soHang = 0;
      while( soHang < beCaoAnh ) {
         unsigned int soCot = 0;
         while( soCot < beRongAnh ) {
            // +------------------+
            // |                  |
            // +---+              |
            // | + |              |
            // +---+--------------+
            
            // ---- tính trung bình đoàn ảnh
            float trungBinh = 0.0f;

            unsigned int soHangNuiSin = 0;
            while( soHangNuiSin < beRongSong ) {
               unsigned int diaChiAnhKem = (soHang + soHangNuiSin)*beRongAnhKem + soCot;
               unsigned int soCotNuiSin = 0;
               while( soCotNuiSin < beRongSong ) {
                  trungBinh += (float)anhKem[diaChiAnhKem];
                  diaChiAnhKem++;
                  soCotNuiSin++;
               }
               soHangNuiSin++;
            }
            
            trungBinh /= beRongSong*beRongSong;

            // ---- tính phương sai và tương quang
            unsigned int diaChiNuiSin = 0;
            tuongQuan[diaChiTuongQuan] = 0.0f;
            float phuongSaiAnh = 0.0f;
            soHangNuiSin = 0;
            while( soHangNuiSin < beRongSong ) {
               unsigned int diaChiAnhKem = (soHang + soHangNuiSin)*beRongAnhKem + soCot;
               unsigned int soCotNuiSin = 0;
               while( soCotNuiSin < beRongSong ) {

                  float sai = anhKem[diaChiAnhKem] - trungBinh;
                  phuongSaiAnh += sai*sai;
                  // ---- tính trung bình cho đoạn hàng ảnh
                  tuongQuan[diaChiTuongQuan] += mangNuiSin[diaChiNuiSin]*sai;

                  diaChiAnhKem++;
                  diaChiNuiSin++;
                  soCotNuiSin++;
               }

               soHangNuiSin++;
            }

            tuongQuan[diaChiTuongQuan] /= sqrtfPhuongSaiNuiSin;
            tuongQuan[diaChiTuongQuan] /= sqrtf( phuongSaiAnh );

            diaChiTuongQuan++;
            soCot++;
         }
         printf( "soHang %d\n", soHang );
         
         soHang++;
      }
      
      // ================ kiểm tra ảnh
   /*
      unsigned char *anhKiemTra = malloc( beRongAnhKem*beCaoAnhKem << 2 );
      unsigned int diaChiAnhKem = 0;
      unsigned int diaChiAnhKemCuoi = beRongAnhKem*beCaoAnhKem;
      soHang = 0;

      while( soHang < beCaoAnh ) {
         
         unsigned int soCot = 0;
         while( soCot < beRongAnh ) {
            unsigned char giaTri = anhKem[diaChiAnhKem];
            printf( " %d", giaTri );
            anhKiemTra[diaChiAnh] = giaTri;
            anhKiemTra[diaChiAnh+1] = giaTri;
            anhKiemTra[diaChiAnh+2] = giaTri;
            anhKiemTra[diaChiAnh+3] = 0xff;
            diaChiAnh += 4;
            diaChiAnhKem++;
            soCot++;
         }
         printf( "\n" );
         soHang++;
      } */
  //    luuAnhPNG_BGRO( "AnhGuong", anhKiemTra, beRongAnhKem, beCaoAnhKem );
      // ================
      
   }
   else {
      printf( "tuongQuanGiuaHaiAnh: SAI LẦM giành trí nhớ cho tuongQuan hay mangSin\n" );
   }
   
   if( mangNuiSin )
      free( mangNuiSin );
   if( anhKem )
      free( anhKem );
   
   return tuongQuan;
}


#pragma mark ---- Núi sin

#define kHAI_PI 6.283185307f
#define kPI 3.141592654f
#define kPI_CHIA_2 1.570796f

// -cos( πx/beRong + π/2)
// Nên dùng bề rộng số lẻ
float *mauAnhNuiSin_1chieu_truTrungBinh( unsigned short beRong, float *phuongSai ) {
   
   float *anhNui = malloc( beRong * sizeof(float) );
   if( anhNui ) {
      float trungBinh = 0.0f;
      
      float buoc = 1.0f/(float)(beRong-1);
      
      unsigned short chiSo = 0;
      while( chiSo < beRong ) {
         anhNui[chiSo] = -cosf( kPI*chiSo*buoc + kPI_CHIA_2 );
         trungBinh += anhNui[chiSo];
         chiSo++;
      }
      
      trungBinh /= (float)beRong;
      
      // ---- trừ trung bình
      *phuongSai = 0.0f;
      chiSo = 0;
      while( chiSo < beRong ) {
         float sai = anhNui[chiSo] - trungBinh;
         anhNui[chiSo] = sai;
         *phuongSai += sai*sai;
         chiSo++;
      }
      
   }
   else
      printf( "TuongQuan: SAI LẦM giành trí nhớ cho mauAnhNuiSin_1chieu\n" );
   
   return anhNui;
}


float *mauAnhNuiSin_2chieu_truTrungBinh( unsigned short beRong, float *phuongSai ) {
   
   float *anhNui = malloc( beRong * beRong * sizeof(float) );
   
   if( anhNui ) {
      float trungBinh = 0.0f;
      
      float buoc = 1.0f/(float)(beRong-1);
      
      unsigned int diaChi = 0;
      unsigned short soHang = 0;
      float y = 0.0f;
      while( soHang < beRong ) {
         unsigned short soCot = 0;
         float x = 0.0f;
         while( soCot < beRong ) {
            anhNui[diaChi] = cosf( kPI*x + kPI_CHIA_2 )*cosf( kPI*y + kPI_CHIA_2 );
            trungBinh += anhNui[diaChi];
            
            x += buoc;
            diaChi++;
            soCot++;
         }
         y += buoc;
         soHang++;
      }
      
      
      // =========== THỬ NGHIỆM
      /*     unsigned int diaChiAnh = 0;
       unsigned int diaChiCuoi_ = beRong*beRong;
       unsigned char *anhKiemTra = malloc( diaChiCuoi_ << 2 );
       diaChi = 0;
       
       while( diaChi < diaChiCuoi_ ) {
       
       unsigned char giaTri = anhNui[diaChi]*255;
       anhKiemTra[diaChiAnh] = giaTri;
       anhKiemTra[diaChiAnh+1] = giaTri;
       anhKiemTra[diaChiAnh+2] = giaTri;
       anhKiemTra[diaChiAnh+3] = 0xff;
       diaChiAnh += 4;
       diaChi++;
       }
       luuAnhPNG_BGRO( "anhNuiSin", anhKiemTra, beRong, beRong );
       free( anhKiemTra );
       exit(0); */
      // ===============
      
      trungBinh /= (float)beRong*beRong;
      
      // ---- trừ trung bình
      *phuongSai = 0.0f;
      diaChi = 0;
      unsigned int diaChiCuoi = beRong*beRong;
      while( diaChi < diaChiCuoi ) {
         float sai = anhNui[diaChi] - trungBinh;
         anhNui[diaChi] = sai;
         *phuongSai += sai*sai;
         diaChi++;
      }
      
   }
   else
      printf( "TuongQuan: SAI LẦM giành trí nhớ cho mauAnhNuiSin_2chieu\n" );
   
   return anhNui;
}

