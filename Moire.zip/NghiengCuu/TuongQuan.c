/* TươngQuan.c */

// TOÀN BỘ NÀY ĐỂ NGHIÊN CỨU - KHÔNG CẦN CHO CHƯƠNG TRÌNH ĐỂ HOẠT ĐỘNG

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CatNgang.h"
#include "../HangSo.h"
#include "../PNG/PNG.h"
#include "../VeVatThe/ChepAnh.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../ToMauAnh/Diem.h"
#include "../TimNet/TimNet.h"


#pragma mark ---- Cắt Ngang (CHO NGHIÊNG CỨU ẢNH)
//        |<------ r ------>|  |<------ r ------>|
//    +--------------------------------------------+
//  - |  +------------------+  +-----------------+ |
//  ^ |  |                  |  +-----------------+ |
//  c |  |                  |  +-----------------+ |
//  v |  |                  |  +-----------------+ |
//  - |  +------------------+  +-----------------+ |
//    |  +----+ +----+ +----+                      |
//    |  |    | |    | |    |                      |
//    |  |    | |    | |    |                      |
//    |  |    | |    | |    |                      |
//    |  +----+ +----+ +----+                      |
//    +--------------------------------------------+
//       |<256>||<256>||<256>|

float *tuongQuanGiuaMangSong_ngang( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong );
float *tuongQuanGiuaMangSong_doc( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong );

float tinhTrungBinhVaPhuongSai_doanHang( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned int soCot, unsigned int soHang, unsigned short beRongSong, float *phuongSai );

float *mauAnhNuiSin_1chieu_truTrungBinh( unsigned short beRong, float *phuongSai );


#define kCACH_GIUA 100 // cách giữa (điểm ảnh)

#define kANH_DO_SANG   0
#define kANH_CAT_NGANG 1
#define kANH_CAT_DOC   6
#define kSO_LUONG_ANH 11

#define kBE_RONG_ANH_KIEM_TRA 81  // điểm ảnh


unsigned char *veAnhTuongQuan( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhTuongQuan, unsigned int *beCaoAnhTuongQuan ) {
   
   *beRongAnhTuongQuan = (beRong << 1) + 3*kCACH_GIUA;
   *beCaoAnhTuongQuan = (beCao << 1) + 3*kCACH_GIUA;
   
   unsigned char *anhTuongQuan = malloc( *beRongAnhTuongQuan * *beCaoAnhTuongQuan << 2);
   unsigned int diaChiAnh = 0;
   unsigned int diaChiAnhCuoi = (*beRongAnhTuongQuan * *beCaoAnhTuongQuan) << 2;
   while( diaChiAnh < diaChiAnhCuoi ) {
      anhTuongQuan[diaChiAnh] = 0xff;
      anhTuongQuan[diaChiAnh+1] = 0xff;
      anhTuongQuan[diaChiAnh+2] = 0xff;
      anhTuongQuan[diaChiAnh+3] = 0xff;
      diaChiAnh += 4;
   }
   
   if( anhTuongQuan != NULL ) {

      // ---- cho giữ vị trí các ảnh, giúp vẽ điểm thích thú trên sơ đồ
      Diem mangGocAnh[kSO_LUONG_ANH];
      /*
      // =========== THỬ NGHIỆN
      unsigned char *anhSin = malloc( beRong*beCao << 2 );
      float buoc = 1.0f/80.0f;
      unsigned int diaChiAnhSin = 0;
      unsigned short soHang = 0;
      while( soHang < beCao ) {
         
         unsigned short soCot = 0;
         while( soCot < beRong ) {
            unsigned char giaTri = -cosf( 3.14159f*((soCot + soHang)*buoc + 0.5f) )*255;
            anhSin[diaChiAnhSin] = giaTri;
            anhSin[diaChiAnhSin+1] = giaTri;
            anhSin[diaChiAnhSin+2] = giaTri;
            anhSin[diaChiAnhSin+3] = 0xff;
            diaChiAnhSin += 4;
            soCot++;
         }
         
         soHang++;
      }
      luuAnhPNG_BGRO( "anhSin", anhSin, beRong, beCao );
  //    exit(0);
      
      float *duLieuTuongQuan = tuongQuanGiuaMangSong_ngang( anhSin, beRong, beCao, kBE_RONG_ANH_KIEM_TRA );
      */
      // ===========
   
     float *duLieuTuongQuanNgang = tuongQuanGiuaMangSong_ngang( anhGoc, beRong, beCao, kBE_RONG_ANH_KIEM_TRA );
      
      if( duLieuTuongQuanNgang ) {
         
         unsigned char *anhDoSangTuongQuan = malloc( beRong*beCao << 2 );
         
         unsigned int diaChi = 0;
         unsigned int diaChiCuoi = beRong*beCao;
         while( diaChi < diaChiCuoi ) {
            float giaTriTuongQuan = duLieuTuongQuanNgang[diaChi];
            if( (giaTriTuongQuan < -1.0f) || (giaTriTuongQuan > 1.0f) ) {
               printf( "  diaChi %d  diaChiCuoi %d\n", diaChi, diaChiCuoi );
               exit(0);
            }
            
            unsigned char doSang = (unsigned char)(128.0f*giaTriTuongQuan) + 128;
//            printf( "  %5.3f  %d", giaTriTuongQuan, doSang );
            anhDoSangTuongQuan[diaChi << 2] = doSang;// << 3;
            anhDoSangTuongQuan[(diaChi << 2)+1] = doSang;
            anhDoSangTuongQuan[(diaChi << 2)+2] = doSang;// << 1;
            anhDoSangTuongQuan[(diaChi << 2)+3] = 0xff;
            diaChi++;
         }
         
         unsigned short x = kCACH_GIUA;
         unsigned short y = (kCACH_GIUA << 1) + beCao;
         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSangTuongQuan, beRong, beCao, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
         
     //    free( duLieuTuongQuanNgang );
         
         // ===========
         
      }
      
      float *duLieuTuongQuanDoc = tuongQuanGiuaMangSong_doc( anhGoc, beRong, beCao, kBE_RONG_ANH_KIEM_TRA );
      
      // ===========
      
      if( duLieuTuongQuanDoc ) {
         
         unsigned char *anhDoSangTuongQuan = malloc( beRong*beCao << 2 );
         
         unsigned int diaChi = 0;
         unsigned int diaChiCuoi = beRong*beCao;
         while( diaChi < diaChiCuoi ) {
            float giaTriTuongQuan = duLieuTuongQuanDoc[diaChi];
            if( (giaTriTuongQuan < -1.0f) || (giaTriTuongQuan > 1.0f) ) {
               printf( "  diaChi %d  diaChiCuoi %d\n", diaChi, diaChiCuoi );
               exit(0);
            }
            
            unsigned char doSang = (unsigned char)(128.0f*giaTriTuongQuan) + 128;
            //            printf( "  %5.3f  %d", giaTriTuongQuan, doSang );
            anhDoSangTuongQuan[diaChi << 2] = doSang;// << 3;
            anhDoSangTuongQuan[(diaChi << 2)+1] = doSang;
            anhDoSangTuongQuan[(diaChi << 2)+2] = doSang;// << 1;
            anhDoSangTuongQuan[(diaChi << 2)+3] = 0xff;
            diaChi++;
         }
         
         unsigned short x = kCACH_GIUA;
         unsigned short y = kCACH_GIUA;
         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSangTuongQuan, beRong, beCao, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
         
     //    free( duLieuTuongQuan );
      }
      
      if( duLieuTuongQuanNgang && duLieuTuongQuanDoc ) {
         unsigned char *anhDoSangTuongQuan = malloc( beRong*beCao << 2 );
         
         unsigned int diaChi = 0;
         unsigned int diaChiCuoi = beRong*beCao;
         while( diaChi < diaChiCuoi ) {
            float giaTriTuongQuanNgang = duLieuTuongQuanNgang[diaChi];
            float giaTriTuongQuanDoc = duLieuTuongQuanDoc[diaChi];
            float giaTriTuongQuan = sqrtf( giaTriTuongQuanNgang*giaTriTuongQuanNgang + giaTriTuongQuanDoc*giaTriTuongQuanDoc );
            
            unsigned char doSang = (unsigned char)(128.0f*giaTriTuongQuan) + 128;
            //            printf( "  %5.3f  %d", giaTriTuongQuan, doSang );
            anhDoSangTuongQuan[diaChi << 2] = doSang;// << 3;
            anhDoSangTuongQuan[(diaChi << 2)+1] = doSang;
            anhDoSangTuongQuan[(diaChi << 2)+2] = doSang;// << 1;
            anhDoSangTuongQuan[(diaChi << 2)+3] = 0xff;
            diaChi++;
         }
         
         unsigned short x = (kCACH_GIUA << 1) + beRong;
         unsigned short y = (kCACH_GIUA << 1) + beCao;
         // ---- chép vào ảnh cắt ngang
         chepAnhVaoAnh( anhDoSangTuongQuan, beRong, beCao, anhTuongQuan, *beRongAnhTuongQuan, *beCaoAnhTuongQuan, x, y );
      }

   }
   else {
      printf( "veAnhTuongQuan: SAI LẦM giành trí nhớ cho ảnh tương quan\n" );
   }
   return anhTuongQuan;
}

#pragma mark ---- Tương Quan
// ---- cộng thức này không an toàn nhưng tính nhanh hơn
// t(xy) = [E(xy) - E(x)E(y)]/[sqrt(E(x²) - E²(x)) • sqrt(E(y²) - E²(y))]

// ---- cộng thức này an toàn hơn nhưng tính chậm hơn
// t(xy) = E((X - E(X))•E((Y - E(Y))/[√(E(X - E(X))²)•√(E(Y - E(Y)))²]
//
//        |<-------------- ảnh chánh ------------->|
//        +------+-------------------------+-------+
//        |      |                         |       |
//        |      |                         |       |
//        +------+-------------------------+-------+
//        |      |                         |       |
//        |      |                         |       |
//        |      |                         |       |
//        |      |                         |       |
//        |      |                         |       |
//    -   +------+-------------------------+-------+
//    ^   |      |                         |       |
//   c0-c1|      |                         |       |
//    -   +------+-------------------------+-------+
//         r0 - r1
//        |<---->|

// lật ngược ảnh (gương) tại ranh giới
// chỉ dùng kinh đỏ

float *tuongQuanGiuaMangSong_ngang( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong ) {
   
   // ---- chỉ cần tính giá trị này một lần E(X²)
   float phuongSaiSin;
   float *mangSin = mauAnhNuiSin_1chieu_truTrungBinh( beRongSong, &phuongSaiSin );
   float sqrtfPhuongSaiSin = sqrtf( phuongSaiSin );
   
   float *tuongQuanNgang = malloc( beRongAnh*beCaoAnh*sizeof( float ) );
   
   // ---- mảng để kèm các điểm ảnh thêm cho có thể tính tương quan đến rành ảnh
   unsigned short nuaBeRongSong = beRongSong >> 1;
   float *mangMotHangAnhKem = malloc( (beRongAnh + (nuaBeRongSong << 1))*sizeof(float) );

   if( tuongQuanNgang && mangSin && mangMotHangAnhKem ) {
      
      // ================
      // ---- địa chỉ trong ảnh
      unsigned int diaChiTuongQuan = 0;
      
      unsigned int soHang = 0;
      while( soHang < beCaoAnh ) {

         // ---- chép và gương hàng ảnh
         unsigned int diaChiAnh = beRongAnh*soHang << 2;
         unsigned int diaChiMangKem = nuaBeRongSong;
         unsigned int chiSo = 0;
         // ---- chép ảnh
         while( chiSo < beRongAnh ) {
            // ---- chỉ chép kênh đỏ
            mangMotHangAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem++;
            diaChiAnh += 4;
            chiSo++;
         }
         
         // ---- chép gương phải
         diaChiAnh -= 4;
         chiSo = 0;
         while( chiSo < nuaBeRongSong ) {
            mangMotHangAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem++;
            diaChiAnh -= 4;
            chiSo++;
         }
         
         // ---- chép gương trái
         chiSo = 0;
         diaChiAnh = beRongAnh*soHang << 2;
         diaChiMangKem = nuaBeRongSong-1;
         while( chiSo < nuaBeRongSong ) {
            mangMotHangAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem--;
            diaChiAnh += 4;
            chiSo++;
         }

         // ==== tính tương quang hàng
         unsigned int soCot = 0;
         while( soCot < beRongAnh ) {
            
            // ---- tính trung bình đoàn ảnh
            float trungBinh = 0.0f;
            chiSo = 0;
            diaChiMangKem = soCot;
            while( chiSo < beRongSong ) {
               trungBinh += mangMotHangAnhKem[diaChiMangKem];
//               printf( " %d diaChiMangKem %d  mangMotHangAnhKem[diaChiMangKem] %5.3f\n", chiSo, diaChiMangKem, mangMotHangAnhKem[diaChiMangKem] );
               diaChiMangKem++;
               chiSo++;
            }
            
            trungBinh /= (float)beRongSong;
  
            
            // ---- tính phương sai và tương quang
            tuongQuanNgang[diaChiTuongQuan] = 0.0f;
            float phuongSaiAnh = 0.0f;
            chiSo = 0;
            diaChiMangKem = soCot;
            while( chiSo < beRongSong ) {
               float sai = mangMotHangAnhKem[diaChiMangKem] - trungBinh;
               phuongSaiAnh += sai*sai;
               // ---- tính trung bình cho đoạn hàng ảnh
               tuongQuanNgang[diaChiTuongQuan] += mangSin[chiSo]*sai;
//               printf( "   %d sai %5.3f  mangSin[chiSo]*sai %5.3f\n", chiSo, sai, mangSin[chiSo]*sai );
               diaChiMangKem++;
               chiSo++;
            }

            tuongQuanNgang[diaChiTuongQuan] /= sqrtfPhuongSaiSin;
            tuongQuanNgang[diaChiTuongQuan] /= sqrtf( phuongSaiAnh );
//            printf( "  %d %d  √PhuongSaiSin %5.3f  √phuongSaiAnh %5.3f  TQ %5.3f\n", soHang, soCot, sqrtfPhuongSaiSin, sqrtf( phuongSaiAnh ), tuongQuan0[diaChiTuongQuan] );
            soCot++;
            diaChiTuongQuan++;
         }
         soHang++;
      }
      
   }
   else {
      printf( "tuongQuanGiuaHaiAnh: SAI LẦM giành trí nhớ cho tuongQuan hay mangSin\n" );
   }
   
   if( mangSin )
      free( mangSin );
   if( mangMotHangAnhKem )
      free( mangMotHangAnhKem );
   
   return tuongQuanNgang;
}
      
float *tuongQuanGiuaMangSong_doc( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short beRongSong ) {
   
   // ---- chỉ cần tính giá trị này một lần E(X²)
   float phuongSaiSin;
   float *mangSin = mauAnhNuiSin_1chieu_truTrungBinh( beRongSong, &phuongSaiSin );
   float sqrtfPhuongSaiSin = sqrtf( phuongSaiSin );
   
   float *tuongQuanDoc = malloc( beRongAnh*beCaoAnh*sizeof( float ) );
   
   // ---- mảng để kèm các điểm ảnh thêm cho có thể tính tương quan đến rành ảnh
   unsigned short nuaBeRongSong = beRongSong >> 1;
   float *mangMotCotAnhKem = malloc( (beCaoAnh + (nuaBeRongSong << 1))*sizeof(float) );
   
   if( tuongQuanDoc && mangSin && mangMotCotAnhKem )  {

      // =================
      unsigned int soCot = 0;
      while( soCot < beRongAnh ) {
         
         // ---- chép và gương hàng ảnh
         unsigned int diaChiAnh = soCot << 2;
         unsigned int diaChiMangKem = nuaBeRongSong;
         unsigned int chiSo = 0;
         // ---- chép ảnh
         while( chiSo < beCaoAnh ) {
            // ---- chỉ chép kênh đỏ
            mangMotCotAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem++;
            diaChiAnh += beRongAnh << 2;
            chiSo++;
         }
         
         // ---- chép gương phải
         diaChiAnh -= beRongAnh << 2;
         chiSo = 0;
         while( chiSo < nuaBeRongSong ) {
            mangMotCotAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem++;
            diaChiAnh -= beRongAnh << 2;
            chiSo++;
         }
         
         // ---- chép gương trái
         chiSo = 0;
         diaChiAnh = soCot << 2;
         diaChiMangKem = nuaBeRongSong-1;
         while( chiSo < nuaBeRongSong ) {
            mangMotCotAnhKem[diaChiMangKem] = (float)anh[diaChiAnh];
            diaChiMangKem--;
            diaChiAnh += beRongAnh << 2;
            chiSo++;
         }
         
         // ==== tính tương quang hàng
         unsigned int diaChiTuongQuan = soCot;
         unsigned int soHang = 0;
         while( soHang < beCaoAnh ) {
           
            // ---- tính trung bình đoàn ảnh
            float trungBinh = 0.0f;
            chiSo = 0;
            diaChiMangKem = soHang;
            while( chiSo < beRongSong ) {
               trungBinh += mangMotCotAnhKem[diaChiMangKem];
         //      printf( " %d diaChiMangKem %d  mangMotCotAnhKem[diaChiMangKem] %5.3f\n", chiSo, diaChiMangKem, mangMotCotAnhKem[diaChiMangKem] );

               diaChiMangKem++;
               chiSo++;
            }
            
            trungBinh /= (float)beRongSong;
          
            // ---- tính phương sai và tương quang
            tuongQuanDoc[diaChiTuongQuan] = 0.0f;
            float phuongSaiAnh = 0.0f;
            chiSo = 0;
            diaChiMangKem = soHang;
            while( chiSo < beRongSong ) {
               float sai = mangMotCotAnhKem[diaChiMangKem] - trungBinh;
               phuongSaiAnh += sai*sai;
               // ---- tính trung bình cho đoạn hàng ảnh
               tuongQuanDoc[diaChiTuongQuan] += mangSin[chiSo]*sai;
               diaChiMangKem++;
               chiSo++;
            }
            tuongQuanDoc[diaChiTuongQuan] /= sqrtfPhuongSaiSin;
            tuongQuanDoc[diaChiTuongQuan] /= sqrtf( phuongSaiAnh );

 /*           if( soHang == beCaoAnh - 1 ) {
               printf( "soHang %d  trungBinh %5.3f  phuongSaiAnh %5.3f  tuongQuan %5.3f\n", soHang, trungBinh, phuongSaiAnh, tuongQuan1[diaChiTuongQuan] );
               exit(9);
            } */
            soHang++;
            diaChiTuongQuan += beRongAnh;
         }
  
         soCot++;
      }

   }
   else {
      printf( "tuongQuanGiuaHaiAnh: SAI LẦM giành trí nhớ cho tuongQuan hay mangSin\n" );
   }
   
   if( mangSin )
      free( mangSin );
   if( mangMotCotAnhKem )
      free( mangMotCotAnhKem );
   
   return tuongQuanDoc;
}

#pragma mark ---- Tính Trung Bình Và Phương Sai
// ham` này lật ngược ảnh tái rành giới
// hàm này tính trung bình quanh sốCột và sốHàng

float tinhTrungBinhVaPhuongSai_doanHang( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned int soCot, unsigned int soHang, unsigned short beRongDoanTrungBinh, float *phuongSai ) {
   
   return 0.0f;
}


/* Phiên bản này không cẩn chép các điểm ảnh ngoài ảnh,
  và nó làm gương cho các điểm ảnh ỡ ngoài
         ngoài ảnh  |<-------  ảnh-------->|  ngoài ảnh
 làm gương --> 45 34| 34 45 02       98 67 | 67 98 <-- làm gương
 
float tinhTrungBinhVaPhuongSai_doanHangGuong( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned int soCot, unsigned int soHang, unsigned short beRongDoanTrungBinh, float *phuongSai ) {
   
   unsigned short nuaBeRongTrungBinh = beRongDoanTrungBinh >> 1;

   *phuongSai = 0.0f;
   float trungBinh = 0.0f;
   //   beRongDoanTrungBinh
   // |<----------+---------->|
   //      +------o---+---------------
   if( soCot < nuaBeRongTrungBinh ) {
      unsigned int diaChiAnh = beRongAnh*soHang << 2;
      unsigned short soCotCuoi = soCot + nuaBeRongTrungBinh + 1;

      // ---- tính trung bình
      unsigned short chiSo = 0;
      while( chiSo < soCotCuoi ) {
         trungBinh += anh[diaChiAnh];
//         printf( "  0: %d trungBinh %5.3f  diaChiAnh %d  anh %d\n", chiSo, trungBinh, diaChiAnh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }

      // ---- cộng thêm lần nữa cho ảnh lất ngoài rành
      soCotCuoi = nuaBeRongTrungBinh - soCot;
      chiSo = 0;
      while( chiSo < soCotCuoi ) {
         trungBinh += anh[diaChiAnh];
//      printf( "  0: ++ %d trungBinh %5.3f  diaChiAnh %d  anh %d\n", chiSo, trungBinh, diaChiAnh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- chia bề rộng đoạn trung bình
      trungBinh /= (float)beRongDoanTrungBinh;
//      printf( "  0: trungBinh %5.3f\n", trungBinh );
      
      // ---- tính phương sai
      soCotCuoi = soCot + nuaBeRongTrungBinh + 1;
      chiSo = 0;
      diaChiAnh = beRongAnh*soHang << 2;
      while( chiSo < soCotCuoi ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
//         printf( "  0: %d *phuongSai %5.3f  sai %5.3f  diaChiAnh %d\n", chiSo, *phuongSai, sai, diaChiAnh );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- cộng thêm lần nữa cho ảnh lất ngoài rành
      soCotCuoi = nuaBeRongTrungBinh - soCot;
      chiSo = 0;
      while( chiSo < soCotCuoi ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
//         printf( "  0: ++ %d *phuongSai %5.3f  sai %5.3f  diaChiAnh %d\n", chiSo, *phuongSai, sai, diaChiAnh );
         diaChiAnh += 4;
         chiSo++;
      }
   }
   else if( soCot > beRongAnh - nuaBeRongTrungBinh - 1 ) {
      unsigned int diaChiAnh = (beRongAnh*soHang + soCot - nuaBeRongTrungBinh) << 2;
      
      // ---- tính trung bình
      unsigned short chiSo = soCot - nuaBeRongTrungBinh;
      while( chiSo < beRongAnh ) {
         trungBinh += anh[diaChiAnh];
//         printf( "  2: soCot %d %d trungBinh %5.3f  diaChiAnh %d  anh %d\n", soCot, chiSo, trungBinh, diaChiAnh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- cộng thêm lần nữa cho ảnh lất ngoài rành
      chiSo = (beRongAnh << 1) - (soCot + nuaBeRongTrungBinh + 1);
      diaChiAnh = (beRongAnh*soHang + chiSo) << 2;
      while( chiSo < beRongAnh ) {
         trungBinh += anh[diaChiAnh];
//         printf( "  2: ++ %d trungBinh %5.3f  diaChiAnh %d  anh %d\n", chiSo, trungBinh, diaChiAnh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- chia bề rộng đoạn trung bình
      trungBinh /= (float)beRongDoanTrungBinh;
//      printf( "  2: trungBinh %5.3f\n", trungBinh );
      
      // ---- tính phương sai
      chiSo = soCot - nuaBeRongTrungBinh;
      diaChiAnh = (beRongAnh*soHang + soCot - nuaBeRongTrungBinh) << 2;
      while( chiSo < beRongAnh ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
//         printf( "  2: %d *phuongSai %5.3f  sai %5.3f  diaChiAnh %d\n", chiSo, *phuongSai, sai, diaChiAnh );
         diaChiAnh += 4;
         chiSo++;
      }
      
      // ---- cộng thêm lần nữa cho ảnh lất ngoài rành
      chiSo = (beRongAnh << 1) - (soCot + nuaBeRongTrungBinh + 1);
      diaChiAnh = (beRongAnh*soHang + chiSo) << 2;
      while( chiSo < beRongAnh ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
//         printf( "  2: ++ %d *phuongSai %5.3f  sai %5.3f  diaChiAnh %d\n", chiSo, *phuongSai, sai, diaChiAnh );
         diaChiAnh += 4;
         chiSo++;
      }
   }
   else {
      unsigned int diaChiAnh = (beRongAnh*soHang + soCot - nuaBeRongTrungBinh) << 2;
      unsigned short soCotDau = soCot - nuaBeRongTrungBinh;
      unsigned short soCotCuoi = soCot + nuaBeRongTrungBinh + 1;

      unsigned short chiSo = soCotDau;
      while( chiSo < soCotCuoi ) {
         trungBinh += anh[diaChiAnh];
//      printf( "soCot %d  1: %d trungBinh %5.3f  anh %d\n", soCot, chiSo, trungBinh, anh[diaChiAnh] );
         diaChiAnh += 4;
         chiSo++;
      }
      // ---- chia bề rộng đoạn trung bình
      trungBinh /= (float)beRongDoanTrungBinh;
//      printf( "  1: trungBinh %5.3f  anh %d\n", trungBinh, anh[diaChiAnh] );
      
      chiSo = soCotDau;
      diaChiAnh = (beRongAnh*soHang + soCot - nuaBeRongTrungBinh) << 2;
      while( chiSo < soCotCuoi ) {
         float sai = trungBinh - anh[diaChiAnh];
         *phuongSai += sai*sai;
         diaChiAnh += 4;
         chiSo++;
      }
   }
   
   
   return trungBinh;
}
*/

#pragma mark ---- Núi sin

#define kHAI_PI 6.283185307f
#define kPI 3.141592654f
#define kPI_CHIA_2 1.570796f

// -cos( πx/beRong + π/2)
// Nên dùng bề rộng số lẻ
float *mauAnhNuiSin_1chieu_truTrungBinh( unsigned short beRong, float *phuongSai ) {
   
   float *anhNui = malloc( beRong * sizeof(float) );
   if( anhNui ) {
      float trungBinh = 0.0f;

      float buoc = 1.0f/(float)(beRong-1);
      
      unsigned short chiSo = 0;
      while( chiSo < beRong ) {
         anhNui[chiSo] = -cosf( kPI*chiSo*buoc + kPI_CHIA_2 );
         trungBinh += anhNui[chiSo];
         chiSo++;
      }

      trungBinh /= (float)beRong;
      
      // ---- trừ trung bình
      *phuongSai = 0.0f;
      chiSo = 0;
      while( chiSo < beRong ) {
         float sai = anhNui[chiSo] - trungBinh;
         anhNui[chiSo] = sai;
         *phuongSai += sai*sai;
         chiSo++;
      }

   }
   else
      printf( "TuongQuan: SAI LẦM giành trí nhớ cho mauAnhNuiSin_1chieu\n" );
   
   return anhNui;
}

