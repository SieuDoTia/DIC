/* TuongQuan.h */

#pragma once

unsigned char *veAnhTuongQuan( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhTuongQuan, unsigned int *beCaoAnhTuongQuan );

