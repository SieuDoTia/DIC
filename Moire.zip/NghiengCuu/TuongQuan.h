/* TuongQuan.h */

#pragma once

/* VẽẢnhTươngQuanSóng */
unsigned char *veAnhTuongQuanSong( unsigned char *anhGoc, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhTuongQuan, unsigned int *beCaoAnhTuongQuan, unsigned short beRongAnhSong );

