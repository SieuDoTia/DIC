/* Bezier.c */

#include <stdio.h>
#include <math.h>
#include "Bezier.h"
#include "MaTran.h"

Vecto tinhViTriBezier3C( Bezier *bezier, float thamSo ) {
   
   // ---- mức 0, cần tính 3 điểm
   Vecto muc0[3];
   muc0[0].x = (1.0f - thamSo)*bezier->diemQuanTri[0].x + thamSo*bezier->diemQuanTri[1].x;
   muc0[0].y = (1.0f - thamSo)*bezier->diemQuanTri[0].y + thamSo*bezier->diemQuanTri[1].y;
   muc0[0].z = (1.0f - thamSo)*bezier->diemQuanTri[0].z + thamSo*bezier->diemQuanTri[1].z;
   muc0[1].x = (1.0f - thamSo)*bezier->diemQuanTri[1].x + thamSo*bezier->diemQuanTri[2].x;
   muc0[1].y = (1.0f - thamSo)*bezier->diemQuanTri[1].y + thamSo*bezier->diemQuanTri[2].y;
   muc0[1].z = (1.0f - thamSo)*bezier->diemQuanTri[1].z + thamSo*bezier->diemQuanTri[2].z;
   muc0[2].x = (1.0f - thamSo)*bezier->diemQuanTri[2].x + thamSo*bezier->diemQuanTri[3].x;
   muc0[2].y = (1.0f - thamSo)*bezier->diemQuanTri[2].y + thamSo*bezier->diemQuanTri[3].y;
   muc0[2].z = (1.0f - thamSo)*bezier->diemQuanTri[2].z + thamSo*bezier->diemQuanTri[3].z;
   
   // ---- mức 1, cần tính 2 điểm
   Vecto muc1[2];
   muc1[0].x = (1.0f - thamSo)*muc0[0].x + thamSo*muc0[1].x;
   muc1[0].y = (1.0f - thamSo)*muc0[0].y + thamSo*muc0[1].y;
   muc1[0].z = (1.0f - thamSo)*muc0[0].z + thamSo*muc0[1].z;
   muc1[1].x = (1.0f - thamSo)*muc0[1].x + thamSo*muc0[2].x;
   muc1[1].y = (1.0f - thamSo)*muc0[1].y + thamSo*muc0[2].y;
   muc1[1].z = (1.0f - thamSo)*muc0[1].z + thamSo*muc0[2].z;
   
   Vecto viTri;
   viTri.x = (1.0f - thamSo)*muc1[0].x + thamSo*muc1[1].x;
   viTri.y = (1.0f - thamSo)*muc1[0].y + thamSo*muc1[1].y;
   viTri.z = (1.0f - thamSo)*muc1[0].z + thamSo*muc1[1].z;
   
   return viTri;
}



// ds(t)/dt = -x0*3*(1-t)² + x1*3*[(1-t)² - 2*t(1-t)] + x2*3[2*t(1-t) - t²] + x3*3*t²

// ds(t)/dt = -x0*3*(1-2t + t²) + x1*3*[1-2t + t² - 2t + 2t²] + x2*3[2t-2t² - t²] + x3*3t²

// ds(t)/dt = -x0(3-6t + 3t²) + x1*[3-12t + 9t²] + x2[6t-9t²] + x3*3t²
// ds(t)/dt =  3[x1 - x0] + 6[x0 - 2x1 + x2]t + 3[-x0 + 3x1 - 3x2 + x3]t²
// 0 =  [x1 - x0] + 2[x0 - 2x1 + x2]t + [-x0 + 3x1 - 3x2 + x3]t²
unsigned char thamSoDiemGocKhong_z( Bezier *bezier, float *nghiem0, float *nghiem1 ) {
   
   float a = -bezier->diemQuanTri[0].z + 3.0f*bezier->diemQuanTri[1].z - 3.0f*bezier->diemQuanTri[2].z + bezier->diemQuanTri[3].z;
   float b = 2.0f*(bezier->diemQuanTri[0].z - 2.0f*bezier->diemQuanTri[1].z + bezier->diemQuanTri[2].z);
   float c = -bezier->diemQuanTri[0].z + bezier->diemQuanTri[1].z;
   
   // ---- tính biệt để biết có nghiệm
   float bietThuc = b*b - 4.0f*a*c;
   if( bietThuc == 0.0f ) {
      *nghiem0 = -b/(2.0f*a);
      // ---- cho cong Bezier tham số t phải 0 ≤ t ≤ 1
      if( (*nghiem0 >= 0.0f) && (*nghiem0 <= 1.0f) )
         return 1;
      else
         return 0;
   }
   else if( bietThuc > 0.0f ) {
      float mauSo = 0.5f/a;
      *nghiem0 = (-b + sqrtf( bietThuc ))*mauSo;
      *nghiem1 = (-b - sqrtf( bietThuc ))*mauSo;

      unsigned char soLuongNghiem = 0;
      // ---- cho cong Bezier tham số t phải 0 ≤ t ≤ 1
      if( (*nghiem0 >= 0.0f) && (*nghiem0 <= 1.0f) )
         soLuongNghiem++;
      
      if( (*nghiem1 >= 0.0f) && (*nghiem1 <= 1.0f) ) {
         if( soLuongNghiem == 0 )
            *nghiem0 = *nghiem1;
         soLuongNghiem++;
      }

      return soLuongNghiem;
   }
   else
      return 0;
   
}


float tinhDoCongTaiThamSo_z( Bezier *bezier, float thamSo ) {

   float doCongZ = (bezier->diemQuanTri[0].z - 2.0f*bezier->diemQuanTri[1].z + bezier->diemQuanTri[2].z)*(1.0f - thamSo);
   doCongZ += (bezier->diemQuanTri[1].z - 2.0f*bezier->diemQuanTri[2].z + bezier->diemQuanTri[3].z)*thamSo;
   doCongZ *= 6.0f;

   return doCongZ;
}


void tinhMaTranToiUuDoanHang( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang, unsigned int soCotDau, unsigned int soCotCuoi ) {
      
   float heSoDonViHoa_t = 1.0f/(soCotCuoi - soCotDau - 1);  // trừ một cho t đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_z = 1.0f/255.0f;
   
   // ----
   unsigned int diaChiAnh = (beRong*soHang + soCotDau) << 2;
   
   // ---- xóa ma ma trận
   maTranBezier[0] = 0.0f;   maTranBezier[1] = 0.0f;   maTranBezier[2] = 0.0f;   maTranBezier[3] = 0.0f;
   maTranBezier[4] = 0.0f;   maTranBezier[5] = 0.0f;   maTranBezier[6] = 0.0f;   maTranBezier[7] = 0.0f;
   maTranBezier[8] = 0.0f;   maTranBezier[9] = 0.0f;   maTranBezier[10] = 0.0f;  maTranBezier[11] = 0.0f;
   maTranBezier[12] = 0.0f;  maTranBezier[13] = 0.0f;  maTranBezier[14] = 0.0f;  maTranBezier[15] = 0.0f;
   
   vectoGiai[0] = 0.0f;    vectoGiai[1] = 0.0f;      vectoGiai[2] = 0.0f;     vectoGiai[3] = 0.0f;
   vectoGiai[4] = 0.0f;    vectoGiai[5] = 0.0f;      vectoGiai[6] = 0.0f;     vectoGiai[7] = 0.0f;
   
   unsigned int soCot = soCotDau;
   
   // ---- tạo ma trận
   while( soCot < soCotCuoi ) {
      float t = (soCot - soCotDau)*heSoDonViHoa_t;
      float z = anh[diaChiAnh]*heSoDonViHoa_z;
//          printf( "   bezier %d  t %5.3f  z %5.3f\n", soCot, t, z );
      
      // ---- tính ma trận
      float phanSo_1 = t;
      float phanSo_2 = phanSo_1*phanSo_1;
      float phanSo_3 = phanSo_2*phanSo_1;
      float phanSo_4 = phanSo_3*phanSo_1;
      float phanSo_5 = phanSo_4*phanSo_1;
      float phanSo_6 = phanSo_5*phanSo_1;
      
      float nghichPhanSo_1 = 1.0f - phanSo_1;
      float nghichPhanSo_2 = nghichPhanSo_1*nghichPhanSo_1;
      float nghichPhanSo_3 = nghichPhanSo_2*nghichPhanSo_1;
      float nghichPhanSo_4 = nghichPhanSo_3*nghichPhanSo_1;
      float nghichPhanSo_5 = nghichPhanSo_4*nghichPhanSo_1;
      float nghichPhanSo_6 = nghichPhanSo_5*nghichPhanSo_1;
      
      maTranBezier[0] += nghichPhanSo_6;
      maTranBezier[1] += 3.0f*nghichPhanSo_5*phanSo_1;
      maTranBezier[2] += 3.0f*nghichPhanSo_4*phanSo_2;
      maTranBezier[3] += nghichPhanSo_3*phanSo_3;
      
      maTranBezier[4] += nghichPhanSo_5*phanSo_1;
      maTranBezier[5] += 3.0f*nghichPhanSo_4*phanSo_2;
      maTranBezier[6] += 3.0f*nghichPhanSo_3*phanSo_3;
      maTranBezier[7] += nghichPhanSo_2*phanSo_4;
      
      maTranBezier[8] += nghichPhanSo_4*phanSo_2;
      maTranBezier[9] += 3.0f*nghichPhanSo_3*phanSo_3;
      maTranBezier[10] += 3.0f*nghichPhanSo_2*phanSo_4;
      maTranBezier[11] += nghichPhanSo_1*phanSo_5;
      
      maTranBezier[12] += nghichPhanSo_3*phanSo_3;
      maTranBezier[13] += 3.0f*nghichPhanSo_2*phanSo_4;
      maTranBezier[14] += 3.0f*nghichPhanSo_1*phanSo_5;
      maTranBezier[15] += phanSo_6;
      
      //      printf( "%d %5.3f %5.3f %5.3f %5.3f\n", chiSoDiem, maTranBezier[0], maTranBezier[1], maTranBezier[2], maTranBezier[3] );
      
      vectoGiai[0] += t*nghichPhanSo_3;
      vectoGiai[2] += t*nghichPhanSo_2*phanSo_1;
      vectoGiai[4] += t*nghichPhanSo_1*phanSo_2;
      vectoGiai[6] += t*phanSo_3;
      
      vectoGiai[1] += z*nghichPhanSo_3;
      vectoGiai[3] += z*nghichPhanSo_2*phanSo_1;
      vectoGiai[5] += z*nghichPhanSo_1*phanSo_2;
      vectoGiai[7] += z*phanSo_3;
      
      diaChiAnh += 4;
      soCot++;
   }

}


void tinhMaTranToiUuDoanCot( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot, unsigned int soHangDau, unsigned int soHangCuoi ) {
   
   float heSoDonViHoa_t = 1.0f/(soHangCuoi - soHangDau - 1);  // trừ một cho t đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_z = 1.0f/255.0f;
   
   // ----
   unsigned int diaChiAnh = (beRong*soHangDau + soCot) << 2;
   
   // ---- xóa ma ma trận
   maTranBezier[0] = 0.0f;   maTranBezier[1] = 0.0f;   maTranBezier[2] = 0.0f;   maTranBezier[3] = 0.0f;
   maTranBezier[4] = 0.0f;   maTranBezier[5] = 0.0f;   maTranBezier[6] = 0.0f;   maTranBezier[7] = 0.0f;
   maTranBezier[8] = 0.0f;   maTranBezier[9] = 0.0f;   maTranBezier[10] = 0.0f;  maTranBezier[11] = 0.0f;
   maTranBezier[12] = 0.0f;  maTranBezier[13] = 0.0f;  maTranBezier[14] = 0.0f;  maTranBezier[15] = 0.0f;
   
   vectoGiai[0] = 0.0f;    vectoGiai[1] = 0.0f;      vectoGiai[2] = 0.0f;     vectoGiai[3] = 0.0f;
   vectoGiai[4] = 0.0f;    vectoGiai[5] = 0.0f;      vectoGiai[6] = 0.0f;     vectoGiai[7] = 0.0f;
   
   unsigned int soHang = soHangDau;
   
   // ---- tạo ma trận
   while( soHang < soHangCuoi ) {
      float t = (soHang - soHangDau)*heSoDonViHoa_t;
      float z = anh[diaChiAnh]*heSoDonViHoa_z;
      //          printf( "   bezier %d  t %5.3f  z %5.3f\n", soCot, t, z );
      
      // ---- tính ma trận
      float phanSo_1 = t;
      float phanSo_2 = phanSo_1*phanSo_1;
      float phanSo_3 = phanSo_2*phanSo_1;
      float phanSo_4 = phanSo_3*phanSo_1;
      float phanSo_5 = phanSo_4*phanSo_1;
      float phanSo_6 = phanSo_5*phanSo_1;
      
      float nghichPhanSo_1 = 1.0f - phanSo_1;
      float nghichPhanSo_2 = nghichPhanSo_1*nghichPhanSo_1;
      float nghichPhanSo_3 = nghichPhanSo_2*nghichPhanSo_1;
      float nghichPhanSo_4 = nghichPhanSo_3*nghichPhanSo_1;
      float nghichPhanSo_5 = nghichPhanSo_4*nghichPhanSo_1;
      float nghichPhanSo_6 = nghichPhanSo_5*nghichPhanSo_1;
      
      maTranBezier[0] += nghichPhanSo_6;
      maTranBezier[1] += 3.0f*nghichPhanSo_5*phanSo_1;
      maTranBezier[2] += 3.0f*nghichPhanSo_4*phanSo_2;
      maTranBezier[3] += nghichPhanSo_3*phanSo_3;
      
      maTranBezier[4] += nghichPhanSo_5*phanSo_1;
      maTranBezier[5] += 3.0f*nghichPhanSo_4*phanSo_2;
      maTranBezier[6] += 3.0f*nghichPhanSo_3*phanSo_3;
      maTranBezier[7] += nghichPhanSo_2*phanSo_4;
      
      maTranBezier[8] += nghichPhanSo_4*phanSo_2;
      maTranBezier[9] += 3.0f*nghichPhanSo_3*phanSo_3;
      maTranBezier[10] += 3.0f*nghichPhanSo_2*phanSo_4;
      maTranBezier[11] += nghichPhanSo_1*phanSo_5;
      
      maTranBezier[12] += nghichPhanSo_3*phanSo_3;
      maTranBezier[13] += 3.0f*nghichPhanSo_2*phanSo_4;
      maTranBezier[14] += 3.0f*nghichPhanSo_1*phanSo_5;
      maTranBezier[15] += phanSo_6;
      
      //      printf( "%d %5.3f %5.3f %5.3f %5.3f\n", chiSoDiem, maTranBezier[0], maTranBezier[1], maTranBezier[2], maTranBezier[3] );
      
      vectoGiai[0] += t*nghichPhanSo_3;
      vectoGiai[2] += t*nghichPhanSo_2*phanSo_1;
      vectoGiai[4] += t*nghichPhanSo_1*phanSo_2;
      vectoGiai[6] += t*phanSo_3;
      
      vectoGiai[1] += z*nghichPhanSo_3;
      vectoGiai[3] += z*nghichPhanSo_2*phanSo_1;
      vectoGiai[5] += z*nghichPhanSo_1*phanSo_2;
      vectoGiai[7] += z*phanSo_3;
      
      diaChiAnh += beRong << 2;
      soHang++;
   }
   
}
