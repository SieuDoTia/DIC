/* Bezier.c */

#include <stdio.h>
#include <math.h>
#include "Bezier.h"
#include "MaTran.h"

Vecto tinhViTriCongBezier3C_B3( Bezier *bezier, float thamSo ) {
   
   // ---- mức 0, cần tính 3 điểm
   Vecto muc0[3];
   muc0[0].x = (1.0f - thamSo)*bezier->diemQuanTri[0].x + thamSo*bezier->diemQuanTri[1].x;
   muc0[0].y = (1.0f - thamSo)*bezier->diemQuanTri[0].y + thamSo*bezier->diemQuanTri[1].y;
   muc0[0].z = (1.0f - thamSo)*bezier->diemQuanTri[0].z + thamSo*bezier->diemQuanTri[1].z;
   muc0[1].x = (1.0f - thamSo)*bezier->diemQuanTri[1].x + thamSo*bezier->diemQuanTri[2].x;
   muc0[1].y = (1.0f - thamSo)*bezier->diemQuanTri[1].y + thamSo*bezier->diemQuanTri[2].y;
   muc0[1].z = (1.0f - thamSo)*bezier->diemQuanTri[1].z + thamSo*bezier->diemQuanTri[2].z;
   muc0[2].x = (1.0f - thamSo)*bezier->diemQuanTri[2].x + thamSo*bezier->diemQuanTri[3].x;
   muc0[2].y = (1.0f - thamSo)*bezier->diemQuanTri[2].y + thamSo*bezier->diemQuanTri[3].y;
   muc0[2].z = (1.0f - thamSo)*bezier->diemQuanTri[2].z + thamSo*bezier->diemQuanTri[3].z;
   
   // ---- mức 1, cần tính 2 điểm
   Vecto muc1[2];
   muc1[0].x = (1.0f - thamSo)*muc0[0].x + thamSo*muc0[1].x;
   muc1[0].y = (1.0f - thamSo)*muc0[0].y + thamSo*muc0[1].y;
   muc1[0].z = (1.0f - thamSo)*muc0[0].z + thamSo*muc0[1].z;
   muc1[1].x = (1.0f - thamSo)*muc0[1].x + thamSo*muc0[2].x;
   muc1[1].y = (1.0f - thamSo)*muc0[1].y + thamSo*muc0[2].y;
   muc1[1].z = (1.0f - thamSo)*muc0[1].z + thamSo*muc0[2].z;
   
   Vecto viTri;
   viTri.x = (1.0f - thamSo)*muc1[0].x + thamSo*muc1[1].x;
   viTri.y = (1.0f - thamSo)*muc1[0].y + thamSo*muc1[1].y;
   viTri.z = (1.0f - thamSo)*muc1[0].z + thamSo*muc1[1].z;
   
   return viTri;
}



// ds(t)/dt = -x0*3*(1-t)² + x1*3*[(1-t)² - 2*t(1-t)] + x2*3[2*t(1-t) - t²] + x3*3*t²

// ds(t)/dt = -x0*3*(1-2t + t²) + x1*3*[1-2t + t² - 2t + 2t²] + x2*3[2t-2t² - t²] + x3*3t²

// ds(t)/dt = -x0(3-6t + 3t²) + x1*[3-12t + 9t²] + x2[6t-9t²] + x3*3t²
// ds(t)/dt =  3[x1 - x0] + 6[x0 - 2x1 + x2]t + 3[-x0 + 3x1 - 3x2 + x3]t²
// 0 =  [x1 - x0] + 2[x0 - 2x1 + x2]t + [-x0 + 3x1 - 3x2 + x3]t²
unsigned char thamSoDiemGocKhong_z_B3( Bezier *bezier, float *nghiem0, float *nghiem1 ) {
   
   float a = -bezier->diemQuanTri[0].z + 3.0f*bezier->diemQuanTri[1].z - 3.0f*bezier->diemQuanTri[2].z + bezier->diemQuanTri[3].z;
   float b = 2.0f*(bezier->diemQuanTri[0].z - 2.0f*bezier->diemQuanTri[1].z + bezier->diemQuanTri[2].z);
   float c = -bezier->diemQuanTri[0].z + bezier->diemQuanTri[1].z;
   
   // ---- tính biệt để biết có nghiệm
   float bietThuc = b*b - 4.0f*a*c;
   if( bietThuc == 0.0f ) {
      *nghiem0 = -b/(2.0f*a);
      // ---- cho cong Bezier tham số t phải 0 ≤ t ≤ 1
      if( (*nghiem0 >= 0.0f) && (*nghiem0 <= 1.0f) )
         return 1;
      else
         return 0;
   }
   else if( bietThuc > 0.0f ) {
      float mauSo = 0.5f/a;
      *nghiem0 = (-b + sqrtf( bietThuc ))*mauSo;
      *nghiem1 = (-b - sqrtf( bietThuc ))*mauSo;

      unsigned char soLuongNghiem = 0;
      // ---- cho cong Bezier tham số t phải 0 ≤ t ≤ 1
      if( (*nghiem0 >= 0.0f) && (*nghiem0 <= 1.0f) )
         soLuongNghiem++;
      
      if( (*nghiem1 >= 0.0f) && (*nghiem1 <= 1.0f) ) {
         if( soLuongNghiem == 0 )
            *nghiem0 = *nghiem1;
         soLuongNghiem++;
      }

      return soLuongNghiem;
   }
   else
      return 0;
   
}

#pragma mark ---- TÍNH ĐỘ CỘNG
float tinhDoCongTaiThamSo_z_B3( Bezier *bezier, float thamSo ) {

   float doCongZ = (bezier->diemQuanTri[0].z - 2.0f*bezier->diemQuanTri[1].z + bezier->diemQuanTri[2].z)*(1.0f - thamSo);
   doCongZ += (bezier->diemQuanTri[1].z - 2.0f*bezier->diemQuanTri[2].z + bezier->diemQuanTri[3].z)*thamSo;
   doCongZ *= 6.0f;

   return doCongZ;
}

/*
void tinhDoCongTaiHaiThamSo_z_B1( MatBezierB1 *matBezier, float t, float u, float *doCong_t, float *doCong_u ) {

   float nghich_t = 1.0f - t;
   float nghich_u = 1.0f - u;

   *doCong_t = -matBezier->diemQuanTri[0].z*nghich_u;
   *doCong_t -= matBezier->diemQuanTri[1].z*u;
   *doCong_t += matBezier->diemQuanTri[2].z*nghich_u;
   *doCong_t += matBezier->diemQuanTri[3].z*u;
   
   *doCong_u = -matBezier->diemQuanTri[0].z*nghich_t;
   *doCong_u += matBezier->diemQuanTri[1].z*nghich_t;
   *doCong_u -= matBezier->diemQuanTri[2].z*t;
   *doCong_u += matBezier->diemQuanTri[3].z*t;
} */


// tôi nghĩ có thể tính này trực tiếp dùng bình phương tối thiểu
void tinhDoCongTaiHaiThamSo_z_B2( MatBezierB2 *matBezier, float t, float u, float *doCong_t, float *doCong_u ) {
   
   float nghich_t = 1.0f - t;
   float nghich_u = 1.0f - u;
   
   float nghich_t_binh = nghich_t*nghich_t;
   float nghich_u_binh = nghich_u*nghich_u;
   float t_binh = t*t;
   float u_binh = u*u;

   *doCong_t = -matBezier->diemQuanTri[0].z*nghich_t*nghich_u_binh;
   *doCong_t -= 2.0f*matBezier->diemQuanTri[1].z*nghich_t*nghich_u*u;
   *doCong_t -= matBezier->diemQuanTri[2].z*nghich_t*u_binh;
   
   *doCong_t += matBezier->diemQuanTri[3].z*(-2.0f*t + 1.0f)*nghich_u_binh;
   *doCong_t += 2.0f*matBezier->diemQuanTri[4].z*(-2.0f*t + 1.0f)*nghich_u*u;
   *doCong_t += matBezier->diemQuanTri[5].z*(-2.0f*t + 1.0f)*u_binh;

   *doCong_t += matBezier->diemQuanTri[6].z*t*nghich_u_binh;
   *doCong_t += 2.0f*matBezier->diemQuanTri[7].z*t*nghich_u*u;
   *doCong_t += matBezier->diemQuanTri[8].z*t*u_binh;
   
   *doCong_t *= 2.0f;

   // ----
   *doCong_u = -matBezier->diemQuanTri[0].z*nghich_t_binh*nghich_u;
   *doCong_u += matBezier->diemQuanTri[1].z*nghich_t_binh*(-2.0f*u + 1.0f);
   *doCong_u += matBezier->diemQuanTri[2].z*nghich_t_binh*u;


   *doCong_u -= 2.0f*matBezier->diemQuanTri[3].z*nghich_t*t*nghich_u;
   *doCong_u += 2.0f*matBezier->diemQuanTri[4].z*nghich_t*t*(-2.0f*u + 1.0f);
   *doCong_u += 2.0f*matBezier->diemQuanTri[5].z*nghich_t*t*u;


   *doCong_u -= matBezier->diemQuanTri[6].z*t_binh*nghich_u;
   *doCong_u += matBezier->diemQuanTri[7].z*t_binh*(-2.0f*u + 1.0f);
   *doCong_u += matBezier->diemQuanTri[8].z*t_binh*u;

   *doCong_u *= 2.0f;
}


#pragma mark ---- Tính Ma Trận Tối Ưu
// xuất ma trận 4x4 và 4x2
void tinhMaTranCongToiUuB3_doanHang( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang, int soCotDau, int soCotCuoi ) {
   
   // ---- không đi ra ngoài ảnh
   if( soCotDau < 0 )
      soCotDau = 0;
   
   if( soCotCuoi >= beRong )
      soCotCuoi = beRong - 1;
   
   if( soHang >= beCao )
      soHang = beCao - 1;
   
   // ---- hệ số đơn vị hóa
   float heSoDonViHoa_t = 1.0f/(soCotCuoi - soCotDau - 1);  // trừ một cho t đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_z = 1.0f/255.0f;
   
   // ----
   unsigned int diaChiAnh = (beRong*soHang + soCotDau) << 2;
   
   // ---- xóa ma ma trận
   maTranBezier[0] = 0.0f;   maTranBezier[1] = 0.0f;   maTranBezier[2] = 0.0f;   maTranBezier[3] = 0.0f;
   maTranBezier[4] = 0.0f;   maTranBezier[5] = 0.0f;   maTranBezier[6] = 0.0f;   maTranBezier[7] = 0.0f;
   maTranBezier[8] = 0.0f;   maTranBezier[9] = 0.0f;   maTranBezier[10] = 0.0f;  maTranBezier[11] = 0.0f;
   maTranBezier[12] = 0.0f;  maTranBezier[13] = 0.0f;  maTranBezier[14] = 0.0f;  maTranBezier[15] = 0.0f;
   
   vectoGiai[0] = 0.0f;    vectoGiai[1] = 0.0f;      vectoGiai[2] = 0.0f;     vectoGiai[3] = 0.0f;
   vectoGiai[4] = 0.0f;    vectoGiai[5] = 0.0f;      vectoGiai[6] = 0.0f;     vectoGiai[7] = 0.0f;
   
   int soCot = soCotDau;
   
   // ---- tạo ma trận
   while( soCot < soCotCuoi ) {
      float t = (soCot - soCotDau)*heSoDonViHoa_t;
      float z = anh[diaChiAnh]*heSoDonViHoa_z;
//          printf( "   bezier %d  t %5.3f  z %5.3f\n", soCot, t, z );
      
      // ---- tính ma trận
      float phanSo_1 = t;
      float phanSo_2 = phanSo_1*phanSo_1;
      float phanSo_3 = phanSo_2*phanSo_1;
      float phanSo_4 = phanSo_3*phanSo_1;
      float phanSo_5 = phanSo_4*phanSo_1;
      float phanSo_6 = phanSo_5*phanSo_1;
      
      float nghichPhanSo_1 = 1.0f - phanSo_1;
      float nghichPhanSo_2 = nghichPhanSo_1*nghichPhanSo_1;
      float nghichPhanSo_3 = nghichPhanSo_2*nghichPhanSo_1;
      float nghichPhanSo_4 = nghichPhanSo_3*nghichPhanSo_1;
      float nghichPhanSo_5 = nghichPhanSo_4*nghichPhanSo_1;
      float nghichPhanSo_6 = nghichPhanSo_5*nghichPhanSo_1;
      
      maTranBezier[0] += nghichPhanSo_6;
      maTranBezier[1] += 3.0f*nghichPhanSo_5*phanSo_1;
      maTranBezier[2] += 3.0f*nghichPhanSo_4*phanSo_2;
      maTranBezier[3] += nghichPhanSo_3*phanSo_3;
      
      maTranBezier[4] += nghichPhanSo_5*phanSo_1;
      maTranBezier[5] += 3.0f*nghichPhanSo_4*phanSo_2;
      maTranBezier[6] += 3.0f*nghichPhanSo_3*phanSo_3;
      maTranBezier[7] += nghichPhanSo_2*phanSo_4;
      
      maTranBezier[8] += nghichPhanSo_4*phanSo_2;
      maTranBezier[9] += 3.0f*nghichPhanSo_3*phanSo_3;
      maTranBezier[10] += 3.0f*nghichPhanSo_2*phanSo_4;
      maTranBezier[11] += nghichPhanSo_1*phanSo_5;
      
      maTranBezier[12] += nghichPhanSo_3*phanSo_3;
      maTranBezier[13] += 3.0f*nghichPhanSo_2*phanSo_4;
      maTranBezier[14] += 3.0f*nghichPhanSo_1*phanSo_5;
      maTranBezier[15] += phanSo_6;
      
      //      printf( "%d %5.3f %5.3f %5.3f %5.3f\n", chiSoDiem, maTranBezier[0], maTranBezier[1], maTranBezier[2], maTranBezier[3] );
      
      vectoGiai[0] += t*nghichPhanSo_3;
      vectoGiai[2] += t*nghichPhanSo_2*phanSo_1;
      vectoGiai[4] += t*nghichPhanSo_1*phanSo_2;
      vectoGiai[6] += t*phanSo_3;
      
      vectoGiai[1] += z*nghichPhanSo_3;
      vectoGiai[3] += z*nghichPhanSo_2*phanSo_1;
      vectoGiai[5] += z*nghichPhanSo_1*phanSo_2;
      vectoGiai[7] += z*phanSo_3;
      
      diaChiAnh += 4;
      soCot++;
   }

}


// xuất ma trận 4x4 và 4x2
void tinhMaTranCongToiUuB3_doanCot( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot, int soHangDau, int soHangCuoi ) {
   
   // ---- không đi ra ngoài ảnh
   if( soHangDau < 0 )
      soHangDau = 0;
   
   if( soHangCuoi >= beCao )
      soHangCuoi = beCao - 1;
   
   if( soCot >= beRong )
      soCot = beRong - 1;
   
   // ---- hệ số đơn vị hóa
   float heSoDonViHoa_t = 1.0f/(soHangCuoi - soHangDau - 1);  // trừ một cho t đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_z = 1.0f/255.0f;
   
   // ----
   unsigned int diaChiAnh = (beRong*soHangDau + soCot) << 2;
   
   // ---- xóa ma trận
   maTranBezier[0] = 0.0f;   maTranBezier[1] = 0.0f;   maTranBezier[2] = 0.0f;   maTranBezier[3] = 0.0f;
   maTranBezier[4] = 0.0f;   maTranBezier[5] = 0.0f;   maTranBezier[6] = 0.0f;   maTranBezier[7] = 0.0f;
   maTranBezier[8] = 0.0f;   maTranBezier[9] = 0.0f;   maTranBezier[10] = 0.0f;  maTranBezier[11] = 0.0f;
   maTranBezier[12] = 0.0f;  maTranBezier[13] = 0.0f;  maTranBezier[14] = 0.0f;  maTranBezier[15] = 0.0f;
   
   vectoGiai[0] = 0.0f;    vectoGiai[1] = 0.0f;      vectoGiai[2] = 0.0f;     vectoGiai[3] = 0.0f;
   vectoGiai[4] = 0.0f;    vectoGiai[5] = 0.0f;      vectoGiai[6] = 0.0f;     vectoGiai[7] = 0.0f;
   
   unsigned int soHang = soHangDau;
   
   // ---- tạo ma trận
   while( soHang < soHangCuoi ) {
      float t = (soHang - soHangDau)*heSoDonViHoa_t;
      float z = anh[diaChiAnh]*heSoDonViHoa_z;
      //          printf( "   bezier %d  t %5.3f  z %5.3f\n", soCot, t, z );
      
      // ---- tính ma trận
      float phanSo_1 = t;
      float phanSo_2 = phanSo_1*phanSo_1;
      float phanSo_3 = phanSo_2*phanSo_1;
      float phanSo_4 = phanSo_3*phanSo_1;
      float phanSo_5 = phanSo_4*phanSo_1;
      float phanSo_6 = phanSo_5*phanSo_1;
      
      float nghichPhanSo_1 = 1.0f - phanSo_1;
      float nghichPhanSo_2 = nghichPhanSo_1*nghichPhanSo_1;
      float nghichPhanSo_3 = nghichPhanSo_2*nghichPhanSo_1;
      float nghichPhanSo_4 = nghichPhanSo_3*nghichPhanSo_1;
      float nghichPhanSo_5 = nghichPhanSo_4*nghichPhanSo_1;
      float nghichPhanSo_6 = nghichPhanSo_5*nghichPhanSo_1;
      
      maTranBezier[0] += nghichPhanSo_6;
      maTranBezier[1] += 3.0f*nghichPhanSo_5*phanSo_1;
      maTranBezier[2] += 3.0f*nghichPhanSo_4*phanSo_2;
      maTranBezier[3] += nghichPhanSo_3*phanSo_3;
      
      maTranBezier[4] += nghichPhanSo_5*phanSo_1;
      maTranBezier[5] += 3.0f*nghichPhanSo_4*phanSo_2;
      maTranBezier[6] += 3.0f*nghichPhanSo_3*phanSo_3;
      maTranBezier[7] += nghichPhanSo_2*phanSo_4;
      
      maTranBezier[8] += nghichPhanSo_4*phanSo_2;
      maTranBezier[9] += 3.0f*nghichPhanSo_3*phanSo_3;
      maTranBezier[10] += 3.0f*nghichPhanSo_2*phanSo_4;
      maTranBezier[11] += nghichPhanSo_1*phanSo_5;
      
      maTranBezier[12] += nghichPhanSo_3*phanSo_3;
      maTranBezier[13] += 3.0f*nghichPhanSo_2*phanSo_4;
      maTranBezier[14] += 3.0f*nghichPhanSo_1*phanSo_5;
      maTranBezier[15] += phanSo_6;
      
      //      printf( "%d %5.3f %5.3f %5.3f %5.3f\n", chiSoDiem, maTranBezier[0], maTranBezier[1], maTranBezier[2], maTranBezier[3] );
      
      vectoGiai[0] += t*nghichPhanSo_3;
      vectoGiai[2] += t*nghichPhanSo_2*phanSo_1;
      vectoGiai[4] += t*nghichPhanSo_1*phanSo_2;
      vectoGiai[6] += t*phanSo_3;
      
      vectoGiai[1] += z*nghichPhanSo_3;
      vectoGiai[3] += z*nghichPhanSo_2*phanSo_1;
      vectoGiai[5] += z*nghichPhanSo_1*phanSo_2;
      vectoGiai[7] += z*phanSo_3;
      
      diaChiAnh += beRong << 2;
      soHang++;
   }
   
}

// #pragma mark ---- MẶT BẬT MỘT
// Mặt bezier bình phương tối ưu
// xuất ma trận 4x4 và 4x3
/*
void tinhMaTranMatToiUuB1_choDienTich( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCotDau, unsigned int soCotCuoi, unsigned int soHangDau, unsigned int soHangCuoi ) {
   
   float heSoDonViHoa_t = 1.0f/(soCotCuoi - soCotDau - 1);  // trừ một cho t đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_u = 1.0f/(soHangCuoi - soHangDau - 1);  // trừ một cho u đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_z = 1.0f/255.0f;
   
   // ---- xóa ma trận
   maTranBezier[0] = 0.0f;   maTranBezier[1] = 0.0f;  maTranBezier[2] = 0.0f;   maTranBezier[3] = 0.0f;
   maTranBezier[4] = 0.0f;   maTranBezier[5] = 0.0f;   maTranBezier[6] = 0.0f;   maTranBezier[7] = 0.0f;
   maTranBezier[8] = 0.0f;   maTranBezier[9] = 0.0f;   maTranBezier[10] = 0.0f;  maTranBezier[11] = 0.0f;
   maTranBezier[12] = 0.0f;  maTranBezier[13] = 0.0f;  maTranBezier[14] = 0.0f;  maTranBezier[15] = 0.0f;

   vectoGiai[0] = 0.0f;   vectoGiai[1] = 0.0f;   vectoGiai[2] = 0.0f;
   vectoGiai[3] = 0.0f;   vectoGiai[4] = 0.0f;  vectoGiai[5] = 0.0f;
   vectoGiai[6] = 0.0f;   vectoGiai[7] = 0.0f;   vectoGiai[8] = 0.0f;
   vectoGiai[9] = 0.0f;   vectoGiai[10] = 0.0f; vectoGiai[11] = 0.0f;

   // ---- đặt giá trị trong ma trận
   unsigned short soHang = soHangDau;
   while( soHang < soHangCuoi ) {
      
      float y = (soHang - soHangDau)*heSoDonViHoa_u;
      unsigned int diaChiAnh = (soCotDau + soHang*beRong) << 2;
      unsigned short soCot = soCotDau;
      while( soCot < soCotCuoi ) {
         
         // ---- chỉ gồm điểm trong phạm vi
         float x = (soCot - soCotDau)*heSoDonViHoa_t;
         float y = (soHang - soHangDau)*heSoDonViHoa_u;
         float z = anh[diaChiAnh]*heSoDonViHoa_z;
         
         // ---- tính ma trận
         float t = x;
         float nghich_t = 1.0f - t;
         
         float u = y;
         float nghich_u = 1.0f - u;
//         printf( "trong pham vi  x %5.3f  y %5.3f  z %5.3f   t %5.3f  u %5.3f\n", x, y, z, t, u );
         
         float t_20 = nghich_t*nghich_t;
         float t_11 = nghich_t*t;
         float t_02 = t;
         
         float u_20 = nghich_u*nghich_u;
         float u_11 = nghich_u*u;
         float u_02 = u;
         
         maTranBezier[0] += t_20*u_20;
         maTranBezier[1] += t_20*u_11;
         maTranBezier[2] += t_11*u_20;
         maTranBezier[3] += t_11*u_11;

         maTranBezier[4] += t_20*u_11;
         maTranBezier[5] += t_20*u_02;
         maTranBezier[6] += t_11*u_11;
         maTranBezier[7] += t_11*u_02;
         
         // ====
         maTranBezier[8] += t_11*u_20;
         maTranBezier[9] += t_11*u_11;
         maTranBezier[10] += t_02*u_20;
         maTranBezier[11] += t_02*u_11;
         
         maTranBezier[12] += t_11*u_11;
         maTranBezier[13] += t_11*u_02;
         maTranBezier[14] += t_02*u_11;
         maTranBezier[15] += t_02*u_02;
   
         // ----
         vectoGiai[0] += x*nghich_t*nghich_u;
         vectoGiai[3] += x*nghich_t*u;
         vectoGiai[6] += x*t*nghich_u;
         vectoGiai[9] += x*t*u;
         
         // ----
         vectoGiai[1] += y*nghich_t*nghich_u;
         vectoGiai[4] += y*nghich_t*u;
         vectoGiai[7] += y*t*nghich_u;
         vectoGiai[10] += y*t*u;
         
         // ----
         vectoGiai[2] += z*nghich_t*nghich_u;
         vectoGiai[5] += z*nghich_t*u;
         vectoGiai[8] += z*t*nghich_u;
         vectoGiai[11] += z*t*u;

         diaChiAnh += 4;
         soCot++;
      }
      
      printf( "soHang %d  %5.3f  %5.3f  %5.3f  %5.3f\n", soHang, vectoGiai[2], vectoGiai[5], vectoGiai[8], vectoGiai[11] );
      soHang++;
   }
} */

#pragma mark ---- MẶT BẬT HAI
// Mặt bezier bình phương tối ưu
// xuất ma trận 9x9 và 9x3
void tinhMaTranMatToiUuB2_choDienTich( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCotDau, unsigned int soCotCuoi, unsigned int soHangDau, unsigned int soHangCuoi ) {
   
   float heSoDonViHoa_t = 1.0f/(soCotCuoi - soCotDau - 1);  // trừ một cho t đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_u = 1.0f/(soHangCuoi - soHangDau - 1);  // trừ một cho u đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_z = 1.0f/255.0f;

   // ---- xóa ma trận
   unsigned short chiSoMaTran = 0;
   while( chiSoMaTran < 81 ) {
      maTranBezier[chiSoMaTran] = 0.0f;
      chiSoMaTran++;
   }
   
   chiSoMaTran = 0;
   while( chiSoMaTran < 27 ) {
      vectoGiai[chiSoMaTran] = 0.0f;
      chiSoMaTran++;
   }
   
   // ---- đặt giá trị trong ma trận
   unsigned short soHang = soHangDau;
   while( soHang < soHangCuoi ) {

      unsigned int diaChiAnh = (soCotDau + soHang*beRong) << 2;
      unsigned short soCot = soCotDau;
      while( soCot < soCotCuoi ) {
      
         // ---- chỉ gồm điểm trong phạm vi
         float x = (soCot - soCotDau)*heSoDonViHoa_t;
         float y = (soHang - soHangDau)*heSoDonViHoa_u;
         float z = anh[diaChiAnh]*heSoDonViHoa_z;
         
         // ---- tính ma trận
         float t = x;
         float nghich_t = 1.0f - t;
         
         float u = y;
         float nghich_u = 1.0f - u;
//         printf( "trong pham vi  x %5.3f  y %5.3f  z %5.3f   t %5.3f  u %5.3f\n", x, y, z, t, u );
         
         float t_40 = nghich_t*nghich_t*nghich_t*nghich_t;
         float t_31 = nghich_t*nghich_t*nghich_t * t;
         float t_22 = nghich_t*nghich_t * t*t;
         float t_13 = nghich_t * t*t*t;
         float t_04 = t*t*t*t;
         
         float u_40 = nghich_u*nghich_u*nghich_u*nghich_u;
         float u_31 = nghich_u*nghich_u*nghich_u * u;
         float u_22 = nghich_u*nghich_u * u*u;
         float u_13 = nghich_u * u*u*u;
         float u_04 = u*u*u*u;
         
         maTranBezier[0] += t_40*u_40;
         maTranBezier[1] += 2.0f*t_40*u_31;
         maTranBezier[2] += t_40*u_22;
         
         maTranBezier[3] += 2.0f*t_31*u_40;
         maTranBezier[4] += 4.0f*t_31*u_31;
         maTranBezier[5] += 2.0f*t_31*u_22;
         
         maTranBezier[6] += t_22*u_40;
         maTranBezier[7] += 2.0f*t_22*u_31;
         maTranBezier[8] += t_22*u_22;
         
         // ----
         maTranBezier[9] += t_40*u_31;
         maTranBezier[10] += 2.0f*t_40*u_22;
         maTranBezier[11] += t_40*u_13;
         
         maTranBezier[12] += 2.0f*t_31*u_31;
         maTranBezier[13] += 4.0f*t_31*u_22;
         maTranBezier[14] += 2.0f*t_31*u_13;
         
         maTranBezier[15] += t_22*u_31;
         maTranBezier[16] += 2.0f*t_22*u_22;
         maTranBezier[17] += t_22*u_13;
         
         // ----
         maTranBezier[18] += t_40*u_22;
         maTranBezier[19] += 2.0f*t_40*u_13;
         maTranBezier[20] += t_40*u_04;
         
         maTranBezier[21] += 2.0f*t_31*u_22;
         maTranBezier[22] += 4.0f*t_31*u_13;
         maTranBezier[23] += 2.0f*t_31*u_04;
         
         maTranBezier[24] += t_22*u_22;
         maTranBezier[25] += 2.0f*t_22*u_13;
         maTranBezier[26] += t_22*u_04;
         
         // ====
         maTranBezier[27] += t_31*u_40;
         maTranBezier[28] += 2.0f*t_31*u_31;
         maTranBezier[29] += t_31*u_22;
         
         maTranBezier[30] += 2.0f*t_22*u_40;
         maTranBezier[31] += 4.0f*t_22*u_31;
         maTranBezier[32] += 2.0f*t_22*u_22;
         
         maTranBezier[33] += t_13*u_40;
         maTranBezier[34] += 2.0f*t_13*u_31;
         maTranBezier[35] += t_13*u_22;
         
         // ----
         maTranBezier[36] += t_31*u_31;
         maTranBezier[37] += 2.0f*t_31*u_22;
         maTranBezier[38] += t_31*u_13;
         
         maTranBezier[39] += 2.0f*t_22*u_31;
         maTranBezier[40] += 4.0f*t_22*u_22;
         maTranBezier[41] += 2.0f*t_22*u_13;
         
         maTranBezier[42] += t_13*u_31;
         maTranBezier[43] += 2.0f*t_13*u_22;
         maTranBezier[44] += t_13*u_13;
         
         // ----
         maTranBezier[45] += t_31*u_22;
         maTranBezier[46] += 2.0f*t_31*u_13;
         maTranBezier[47] += t_31*u_04;
         
         maTranBezier[48] += 2.0f*t_22*u_22;
         maTranBezier[49] += 4.0f*t_22*u_13;
         maTranBezier[50] += 2.0f*t_22*u_04;
         
         maTranBezier[51] += t_13*u_22;
         maTranBezier[52] += 2.0f*t_13*u_13;
         maTranBezier[53] += t_13*u_04;
         
         // ====
         maTranBezier[54] += t_22*u_40;
         maTranBezier[55] += 2.0f*t_22*u_31;
         maTranBezier[56] += t_22*u_22;
         
         maTranBezier[57] += 2.0f*t_13*u_40;
         maTranBezier[58] += 4.0f*t_13*u_31;
         maTranBezier[59] += 2.0f*t_13*u_22;
         
         maTranBezier[60] += t_04*u_40;
         maTranBezier[61] += 2.0f*t_04*u_31;
         maTranBezier[62] += t_04*u_22;
         
         // ----
         maTranBezier[63] += t_22*u_31;
         maTranBezier[64] += 2.0f*t_22*u_22;
         maTranBezier[65] += t_22*u_13;
         
         maTranBezier[66] += 2.0f*t_13*u_31;
         maTranBezier[67] += 4.0f*t_13*u_22;
         maTranBezier[68] += 2.0f*t_13*u_13;
         
         maTranBezier[69] += t_04*u_31;
         maTranBezier[70] += 2.0f*t_04*u_22;
         maTranBezier[71] += t_04*u_13;
         
         // ----
         maTranBezier[72] += t_22*u_22;
         maTranBezier[73] += 2.0f*t_22*u_13;
         maTranBezier[74] += t_22*u_04;
         
         maTranBezier[75] += 2.0f*t_13*u_22;
         maTranBezier[76] += 4.0f*t_13*u_13;
         maTranBezier[77] += 2.0f*t_13*u_04;
         
         maTranBezier[78] += t_04*u_22;
         maTranBezier[79] += 2.0f*t_04*u_13;
         maTranBezier[80] += t_04*u_04;
         
         float t_20 = nghich_t*nghich_t;
         float t_11 = nghich_t*t;
         float t_02 = t*t;
         
         float u_20 = nghich_u*nghich_u;
         float u_11 = nghich_u*u;
         float u_02 = u*u;
         
         // ----
         vectoGiai[0] += x*t_20*u_20;
         vectoGiai[3] += x*t_20*u_11;
         vectoGiai[6] += x*t_20*u_02;
         
         vectoGiai[9] += x*t_11*u_20;
         vectoGiai[12] += x*t_11*u_11;
         vectoGiai[15] += x*t_11*u_02;
         
         vectoGiai[18] += x*t_02*u_20;
         vectoGiai[21] += x*t_02*u_11;
         vectoGiai[24] += x*t_02*u_02;
         
         // ----
         vectoGiai[1] += y*t_20*u_20;
         vectoGiai[4] += y*t_20*u_11;
         vectoGiai[7] += y*t_20*u_02;
         
         vectoGiai[10] += y*t_11*u_20;
         vectoGiai[13] += y*t_11*u_11;
         vectoGiai[16] += y*t_11*u_02;
         
         vectoGiai[19] += y*t_02*u_20;
         vectoGiai[22] += y*t_02*u_11;
         vectoGiai[25] += y*t_02*u_02;
         
         // ----
         vectoGiai[2] += z*t_20*u_20;
         vectoGiai[5] += z*t_20*u_11;
         vectoGiai[8] += z*t_20*u_02;
         
         vectoGiai[11] += z*t_11*u_20;
         vectoGiai[14] += z*t_11*u_11;
         vectoGiai[17] += z*t_11*u_02;
         
         vectoGiai[20] += z*t_02*u_20;
         vectoGiai[23] += z*t_02*u_11;
         vectoGiai[26] += z*t_02*u_02;

         diaChiAnh += 4;
         soCot++;
      }
      soHang++;
   }
}
