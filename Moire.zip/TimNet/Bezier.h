/* Bezier.h */

#pragma once
#include "../ToMauAnh/Diem.h"


/* Vectơ */
typedef struct {
   float x;
   float y;
   float z;
} Vecto;

/* Bezier */
typedef struct {
   Vecto diemQuanTri[4];  // danh sách điểm quản trị
   //   unsigned short soLuongDiem;  // số lượng điểm
} Bezier;

/* Tính Vị Trí Bezier 3 Chiều */
Vecto tinhViTriBezier3C( Bezier *bezier, float thamSo );

/* Tham Số Điểm Góc Không, cho tọa độ z */
unsigned char thamSoDiemGocKhong_z( Bezier *bezier, float *nghiem0, float *nghiem1 );

/* Tính độ Cong tại Tham Số */
float tinhDoCongTaiThamSo_z( Bezier *bezier, float thamSo );

/* Tính Ma Trận Tối Ưu Đoạn Hàng */
void tinhMaTranToiUuDoanHang( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang, unsigned int soCotDau, unsigned int soCotCuoi );

/* Tính Ma Trận Tối Ưu Đoạn Cột */
void tinhMaTranToiUuDoanCot( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot, unsigned int soHangDau, unsigned int soHangCuoi );

