/* Bezier.h */

#pragma once
#include "../ToMauAnh/Diem.h"


/* Vectơ */
typedef struct {
   float x;
   float y;
   float z;
} Vecto;

/* Cong Bezier Bật 3 */
typedef struct {
   Vecto diemQuanTri[4];  // danh sách điểm quản trị
} Bezier;

/* Mặt Bezier Bật 1 */
typedef struct {
   Vecto diemQuanTri[4];  // danh sách điểm quản trị
} MatBezierB1;


/* Mặt Bezier Bật 2 */
typedef struct {
   Vecto diemQuanTri[9];  // danh sách điểm quản trị
} MatBezierB2;


/* Tính Vị Trí Cong Bezier 3 Chiều Bật 3 */
Vecto tinhViTriCongBezier3C_B3( Bezier *bezier, float thamSo );

/* Tham Số Điểm Góc Không, cho tọa độ z Bật 3 */
unsigned char thamSoDiemGocKhong_z_B3( Bezier *bezier, float *nghiem0, float *nghiem1 );

// ==== ĐỘ CONG
/* Tính độ Cong Tại Tham Số - Bật 3 */
float tinhDoCongTaiThamSo_z_B3( Bezier *bezier, float thamSo );

/* Tính độ Cong Tại Hai Tham Số - Bật 1 */
void tinhDoCongTaiHaiThamSo_z_B1( MatBezierB1 *matBezier, float t, float u, float *doCong_t, float *doCong_u );

/* Tính độ Cong Tại Hai Tham Số - Bật 2 */
void tinhDoCongTaiHaiThamSo_z_B2( MatBezierB2 *matBezier, float t, float u, float *doCong_t, float *doCong_u );

//  ==== TÍNH MA TRẬN
/* Tính Ma Trận Cong Tối Ưu Bật 3 Đoạn Hàng */
// maTranBezier 4 x 4  vectoGiai 4 x 1  (hàng x cột)
void tinhMaTranCongToiUuB3_doanHang( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang, unsigned int soCotDau, unsigned int soCotCuoi );

/* Tính Ma Trận Cong Tối Ưu Bật 3 Đoạn Cột */
// maTranBezier 4 x 4  vectoGiai 4 x 1  (hàng x cột)
void tinhMaTranCongToiUuB3_doanCot( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot, unsigned int soHangDau, unsigned int soHangCuoi );

// ====
/* Tính Ma Trận Mặt Tối Ưu Bật 2 Đoạn Cột */
void tinhMaTranMatToiUuB1_choDienTich( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCotDau, unsigned int soCotCuoi, unsigned int soHangDau, unsigned int soHangCuoi );

// maTranBezier 3 x 3  vectoGiai 3 x 1  (hàng x cột)
void tinhMaTranMatToiUuB2_choDienTich( float *maTranBezier, float *vectoGiai, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int trai, unsigned int phai, unsigned int duoi, unsigned int tren );
