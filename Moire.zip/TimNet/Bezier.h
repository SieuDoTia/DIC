/* Bezier.h */

#pragma once
#include "../ToMauAnh/Diem.h"


/* */
typedef struct {
   float x;
   float y;
   float z;
} Vecto;

/* Bezier */
typedef struct {
   Vecto diemQuanTri[4];  // danh sách điểm quản trị
   //   unsigned short soLuongDiem;  // số lượng điểm
} Bezier;

Vecto tinhViTriBezier3C( Bezier *bezier, float thamSo );
unsigned char thamSoDiemGocKhong( Bezier *bezier, float *nghiem0, float *nghiem1 );

Bezier doiHangAnhDoSangCongBezier( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang, unsigned int soCotDau, unsigned int soCotCuoi );

Bezier doiCotAnhDoSangCongBezier( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot, unsigned int soHangDau, unsigned int soHangCuoi );
