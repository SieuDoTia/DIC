/* Ma Trận */

#include <stdio.h>
#include <math.h>
#include "../HangSo.h"
#include "MaTran.h"


// ----- chỉ được xài cho hệ phương tuyến tối đa 128 x 128
unsigned char khuMaTran( float *maTranChanh, unsigned char soLuongHangChanh, unsigned char soLuongCotChanh,
                        float *maTranPhu, unsigned char soLuongHangPhu, unsigned char soLuongCotPhu, unsigned char *mangThuTu ) {
   
   unsigned char soHangDangDungDeKhu = 0;
   
   while( soHangDangDungDeKhu < soLuongHangChanh - 1) {
      
      float giaTriLonNhat = 0.0f;
      unsigned char chiSoHangLonNhat;
      unsigned char soHang = soHangDangDungDeKhu;
      
      while( soHang < soLuongHangChanh ) {
         // ---- rút giá trị tuyệt đối của hàng này
         float giaTriTuyetDoi = maTranChanh[mangThuTu[soHang]*soLuongCotChanh + soHangDangDungDeKhu];
         
         if( giaTriTuyetDoi < 0.0f )
            giaTriTuyetDoi = -giaTriTuyetDoi;
         
         // ---- so sánh giá trị tuyệt đối với lớn nhất
         if( giaTriTuyetDoi > giaTriLonNhat ) {
            giaTriLonNhat = giaTriTuyetDoi;
            chiSoHangLonNhat = soHang;
         }
         
         soHang++;
      }
      
      // ---- xem có nghiệm
      if( giaTriLonNhat == 0.0f )
         return kSAI;
      
      //      printf(" mangThuTu  doi soHangDangDungDeKhu %d voi chiSoHangLonNhat %d\n", soHangDangDungDeKhu, chiSoHangLonNhat );
      //      printf("           doi mangThutu[soHangDangDungDeKhu] %d voi mangThuTu[chiSoHangLonNhat] %d\n", mangThuTu[soHangDangDungDeKhu], mangThuTu[chiSoHangLonNhat] );
      // ---- nâng cấp mảng thứ tự (trao đổi hàng)
      unsigned char so = mangThuTu[soHangDangDungDeKhu];
      mangThuTu[soHangDangDungDeKhu] = mangThuTu[chiSoHangLonNhat];
      mangThuTu[chiSoHangLonNhat] = so;
      
      //      printf(" mangThuTu\n" );
      //      printf("  %d\n", mangThuTu[0]);
      //      printf("  %d\n", mangThuTu[1]);
      //      printf("  %d\n", mangThuTu[2]);
      //      printf("  %d\n", mangThuTu[3]);
      
      // ==== chia toàn bộ hàng bởi giá trị lớn nhất
      unsigned soCot = soHangDangDungDeKhu + 1;
      // ---- mẫu số để chia hàng này
      
      float mauSo = maTranChanh[mangThuTu[soHangDangDungDeKhu]*soLuongCotChanh + soHangDangDungDeKhu];  // không thể dùng biến giá trị lớn nhất vỉ có lẻ nó âm
      
      // ---- không cần chi nếu mẫu số = 1.0f
      if( mauSo != 1.0f ) {
         // ---- đặt phân tử đầu bằng 1,0f, là kết qủa chia một mình
         maTranChanh[mangThuTu[soHangDangDungDeKhu]*soLuongCotChanh + soHangDangDungDeKhu] = 1.0f;
         // ---- phần tử đầu để chia
         float *phanTuChia = &(maTranChanh[mangThuTu[soHangDangDungDeKhu]*soLuongCotChanh + soHangDangDungDeKhu + 1]);
         while( soCot < soLuongCotChanh ) {
            *phanTuChia /= mauSo;
            phanTuChia++;
            soCot++;
         }
         
         // ---- chia hàng ma trận phụ
         phanTuChia = &(maTranPhu[mangThuTu[soHangDangDungDeKhu]*soLuongCotPhu]);
         soCot = 0;
         while( soCot < soLuongCotPhu ) {
            *phanTuChia /= mauSo;
            phanTuChia++;
            soCot++;
         }
      }
      
      // ==== khử các phân tử trong hàng ở dưới
      unsigned char soHangKhu = soHangDangDungDeKhu+1;
      
      while( soHangKhu < soLuongHangChanh ) {
         float giaTriNhan = maTranChanh[mangThuTu[soHangKhu]*soLuongCotChanh + soHangDangDungDeKhu];
         
         // ---- nếu phân tử đầu bằng không, không cần khử hàng này
         if( giaTriNhan != 0.0f ) {
            
            maTranChanh[mangThuTu[soHangKhu]*soLuongCotChanh + soHangDangDungDeKhu] = 0.0f;
            float *phanTuGiaTriGoc = &(maTranChanh[mangThuTu[soHangDangDungDeKhu]*soLuongCotChanh + soHangDangDungDeKhu + 1]);
            float *phanTuDeKhu = &(maTranChanh[mangThuTu[soHangKhu]*soLuongCotChanh + soHangDangDungDeKhu + 1]);
            
            // ---- trừ hàng gốc từ hàng khử
            soCot = soHangDangDungDeKhu+1;
            while( soCot < soLuongCotChanh ) {
               *phanTuDeKhu -= giaTriNhan* *phanTuGiaTriGoc;
               
               phanTuDeKhu++;
               phanTuGiaTriGoc++;
               soCot++;
            }
            
            // ----
            phanTuGiaTriGoc = &(maTranPhu[mangThuTu[soHangDangDungDeKhu]*soLuongCotPhu]);
            phanTuDeKhu = &(maTranPhu[mangThuTu[soHangKhu]*soLuongCotPhu]);
            soCot = 0;
            while( soCot < soLuongCotPhu ) {
               *phanTuDeKhu -= giaTriNhan* *phanTuGiaTriGoc;
               phanTuDeKhu++;
               phanTuGiaTriGoc++;
               soCot++;
            }
            
         }
         
         soHangKhu++;
      }
      soHangDangDungDeKhu++;
      
   }
   
   // ==== chia hàng cuối (thật là tính nghiệm của hàng cuối)
   float mauSo = maTranChanh[mangThuTu[soHangDangDungDeKhu]*soLuongCotChanh + soHangDangDungDeKhu];
   if( mauSo != 0.0f ) {
      maTranChanh[mangThuTu[soHangDangDungDeKhu]*soLuongCotChanh + soHangDangDungDeKhu] = 1.0f;
      
      // ----
      float *phanTuChia = &(maTranPhu[mangThuTu[soHangDangDungDeKhu]*soLuongCotPhu]);
      unsigned char soCot = 0;
      while( soCot < soLuongCotPhu ) {
         *phanTuChia /= mauSo;
         phanTuChia++;
         soCot++;
      }
      
      return kDUNG;   // có nghiệm
   }
   
   return kSAI;
}

// ----- bỏ nghiệm vào ma trận phụ
void tinhNghiem( float *maTranChanh, unsigned char soLuongHangChanh, unsigned char soLuongCotChanh,
                float *maTranPhu, unsigned char soLuongHangPhu, unsigned char soLuongCotPhu, unsigned char *mangThuTu ) {
   
   unsigned char soCotPhu = 0;  // số cột phụ cho tính nghiệm
   
   while( soCotPhu < soLuongCotPhu ) {
      
      // ---- hàng cuối có nghiệm sẵn từ khử ma trận Gauss rổi
      char soHangTinhNghiem = soLuongHangChanh - 2;
      
      while( soHangTinhNghiem > -1 ) {
         // ---- tính trở ngược lại
         unsigned char soCotTinh = soLuongCotChanh - 1;
         float *nghiem = &(maTranPhu[mangThuTu[soHangTinhNghiem]*soLuongCotPhu + soCotPhu]);
         float *phanTuTinhChanh = &(maTranChanh[mangThuTu[soHangTinhNghiem]*soLuongCotChanh + soCotTinh]);
         
         while( soCotTinh > soHangTinhNghiem ) {
            *nghiem -= *phanTuTinhChanh * maTranPhu[mangThuTu[soCotTinh]*soLuongCotPhu + soCotPhu];
            phanTuTinhChanh--;
            soCotTinh--;
         }
         
         soHangTinhNghiem--;
      }
      soCotPhu++;
   }
   
}


#pragma mark ---- Chép Ma Trận
// chép toàn bộ ma trận chép vào ma trận địch tại số cột và số hàng đã chọn
void chepMaTranVaoMaTran( float *maTranChep, unsigned short beRongMaTranChep, unsigned short beCaoMaTranChep,
                         float *maTranDich, unsigned short beRongMaTranDich, unsigned short beCaoMaTranDich,
                         unsigned short soCotDau, unsigned short soHangDau ) {
   
   // ---- nếu số cột và hàng bắt đầu hơn bề rộng và bề cao ma trận đích, không cần chép gì cả
   if( !maTranChep ) {
      printf( "chepMaTranVaoMaTran: maTranChep == NULL\n" );
      return;
   }
   if( !maTranDich ) {
      printf( "chepMaTranVaoMaTran: maTranDich == NULL\n" );
      return;
   }
   
   // ---- chỉ chép được nếu ma trận chép ở trong phạm vi ma trận đích
   if( (soCotDau < beRongMaTranDich) && (soHangDau < beCaoMaTranDich) ) {
      
      // ---- tính số cột và số hàng cuối
      unsigned short soCotCuoi = soCotDau + beRongMaTranChep;
      unsigned short soHangCuoi = soHangDau + beCaoMaTranChep;
      if( soCotCuoi > beRongMaTranDich )
         soCotCuoi = beRongMaTranDich;
      
      if( soHangCuoi > beCaoMaTranDich )
         soHangCuoi = beCaoMaTranDich;
      
      // ---- chép giá trị phân tử ma trận chép vào ma trận đích
      unsigned short soHang = soHangDau;
      unsigned short soHangMaTranChep = 0;
      
      while( soHang < soHangCuoi  ) {
         
         unsigned short soCot = soCotDau;
         unsigned int diaChiMaTranDich = soHang*beRongMaTranDich + soCot;
         unsigned int diaChiMaTranChep = soHangMaTranChep*beRongMaTranChep;
         while( soCot < soCotCuoi ) {
            maTranDich[diaChiMaTranDich] = maTranChep[diaChiMaTranChep];
            diaChiMaTranDich++;
            diaChiMaTranChep++;
            soCot++;
         }
         soHangMaTranChep++;
         soHang++;
      }
   }
}

#pragma mark ---- CHIẾU MA TRẬN
void chieuMaTran( float *maTran, unsigned short beRong, unsigned short beCao ) {
   
   unsigned int chiSoMaTran = 0;
   unsigned short soHang = 0;
   while( soHang < beCao ) {
      unsigned short soCot = 0;
      while( soCot < beRong ) {
         printf( " %7.4f", maTran[chiSoMaTran] );
         soCot++;
         chiSoMaTran++;
      }
      soHang++;
      printf( "\n" );
   }
   printf( "\n" );
}


#pragma mark ---- BIẾN HÓA
// ------------------
//   |  1   0   0   0 |    0  1  2  3
//   |  0   c  -s   0 |    4  5  6  7
//   |  0   s   c   0 |    8  9 10 11
//   |  0   0   0   1 |   12 13 14 15
void maTranQuayQuanhTrucX( float *maTran, float goc ) {
   
   float cosGoc = cosf( goc );
   float sinGoc = sinf( goc );
   
   maTran[0] = 1.0f;
   maTran[1] = 0.0f;
   maTran[2] = 0.0f;
   maTran[3] = 0.0f;
   
   maTran[4] = 0.0f;
   maTran[5] = cosGoc;
   maTran[6] = -sinGoc;
   maTran[7] = 0.0f;
   
   maTran[8] = 0.0f;
   maTran[9] = sinGoc;
   maTran[10] = cosGoc;
   maTran[11] = 0.0f;
   
   maTran[12] = 0.0f;
   maTran[13] = 0.0f;
   maTran[14] = 0.0f;
   maTran[15] = 1.0f;
}

//   |  c   0   s   0 |      0  1  2  3
//   |  0   1   0   0 |      4  5  6  7
//   | -s   0   c   0 |      8  9 10 11
//   |  0   0   0   1 |     12 13 14 15
void maTranQuayQuanhTrucY( float *maTran, float goc ) {
   
   float cosGoc = cosf( goc );
   float sinGoc = sinf( goc );
   
   maTran[0] = cosGoc;
   maTran[1] = 0.0f;
   maTran[2] = sinGoc;
   maTran[3] = 0.0f;
   
   maTran[4] = 0.0f;
   maTran[5] = 1.0f;
   maTran[6] = 0.0f;
   maTran[7] = 0.0f;
   
   maTran[8] = -sinGoc;
   maTran[9] = 0.0f;
   maTran[10] = cosGoc;
   maTran[11] = 0.0f;
   
   maTran[12] = 0.0f;
   maTran[13] = 0.0f;
   maTran[14] = 0.0f;
   maTran[15] = 1.0f;
}

//   |  c  -s   0   0 |
//   |  s   c   0   0 |
//   |  0   0   1   0 |
//   |  0   0   0   1 |
void maTranQuayQuanhTrucZ( float *maTran, float goc ) {
   
   float cosGoc = cosf( goc );
   float sinGoc = sinf( goc );
   
   maTran[0] = cosGoc;
   maTran[1] = -sinGoc;
   maTran[2] = 0.0f;
   maTran[3] = 0.0f;
   
   maTran[4] = sinGoc;
   maTran[5] = cosGoc;
   maTran[6] = 0.0f;
   maTran[7] = 0.0f;
   
   maTran[8] = 0.0f;
   maTran[9] = 0.0f;
   maTran[10] = 1.0f;
   maTran[11] = 0.0f;
   
   maTran[12] = 0.0f;
   maTran[13] = 0.0f;
   maTran[14] = 0.0f;
   maTran[15] = 1.0f;
}


#pragma mark ---- NHÂN MA TRẬN
void nhanMaTranVoiMaTranVaBoVaoKetQua( float *maTran1, float *maTran2, float *ketQua ) {
   
   ketQua[0] = maTran1[0]*maTran2[0] + maTran1[1]*maTran2[4] + maTran1[2]*maTran2[8] + maTran1[3]*maTran2[12];
   ketQua[1] = maTran1[0]*maTran2[1] + maTran1[1]*maTran2[5] + maTran1[2]*maTran2[9] + maTran1[3]*maTran2[13];
   ketQua[2] = maTran1[0]*maTran2[2] + maTran1[1]*maTran2[6] + maTran1[2]*maTran2[10] + maTran1[3]*maTran2[14];
   ketQua[3] = maTran1[0]*maTran2[3] + maTran1[1]*maTran2[7] + maTran1[2]*maTran2[11] + maTran1[3]*maTran2[15];
   
   ketQua[4] = maTran1[4]*maTran2[0] + maTran1[5]*maTran2[4] + maTran1[6]*maTran2[8] + maTran1[7]*maTran2[12];
   ketQua[5] = maTran1[4]*maTran2[1] + maTran1[5]*maTran2[5] + maTran1[6]*maTran2[9] + maTran1[7]*maTran2[13];
   ketQua[6] = maTran1[4]*maTran2[2] + maTran1[5]*maTran2[6] + maTran1[6]*maTran2[10] + maTran1[7]*maTran2[14];
   ketQua[7] = maTran1[4]*maTran2[3] + maTran1[5]*maTran2[7] + maTran1[6]*maTran2[11] + maTran1[7]*maTran2[15];
   
   ketQua[8] = maTran1[8]*maTran2[0] + maTran1[9]*maTran2[4] + maTran1[10]*maTran2[8] + maTran1[11]*maTran2[12];
   ketQua[9] = maTran1[8]*maTran2[1] + maTran1[9]*maTran2[5] + maTran1[10]*maTran2[9] + maTran1[11]*maTran2[13];
   ketQua[10] = maTran1[8]*maTran2[2] + maTran1[9]*maTran2[6] + maTran1[10]*maTran2[10] + maTran1[11]*maTran2[14];
   ketQua[11] = maTran1[8]*maTran2[3] + maTran1[9]*maTran2[7] + maTran1[10]*maTran2[11] + maTran1[11]*maTran2[15];
   
   ketQua[12] = maTran1[12]*maTran2[0] + maTran1[13]*maTran2[4] + maTran1[14]*maTran2[8] + maTran1[15]*maTran2[12];
   ketQua[13] = maTran1[12]*maTran2[1] + maTran1[13]*maTran2[5] + maTran1[14]*maTran2[9] + maTran1[15]*maTran2[13];
   ketQua[14] = maTran1[12]*maTran2[2] + maTran1[13]*maTran2[6] + maTran1[14]*maTran2[10] + maTran1[15]*maTran2[14];
   ketQua[15] = maTran1[12]*maTran2[3] + maTran1[13]*maTran2[7] + maTran1[14]*maTran2[11] + maTran1[15]*maTran2[15];
}

// [  1 x 4 ] [         ]
//            [ ma trận ]
//            [  4 x 4  ]
//            [         ]
void nhanVectVoiMaTranVaBoVaoKetQua( float *vecto, float *maTran, float *ketQua ) {
   
   ketQua[0] = vecto[0]*maTran[0] + vecto[1]*maTran[4] + vecto[2]*maTran[8] + vecto[3]*maTran[12];
   ketQua[1] = vecto[0]*maTran[1] + vecto[1]*maTran[5] + vecto[2]*maTran[9] + vecto[3]*maTran[13];
   ketQua[2] = vecto[0]*maTran[2] + vecto[1]*maTran[6] + vecto[2]*maTran[10] + vecto[3]*maTran[14];
   ketQua[3] = vecto[0]*maTran[3] + vecto[1]*maTran[7] + vecto[2]*maTran[11] + vecto[3]*maTran[15];
}
