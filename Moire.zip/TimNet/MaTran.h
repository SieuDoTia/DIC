/* Ma Trận */

#pragma once

unsigned char khuMaTran( float *maTranChanh, unsigned char soLuongHangChanh, unsigned char soLuongCotChanh,
                        float *maTranPhu, unsigned char soLuongHangPhu, unsigned char soLuongCotPhu, unsigned char *mangThuTu );

void tinhNghiem( float *maTranChanh, unsigned char soLuongHangChanh, unsigned char soLuongCotChanh,
                float *maTranPhu, unsigned char soLuongHangPhu, unsigned char soLuongCotPhu, unsigned char *mangThuTu );

void maTranNghichDao3x3( float *maTran, float *maTranNghichDao );

void chepMaTranVaoMaTran( float *maTranChep, unsigned short beRongMaTranChep, unsigned short beCaoMaTranChep,
                         float *maTranDich, unsigned short beRongMaTranDich, unsigned short beCaoMaTranDich,
                         unsigned short soCotDau, unsigned short soHangDau );

void chieuMaTran( float *maTran, unsigned short beRong, unsigned short beCao );

void maTranQuayQuanhTrucX( float *maTran, float goc );
void maTranQuayQuanhTrucY( float *maTran, float goc );
void maTranQuayQuanhTrucZ( float *maTran, float goc );

// [ 4x4 ] [ 4x4 ]
// [     ] [     ]
void nhanMaTranVoiMaTranVaBoVaoKetQua4x4( float *maTran1, float *maTran2, float *ketQua );

// [ 1x4 ] [ 4x4 ]
//         [     ]
void nhanVectVoiMaTranVaBoVaoKetQua4x4( float *vecto, float *maTran, float *ketQua );

