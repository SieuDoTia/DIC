/* Ma Trận */

#pragma once

unsigned char khuMaTran( float *maTranChanh, unsigned char soLuongHangChanh, unsigned char soLuongCotChanh,
                        float *maTranPhu, unsigned char soLuongHangPhu, unsigned char soLuongCotPhu, unsigned char *mangThuTu );

void tinhNghiem( float *maTranChanh, unsigned char soLuongHangChanh, unsigned char soLuongCotChanh,
                float *maTranPhu, unsigned char soLuongHangPhu, unsigned char soLuongCotPhu, unsigned char *mangThuTu );

void chepMaTranVaoMaTran( float *maTranChep, unsigned short beRongMaTranChep, unsigned short beCaoMaTranChep,
                         float *maTranDich, unsigned short beRongMaTranDich, unsigned short beCaoMaTranDich,
                         unsigned short soCotDau, unsigned short soHangDau );

void chieuMaTran( float *maTran, unsigned short beRong, unsigned short beCao );
