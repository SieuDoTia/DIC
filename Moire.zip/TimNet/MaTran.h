/* Ma Trận */

#pragma once

unsigned char khuMaTran( float *maTranChanh, unsigned char soLuongHangChanh, unsigned char soLuongCotChanh,
                        float *maTranPhu, unsigned char soLuongHangPhu, unsigned char soLuongCotPhu, unsigned char *mangThuTu );

void tinhNghiem( float *maTranChanh, unsigned char soLuongHangChanh, unsigned char soLuongCotChanh,
                float *maTranPhu, unsigned char soLuongHangPhu, unsigned char soLuongCotPhu, unsigned char *mangThuTu );
