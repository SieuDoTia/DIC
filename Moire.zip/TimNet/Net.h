/* Nét.h */

#pragma once

#include "../ChuNhat.h"

typedef struct {
   Diem mangDiem[128];      // mảng điểm
   float cap;               // cấp
   unsigned char khongDoiDuyen;       // nghĩa là không xiêng qua hai ranh giới đối duyên nhau
   unsigned short soLuongDiem;  // số lượng điểm trong nét
   float docTrungBinh;      // dốc trung bình
   ChuNhat chuNhat;         // chữ nhật
   unsigned int dienTich;   // diện tích chữ nhật, giúp phân biệt chữ nhật lớn nhỏ
   unsigned char xuLyRoi;   // xử lý rồi, cho biết đã gặp net này rồi và nên bỏ qua nó
   short tamChuNhatX;       // tâm chữ nhật X
   short tamChuNhatY;       // tâm chữ nhật Y
} Net;
