/* TìmNét.c */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "TimNet.h"
#include "MaTran.h"
#include "Bezier.h"
#include "../VeVatThe/VeVongTron.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeSoCai.h"
#include "../HangSo.h"


Diem quetNghieng( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem tam, unsigned char cao );
Diem xemDiemQuetNghieng_cao( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem diem0, Diem diem1 );
Diem xemDiemQuetNghieng_thap( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem diem0, Diem diem1 );

// - quét tới và lui kiếm điểm cao nhất  <----+---->
// - xem có điểm này trong danh sách điểm hay chưa
//      chưa có: bỏ vào danh sách
//      có rồi: bỏ nỏ

// vài trường hợp:
//     1.          -*----
//         -------/      \------   <---- tìm điểm cao
//
//     2.          ------
//         ---*---/      \------   <---- tìm điểm cao - CHƯA được kiếm trường hợp này
//
//     3.          ------
//         -------/      \---*--   <---- tìm điểm cao - CHƯA được kiếm trường hợp này
//
//     4.             ----------   <---- bỏ trường hợp này
//         ------*---/
//
//     5.             -----*----   <---- bỏ trường hợp này
//         ----------/

#define kTAM_XA   50.0f

/* Tìm Các Điểm Thích Thú Ngang */
unsigned short timCacDiemThichThuNgang( Diem *mangDiemThichThu, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang ) {
   
   // ---- không cho ra ngoài phạm vi
   if( soHang >= beCao )
      soHang = beCao - 1;

   // ---- tìm điểm thích thú ở hàng trên nhất của ảnh ----> CẦN GIẢI THUẬT MỚI, CÒN PHÁT TRIỂN
   unsigned int diaChiAnh = beRong*soHang << 2;
   
   // ---- tìm nên đặt chế độ sáng trước hay tối
   unsigned short soCot = 2;
   unsigned char doSangDau = anh[diaChiAnh];
   diaChiAnh += 4;
   unsigned char doSangHienTai = anh[diaChiAnh];
   diaChiAnh += 4;
   
//   printf( "doSangDau %d doSangHienTai %d\n", doSangDau, doSangHienTai );
   while( (soCot < beRong) && (doSangDau == doSangHienTai) ) {
      doSangHienTai = anh[diaChiAnh ];
      diaChiAnh += 4;
      soCot++;
   }

   unsigned char cheDoSang = kDUNG;
   if( doSangHienTai < doSangDau )
      cheDoSang = kSAI;
   else
      cheDoSang = kDUNG;
   
   unsigned short soLuongDiem = 0;
   
   // ---- sáng nhất
   unsigned char sangNhat = 0;
   unsigned short soLuongSangNhat = 0;
   unsigned short soCotSangNhat = 0;
   
   // ---- tối nhất
   unsigned char toiNhat = 255;
   unsigned short soLuongToiNhat = 0;
   unsigned short soCotToiNhat = 0;

   diaChiAnh = beRong*soHang << 2;
   soCot = 0;
   while( soCot < beRong ) {
      unsigned char doSang = anh[diaChiAnh];
      
      // ---- chế độ sáng
      if( cheDoSang ) {
         if( doSang > sangNhat ) {
            sangNhat = doSang;
            soLuongSangNhat = 1;
            soCotSangNhat = soCot;
         }
         else if( doSang == sangNhat ) {
            soLuongSangNhat++;
         }
         else if( sangNhat - doSang > 5 ) {
            // ---- giữ tông tin điểm
            Diem *diemMoi = &(mangDiemThichThu[soLuongDiem]);
            diemMoi->x = soCotSangNhat + (soLuongSangNhat >> 1);
            diemMoi->y = soHang;
            diemMoi->loai = kLOAI_CAO;
            diemMoi->doSang = sangNhat;
            diemMoi->xuLyRoi = kSAI;
            diemMoi->huongQuet = kQUET_NGANG;
            // ---- đơn vi hóa vị trí tương đội với khổ ảnh
            diemMoi->x_DH = (float)soCotSangNhat/(float)beRong;
            diemMoi->y_DH = (float)soHang/(float)beCao;
            
            soLuongDiem++;
            cheDoSang = kLOAI_THAP;
            toiNhat = 255;
            soLuongToiNhat = 0;
         }
      }
      // ---- chế độ tối
      else {
         if( doSang < toiNhat ) {
            toiNhat = doSang;
            soLuongToiNhat = 1;
            soCotToiNhat = soCot;
         }
         else if( doSang == toiNhat ) {
            soLuongToiNhat++;
         }
         else if( doSang - toiNhat > 10 ) {
            // ---- giữ tông tin điểm
            Diem *diemMoi = &(mangDiemThichThu[soLuongDiem]);
            diemMoi->x = soCotToiNhat + (soLuongToiNhat >> 1);
            diemMoi->y = soHang;
            diemMoi->loai = kLOAI_THAP;
            diemMoi->doSang = toiNhat;
            diemMoi->xuLyRoi = kSAI;
            diemMoi->huongQuet = kQUET_NGANG;
            // ---- đơn vi hóa vị trí tương đội với khổ ảnh
            diemMoi->x_DH = (float)soCotToiNhat/(float)beRong;
            diemMoi->y_DH = (float)soHang/(float)beCao;
            
            soLuongDiem++;
            cheDoSang = kLOAI_CAO;
            sangNhat = 0;
            soLuongSangNhat = 0;
         }

      }

      soCot++;
      diaChiAnh += 4;
   }
   
   // ---- coi chừng có một gần ranh giới cuối
   diaChiAnh = (beRong*(soHang+1)-1) << 2;
   unsigned char doSangDiemAnhCuoi = anh[diaChiAnh];
   if( cheDoSang == kLOAI_CAO ) {
      if( soLuongSangNhat && (sangNhat > doSangDiemAnhCuoi) ) {
         Diem *diemMoi = &(mangDiemThichThu[soLuongDiem]);
         diemMoi->x = soCotSangNhat + (soLuongSangNhat >> 1);
         diemMoi->y = soHang;
         diemMoi->loai = kLOAI_CAO;
         diemMoi->doSang = sangNhat;
         diemMoi->xuLyRoi = kSAI;
         diemMoi->huongQuet = kQUET_NGANG;
         // ---- đơn vi hóa vị trí tương đội với khổ ảnh
         diemMoi->x_DH = (float)soCotSangNhat/(float)beRong;
         diemMoi->y_DH = (float)soHang/(float)beCao;
         
         soLuongDiem++;
      }
   }
   else {
      if( soLuongToiNhat && (toiNhat < doSangDiemAnhCuoi) ) {
         // ---- giữ tông tin điểm
         Diem *diemMoi = &(mangDiemThichThu[soLuongDiem]);
         diemMoi->x = soCotToiNhat + (soLuongToiNhat >> 1);
         diemMoi->y = soHang;
         diemMoi->loai = kLOAI_THAP;
         diemMoi->doSang = toiNhat;
         diemMoi->xuLyRoi = kSAI;
         diemMoi->huongQuet = kQUET_NGANG;
         // ---- đơn vi hóa vị trí tương đội với khổ ảnh
         diemMoi->x_DH = (float)soCotToiNhat/(float)beRong;
         diemMoi->y_DH = (float)soHang/(float)beCao;
         
         soLuongDiem++;
      }
   }
   
   return soLuongDiem;
}

/* Tìm Các Điểm Thích Thú Dộc */
unsigned short timCacDiemThichThuDoc( Diem *mangDiemThichThu, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot ) {

   // ---- không cho ra ngoài phạm vi
   if( soCot >= beRong )
      soCot = beRong - 1;

   // ---- tìm điểm thích thú ở hàng trên nhất của ảnh ----> CẦN GIẢI THUẬT MỚI, CÒN PHÁT TRIỂN
   unsigned int diaChiAnh = soCot << 2;
   
   // ---- tìm nên đặt chế độ sáng trước hay tối
   unsigned short soHang = 2;
   unsigned char doSangDau = anh[diaChiAnh];
   diaChiAnh += beRong << 2;
   unsigned char doSangHienTai = anh[diaChiAnh];
   diaChiAnh += beRong << 2;
   
   //   printf( "doSangDau %d doSangHienTai %d\n", doSangDau, doSangHienTai );
   while( (soHang < beCao) && (doSangDau == doSangHienTai) ) {
      doSangHienTai = anh[diaChiAnh ];
      diaChiAnh += beRong << 2;
      soHang++;
   }
   
   unsigned char cheDoSang = kDUNG;
   if( doSangHienTai < doSangDau )
      cheDoSang = kSAI;
   else
      cheDoSang = kDUNG;
   
   unsigned short soLuongDiem = 0;
   
   // ---- sáng nhất
   unsigned char sangNhat = 0;
   unsigned short soLuongSangNhat = 0;
   unsigned short soHangSangNhat = 0;
   
   // ---- tối nhất
   unsigned char toiNhat = 255;
   unsigned short soLuongToiNhat = 0;
   unsigned short soHangToiNhat = 0;
   
   diaChiAnh = soCot << 2;
   soHang = 0;
   while( soHang < beCao ) {
      unsigned char doSang = anh[diaChiAnh];
      
      // ---- chế độ sáng
      if( cheDoSang ) {
         if( doSang > sangNhat ) {
            sangNhat = doSang;
            soLuongSangNhat = 1;
            soHangSangNhat = soHang;
         }
         else if( doSang == sangNhat ) {
            soLuongSangNhat++;
         }
         else if( sangNhat - doSang > 5 ) {
            // ---- giữ tông tin điểm
            Diem *diemMoi = &(mangDiemThichThu[soLuongDiem]);
            diemMoi->x = soCot;
            diemMoi->y = soHangSangNhat + (soLuongSangNhat >> 1);
            diemMoi->loai = kLOAI_CAO;
            diemMoi->doSang = sangNhat;
            diemMoi->xuLyRoi = kSAI;
            diemMoi->huongQuet = kQUET_DOC;
            // ---- đơn vi hóa vị trí tương đội với khổ ảnh
            diemMoi->x_DH = (float)soCot/(float)beRong;
            diemMoi->y_DH = (float)soHangSangNhat/(float)beCao;
            
            soLuongDiem++;
            cheDoSang = kLOAI_THAP;
            toiNhat = 255;
            soLuongToiNhat = 0;
         }
      }
      // ---- chế độ tối
      else {
         if( doSang < toiNhat ) {
            toiNhat = doSang;
            soLuongToiNhat = 1;
            soHangToiNhat = soHang;
         }
         else if( doSang == toiNhat ) {
            soLuongToiNhat++;
         }
         else if( doSang - toiNhat > 10 ) {
            //            printf( "  sangNhat tai %d\n", soCotSangNhat + (soLuongSangNhat >>1) );
            // ---- giữ tông tin điểm
            Diem *diemMoi = &(mangDiemThichThu[soLuongDiem]);
            diemMoi->x = soCot;
            diemMoi->y = soHangToiNhat + (soLuongToiNhat >> 1);
            diemMoi->loai = kLOAI_THAP;
            diemMoi->doSang = toiNhat;
            diemMoi->xuLyRoi = kSAI;
            diemMoi->huongQuet = kQUET_DOC;
            // ---- đơn vi hóa vị trí tương đội với khổ ảnh
            diemMoi->x_DH = (float)soCot/(float)beRong;
            diemMoi->y_DH = (float)soHangToiNhat/(float)beCao;

            soLuongDiem++;
            cheDoSang = kLOAI_CAO;
            sangNhat = 0;
            soLuongSangNhat = 0;
         }

      }
      
      soHang++;
      diaChiAnh += beRong << 2;
   }
   
   // ---- coi chừng có một gần ranh giới cuối
   diaChiAnh = (beRong*(beCao - 1) + soCot) << 2;  // điểm cuối cột
   unsigned char doSangDiemAnhCuoi = anh[diaChiAnh];
   if( cheDoSang == kLOAI_CAO ) {
      if( soLuongSangNhat && (sangNhat > doSangDiemAnhCuoi) ) {
         Diem *diemMoi = &(mangDiemThichThu[soLuongDiem]);
         diemMoi->x = soCot;
         diemMoi->y = soHangSangNhat + (soLuongSangNhat >> 1);
         diemMoi->loai = kLOAI_CAO;
         diemMoi->doSang = sangNhat;
         diemMoi->xuLyRoi = kSAI;
         diemMoi->huongQuet = kQUET_DOC;
         // ---- đơn vi hóa vị trí tương đội với khổ ảnh
         diemMoi->x_DH = (float)soCot/(float)beRong;
         diemMoi->y_DH = (float)soHangSangNhat/(float)beCao;

         soLuongDiem++;
      }
   }
   else {
      if( soLuongToiNhat && (toiNhat < doSangDiemAnhCuoi) ) {
         // ---- giữ tông tin điểm
         Diem *diemMoi = &(mangDiemThichThu[soLuongDiem]);
         diemMoi->x = soCot;
         diemMoi->y = soHangToiNhat + (soLuongToiNhat >> 1);
         diemMoi->loai = kLOAI_THAP;
         diemMoi->doSang = toiNhat;
         diemMoi->xuLyRoi = kSAI;
         diemMoi->huongQuet = kQUET_DOC;
         // ---- đơn vi hóa vị trí tương đội với khổ ảnh
         diemMoi->x_DH = (float)soCot/(float)beRong;
         diemMoi->y_DH = (float)soHangToiNhat/(float)beCao;
         
         soLuongDiem++;
      }
   }

   return soLuongDiem;
}

/*  Quét Và Tạo Danh Sách Điểm Thích Thú Từ Ảnh */
void quetVaTaoDanhSachDiemThichThuTuAnh( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, DiemGon **dauDanhSachDiem, DiemGon **cuoiDanhSachDiem, unsigned char soLanCatDoc, unsigned char soLanCatNgang ) {

   unsigned short buocCot = beRongAnh/(soLanCatDoc - 1);
   unsigned short buocHang = beCaoAnh/(soLanCatNgang - 1);
   
   // ---- đặt NULL
   *dauDanhSachDiem = NULL;
   *cuoiDanhSachDiem = NULL;
   
   // ==== tìm các điểm
   // ---- quét ngang hàng đầu
   *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetNgang( dauDanhSachDiem, anh, beRongAnh, beCaoAnh, 0 );
   
   // ----  quét ngang hàng cuối
   if( *dauDanhSachDiem == NULL )
      *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetNgang( dauDanhSachDiem, anh, beRongAnh, beCaoAnh, beCaoAnh - 1 );
   else
      *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetNgang( cuoiDanhSachDiem, anh, beRongAnh, beCaoAnh, beCaoAnh - 1 );
   
   // ---- quét dộc cột đầu
   if( *dauDanhSachDiem == NULL )
      *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetDoc( dauDanhSachDiem, anh, beRongAnh, beCaoAnh, 0 );
   else
      *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetDoc( cuoiDanhSachDiem, anh, beRongAnh, beCaoAnh, 0 );
   
   // ---- quét dộc cột cuối
   if( *dauDanhSachDiem == NULL )
      *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetDoc( dauDanhSachDiem, anh, beRongAnh, beCaoAnh, beRongAnh - 1 );
   else
      *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetDoc( cuoiDanhSachDiem, anh, beRongAnh, beCaoAnh, beRongAnh - 1 );
   
   // ---- quét dộc các hàng giữa
   unsigned char soBuocCat = 1;
   unsigned int soHang = buocHang;
   while( soBuocCat < (soLanCatNgang - 1) ) {
      if( *dauDanhSachDiem == NULL )
         *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetNgang( dauDanhSachDiem, anh, beRongAnh, beCaoAnh, soHang );
      else
         *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetNgang( cuoiDanhSachDiem, anh, beRongAnh, beCaoAnh, soHang );
      
      soHang += buocHang;
      soBuocCat++;
   }
   
   // ---- quét dộc các dộc giữa
   soBuocCat = 1;
   unsigned short soCot = buocCot;
   while( soBuocCat < (soLanCatDoc - 1) ) {
      if( *dauDanhSachDiem == NULL )
         *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetDoc( dauDanhSachDiem, anh, beRongAnh, beCaoAnh, soCot );
      else
         *cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetDoc( cuoiDanhSachDiem, anh, beRongAnh, beCaoAnh, soCot );
      
      soCot += buocCot;
      soBuocCat++;
   }
}

#pragma mark ---- TÌM NÉT PHƯƠNG PHÁP BEZIER
/*unsigned short timCacDiemThichThuNgang_bezier( Diem *mangDiemThichThu, unsigned char *anhDoSang, unsigned int beRongAnhDoSang, unsigned int beCaoAnhDoSang, unsigned int soHang, unsigned short beDaiCongBezier ) {
   
   unsigned short soLuongDiem = 0;
   
   if( soHang >= beCaoAnhDoSang )
      soHang = beCaoAnhDoSang - 1;
   
   // ---- tính số lượng cong Bezier
   unsigned short soLuongCong = beRongAnhDoSang/beDaiCongBezier;
   
   // ---- phải có ít nhất một conng
   if( soLuongCong == 0 )
      soLuongCong = 1;
   
   // ---- hạng chế số lượng
   else if( soLuongCong > 64 )
      soLuongCong = 64;
   
   // ---- tính số lượng điểm ảnh một cong Beizer (chỉnh giá trị của bề dài cong Bezier)
   unsigned short soLuongDiemAnhChoCong = beRongAnhDoSang/soLuongCong;
   
   // ==== tạo ma trận để tính cong Bezier (bật ba) tối thiểu cho hàng ảnh
   unsigned short khoMaTran = (soLuongCong << 2) + ((soLuongCong - 1) << 1);
   float *maTranGop = calloc( khoMaTran*khoMaTran, sizeof(float) );
   float *vectoGop = calloc( khoMaTran << 1, sizeof(float) );
   unsigned char *mangThuTu = malloc( khoMaTran );
   
   if( maTranGop == NULL ) {
      printf( "TimNet: SAI LẦM vấn đề giàng trí nhớ cho maTrậnGóp\n" );
      exit(0);
   }
   
   if( vectoGop == NULL ) {
      printf( "TimNet: SAI LẦM vấn đề giàng trí nhớ cho vectơGóp\n" );
      exit(0);
   }
   
   if( mangThuTu == NULL ) {
      printf( "TimNet: SAI LẦM vấn đề giàng trí nhớ cho mảngThứTự\n" );
      exit(0);
   }
   
   // ---- hai ma trận này cho các cong có cùng điểm và góc (mịn) tại điểm kết nói
   float maTranKetNoi4x2[8] = {0.0f, -1.0f/6.0f, 0.5f, 0.5f, -0.5f, 0.5f, 0.0f, -1.0f/6.0f};
   float maTranKetNoi2x4[8] = {0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 1.0f, -1.0f};
   
   // ---- mảng thứ tự cho hàm khử Gauss
   unsigned short chiSo = 0;
   while( chiSo < khoMaTran ) {
      mangThuTu[chiSo] = chiSo;
      chiSo++;
   }

   // ---- góp ma trận
   unsigned short soCong = 0;
   while( soCong < soLuongCong ) {
      
      float maTran4x4[16];
      float maTran4x2[8];
      tinhMaTranCongToiUuB3_doanHang( maTran4x4, maTran4x2, anhDoSang, beRongAnhDoSang, beCaoAnhDoSang, soHang, soCong*soLuongDiemAnhChoCong, (soCong+1)*soLuongDiemAnhChoCong );
      //      chieuMaTran( maTran4x4, 4, 4 );
      chepMaTranVaoMaTran( maTran4x4, 4, 4, maTranGop, khoMaTran, khoMaTran, soCong << 2, soCong << 2 );
      chepMaTranVaoMaTran( maTran4x2, 2, 4, vectoGop, 2, khoMaTran, 0, soCong << 2 );
      
      soCong++;
   }
   
   soCong = 1;
   while( soCong < soLuongCong ) {
      unsigned short dich = (soLuongCong << 2) + ((soCong - 1) << 1);
      chepMaTranVaoMaTran( maTranKetNoi4x2, 2, 4, maTranGop, khoMaTran, khoMaTran, dich, (soCong << 2) - 2 );
      chepMaTranVaoMaTran( maTranKetNoi2x4, 4, 2, maTranGop, khoMaTran, khoMaTran, (soCong << 2) - 2 , dich );
      soCong++;
   }
   
   //   chieuMaTran( maTranGop, khoMaTran, khoMaTran );
   //   chieuMaTran( vectoGop, 2, khoMaTran );
   // ==== giải nghiệm ma trận
   unsigned char coNghiem = khuMaTran( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranGop, khoMaTran, khoMaTran, vectoGop, khoMaTran, 2, mangThuTu );
      
      // ====
      soCong = 0;
      while( soCong < soLuongCong ) {
         
         // ---- chép thông tin từ vectơ góp
         chiSo = soCong << 2;
         Bezier bezier;
         bezier.diemQuanTri[0].x = 0.0000f;
         bezier.diemQuanTri[0].y = 0.0f;
         bezier.diemQuanTri[0].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[1].x = 0.3333f;
         bezier.diemQuanTri[1].y = 0.0f;
         bezier.diemQuanTri[1].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[2].x = 0.6667f;
         bezier.diemQuanTri[2].y = 0.0f;
         bezier.diemQuanTri[2].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];
         chiSo++;
         
         bezier.diemQuanTri[3].x = 1.0000f;
         bezier.diemQuanTri[3].y = 0.0f;
         bezier.diemQuanTri[3].z = vectoGop[(mangThuTu[chiSo] << 1) + 1];

         // ---- tìm điểm cực (góc = 0)
         float nghiem0;
         float nghiem1;
         unsigned char soLuongNghiem = thamSoDiemGocKhong_z_B3( &bezier, &nghiem0, &nghiem1 );
         printf( "soHang %d  soLuongNghiem %d  %5.3f %5.3f\n", soHang, soLuongNghiem,  nghiem0, nghiem1 );
         
         if( soLuongNghiem > 0 ) {
            
            // ---- tính độ cong để biết đỉnh hay thủng lủng
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem0 );
            
            if( doCong > 0.0f ) {
               unsigned short x = nghiem0*soLuongDiemAnhChoCong;
               mangDiemThichThu[soLuongDiem].x = x;
               mangDiemThichThu[soLuongDiem].y = soHang;
               mangDiemThichThu[soLuongDiem].loai = kDIEM_TOI;
               mangDiemThichThu[soLuongDiem].doSang = anhDoSang[(soHang*beRongAnhDoSang + x) << 2];
            }
            else {
               unsigned short x = nghiem0*soLuongDiemAnhChoCong;
               mangDiemThichThu[soLuongDiem].x = x;
               mangDiemThichThu[soLuongDiem].y = soHang;
               mangDiemThichThu[soLuongDiem].loai = kDIEM_SANG;
               mangDiemThichThu[soLuongDiem].doSang = anhDoSang[(soHang*beRongAnhDoSang + x) << 2];
            }
            soLuongDiem++;
         }
         if( soLuongNghiem == 2 ) {
            
            float doCong = tinhDoCongTaiThamSo_z_B3(  &bezier, nghiem1 );
   
            if( doCong > 0.0f ) {
               unsigned short x = nghiem1*soLuongDiemAnhChoCong;
               mangDiemThichThu[soLuongDiem].x = x;
               mangDiemThichThu[soLuongDiem].y = soHang;
               mangDiemThichThu[soLuongDiem].loai = kDIEM_TOI;
               mangDiemThichThu[soLuongDiem].doSang = anhDoSang[(soHang*beRongAnhDoSang + x) << 2];
            }
            else {
               unsigned short x = nghiem1*soLuongDiemAnhChoCong;
               mangDiemThichThu[soLuongDiem].x = x;
               mangDiemThichThu[soLuongDiem].y = soHang;
               mangDiemThichThu[soLuongDiem].loai = kDIEM_SANG;
               mangDiemThichThu[soLuongDiem].doSang = anhDoSang[(soHang*beRongAnhDoSang + x) << 2];
            }
            soLuongDiem++;
         }
         soCong++;
      }
   }
   
   // ---- thả trí nhớ
   free( maTranGop );
   free( vectoGop );
   free( mangThuTu );

   return soLuongDiem;
} */
/*
unsigned short timCacNet( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char cach, Diem *mangDiemThichThu, unsigned short soLuongDiemThichThu, Net *mangNet ) {

//   printf( "số lượng điểm %d\n", soLuongDiemThichThu );

   // ==== ĐI THEO DÕI ĐƯỜNG

   // ---- để tính cấp nét
   float cap = 0.5f;      // cấp nét
   unsigned char tangCap = kDUNG;   // cho biết tăng hay giảm cấp
   unsigned char khongGapDoiVien = kSAI;    // cho biết nét không gặp ranh đối viên
   unsigned char soLanKhongGapDoiVien = 0;   // số lần không gặp ranh đối viên
   
   unsigned char soLuongNet = 0;

   unsigned char soDiem = 0;
   while( soDiem < soLuongDiemThichThu ) {
      
      if( !(mangDiemThichThu[soDiem].xuLyRoi) ) {
         // ---- kiếm các điểm ở dưới
         mangDiemThichThu[soDiem].huongX = 0.0f;
         mangDiemThichThu[soDiem].huongY = -1.0f;
 //       printf( " --- %d: diemThichThu %d %d\n", soDiem, mangDiemThichThu[soDiem].x, mangDiemThichThu[soDiem].y );
         
         mangNet[soLuongNet].mangDiem[0] = mangDiemThichThu[soDiem];

         // ---- cần giữ điểm để xem đường có kết nối với các điểm thích thú
         Diem diemCuoi;
         if( mangDiemThichThu[soDiem].loai == kLOAI_CAO )
            diemCuoi = diTheoDoiDuongVaChoDiemCuoi( anh, beRong, beCao, &(mangDiemThichThu[soDiem]), kLOAI_CAO, &(mangNet[soLuongNet]), kTAM_XA );
         else
            diemCuoi = diTheoDoiDuongVaChoDiemCuoi( anh, beRong, beCao, &(mangDiemThichThu[soDiem]), kLOAI_THAP, &(mangNet[soLuongNet]), kTAM_XA );
         
         printf( "   %d timDiemCao: diemCuoi (%d; %d)\n", soDiem, diemCuoi.x, diemCuoi.y );
         
         // ---- xem có điểm thích thú để gần điểm cuối
         //      chỉ cần xem điểm thích thú sau, những điểm trước đã được xử lý rồi
         unsigned char soDiemThichThuKiemTra = soDiem + 1;

         unsigned char khongGapDoiVien = kSAI;
         while( soDiemThichThuKiemTra < soLuongDiemThichThu ) {
            
            // ---- tính các giữa điểm cuối và điểm thích thú
            int cachX = mangDiemThichThu[soDiemThichThuKiemTra].x - diemCuoi.x;
            int cachY = mangDiemThichThu[soDiemThichThuKiemTra].y - diemCuoi.y;
 //           printf( "mangDiemThichThu[%d] (%d; %d) - diemCuoi (%d; %d)  cachX %d cachY %d ",
 //                  soDiemThichThuKiemTra, mangDiemThichThu[soDiemThichThuKiemTra].x, mangDiemThichThu[soDiemThichThuKiemTra].y,
 //                  diemCuoi.x, diemCuoi.y, cachX, cachY );
            unsigned int cachBinh = cachX*cachX + cachY*cachY;
 //           printf( " cachBinh %d\n", cachBinh );
            if( cachBinh < 1000 ) {
               //               printf( "  BO DIEM %d  tai %d; %d\n", soDiemThichThuCon,
               //                       mangDiemThichThu[soDiemThichThuCon].x, mangDiemThichThu[soDiemThichThuCon].y );
               mangDiemThichThu[soDiemThichThuKiemTra].xuLyRoi = kDUNG;
               // ---- chỉ tăng lên nếu được dùng nét
               //             printf( "%d mangNet[soLuongNet].docTB %5.3f\n", chiSoDiemCuoi, mangNet[soLuongNet].docTrungBinh );
               //     if( mangNet[soLuongNet].docTrungBinh < 3.6f )
               soLanKhongGapDoiVien++;
               khongGapDoiVien = kDUNG;
            }
            soDiemThichThuKiemTra++;

         }
         
         // ---- hết gắp nét không gặp ranh đối viên, trừ số lần gắp không đối viên để có đúng cấp
         if( !khongGapDoiVien && soLanKhongGapDoiVien ) {
            mangNet[soLuongNet].cap = cap - (soLanKhongGapDoiVien)*0.5f;  // cần trừ một thêm một lần vì đã cộng 1 với cấp từ lặp vòng trước
            tangCap = kSAI;
         }
         else
            mangNet[soLuongNet].cap = cap;
         
         // ---- tíng cấp tiếp
         if( tangCap )
            cap += 0.5f;
         else
            cap -= 0.5f;

 //        printf( " NET soDiem %d (%d;%d) cap %5.3f  docTB %5.3f  tangCap %d  soLanKhongGapDoiVien %d\n", soDiem, mangNet[soLuongNet].mangDiem[0].x, mangNet[soLuongNet].mangDiem[0].y,
 //               mangNet[soLuongNet].cap, mangNet[soLuongNet].docTrungBinh, tangCap, soLanKhongGapDoiVien );
         soLuongNet++;
      }

      soDiem++;
   }
//   printf( "timNet: soLuongNet %d \n", soLuongNet );

   return soLuongNet;
}
*/
/*
// ---- LƯU Ý: NẾU CÓ nét VÒNG TRÒN (nét không đến ranh ảnh), cái lặp vọng trong hàm này sẽ bị mất kệt
Diem diTheoDoiDuongVaChoDiemCuoi( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem *diem, unsigned char cao, Net *net, float buoc ) {
   
   int gioiHanThap = 0;
   int gioiHanCao = beCao - 1;
   int gioiHanTrai = 0;
   int gioiHanPhai = beRong - 1;

   Diem danhSachDiem[1024];  // chứa điểm
   danhSachDiem[0] = *diem;

   Diem nganXepDiem[16];  // chứa điểm đang kiểm tra
   
   // ---- tiến tới
   Diem diem0;
   diem0.x = diem->x;
   diem0.y = diem->y;
   diem0.huongX = diem->huongX;
   diem0.huongY = diem->huongY;
   net->mangDiem[0] = diem0;

   unsigned short dem = 1;    // đừng cho điTheoĐường() bị mất kế
   
   float docNet = 0.0f;
   
   do {
      Diem diemTiepTheo;
      diemTiepTheo.x = diem0.x + diem0.huongX*buoc;
      diemTiepTheo.y = diem0.y + diem0.huongY*buoc;
      diemTiepTheo.huongX = diem0.huongX;
      diemTiepTheo.huongY = diem0.huongY;

      // ---- nên kiểm tra GIỚI HẠN TRÁi PHẢI
      if( diemTiepTheo.x > gioiHanPhai ) {
         float soPhan = (float)(gioiHanPhai - diem0.x)/(float)(diemTiepTheo.x - diem0.x);
         diemTiepTheo.x = diem0.x + (diemTiepTheo.x - diem0.x)*soPhan;
         diemTiepTheo.y = diem0.y + (diemTiepTheo.y - diem0.y)*soPhan;
         // ---- đến cạnh và tìm điểm tốt nhất ở đó
         diemTiepTheo.huongX = 1.0f;
         diemTiepTheo.huongY = 0.0f;
      }
      else if( diemTiepTheo.x < gioiHanTrai ) {
         float soPhan = (float)(diem0.x - gioiHanTrai)/(float)(diem0.x - diemTiepTheo.x);
         diemTiepTheo.x = diem0.x + (diemTiepTheo.x - diem0.x)*soPhan;
         diemTiepTheo.y = diem0.y + (diemTiepTheo.y - diem0.y)*soPhan;
         // ---- đến cạnh và tìm điểm tốt nhất ở đó
         diemTiepTheo.huongX = -1.0f;
         diemTiepTheo.huongY = 0.0f;
      }
   
      // ---- đừng cho điểm ra ngoài phạm vi, dùng hướng của điểm để sửa lại vị trí năm trên ranh giới hạn
      if( diemTiepTheo.y > gioiHanCao ) {
         float soPhan = (float)(gioiHanCao - diem0.y)/(float)(diemTiepTheo.y - diem0.y);
         diemTiepTheo.x = diem0.x + (diemTiepTheo.x - diem0.x)*soPhan;
         diemTiepTheo.y = diem0.y + (diemTiepTheo.y - diem0.y)*soPhan;
         // ---- đến cạnh và tìm điểm tốt nhất ở đó
         diemTiepTheo.huongX = 0.0f;
         diemTiepTheo.huongY = 1.0f;
//         printf( " diTheoDoiDuong: suaLai diemTiepTheo: %d  %d  soPhan %5.3f  gioiHanThap %d\n", diemTiepTheo.x, diemTiepTheo.y, soPhan, gioiHanThap );
      }
      else if( diemTiepTheo.y < gioiHanThap ) {
         float soPhan = (float)(diem0.y - gioiHanThap)/(float)(diem0.y - diemTiepTheo.y);
         diemTiepTheo.x = diem0.x + (diemTiepTheo.x - diem0.x)*soPhan;
         diemTiepTheo.y = diem0.y + (diemTiepTheo.y - diem0.y)*soPhan;
         // ---- đến cạnh và tìm điểm tốt nhất ở đó
         diemTiepTheo.huongX = 0.0f;
         diemTiepTheo.huongY = -1.0f;
//         printf( " diTheoDoiDuong: suaLai diemTiepTheo: %d  %d  soPhan %5.3f  gioiHanThap %d\n", diemTiepTheo.x, diemTiepTheo.y, soPhan, gioiHanThap );
      }
      
      
//      printf( " diTheoDoiDuong: sau  diemTiep: (%d; %d)\n", diemTiepTheo.x, diemTiepTheo.y );
      Diem diemMoi = quetNghieng( anh, beRong, beCao, diemTiepTheo, cao );
      
      // ---- tính hướng đến điểm mới
      short huongX = diemMoi.x - diem0.x;
      short huongY = diemMoi.y - diem0.y;
      //   printf( " diemMoi %d %d  tam %d %d huongX %d  huongY %d\n", diemMoi.x, diemMoi.y, tam.x, tam.y, huongX, huongY  );
      float doLon = sqrtf( huongX*huongX + huongY*huongY );
      diemMoi.huongX = huongX/doLon;
      diemMoi.huongY = huongY/doLon;

      // ---- tính dốc giữa hai điểm, dùng này để biết chật lượng nét. Thật nên có giải thuật thông minh hơn để tránh cần làm bước này
      char docGiuaDiem = diemMoi.doSang - diem0.doSang;
      // ---- cộng giá trị tuyệt đối
      if( docGiuaDiem < 0 )
         docNet -= docGiuaDiem;
      else
         docNet += docGiuaDiem;
      
//      printf( "diTheoDoiDuong: diemMoi.doSang %d\n", diemMoi.doSang );  <---- kiểm tra này sau
      
      diem0 = diemMoi;
      net->mangDiem[dem] = diem0;
      dem++;
      if( dem > 100 )
         break;
   } while( (diem0.y > gioiHanThap) && (diem0.y < gioiHanCao) && (diem0.x > gioiHanTrai) && (diem0.x < gioiHanPhai) );

   net->soLuongDiem = dem;
   net->docTrungBinh = docNet/(float)(dem - 1);
 //  printf( " net->docTrungBinh %5.3f\n", net->docTrungBinh );
   // ---- xem đã đến từ hướng này chưa
   return diem0;
}
*/

#define kCACH_QUET 50

Diem quetNghieng( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem tam, unsigned char cao ) {
   
   float huongVuongGocX = tam.huongY;
   float huongVuongGocY = -tam.huongX;
   
   // ---- tính điểm khởi đầu và kết thúc
   Diem diemBatDau;
   Diem diemKetThuc;
   diemBatDau.x = tam.x - huongVuongGocX*kCACH_QUET;
   diemBatDau.y = tam.y - huongVuongGocY*kCACH_QUET;
   diemKetThuc.x = tam.x + huongVuongGocX*kCACH_QUET;
   diemKetThuc.y = tam.y + huongVuongGocY*kCACH_QUET;
   
   // =====  coi chừng đi ra ngoài phạm vi
   // ----- điểm bặt đầu
   if( diemBatDau.x < 0 ) {
      float soPhan = (float)tam.x/(float)(tam.x - diemBatDau.x);
      diemBatDau.x = tam.x + (diemBatDau.x - tam.x)*soPhan;
      diemBatDau.y = tam.y + (diemBatDau.y - tam.y)*soPhan;
   }
   else if( diemBatDau.x >= beRong ) {
      float soPhan = (float)(beRong - 1 - tam.x)/(float)(diemBatDau.x - tam.x);
      diemBatDau.x = tam.x + (diemBatDau.x - tam.x)*soPhan;
      diemBatDau.y = tam.y + (diemBatDau.y - tam.y)*soPhan;
   }
   if( diemBatDau.y < 0 ) {
      float soPhan = (float)tam.y/(float)(tam.y - diemBatDau.y);
      diemBatDau.x = tam.x + (diemBatDau.x - tam.x)*soPhan;
      diemBatDau.y = tam.y + (diemBatDau.y - tam.y)*soPhan;
   }
   else if( diemBatDau.y >= beCao ) {
      float soPhan = (float)(beCao - 1 - tam.y)/(float)(diemBatDau.y - tam.y);
      diemBatDau.x = tam.x + (diemBatDau.x - tam.x)*soPhan;
      diemBatDau.y = tam.y + (diemBatDau.y - tam.y)*soPhan;
   }
   
   // ----- điểm kết thúc
   if( diemKetThuc.x < 0 ) {
      float soPhan = (float)tam.x/(float)(tam.x - diemKetThuc.x);
      diemKetThuc.x = tam.x + (diemKetThuc.x - tam.x)*soPhan;
      diemKetThuc.y = tam.y + (diemKetThuc.y - tam.y)*soPhan;
   }
   else if( diemKetThuc.x >= beRong ) {
      float soPhan = (float)(beRong - 1 - tam.x)/(float)(diemKetThuc.x - tam.x);
      diemKetThuc.x = tam.x + (diemKetThuc.x - tam.x)*soPhan;
      diemKetThuc.y = tam.y + (diemKetThuc.y - tam.y)*soPhan;
   }
   if( diemKetThuc.y < 0 ) {
      float soPhan = (float)tam.y/(float)(tam.y - diemKetThuc.y);
      diemKetThuc.x = tam.x + (diemKetThuc.x - tam.x)*soPhan;
      diemKetThuc.y = tam.y + (diemKetThuc.y - tam.y)*soPhan;
   }
   else if( diemKetThuc.y >= beCao ) {
      float soPhan = (float)(beCao - 1 - tam.y)/(float)(diemKetThuc.y - tam.y);
      diemKetThuc.x = tam.x + (diemKetThuc.x - tam.x)*soPhan;
      diemKetThuc.y = tam.y + (diemKetThuc.y - tam.y)*soPhan;
   }
   
//   printf( "  quetNghieng: tam %d %d  huong %5.3f %5.3f  huongVG %5.3f %5.3f\n   batdau (%d; %d)  ketThuc (%d; %d)\n", tam.x, tam.y, tam.huongX, tam.huongY, huongVuongGocX, huongVuongGocY,  diemBatDau.x, diemBatDau.y, diemKetThuc.x, diemKetThuc.y );
   
   Diem diemMoi;
   if( cao )
      diemMoi = xemDiemQuetNghieng_cao( anh, beRong, beCao, diemBatDau, diemKetThuc );
   else
      diemMoi = xemDiemQuetNghieng_thap( anh, beRong, beCao, diemBatDau, diemKetThuc );
   
   return diemMoi;
}

Diem xemDiemQuetNghieng_cao( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem diem0, Diem diem1 ) {
   
   short cachX = diem1.x - diem0.x;
   short cachY = diem1.y - diem0.y;
   Diem mangDiemQuet[(kCACH_QUET << 1) + 1];
   unsigned char giaTriCao = 0;
   unsigned short soLan = 0;
   unsigned short chiSoCaoNhat = 0;
   //   printf( " cach %d %d\n", cachX, cachY );
   
   // ---- ∆x < 0; ∆y < 0 đổi thành ∆x > 0; ∆y > 0
   if( (cachX <= 0) && (cachY <= 0) ) {
      //     printf( " ...dang trao doi\n");
      cachX = -cachX;
      cachY = -cachY;
      short so_x = diem0.x;
      short so_y = diem0.y;
      diem0.x = diem1.x;
      diem0.y = diem1.y;
      diem1.x = so_x;
      diem1.y = so_y;
   }
   else if( (cachX > 0) && (cachY < 0) ) {
      cachX = -cachX;
      cachY = -cachY;
      short so_x = diem0.x;
      short so_y = diem0.y;
      diem0.x = diem1.x;
      diem0.y = diem1.y;
      diem1.x = so_x;
      diem1.y = so_y;
   }
   //   printf( " (sau trao doi) cach %d %d  diem0 %d %d   diem1 %d %d\n", cachX, cachY, diem0.x, diem0.y, diem1.x, diem1.y );
   
   unsigned short chiSoMang = 0;
   short x = diem0.x;
   short y = diem0.y;
   
   if( (cachX == 0) && (cachY != 0) ) {  // đường dọc
      while( y <= diem1.y ) {
         unsigned int diaChiAnh = (beRong*y + x) << 2;
         mangDiemQuet[chiSoMang].x = x;
         mangDiemQuet[chiSoMang].y = y;
         unsigned char giaTriHienTai = anh[diaChiAnh];
         mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
         if( giaTriHienTai > giaTriCao ) {
            giaTriCao = giaTriHienTai;
            soLan = 1;
            chiSoCaoNhat = chiSoMang;
         }
         else if( giaTriHienTai == giaTriCao ) {
            soLan++;
         }
         //         printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
         y++;
         chiSoMang++;
      }
   }
   else if( (cachX != 0) && (cachY == 0) ) {  // đường ngang
      while( x <= diem1.x ) {
         unsigned int diaChiAnh = (beRong*y + x) << 2;
         mangDiemQuet[chiSoMang].x = x;
         mangDiemQuet[chiSoMang].y = y;
         unsigned char giaTriHienTai = anh[diaChiAnh];
         mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
         if( giaTriHienTai > giaTriCao ) {
            giaTriCao = giaTriHienTai;
            soLan = 1;
            chiSoCaoNhat = chiSoMang;
         }
         else if( giaTriHienTai == giaTriCao ) {
            soLan++;
         }
         //         printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
         x++;
         chiSoMang++;
      }
   }
   
   else {
      if( cachX > 0 && cachY > 0 ) {  // ---- ∆x > 0; ∆y > 0
         if( cachY <= cachX ) {
            short saiLam = (cachY << 1) - cachX;
            
            while( x <= diem1.x ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               mangDiemQuet[chiSoMang].x = x;
               mangDiemQuet[chiSoMang].y = y;
               unsigned char giaTriHienTai = anh[diaChiAnh];
               mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
               if( giaTriHienTai > giaTriCao ) {
                  giaTriCao = giaTriHienTai;
                  soLan = 1;
                  chiSoCaoNhat = chiSoMang;
               }
               else if( giaTriHienTai == giaTriCao ) {
                  soLan++;
               }
               //               printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
               
               if( saiLam > 0 ) {
                  y++;
                  saiLam -= (cachX << 1);
               }
               saiLam += cachY << 1;
               chiSoMang++;
               x++;
            }
         }
         else {
            short saiLam = (cachX << 1) - cachY;
            
            while( y <= diem1.y ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               mangDiemQuet[chiSoMang].x = x;
               mangDiemQuet[chiSoMang].y = y;
               unsigned char giaTriHienTai = anh[diaChiAnh];
               mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
               if( giaTriHienTai > giaTriCao ) {
                  giaTriCao = giaTriHienTai;
                  soLan = 1;
                  chiSoCaoNhat = chiSoMang;
               }
               else if( giaTriHienTai == giaTriCao ) {
                  soLan++;
               }
               //               printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
               
               if( saiLam > 0 ) {
                  x++;
                  saiLam -= (cachY << 1);
               }
               saiLam += cachX << 1;
               chiSoMang++;
               y++;
            }
         }
      }
      else {           // ---- ∆x < 0; ∆y > 0
         short cachX_tuyetDoi = -cachX;
         if( cachY <= cachX_tuyetDoi ) {
            short saiLam = (cachY << 1) + cachX;
            
            while( x >= diem1.x ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               mangDiemQuet[chiSoMang].x = x;
               mangDiemQuet[chiSoMang].y = y;
               unsigned char giaTriHienTai = anh[diaChiAnh];
               mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
               if( giaTriHienTai > giaTriCao ) {
                  giaTriCao = giaTriHienTai;
                  soLan = 1;
                  chiSoCaoNhat = chiSoMang;
               }
               else if( giaTriHienTai == giaTriCao ) {
                  soLan++;
               }
               //               printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
               
               if( saiLam > 0 ) {
                  y++;
                  saiLam += (cachX << 1);
               }
               saiLam += cachY << 1;
               chiSoMang++;
               x--;
            }
         }
         else {
            short saiLam = -(cachX << 1) - cachY;
            
            while( y <= diem1.y ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               mangDiemQuet[chiSoMang].x = x;
               mangDiemQuet[chiSoMang].y = y;
               unsigned char giaTriHienTai = anh[diaChiAnh];
               mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
               if( giaTriHienTai > giaTriCao ) {
                  giaTriCao = giaTriHienTai;
                  soLan = 1;
                  chiSoCaoNhat = chiSoMang;
               }
               else if( giaTriHienTai == giaTriCao ) {
                  soLan++;
               }
               //               printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
               
               if( saiLam > 0 ) {
                  x--;
                  saiLam -= (cachY << 1);
               }
               saiLam -= cachX << 1;
               chiSoMang++;
               y++;
               
            }
            
         }
      }
   }
   
   return mangDiemQuet[chiSoCaoNhat + (soLan >> 1)];
}

Diem xemDiemQuetNghieng_thap( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem diem0, Diem diem1 ) {
   
   short cachX = diem1.x - diem0.x;
   short cachY = diem1.y - diem0.y;
   Diem mangDiemQuet[(kCACH_QUET << 1) + 1];
   unsigned char giaTriThap = 255;
   unsigned short soLan = 0;
   unsigned short chiSoThapNhat = 0;
   //   printf( " cach %d %d\n", cachX, cachY );
   
   // ---- ∆x < 0; ∆y < 0 đổi thành ∆x > 0; ∆y > 0
   if( (cachX <= 0) && (cachY <= 0) ) {
      //     printf( " ...dang trao doi\n");
      cachX = -cachX;
      cachY = -cachY;
      short so_x = diem0.x;
      short so_y = diem0.y;
      diem0.x = diem1.x;
      diem0.y = diem1.y;
      diem1.x = so_x;
      diem1.y = so_y;
   }
   else if( (cachX > 0) && (cachY < 0) ) {
      cachX = -cachX;
      cachY = -cachY;
      short so_x = diem0.x;
      short so_y = diem0.y;
      diem0.x = diem1.x;
      diem0.y = diem1.y;
      diem1.x = so_x;
      diem1.y = so_y;
   }
   //   printf( " (sau trao doi) cach %d %d  diem0 %d %d   diem1 %d %d\n", cachX, cachY, diem0.x, diem0.y, diem1.x, diem1.y );
   
   unsigned short chiSoMang = 0;
   short x = diem0.x;
   short y = diem0.y;
   
   if( (cachX == 0) && (cachY != 0) ) {  // đường dọc
      while( y <= diem1.y ) {
         unsigned int diaChiAnh = (beRong*y + x) << 2;
         mangDiemQuet[chiSoMang].x = x;
         mangDiemQuet[chiSoMang].y = y;
         unsigned char giaTriHienTai = anh[diaChiAnh];
         mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
         if( giaTriHienTai < giaTriThap ) {
            giaTriThap = giaTriHienTai;
            soLan = 1;
            chiSoThapNhat = chiSoMang;
         }
         else if( giaTriHienTai == giaTriThap ) {
            soLan++;
         }
         //         printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
         y++;
         chiSoMang++;
      }
   }
   else if( (cachX != 0) && (cachY == 0) ) {  // đường ngang
      while( x <= diem1.x ) {
         unsigned int diaChiAnh = (beRong*y + x) << 2;
         mangDiemQuet[chiSoMang].x = x;
         mangDiemQuet[chiSoMang].y = y;
         unsigned char giaTriHienTai = anh[diaChiAnh];
         mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
         if( giaTriHienTai < giaTriThap ) {
            giaTriThap = giaTriHienTai;
            soLan = 1;
            chiSoThapNhat = chiSoMang;
         }
         else if( giaTriHienTai == giaTriThap ) {
            soLan++;
         }
         //         printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
         x++;
         chiSoMang++;
      }
   }
   
   else {
      if( cachX > 0 && cachY > 0 ) {  // ---- ∆x > 0; ∆y > 0
         if( cachY <= cachX ) {
            short saiLam = (cachY << 1) - cachX;
            
            while( x <= diem1.x ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               mangDiemQuet[chiSoMang].x = x;
               mangDiemQuet[chiSoMang].y = y;
               unsigned char giaTriHienTai = anh[diaChiAnh];
               mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
               if( giaTriHienTai < giaTriThap ) {
                  giaTriThap = giaTriHienTai;
                  soLan = 1;
                  chiSoThapNhat = chiSoMang;
               }
               else if( giaTriHienTai == giaTriThap ) {
                  soLan++;
               }
               //               printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
               
               if( saiLam > 0 ) {
                  y++;
                  saiLam -= (cachX << 1);
               }
               saiLam += cachY << 1;
               chiSoMang++;
               x++;
            }
         }
         else {
            short saiLam = (cachX << 1) - cachY;
            
            while( y <= diem1.y ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               mangDiemQuet[chiSoMang].x = x;
               mangDiemQuet[chiSoMang].y = y;
               unsigned char giaTriHienTai = anh[diaChiAnh];
               mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
               if( giaTriHienTai < giaTriThap ) {
                  giaTriThap = giaTriHienTai;
                  soLan = 1;
                  chiSoThapNhat = chiSoMang;
               }
               else if( giaTriHienTai == giaTriThap ) {
                  soLan++;
               }
               //               printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
               
               if( saiLam > 0 ) {
                  x++;
                  saiLam -= (cachY << 1);
               }
               saiLam += cachX << 1;
               chiSoMang++;
               y++;
            }
         }
      }
      else {           // ---- ∆x < 0; ∆y > 0
         short cachX_tuyetDoi = -cachX;
         if( cachY <= cachX_tuyetDoi ) {
            short saiLam = (cachY << 1) + cachX;
            
            while( x >= diem1.x ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               mangDiemQuet[chiSoMang].x = x;
               mangDiemQuet[chiSoMang].y = y;
               unsigned char giaTriHienTai = anh[diaChiAnh];
               mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
               if( giaTriHienTai < giaTriThap ) {
                  giaTriThap = giaTriHienTai;
                  soLan = 1;
                  chiSoThapNhat = chiSoMang;
               }
               else if( giaTriHienTai == giaTriThap ) {
                  soLan++;
               }
               //               printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
               
               if( saiLam > 0 ) {
                  y++;
                  saiLam += (cachX << 1);
               }
               saiLam += cachY << 1;
               chiSoMang++;
               x--;
            }
         }
         else {
            short saiLam = -(cachX << 1) - cachY;
            
            while( y <= diem1.y ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               mangDiemQuet[chiSoMang].x = x;
               mangDiemQuet[chiSoMang].y = y;
               unsigned char giaTriHienTai = anh[diaChiAnh];
               mangDiemQuet[chiSoMang].doSang = giaTriHienTai;
               if( giaTriHienTai < giaTriThap ) {
                  giaTriThap = giaTriHienTai;
                  soLan = 1;
                  chiSoThapNhat = chiSoMang;
               }
               else if( giaTriHienTai == giaTriThap ) {
                  soLan++;
               }
               //               printf( "%d: %d %d  giaTri %d  diaChiAnh %d\n", chiSoMang, x, y, mangDiemQuet[chiSoMang].doSang, diaChiAnh );
               
               if( saiLam > 0 ) {
                  x--;
                  saiLam -= (cachY << 1);
               }
               saiLam -= cachX << 1;
               chiSoMang++;
               y++;
               
            }
            
         }
      }
   }
   
   return mangDiemQuet[chiSoThapNhat + (soLan >> 1)];
}

#pragma mark ---- Phép Tuyến
Vecto tinhPhapTuyenMatPhangToiUu( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem ) {
   
   Vecto phapTuyen;
   phapTuyen.x = 0.0f;
   phapTuyen.y = 0.0f;
   phapTuyen.z = 0.0f;
   
   if( x > beRongAnhBoLoc ) {
      printf( "CatNgang: tinhMatPhangToiUu: x ở ngoài phạm vi (%d > %d)\n", x, beRongAnhBoLoc );
      return phapTuyen;
   }
   else if( x < 0 ) {
      printf( "CatNgang: tinhMatPhangToiUu: x ở ngoài phạm vi (%d < 0)\n", x );
      return phapTuyen;
   }
   
   if( y > beCaoAnhBoLoc ) {
      printf( "CatNgang: tinhMatPhangToiUu: y ở ngoài phạm vi (%d > %d)\n", y, beCaoAnhBoLoc );
      return phapTuyen;
   }
   else if( y < 0 ) {
      printf( "CatNgang: tinhMatPhangToiUu: x ở ngoài phạm vi (%d < 0)\n", y );
      return phapTuyen;
   }
   
   // ---- tính cột và hàng quanh điểm
   short soCotDau = x - cachQuanhDiem;
   short soCotCuoi = x + cachQuanhDiem + 1;
   short soHangDau = y - cachQuanhDiem;
   short soHangCuoi = y + cachQuanhDiem + 1;
   
   // ---- không cho ra ngoài phạm vi ảnh
   if( soCotDau < 0 )
      soCotDau = 0;
   if( soCotCuoi >= beRongAnhBoLoc )
      soCotCuoi = beRongAnhBoLoc - 1;
   
   if( soHangDau < 0 )
      soHangDau = 0;
   if( soHangCuoi >= beCaoAnhBoLoc )
      soHangCuoi = beCaoAnhBoLoc - 1;
   
   // ---- tính ma trận
   float heSoDonViHoa_x = 1.0f/(soCotCuoi - soCotDau);  // trừ một cho t đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_y = 1.0f/(soHangCuoi - soHangDau);  // trừ một cho u đi qua toàn phạm vi từ 0 đến 1
   float heSoDonViHoa_z = 1.0f/255.0f;
   
   float maTranMatPhang[9] = {0.0f, 0.0f, 0.0f,  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
   float vectoGiai[3] = {0.0f, 0.0f, 0.0f};

   // ---- tính ma trận
   unsigned short soHang = soHangDau;
   while( soHang < soHangCuoi ) {
      
      float y = (float)(soHang - soHangDau)*heSoDonViHoa_y;
      
      unsigned short soCot = soCotDau;
      unsigned int diaChiAnh = (soHang*beRongAnhBoLoc + soCot) << 2;
      
      while( soCot < soCotCuoi ) {
         float x = (float)(soCot - soCotDau)*heSoDonViHoa_x;
         float z = anhBoLoc[diaChiAnh]*heSoDonViHoa_z;
         
         maTranMatPhang[0] += x*x;
         maTranMatPhang[1] += x*y;
         maTranMatPhang[2] -= x;
         
         maTranMatPhang[3] += y*x;
         maTranMatPhang[4] += y*y;
         maTranMatPhang[5] -= y;
         
         maTranMatPhang[6] -= x;
         maTranMatPhang[7] -= y;
         maTranMatPhang[8] += 1;
         
         vectoGiai[0] -= z*x;
         vectoGiai[1] -= z*y;
         vectoGiai[2] += z;
         
         diaChiAnh += 4;
         soCot++;
      }
      
      soHang++;
   }
   
   unsigned char mangThuTu[3] = {0, 1, 2};
   unsigned char coNghiem = khuMaTran( maTranMatPhang, 3, 3, vectoGiai, 3, 1, mangThuTu );
   
   if( coNghiem ) {
      tinhNghiem( maTranMatPhang, 3, 3, vectoGiai, 3, 1, mangThuTu );
      
      // ---- nghiệm: A, B, D  -> Ax + By + 1z – D = 0
      float nghiem[3];
      nghiem[0] =  vectoGiai[mangThuTu[0]]*(soCotCuoi - soCotDau);
      nghiem[1] =  vectoGiai[mangThuTu[1]]*(soHangCuoi - soHangDau);
      nghiem[2] =  vectoGiai[mangThuTu[2]]*255.0f;
      
      // ---- pháp tuyến
      phapTuyen.x = nghiem[0];
      phapTuyen.y = nghiem[1];
      phapTuyen.z = 1.0f;
      
      float doLon = sqrtf( phapTuyen.x*phapTuyen.x + phapTuyen.y*phapTuyen.y + phapTuyen.z*phapTuyen.z );
      if( doLon != 0.0f ) {
         phapTuyen.x = phapTuyen.x/doLon;
         phapTuyen.y = phapTuyen.y/doLon;
         phapTuyen.z = phapTuyen.z/doLon;
      }
   }
   else
      printf( "CatNgang: tinhMatPhangToiUu: SAI LẦM ma trận không có nghiệm\n" );
   
   return phapTuyen;
}

