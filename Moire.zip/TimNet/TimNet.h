/* TìmNét.h */


#pragma once

#include "../ToMauAnh/Diem.h"
#include "Bezier.h"
#include "Net.h"

#define kQUET_NGANG 0
#define kQUET_DOC   1

Diem diTheoDoiDuongVaChoDiemCuoi( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem *diem, unsigned char cao, Net *net, float buoc );

unsigned short timCacDiemThichThuNgang( Diem *mangDiemThichThu, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang );

unsigned short timCacDiemThichThuDoc( Diem *mangDiemThichThu, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot );

void quetVaTaoDanhSachDiemThichThuTuAnh( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, DiemGon **dauDanhSachDiem, DiemGon **cuoiDanhSachDiem, unsigned char soLanCatDoc, unsigned char soLanCatNgang );


unsigned short timCacNet( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char cach, Diem *mangDiemThichThu, unsigned short soLuongDiemThichThu, Net *mangNet );

Vecto tinhPhapTuyenMatPhangToiUu( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem );

