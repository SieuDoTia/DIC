/* TìmNét.h */


#pragma once

#include "../ToMauAnh/Diem.h"
#include "Bezier.h"
#include "Net.h"

#define kQUET_NGANG 0
#define kQUET_DOC   1

#define kRANH__NET_NOI_DOI_DIEN 1  // kết nối ranh đối diện
#define kRANH__NET_NOI_KE 2        // kết nối ranh kề
#define kRANH__NET_NOI_CUNG 3      // kết nối cùng ranh
#define kRANH__KHONG_KET_NOI 4     // kết nối cùng ranh

#define kKHONG_DEN_RANH 2

Diem diTheoDoiDuongVaChoDiemCuoi( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem *diem, unsigned char cao, Net *net, float buoc );

unsigned short timCacDiemThichThuNgang( Diem *mangDiemThichThu, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang );

unsigned short timCacDiemThichThuDoc( Diem *mangDiemThichThu, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot );

void quetVaTaoDanhSachDiemThichThuTuAnh( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, DiemGon **dauDanhSachDiem, DiemGon **cuoiDanhSachDiem, unsigned char soLanCatDoc, unsigned char soLanCatNgang );

unsigned char khuNet( DiemGon *danhSachDiem, unsigned int beRongAnh, unsigned int beCaoAnh, unsigned short cachGiuaCot, unsigned short cachGiuaHang, unsigned char *ranh );


unsigned short timCacNet( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char cach, Diem *mangDiemThichThu, unsigned short soLuongDiemThichThu, Net *mangNet );

Vecto tinhPhapTuyenMatPhangToiUu( unsigned char *anhBoLoc, unsigned int beRongAnhBoLoc, unsigned int beCaoAnhBoLoc, short x, short y, unsigned char cachQuanhDiem );

