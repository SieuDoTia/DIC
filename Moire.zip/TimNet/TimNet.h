/* TìmNét.h */


#pragma once

#include "../ToMauAnh/Diem.h"
#include "Net.h"

Diem diTheoDoiDuongVaChoDiemCuoi( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem *diem, unsigned char cao, Net *net, float buoc );

unsigned short timCacDiemThichThu( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem *mangDiemThichThu );

unsigned short timCacNet( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char cach, Diem *mangDiemThichThu, unsigned short soLuongDiemThichThu, Net *mangNet );
