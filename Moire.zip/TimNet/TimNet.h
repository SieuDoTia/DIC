/* TìmNét.h */


#pragma once

#include "../ToMauAnh/Diem.h"
#include "Net.h"


Diem diTheoDoiDuongVaChoDiemCuoi( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem *diem, unsigned char cao, Net *net, float buoc );

unsigned short timCacDiemThichThuNgang( Diem *mangDiemThichThu, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang );

unsigned short timCacDiemThichThuDoc( Diem *mangDiemThichThu, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot );

unsigned short timCacNet( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char cach, Diem *mangDiemThichThu, unsigned short soLuongDiemThichThu, Net *mangNet );
