/* Vectơ.h */

#pragma once

/* Vectơ */
typedef struct {
   float x;
   float y;
   float z;
} Vecto;
