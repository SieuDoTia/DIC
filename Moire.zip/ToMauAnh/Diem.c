//
//  Diem.c
//  
//
//  Created by 胡州 on 28/03/2561 BE.
//

#include <stdio.h>
#include <stdlib.h>
#include "Diem.h"
#include "../HangSo.h"
#include "../TimNet/Vecto.h"
#include "../TimNet/TimNet.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"


DiemGon *taoDanhSachDiemThichThu_quetNgang( DiemGon **dauDanhSachDiem, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soHang ) {
   
   // ---- không cho ra ngoài phạm vi
   if( soHang >= beCao )
      soHang = beCao - 1;
   
   // ---- tìm điểm thích thú ở hàng trên nhất của ảnh ----> CẦN GIẢI THUẬT MỚI, CÒN PHÁT TRIỂN
   unsigned int diaChiAnh = beRong*soHang << 2;
   
   // ---- tìm nên đặt chế độ sáng trước hay tối
   unsigned short soCot = 2;
   unsigned char doSangDau = anh[diaChiAnh];
   diaChiAnh += 4;
   unsigned char doSangHienTai = anh[diaChiAnh];
   diaChiAnh += 4;
   
   while( (soCot < beRong) && (doSangDau == doSangHienTai) ) {
      doSangHienTai = anh[diaChiAnh ];
      diaChiAnh += 4;
      soCot++;
   }
   
   unsigned char cheDoSang = kDUNG;
   if( doSangHienTai < doSangDau )
      cheDoSang = kSAI;
   else
      cheDoSang = kDUNG;
   
   unsigned short soLuongDiem = 0;  // không cần nhưng giúpbvbtìm sai lầm
   
   // ---- sáng nhất
   unsigned char sangNhat = 0;
   unsigned short soLuongSangNhat = 0;
   unsigned short soCotSangNhat = 0;
   
   // ---- tối nhất
   unsigned char toiNhat = 255;
   unsigned short soLuongToiNhat = 0;
   unsigned short soCotToiNhat = 0;
   
   DiemGon *diemHienTai = *dauDanhSachDiem;

   diaChiAnh = beRong*soHang << 2;
   soCot = 0;
   while( soCot < beRong ) {
      unsigned char doSang = anh[diaChiAnh];
      
      // ---- chế độ sáng
      if( cheDoSang ) {
         if( doSang > sangNhat ) {
            sangNhat = doSang;
            soLuongSangNhat = 1;
            soCotSangNhat = soCot;
         }
         else if( doSang == sangNhat ) {
            soLuongSangNhat++;
         }
         else if( sangNhat - doSang > 5 ) {
            // ---- tạo điểm mới
            DiemGon *diemMoi = malloc( sizeof( DiemGon ) );

            if( diemHienTai != NULL ) {
               diemHienTai->sau = diemMoi;
               diemMoi->truoc = diemHienTai;
            }
            else {
               diemMoi->truoc = NULL;
               *dauDanhSachDiem = diemMoi;
            }

            diemHienTai = diemMoi;
            soLuongDiem++;

            // ---- giữ thông tin điểm
            diemHienTai->x = soCotSangNhat + (soLuongSangNhat >> 1);
            diemHienTai->y = soHang;
            diemHienTai->doSang = sangNhat;
            diemHienTai->cucDoan = kDIEM_SANG;

            // ---- đổi chế độ sang tìm điểm tối
            cheDoSang = kDIEM_TOI;
            toiNhat = 255;
            soLuongToiNhat = 0;
         }
      }
      // ---- chế độ tối
      else {
         if( doSang < toiNhat ) {
            toiNhat = doSang;
            soLuongToiNhat = 1;
            soCotToiNhat = soCot;
         }
         else if( doSang == toiNhat ) {
            soLuongToiNhat++;
         }
         else if( doSang - toiNhat > 10 ) {
            // ---- tạo điểm mới
            DiemGon *diemMoi = malloc( sizeof( DiemGon ) );

            if( diemHienTai != NULL ) {
               diemHienTai->sau = diemMoi;
               diemMoi->truoc = diemHienTai;
            }
            else {
               diemMoi->truoc = NULL;
               *dauDanhSachDiem = diemMoi;
            }

            diemHienTai = diemMoi;
            soLuongDiem++;

            // ---- giữ tông tin điểm
            diemHienTai->x = soCotToiNhat + (soLuongToiNhat >> 1);
            diemHienTai->y = soHang;
            diemHienTai->doSang = toiNhat;
            diemHienTai->cucDoan = kDIEM_TOI;

            // ---- đổi chế độ sang tìm điểm sang
            cheDoSang = kDIEM_SANG;
            sangNhat = 0;
            soLuongSangNhat = 0;
         }
         
      }
      
      soCot++;
      diaChiAnh += 4;
   }
   
   // ---- coi chừng có một gần ranh giới cuối
   diaChiAnh = (beRong*(soHang+1)-1) << 2;
   unsigned char doSangDiemAnhCuoi = anh[diaChiAnh];
   if( cheDoSang == kLOAI_CAO ) {
      if( soLuongSangNhat && (sangNhat > doSangDiemAnhCuoi) ) {
         // ---- tạo điểm mới
         DiemGon *diemMoi = malloc( sizeof( DiemGon ) );

         if( diemHienTai != NULL ) {
            diemHienTai->sau = diemMoi;
            diemMoi->truoc = diemHienTai;
         }
         else {
            diemMoi->truoc = NULL;
            *dauDanhSachDiem = diemMoi;
         }

         diemHienTai = diemMoi;
         soLuongDiem++;

         // ---- giữ tông tin điểm
         diemHienTai->x = soCotSangNhat + (soLuongSangNhat >> 1);
         diemHienTai->y = soHang;
         diemHienTai->doSang = sangNhat;
         diemHienTai->cucDoan = kDIEM_SANG;
      }
   }
   else {
      if( soLuongToiNhat && (toiNhat < doSangDiemAnhCuoi) ) {
         // ---- tạo điểm mới
         DiemGon *diemMoi = malloc( sizeof( DiemGon ) );

         if( diemHienTai != NULL ) {
            diemHienTai->sau = diemMoi;
            diemMoi->truoc = diemHienTai;
         }
         else {
            diemMoi->truoc = NULL;
            *dauDanhSachDiem = diemMoi;
         }

         diemHienTai = diemMoi;
         soLuongDiem++;

         // ---- giữ tông tin điểm
         diemHienTai->x = soCotToiNhat + (soLuongToiNhat >> 1);
         diemHienTai->y = soHang;
         diemHienTai->doSang = toiNhat;
         diemHienTai->cucDoan = kDIEM_TOI;
      }
   }
   
   // ---- kết thúc danh sách
   if( diemHienTai != NULL ) {
      diemHienTai->sau = NULL;
   }

   // ---- gởi điểm cuối
   return diemHienTai;
}

DiemGon *taoDanhSachDiemThichThu_quetDoc( DiemGon **dauDanhSachDiem, unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int soCot ) {

   // ---- không cho ra ngoài phạm vi
   if( soCot >= beRong )
      soCot = beRong - 1;
   
   // ---- tìm điểm thích thú ở hàng trên nhất của ảnh ----> CẦN GIẢI THUẬT MỚI, CÒN PHÁT TRIỂN
   unsigned int diaChiAnh = soCot << 2;
   
   // ---- tìm nên đặt chế độ sáng trước hay tối
   unsigned short soHang = 2;
   unsigned char doSangDau = anh[diaChiAnh];
   diaChiAnh += beRong << 2;
   unsigned char doSangHienTai = anh[diaChiAnh];
   diaChiAnh += beRong << 2;
   
   //   printf( "doSangDau %d doSangHienTai %d\n", doSangDau, doSangHienTai );
   while( (soHang < beCao) && (doSangDau == doSangHienTai) ) {
      doSangHienTai = anh[diaChiAnh ];
      diaChiAnh += beRong << 2;
      soHang++;
   }
   
   unsigned char cheDoSang = kDUNG;
   if( doSangHienTai < doSangDau )
      cheDoSang = kSAI;
   else
      cheDoSang = kDUNG;
   
   unsigned short soLuongDiem = 0;  // không cần nhưng giúpbvbtìm sai lầm
   
   // ---- sáng nhất
   unsigned char sangNhat = 0;
   unsigned short soLuongSangNhat = 0;
   unsigned short soHangSangNhat = 0;
   
   // ---- tối nhất
   unsigned char toiNhat = 255;
   unsigned short soLuongToiNhat = 0;
   unsigned short soHangToiNhat = 0;
   
   DiemGon *diemHienTai = *dauDanhSachDiem;
   
   diaChiAnh = soCot << 2;
   soHang = 0;
   while( soHang < beCao ) {
      unsigned char doSang = anh[diaChiAnh];
      
      // ---- chế độ sáng
      if( cheDoSang ) {
         if( doSang > sangNhat ) {
            sangNhat = doSang;
            soLuongSangNhat = 1;
            soHangSangNhat = soHang;
         }
         else if( doSang == sangNhat ) {
            soLuongSangNhat++;
         }
         else if( sangNhat - doSang > 5 ) {
            // ---- tạo điểm mới
            DiemGon *diemMoi = malloc( sizeof( DiemGon ) );

            if( diemHienTai != NULL ) {
               diemHienTai->sau = diemMoi;
               diemMoi->truoc = diemHienTai;
            }
            else {
               diemMoi->truoc = NULL;
               *dauDanhSachDiem = diemMoi;
            }

            diemHienTai = diemMoi;
            soLuongDiem++;
            
            // ---- giữ thông tin điểm
            diemHienTai->x = soCot;
            diemHienTai->y = soHangSangNhat + (soLuongSangNhat >> 1);
            diemHienTai->doSang = sangNhat;
            diemHienTai->cucDoan = kDIEM_SANG;
            
            // ---- đổi chế độ
            cheDoSang = kDIEM_TOI;
            toiNhat = 255;
            soLuongToiNhat = 0;
         }
      }
      // ---- chế độ tối
      else {
         if( doSang < toiNhat ) {
            toiNhat = doSang;
            soLuongToiNhat = 1;
            soHangToiNhat = soHang;
         }
         else if( doSang == toiNhat ) {
            soLuongToiNhat++;
         }
         else if( doSang - toiNhat > 10 ) {
            // ---- tạo điểm mới
            DiemGon *diemMoi = malloc( sizeof( DiemGon ) );

            if( diemHienTai != NULL ) {
               diemHienTai->sau = diemMoi;
               diemMoi->truoc = diemHienTai;
            }
            else {
               diemMoi->truoc = NULL;
               *dauDanhSachDiem = diemMoi;
            }

            diemHienTai = diemMoi;
            soLuongDiem++;
            
            // ---- giữ thông tin điểm
            diemHienTai->x = soCot;
            diemHienTai->y = soHangToiNhat + (soLuongToiNhat >> 1);
            diemHienTai->doSang = toiNhat;
            diemHienTai->cucDoan = kDIEM_TOI;
            
            // ---- đổi chế độ
            cheDoSang = kDIEM_SANG;
            sangNhat = 0;
            soLuongSangNhat = 0;
         }
         
      }
      
      soHang++;
      diaChiAnh += beRong << 2;
   }
   
   // ---- coi chừng có một gần ranh giới cuối
   diaChiAnh = (beRong*(beCao - 1) + soCot) << 2;  // điểm cuối cột
   unsigned char doSangDiemAnhCuoi = anh[diaChiAnh];
   if( cheDoSang == kLOAI_CAO ) {
      if( soLuongSangNhat && (sangNhat > doSangDiemAnhCuoi) ) {
         // ---- tạo điểm mới
         DiemGon *diemMoi = malloc( sizeof( DiemGon ) );

         if( diemHienTai != NULL ) {
            diemHienTai->sau = diemMoi;
            diemMoi->truoc = diemHienTai;
         }
         else {
            diemMoi->truoc = NULL;
            *dauDanhSachDiem = diemMoi;
         }

         diemHienTai = diemMoi;
         soLuongDiem++;
         
         // ---- giữ thông tin điểm
         diemHienTai->x = soCot;
         diemHienTai->y = soHangSangNhat + (soLuongSangNhat >> 1);
         diemHienTai->doSang = sangNhat;
         diemHienTai->cucDoan = kDIEM_SANG;
      }
   }
   else {
      if( soLuongToiNhat && (toiNhat < doSangDiemAnhCuoi) ) {
         // ---- tạo điểm mới
         DiemGon *diemMoi = malloc( sizeof( DiemGon ) );

         if( diemHienTai != NULL ) {
            diemHienTai->sau = diemMoi;
            diemMoi->truoc = diemHienTai;
         }
         else {
            diemMoi->truoc = NULL;
            *dauDanhSachDiem = diemMoi;
         }

         diemHienTai = diemMoi;
         soLuongDiem++;
         
         // ---- giữ thông tin điểm
         diemHienTai->x = soCot;
         diemHienTai->y = soHangToiNhat + (soLuongToiNhat >> 1);
         diemHienTai->doSang = toiNhat;
         diemHienTai->cucDoan = kDIEM_TOI;
      }
   }
   
   // ---- kết thúc danh sách
   if( diemHienTai != NULL )
      diemHienTai->sau = NULL;
   
//   printf( "Diem: taoDanhSachDoc: soLuongDiem %d  diemHienTai %p\n", soLuongDiem, diemHienTai );
   // ---- gởi điểm cuối
   return diemHienTai;
}


#pragma mark ---- Chiếu Thông Tin Điểm
void chieuThongTinDiem( Diem diem, unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat,
                       unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned short x, unsigned short y, unsigned int mauDiem ) {
   
   // ---- nế điểm ở ngoài ảnh, về nhà sớm, không có gì để làm
   if( diem.x < 0 )
      return;
   else if( diem.x >= beRong )
      return;
   
   if( diem.y < 0 )
      return;
   else if( diem.y >= beCao )
      return;
   
   // ---- tính pháp tuyến
   Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anh, beRong, beCao, diem.x, diem.y, 20 );
 
   // ---- vẽ pháp tuyến - tính điểm đầu va điểm cuối để vẽ phép tuyến
   Diem diemDau;
   diemDau.x = diem.x + x;
   diemDau.y = diem.y + y;
   Diem diemCuoi;
   diemCuoi.x = diemDau.x + 50*phapTuyen.x;
   diemCuoi.y = diemDau.y + 50*phapTuyen.y;
   veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, mauDiem );

   // ---- vẽ vòng tròn
   // unsigned char *anh, unsigned int beRong, unsigned int beCao, short tamX, short tamY, short banKinh, unsigned int mau );
   veVongTron( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau.x, diemDau.y, 8, mauDiem );
   
   // ---- in thành phân pháp tuyến
   /*   char xauThongTin[256];
    sprintf( xauThongTin, "↑ %5.3f\n  %5.3f\n  %5.3f", phapTuyen.x, phapTuyen.y, phapTuyen.z );
    veSoCaiNho( xauThongTin, diemDau.x, diemDau.y + 8, anhXuat, beRongAnhXuat, beCaoAnhXuat );
    
    // ---- in thông tin về độ sáng
    unsigned char doSang;
    doSang = anh[(diem.x + diem.y*beRong) << 2];
    sprintf( xauThongTin, "光 %d\n", doSang );
    veSoCaiNho( xauThongTin, diemDau.x, diemDau.y + 16, anhXuat, beRongAnhXuat, beCaoAnhXuat ); */
}
