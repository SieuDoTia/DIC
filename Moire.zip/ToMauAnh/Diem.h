/*  Điểm.h */


#pragma once

/* Điểm */
typedef struct {
   int x;             // vị trí điểm
   int y;
   float x_DH;       // sau vị trí đơn vị hóa (bề rộng ảnh)
   float y_DH;       // sau vị trí đơn vị hóa (bề cao ảnh)
   char doc;         // dốc hướng X mặt độ sáng tại điểm trong ảnh
   float goc;
   float huongX;       // hướng đến điểm này từ điểm trước
   float huongY;       // hướng đến điểm này từ điểm trước
   unsigned char xuLyRoi;   // xử lý rồi, cho biết đã gặp điểm này rồi và nên bỏ qua nó
   unsigned char doSang;
   float cap;
   unsigned char loai;  // hai loại: sáng và tối
   //   float doLonDoc;
   //   float huongDoc;
} Diem;
