/*  TôMàuẢnh.c */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "../HangSo.h"
#include "../ChuNhat.h"
#include "Diem.h"
#include "../TimNet/Bezier.h"
#include "../TimNet/Net.h"
#include "../TimNet/TimNet.h"
#include "../TimNet/MaTran.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../VeVatThe/VeChuNhat.h"
#include "../VeVatThe/ChepAnh.h"
#include "ToTranDay.h"
#include "DanhSachMau.h"


#pragma mark ---- Tô Màu

typedef struct {
   char chiSo;
   char trai;
   char giua;
   char phai;
} GiaoDiemNet;

/* Tìm Đường */

void veNetVaSo( unsigned char *anhToMau, unsigned short beRong, unsigned short beCao, Net *mangNet, unsigned char soLuongNet, short dichX, short dichY );
void veKhungVaToaDo( unsigned char *anhToMau, unsigned short beRong, unsigned short beCao, ChuNhat khung, unsigned short cachNet );
void veNetCap( float *anhFloat, unsigned short beRong, unsigned short beCao, Net *mangNet, unsigned char soLuongNet );
void veThanhMau( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned short x, unsigned short y );

unsigned int mauChoSoThuc( float so );

char *xauChoSo( float cap );

// ----
void rutDiemTuDanhSach( DiemGon **dauDanhSachDiem, DiemGon **diemHienTai );
DiemGon *timDiemTiep( DiemGon **dauDanhSachDiem, unsigned int cachXaToiDaBinh );
ChuNhat tinhChuNhatChoNet( DiemGon *danhSachDiem );

void timCapChoNetXungQuanhNet( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned int beRong, unsigned int beCao,
                              Net *mangNet, unsigned char soLuongNet, short tamPhatTia_x, short tamPhatTia_y, Diem gocAnh, unsigned char capCao, unsigned char huongTimNet );

//void chonHuongDi( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem diemThichThu, short *huongX, short *huongY, unsigned char cachXa );

void toAnh( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anh, unsigned int beRong, unsigned int beCao,
           Net *mangNet, unsigned char soLuongNet, Diem gocAnh, unsigned char chiSoCapCaoNhat, unsigned char huongToMau );

#define kSO_LAN__CAT_NGANG 15
#define kSO_LAN__CAT_DOC   30
#define kSO_LUONG_DIEM_QUET_TOI_DA   32    // số lượng điểm tối đa được kiếm trong

#define kCACH_XA__PHAP_TUYEN 15
#define kGIOI_HAN__PHAP_TUYEN 0.93f

#define kSO_LUONG__NET_TOI_DA 32

#define kANH_DIEM_THICH_THU 0
#define kANH_PHAN_TICH_NET  1
#define kANH_TO_MAU         2


// ---- hướng để tìm nét cấp kề tiếp
#define kHUONG__TRAI       0x01
#define kHUONG__TRAI_DUOI  0x02
#define kHUONG__DUOI       0x04
#define kHUONG__PHAI_DUOI  0x08
#define kHUONG__PHAI       0x10
#define kHUONG__PHAI_TREN  0x20
#define kHUONG__TREN       0x40
#define kHUONG__TRAI_TREN  0x80
#define kHUONG__HET        0xff

unsigned char *toMauAnh( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhXuat, unsigned int *beCaoAnhXuat ) {
   
   *beRongAnhXuat = beRong + kLE_TRAI__ANH_TO + kLE_PHAI__ANH_TO;
   *beCaoAnhXuat = (beCao*3) + (kLE_TREN__ANH_TO << 2);
   
   printf( "  toMauAnh: anh  %d x %d   anhXuat %d x %d\n", beRong, beCao, *beRongAnhXuat, *beCaoAnhXuat );
   Diem mangGocAnh[3];

   // ==== ảnh để tô màu
   unsigned char *anhToMau = malloc( beRong * beCao << 2 );
   
   float *anhGiupToMau = malloc( beRong * beCao * sizeof(float) );
   
   // ---- ảnh xuất, có khung, số nét, và tọa độ
   unsigned char *anhXuat = malloc( *beRongAnhXuat * *beCaoAnhXuat << 2 );
   
   if( (anhToMau != NULL) && (anhGiupToMau != NULL) && (anhXuat != NULL) ) {
      // ---- xóa ảnh tô
      unsigned int diaChiAnh = 0;
      while( diaChiAnh < (beRong*beCao << 2) ) {
         anhToMau[diaChiAnh] = 255;
         anhToMau[diaChiAnh+1] = 255;
         anhToMau[diaChiAnh+2] = 0;
         anhToMau[diaChiAnh+3] = 255;
         diaChiAnh += 4;
      }
      
      // ---- xóa ảnh giúp tô màu
      diaChiAnh = 0;
      while( diaChiAnh < beRong*beCao ) {
         anhGiupToMau[diaChiAnh] = -1.0f;
         diaChiAnh++;
      }
      
      // ---- xóa ảnh xuất
      diaChiAnh = 0;
      while( diaChiAnh < (*beRongAnhXuat * *beCaoAnhXuat << 2) ) {
         anhXuat[diaChiAnh] = 255;
         anhXuat[diaChiAnh+1] = 255;
         anhXuat[diaChiAnh+2] = 255;
         anhXuat[diaChiAnh+3] = 255;
         diaChiAnh += 4;
      }
      
      // ==== chuẩn bị quét ngang và dộc để kiếm điểm thích thú (gíá trị cực đoạn)
      unsigned short buocCot = beRong/(kSO_LAN__CAT_DOC - 1);
      unsigned short buocHang = beCao/(kSO_LAN__CAT_NGANG - 1);
      
      DiemGon *dauDanhSachDiem = NULL;
      DiemGon *cuoiDanhSachDiem = NULL;

      // ==== tìm các điểm
      quetVaTaoDanhSachDiemThichThuTuAnh( anh, beRong, beCao, &dauDanhSachDiem, &cuoiDanhSachDiem, kSO_LAN__CAT_DOC, kSO_LAN__CAT_NGANG );
      
      // ---- vẽ điểm từ quét trên sơ đồ
      mangGocAnh[kANH_DIEM_THICH_THU].x = kLE_TRAI__ANH_TO;
      mangGocAnh[kANH_DIEM_THICH_THU].y = kLE_DUOI__ANH_TO*3 + (beCao << 1);

      unsigned short soLuongDiemTot = 0;
      unsigned short soLuongDiem = 0;
      DiemGon *diemHienTai = dauDanhSachDiem;
      while( diemHienTai != NULL ) {
         
         // ---- tính pháp tuyến
         Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anh, beRong, beCao, diemHienTai->x, diemHienTai->y, kCACH_XA__PHAP_TUYEN );
         
         soLuongDiem++;
         if( phapTuyen.z > kGIOI_HAN__PHAP_TUYEN )
            soLuongDiemTot++;
         
         // ---- chọn màu
         unsigned int mauDiem;
         if( diemHienTai->cucDoan == kDIEM_SANG )
            mauDiem = 0x0000ffff;
         else
            mauDiem = 0xff0000ff;
         
         // ---- vẽ pháp tuyến - tính điểm đầu va điểm cuối để vẽ phép tuyến
         Diem diemDau;
         diemDau.x = diemHienTai->x + mangGocAnh[kANH_DIEM_THICH_THU].x;
         diemDau.y = diemHienTai->y + mangGocAnh[kANH_DIEM_THICH_THU].y;
         Diem diemCuoi;
         diemCuoi.x = diemDau.x + 50*phapTuyen.x;
         diemCuoi.y = diemDau.y + 50*phapTuyen.y;
         veDuong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau, diemCuoi, mauDiem );
         
         short x = diemHienTai->x + mangGocAnh[kANH_DIEM_THICH_THU].x;
         short y = diemHienTai->y + mangGocAnh[kANH_DIEM_THICH_THU].y;
         veVongTron( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, x, y, 7, mauDiem );
         
         diemHienTai = diemHienTai->sau;
      }
 
     // ==== khử điểm hết điểm pháp tuyến < kGIOI_HAN__PHAP_TUYEN
      soLuongDiem = 0;
      soLuongDiemTot = 0;
      diemHienTai = dauDanhSachDiem;
      while( diemHienTai != NULL ) {
         // ---- tính pháp tuyến
         Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anh, beRong, beCao, diemHienTai->x, diemHienTai->y, kCACH_XA__PHAP_TUYEN );

         // ---- bỏ
         if( phapTuyen.z < kGIOI_HAN__PHAP_TUYEN )
            rutDiemTuDanhSach( &dauDanhSachDiem, &diemHienTai );
         else
            diemHienTai = diemHienTai->sau;
         
         soLuongDiem++;
      }

      // ---- vẽ điểm từ quét trên sơ đồ
      mangGocAnh[kANH_PHAN_TICH_NET].x = kLE_TRAI__ANH_TO;
      mangGocAnh[kANH_PHAN_TICH_NET].y = (kLE_DUOI__ANH_TO << 1) + beCao;

      soLuongDiem = 0;
      diemHienTai = dauDanhSachDiem;
      while( diemHienTai != NULL ) {

         // ---- tính pháp tuyến
         Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anh, beRong, beCao, diemHienTai->x, diemHienTai->y, kCACH_XA__PHAP_TUYEN );

         soLuongDiem++;
         if( phapTuyen.z > kGIOI_HAN__PHAP_TUYEN )
            soLuongDiemTot++;
         
         // ---- chọn màu
         unsigned int mauDiem;
         if( diemHienTai->cucDoan == kDIEM_SANG )
            mauDiem = 0x0000ffff;
         else
            mauDiem = 0xff0000ff;
         
         // ---- vẽ pháp tuyến - tính điểm đầu va điểm cuối để vẽ phép tuyến
         Diem diemDau;
         diemDau.x = diemHienTai->x + mangGocAnh[kANH_PHAN_TICH_NET].x;
         diemDau.y = diemHienTai->y + mangGocAnh[kANH_PHAN_TICH_NET].y;
         Diem diemCuoi;
         diemCuoi.x = diemDau.x + 50*phapTuyen.x;
         diemCuoi.y = diemDau.y + 50*phapTuyen.y;
         veDuong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau, diemCuoi, mauDiem );
         
         short x = diemHienTai->x + mangGocAnh[kANH_PHAN_TICH_NET].x;
         short y = diemHienTai->y + mangGocAnh[kANH_PHAN_TICH_NET].y;
         veVongTron( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, x, y, 7, mauDiem );
         
         diemHienTai = diemHienTai->sau;
      }

      // ==== kết nối điểm - tìm nét
      unsigned int cachXaToiDa = buocHang + buocCot;
      unsigned int cachXaToiDaBinh = cachXaToiDa * cachXaToiDa;
      
      // ----
      Net *mangNet = malloc( sizeof( Net )*kSO_LUONG__NET_TOI_DA );
      DiemGon *dauDanhSachDiemMoCoi = NULL;
      DiemGon *cuoiDanhSachDiemMoCoi = NULL;

      unsigned char chiSoTimNet = 0;
      
      while( (chiSoTimNet < kSO_LUONG__NET_TOI_DA) && (dauDanhSachDiem != NULL) ) {

         DiemGon *diemMoCoi = NULL; //
         mangNet[chiSoTimNet].mangDiem = timDiemTiep( &dauDanhSachDiem, cachXaToiDaBinh << 1 );
         
         // ----- chỉ vẽ nét nếu có nét để vẽ
         if( mangNet[chiSoTimNet].mangDiem != NULL ) {

            mangNet[chiSoTimNet].bo = khuNet( mangNet[chiSoTimNet].mangDiem, beRong, beCao, buocCot, buocHang, &(mangNet[chiSoTimNet].ranh) );
//            printf( " mangNet[chiSoTimNet].bo %d\n", mangNet[chiSoTimNet].bo );
            
            if( !mangNet[chiSoTimNet].bo ) {

               // ---- giữ cực đọan nét
               mangNet[chiSoTimNet].cucDoan = mangNet[chiSoTimNet].mangDiem->cucDoan;
               
               diemHienTai = mangNet[chiSoTimNet].mangDiem;
               if( diemHienTai->sau == NULL ) {
                  printf( "ToMauAnh: diemMoCoi (%d; %d)\n", diemHienTai->x, diemHienTai->y );
                  short x = diemHienTai->x + mangGocAnh[kANH_PHAN_TICH_NET].x;
                  short y = diemHienTai->y + mangGocAnh[kANH_PHAN_TICH_NET].y;
                  veVongTron( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, x, y, 15, 0x00ff40ff );
                  char xauSoDiem[256];
                  sprintf( xauSoDiem, "%d %d", chiSoTimNet, diemHienTai->chiSo );
                  veSoCaiNho( xauSoDiem, x + 8, y, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );
               }
               
               // ---- chọn màu nét tùy kiểu nét kết nối ranh ảnh
               unsigned int mauNet;
               // ---- kết nối đối diện
               if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_DOI_DIEN__NGANG )
                  mauNet = 0x800080ff;
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_DOI_DIEN__DOC )
                  mauNet = 0x800080ff;
               // ---- kết nối kề
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_KE__TRAI_DUOI )
                  mauNet = 0xff0000ff;
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_KE__TRAI_TREN )
                  mauNet = 0xff0000ff;
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_KE__PHAI_DUOI )
                  mauNet = 0xff0000ff;
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_KE__PHAI_TREN )
                  mauNet = 0xff0000ff;
               // ---- kết nối cùng
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_CUNG__TRAI )
                  mauNet = 0x00ff00ff;
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_CUNG__PHAI )
                  mauNet = 0x00ff00ff;
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_CUNG__DUOI )
                  mauNet = 0x00ff00ff;
               else if( mangNet[chiSoTimNet].ranh == kRANH__NET_NOI_CUNG__TREN )
                  mauNet = 0x00ff00ff;
               // ---- không kết nối
               else if( mangNet[chiSoTimNet].ranh == kRANH__KHONG_KET_NOI )
                  mauNet = 0x0080ffff;
               else
                  mauNet = 0x7f7f7fff;

               while( diemHienTai->sau != NULL ) {
                  
                  Diem diemDau;
                  diemDau.x = diemHienTai->x + mangGocAnh[kANH_PHAN_TICH_NET].x;
                  diemDau.y = diemHienTai->y + mangGocAnh[kANH_PHAN_TICH_NET].y;
                  Diem diemCuoi;
                  diemCuoi.x = diemHienTai->sau->x + mangGocAnh[kANH_PHAN_TICH_NET].x;
                  diemCuoi.y = diemHienTai->sau->y + mangGocAnh[kANH_PHAN_TICH_NET].y;
                  //         printf( "%d %d --> %d %d\n", diemDau.x, diemDau.y, diemCuoi.x, diemCuoi.y );
                  veDuong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau, diemCuoi, mauNet );
                  
                  // ---- vẽ điểm khởi đầu nét
                  if( diemHienTai->chiSo == 0 )
                     veVongTron( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau.x, diemDau.y, 10, 0x804080ff );
                  
                  short x = (diemDau.x + diemCuoi.x) >> 1;
                  short y = (diemDau.y + diemCuoi.y) >> 1;
                  char xauSoDiem[256];
                  sprintf( xauSoDiem, "%d %d↔︎%d", chiSoTimNet, diemHienTai->chiSo, diemHienTai->sau->chiSo );
                  veSoCaiNho( xauSoDiem, x, y, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );
                  
                  diemHienTai = diemHienTai->sau;
               }
               
               // ---- nếu nét không kết nối (vòng tròn)
               if( mangNet[chiSoTimNet].ranh == kRANH__KHONG_KET_NOI ) {
                  Diem diemDau;
                  diemDau.x = diemHienTai->x + mangGocAnh[kANH_PHAN_TICH_NET].x;
                  diemDau.y = diemHienTai->y + mangGocAnh[kANH_PHAN_TICH_NET].y;
                  Diem diemCuoi;
                  diemCuoi.x = mangNet[chiSoTimNet].mangDiem->x + mangGocAnh[kANH_PHAN_TICH_NET].x;
                  diemCuoi.y = mangNet[chiSoTimNet].mangDiem->y + mangGocAnh[kANH_PHAN_TICH_NET].y;
                  //         printf( "%d %d --> %d %d\n", diemDau.x, diemDau.y, diemCuoi.x, diemCuoi.y );
                  veDuong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau, diemCuoi, mauNet );
               }

               // ---- tính chữ nhật
               mangNet[chiSoTimNet].chuNhat = tinhChuNhatChoNet( mangNet[chiSoTimNet].mangDiem );

               // ---- tính thông về chữ nhật
               ChuNhat chuNhatNet = mangNet[chiSoTimNet].chuNhat;
               mangNet[chiSoTimNet].dienTichChuNhat = (chuNhatNet.phai - chuNhatNet.trai)*(chuNhatNet.tren - chuNhatNet.duoi);
               mangNet[chiSoTimNet].tamChuNhatX = chuNhatNet.trai + ((chuNhatNet.phai - chuNhatNet.trai) >> 1);
               mangNet[chiSoTimNet].tamChuNhatY = chuNhatNet.duoi + ((chuNhatNet.tren - chuNhatNet.duoi) >> 1);
               
               // ---- vẽ chữ nhật
               chuNhatNet.trai += mangGocAnh[kANH_PHAN_TICH_NET].x;
               chuNhatNet.phai += mangGocAnh[kANH_PHAN_TICH_NET].x;
               chuNhatNet.duoi += mangGocAnh[kANH_PHAN_TICH_NET].y;
               chuNhatNet.tren += mangGocAnh[kANH_PHAN_TICH_NET].y;
               veChuNhat( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, chuNhatNet, 0x10101010 );
               
               veSoThapPhan( mangNet[chiSoTimNet].chuNhat.trai, chuNhatNet.trai, (chuNhatNet.tren + chuNhatNet.duoi) >> 1, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );
               veSoThapPhan( mangNet[chiSoTimNet].chuNhat.phai, chuNhatNet.phai, (chuNhatNet.tren + chuNhatNet.duoi) >> 1, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );
               veSoThapPhan( mangNet[chiSoTimNet].chuNhat.duoi, (chuNhatNet.trai + chuNhatNet.phai) >> 1, chuNhatNet.duoi, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );
               veSoThapPhan( mangNet[chiSoTimNet].chuNhat.tren, (chuNhatNet.trai + chuNhatNet.phai) >> 1, chuNhatNet.tren, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );

               
               // ---- vẽ trung tâm chữ nhật
               Diem diemDau;
               Diem diemCuoi;
               diemDau.x = mangNet[chiSoTimNet].tamChuNhatX + mangGocAnh[kANH_PHAN_TICH_NET].x - 10;
               diemDau.y = mangNet[chiSoTimNet].tamChuNhatY + mangGocAnh[kANH_PHAN_TICH_NET].y - 10;
               diemCuoi.x = mangNet[chiSoTimNet].tamChuNhatX + mangGocAnh[kANH_PHAN_TICH_NET].x + 10;
               diemCuoi.y = mangNet[chiSoTimNet].tamChuNhatY + mangGocAnh[kANH_PHAN_TICH_NET].y + 10;
               veDuong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau, diemCuoi, 0x0000ffff );
               
               diemDau.x += 20;
               diemCuoi.x -= 20;
               veDuong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau, diemCuoi, 0x0000ffff );

               printf( "ToMauAnh: %d  ranh %d  dienTich %d  CH %d %d %d %d  tam (%d; %d)\n", chiSoTimNet, mangNet[chiSoTimNet].ranh, mangNet[chiSoTimNet].dienTichChuNhat,
                      chuNhatNet.trai, chuNhatNet.phai, chuNhatNet.duoi, chuNhatNet.tren,
                      mangNet[chiSoTimNet].tamChuNhatX, mangNet[chiSoTimNet].tamChuNhatY  );
            }
            chiSoTimNet++;
         }

      }

      // ==== sắp xếp nét
      //      Cần tìm nét cực đoạn, cao/thấp nhất, thứ tự tìm. Nó là nét cấp cao nhất
      //        1. Nét vòng tròn, nhỏ nhất
      //        2. Nét điểm đầu và cuồi trên cùng ranh ảnh, nhỏ nhất
      //        3. Nét điểm đầu và cuồi trên kề ranh ảnh, nhỏ nhất
      //        4. Nét điểm đầu và cuồi trên ranh ảnh đối diện
      //      Sau kiếm nét cực đoạn, tìm những nét kề tiếp
      
      // ---- tìm nét cấp cao nhất
      unsigned char soLuongNet = chiSoTimNet;
      
      if( soLuongNet ) {
         unsigned int dienTichChoNetCaoNhat = beRong*beCao;
         unsigned int ranhCaoNhat = 0;
         unsigned chiSoCaoNhat = 0;
         
         unsigned char chiSoNet = 0;
         while( chiSoNet < soLuongNet ) {
            // ---- xem nét bị mbỏ chưa
            if( !mangNet[chiSoNet].bo ) {
               unsigned char ranh = mangNet[chiSoNet].ranh;
               //            printf( "%d  ranh %d  ranhCaoNhat %d\n", chiSoNet, ranh, ranhCaoNhat );
               // ----
               if( ranh > ranhCaoNhat ) {
                  chiSoCaoNhat = chiSoNet;
                  ranhCaoNhat = mangNet[chiSoNet].ranh;
                  dienTichChoNetCaoNhat = mangNet[chiSoNet].dienTichChuNhat;
               }
               // ---- nếu hai nét có ranh bằng nhau, chọn nét có diện tích nhỏ nhất
               else if( ranh == ranhCaoNhat ) {
                  if( mangNet[chiSoNet].dienTichChuNhat < dienTichChoNetCaoNhat ) {
                     chiSoCaoNhat = chiSoNet;
                     ranhCaoNhat = mangNet[chiSoNet].ranh;
                     dienTichChoNetCaoNhat = mangNet[chiSoNet].dienTichChuNhat;
                  }
               }
            }
            
            chiSoNet++;
         }
         
         // ==== đặt cấp cho hết nét còn lại
         printf( "ToAnh: --- Nét cấp cao %d   rang %d\n", chiSoCaoNhat, mangNet[chiSoCaoNhat].ranh );
         mangNet[chiSoCaoNhat].cap = 10;
         mangNet[chiSoCaoNhat].xuLyRoi = kDUNG;
         short tamPhatTia_x = mangNet[chiSoCaoNhat].tamChuNhatX;
         short tamPhatTia_y = mangNet[chiSoCaoNhat].tamChuNhatY;
         
         // ---- nét cao là vòng tròn hay kết nối hai ranh kề nhau - xem đến bộn góc ảnh
         unsigned char huongTimNet;
         if( mangNet[chiSoCaoNhat].ranh == kRANH__KHONG_KET_NOI )
            huongTimNet = kHUONG__HET;
         // ----
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_CUNG__TRAI )
            huongTimNet = kHUONG__HET & ~kHUONG__TRAI;
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_CUNG__PHAI )
            huongTimNet = kHUONG__HET & ~kHUONG__PHAI;
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_CUNG__DUOI )
            huongTimNet = kHUONG__HET & ~kHUONG__DUOI;
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_CUNG__TREN )
            huongTimNet = kHUONG__HET & ~kHUONG__TREN;
         // ----
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_KE__TRAI_DUOI )
            huongTimNet = kHUONG__HET & ~kHUONG__TRAI_DUOI;
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_KE__TRAI_TREN )
            huongTimNet = kHUONG__HET & ~kHUONG__TRAI_TREN;
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_KE__PHAI_DUOI )
            huongTimNet = kHUONG__HET & ~kHUONG__PHAI_DUOI;
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_KE__PHAI_TREN )
            huongTimNet = kHUONG__HET & ~kHUONG__PHAI_TREN;
         // ----
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_DOI_DIEN__NGANG )
            huongTimNet = kHUONG__DUOI | kHUONG__TREN;
         else if(  mangNet[chiSoCaoNhat].ranh == kRANH__NET_NOI_DOI_DIEN__DOC )
            huongTimNet = kHUONG__TRAI | kHUONG__PHAI;
         
         timCapChoNetXungQuanhNet( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, beRong, beCao, mangNet, soLuongNet, tamPhatTia_x, tamPhatTia_y, mangGocAnh[kANH_PHAN_TICH_NET], 10, huongTimNet );
         
         // ==== vẽ ảnh tô màu
         mangGocAnh[kANH_TO_MAU].x = kLE_TRAI__ANH_TO;
         mangGocAnh[kANH_TO_MAU].y = kLE_DUOI__ANH_TO;
         toAnh( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, anh, beRong, beCao, mangNet, soLuongNet, mangGocAnh[kANH_TO_MAU], chiSoCaoNhat, huongTimNet );
      }
      else {
         printf( "Tìm nét bị thất bại!\n" );
      }

      // ==== vẽ khung quanh ảnh kết qủa
      ChuNhat khung;
      khung.trai = mangGocAnh[kANH_DIEM_THICH_THU].x - 1;
      khung.phai = mangGocAnh[kANH_DIEM_THICH_THU].x + beRong;
      khung.duoi = mangGocAnh[kANH_DIEM_THICH_THU].y - 1;
      khung.tren = mangGocAnh[kANH_DIEM_THICH_THU].y + beCao;
      
      printf( "  toMauAnh: veKhungVaToaDo\n" );
      veKhungVaToaDo( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, khung, 200 );

      // ---- vẽ khung quanh ảnh nghiên cứu

//      khung.trai = mangGocAnh[kANH_PHAN_TICH_NET].x;
//      khung.phai = mangGocAnh[kANH_PHAN_TICH_NET].x + beRong;
      khung.duoi = mangGocAnh[kANH_PHAN_TICH_NET].y - 1;
      khung.tren = mangGocAnh[kANH_PHAN_TICH_NET].y + beCao;

      veKhungVaToaDo( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, khung, 200 );
      

      //      khung.trai = mangGocAnh[kANH_PHAN_TICH_NET].x;
      //      khung.phai = mangGocAnh[kANH_PHAN_TICH_NET].x + beRong;
      khung.duoi = mangGocAnh[kANH_TO_MAU].y - 1;
      khung.tren = mangGocAnh[kANH_TO_MAU].y + beCao;
      
      veKhungVaToaDo( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, khung, 200 );
      
      // ---- vẽ thanh màu
      veThanhMau( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, kLE_TRAI__ANH_TO - 100, kLE_DUOI__ANH_TO + 200 );
         /*
      
      if( soLuongDiemThichThu ) {
         Net *mangNet  = malloc( 512*sizeof( Net ) );
         unsigned short soLuongNet = timCacNet( anh, beRong, beCao, 10, mangDiemThichThu, soLuongDiemThichThu, mangNet );
         
         printf( "  toMauAnh: soLuongNet %d \n", soLuongNet );
         // ---- vẽ nét cập trong giúp tô màu
         veNetCap( anhGiupToMau, beRong, beCao, mangNet, soLuongNet );
         
         // ---- tô màu
         printf( "  toMauAnh: toMau\n" );
         toGiuaNet( anh, anhToMau, anhGiupToMau, beRong, beCao );
         
         // ---- chép vào ảnh xuất
         printf( "  toMauAnh: chepAnh\n" );
         chepAnhVaoAnh( anhToMau, beRong, beCao, anhXuat, *beRongXuat, *beCaoXuat, kLE_TRAI__ANH_TO, kLE_DUOI__ANH_TO );
         
         // ---- vẽ nét trắng và số
         printf( "  toMauAnh: veNet\n" );
         veNetVaSo( anhXuat, *beRongXuat, *beCaoXuat, mangNet, soLuongNet, kLE_TRAI__ANH_TO, kLE_DUOI__ANH_TO );
         
         // ---- vẽ thanh màu
         veThanhMau( anhXuat, *beRongXuat, *beCaoXuat, kLE_TRAI__ANH_TO - 100, kLE_DUOI__ANH_TO + 200 );
         
         // ---- vẽ khung quanh ảnh
         ChuNhat khung;
         khung.trai = kLE_TRAI__ANH_TO;
         khung.phai = *beRongXuat - 1 - kLE_PHAI__ANH_TO;
         khung.duoi = kLE_DUOI__ANH_TO;
         khung.tren = *beCaoXuat - 1 - kLE_TREN__ANH_TO;
         
         printf( "  toMauAnh: veKhungVaToaDo\n" );
         veKhungVaToaDo( anhXuat, *beRongXuat, *beCaoXuat, khung, 200 );
         //      printf( "toMauAnh: xong\n" );
         free( anhGiupToMau );
         free( anhToMau );
         free( mangDiemThichThu );
      }
      else {
         printf( "  toMauAnh: không thể tìm nét để vẽ ảnh\n" );
         free( mangDiemThichThu );
         exit(0);
      }
      */

   }
   else {
      printf( "TôMàuẢnh: vấn đề tạo ảnh tô màu\n" );
      exit(0);
   }
   
   return anhXuat;
}

/*
void veNetVaSo( unsigned char *anhToMau, unsigned short beRong, unsigned short beCao, Net *mangNet, unsigned char soLuongNet, short dichX, short dichY ) {
   
   unsigned char chiSoNet = 0;
   while( chiSoNet < soLuongNet ) {
      
      if( mangNet[chiSoNet].docTrungBinh < 5.0f ) {
         // ---- vẽ nét
         unsigned char chiSoDiem = 1;
         unsigned short soLuongDiem = mangNet[chiSoNet].soLuongDiem;
         while( chiSoDiem < soLuongDiem ) {
            Diem diem0 = mangNet[chiSoNet].mangDiem[chiSoDiem];
            Diem diem1 = mangNet[chiSoNet].mangDiem[chiSoDiem-1];
            diem0.x += dichX;
            diem0.y += dichY;
            diem1.x += dichX;
            diem1.y += dichY;
            veDuong( anhToMau, beRong, beCao, diem0, diem1, 0xff );
            chiSoDiem++;
         }
         
         // --- vẽ số cấp của nét
         short x = mangNet[chiSoNet].mangDiem[0].x - 24 + dichX;
         short y = mangNet[chiSoNet].mangDiem[0].y + 20 + dichY;
         veSoCai( xauChoSo( mangNet[chiSoNet].cap ), x, y, anhToMau, beRong, beCao );
      }
      
      chiSoNet++;
   }
}*/

void veKhungVaToaDo( unsigned char *anhToMau, unsigned short beRong, unsigned short beCao, ChuNhat khung, unsigned short cachNet ) {
   
   // ---- vẽ khung
   Diem netKhung0;
   Diem netKhung1;
   netKhung0.x = khung.trai;
   netKhung0.y = khung.duoi;
   netKhung1.x = khung.phai;
   netKhung1.y = khung.duoi;
   veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
   netKhung0.y = khung.tren;
   netKhung1.y = khung.tren;
   veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
   
   netKhung0.x = khung.trai;
   netKhung0.y = khung.duoi;
   netKhung1.x = khung.trai;
   netKhung1.y = khung.tren;
   veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
   netKhung0.x = khung.phai;
   netKhung1.x = khung.phai;
   veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
   
   // ---- vẽ nét tọa độ ở trên
   netKhung0.y = khung.tren - 20;
   netKhung1.y = khung.tren;
   netKhung0.x = khung.trai;
   netKhung1.x = khung.trai;
   
   while( netKhung0.x < khung.phai ) {
      veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
      netKhung0.x += cachNet;
      netKhung1.x += cachNet;
   }
   
   // ---- vẽ nét tọa độ ở dưới
   netKhung0.y = khung.duoi;
   netKhung1.y = khung.duoi + 20;
   netKhung0.x = khung.trai;
   netKhung1.x = khung.trai;
   
   while( netKhung0.x < khung.phai ) {
      veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
      netKhung0.x += cachNet;
      netKhung1.x += cachNet;
   }
   
   // ---- vẽ nét tọa độ phía trái
   netKhung0.y = khung.duoi;
   netKhung1.y = khung.duoi;
   netKhung0.x = khung.trai;
   netKhung1.x = khung.trai + 20;
   
   while( netKhung0.y < khung.tren ) {
      veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
      netKhung0.y += cachNet;
      netKhung1.y += cachNet;
   }
   
   // ---- vẽ nét tọa độ phía phải
   netKhung0.y = khung.duoi;
   netKhung1.y = khung.duoi;
   netKhung0.x = khung.phai - 20;
   netKhung1.x = khung.phai;
   
   while( netKhung0.y < khung.tren ) {
      veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
      netKhung0.y += cachNet;
      netKhung1.y += cachNet;
   }
   
   // ----
   Diem diemNgang0;
   Diem diemNgang1;
   Diem diemDoc0;
   Diem diemDoc1;
   diemNgang0.y = khung.duoi + cachNet;
   diemNgang1.y = khung.duoi + cachNet;
   while( diemNgang0.y < khung.tren ) {
      diemNgang0.x = khung.trai + cachNet - 20;
      diemNgang1.x = khung.trai + cachNet + 20;
      
      diemDoc0.x = khung.trai + cachNet;
      diemDoc1.x = khung.trai + cachNet;
      diemDoc0.y = diemNgang0.y - 20;
      diemDoc1.y = diemNgang0.y + 20;
      while( diemDoc0.x < khung.phai ) {
         veDuong( anhToMau, beRong, beCao, diemNgang0, diemNgang1, 0xff );
         veDuong( anhToMau, beRong, beCao, diemDoc0, diemDoc1, 0xff );
         diemNgang0.x += cachNet;
         diemNgang1.x += cachNet;
         diemDoc0.x += cachNet;
         diemDoc1.x += cachNet;
      }
      
      diemNgang0.y += cachNet;
      diemNgang1.y += cachNet;
   }
}


/*
void veNetCap( float *anhFloat, unsigned short beRong, unsigned short beCao, Net *mangNet, unsigned char soLuongNet ) {
   
   unsigned char chiSoNet = 0;
   while( chiSoNet < soLuongNet ) {
      if( mangNet[chiSoNet].docTrungBinh < 5.0f ) {
         // ---- vẽ nét
         unsigned char chiSoDiem = 1;
         unsigned short soLuongDiem = mangNet[chiSoNet].soLuongDiem;
         while( chiSoDiem < soLuongDiem ) {
            //               veDuong( anhToMau, beRong, beCao, mangNetCao[chiSoNet].mangDiem[chiSoDiem], mangNetCao[chiSoNet].mangDiem[chiSoDiem-1],
            //                       mau );
            veDuongCap( anhFloat, beRong, beCao, mangNet[chiSoNet].mangDiem[chiSoDiem], mangNet[chiSoNet].mangDiem[chiSoDiem-1],
                       mangNet[chiSoNet].cap );
            chiSoDiem++;
         }
         
      }
      
      chiSoNet++;
   }
} */


#pragma mark ---- Vẽ Thanh Màu
#define kTHANH_MAU__BE_RONG    50
#define kTHANH_MAU__BE_CAO    500

void veThanhMau( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned short x, unsigned short y ) {
   
   if( (x + kTHANH_MAU__BE_RONG < beRong) && (y + kTHANH_MAU__BE_CAO < beCao) ) {
      
      // ---- thanh màu
      unsigned short soHang = 0;
      float toaDoMau = 0.0f;
      float buocMau = 10.0f/kTHANH_MAU__BE_CAO;
      
      while( soHang < kTHANH_MAU__BE_CAO ) {
         unsigned int mau = mauChoSoThuc( toaDoMau );
         unsigned int diaChiAnh = ((soHang + y)*beRong + x) << 2;
         unsigned short soCot = 0;
         while( soCot < kTHANH_MAU__BE_RONG ) {
            anh[diaChiAnh] = mau >> 24;
            anh[diaChiAnh+1] = mau >> 16;
            anh[diaChiAnh+2] = mau >> 8;
            soCot++;
            diaChiAnh += 4;
         }
         toaDoMau += buocMau;
         soHang++;
      }
   }
   
   // ---- số, dùng vị trí của điểm đầu nét làm vị trí cho số
   //      đụ đoán là nét bắt đầu ở cạnh phía trên
   unsigned short so_viTriX = x - 70;
   unsigned short so_viTriY = y - 8;
   
   veSoCai( xauChoSo( 0.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 1.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 2.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 3.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 4.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 5.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 6.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 7.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 8.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 9.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriX -= 16;
   so_viTriY += 50;
   veSoCai( xauChoSo( 10.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   
   // ---- khung
   Diem dauNet;
   Diem cuoiNet;
   // ---- trái
   dauNet.x = x;
   dauNet.y = y;
   cuoiNet.x = x;
   cuoiNet.y = y + kTHANH_MAU__BE_CAO;
   veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
   // ---- phải
   dauNet.x += kTHANH_MAU__BE_RONG;
   cuoiNet.x += kTHANH_MAU__BE_RONG;
   veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
   // ---- dưới
   dauNet.x = x;
   cuoiNet.y = y;
   veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
   // ---- trên
   dauNet.y += kTHANH_MAU__BE_CAO;
   cuoiNet.y += kTHANH_MAU__BE_CAO;
   veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
   
   
   // ---- nét
   
   dauNet.x = x - 15;
   dauNet.y = y;
   cuoiNet.x = x;
   cuoiNet.y = y;
   
   unsigned char soNet = 0;
   while( soNet < 11 ) {
      veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
      dauNet.y += 50;
      cuoiNet.y += 50;
      soNet++;
   }
   
}


unsigned int mauChoSoThuc( float so ) {
   
   unsigned char chiSoMau = floorf( so );
   float phanSo = (so - chiSoMau);
   chiSoMau <<= 2;

   unsigned char mauDo = danhSachMau[chiSoMau]*(1.0f - phanSo) + danhSachMau[chiSoMau+4]*phanSo;
   unsigned char mauLuc = danhSachMau[chiSoMau+1]*(1.0f - phanSo) + danhSachMau[chiSoMau+5]*phanSo;
   unsigned char mauXanh = danhSachMau[chiSoMau+2]*(1.0f - phanSo) + danhSachMau[chiSoMau+6]*phanSo;
   unsigned char mauDuc = danhSachMau[chiSoMau+3]*(1.0f - phanSo) + danhSachMau[chiSoMau+7]*phanSo;
   
   unsigned int mauSuyNoi = mauDo << 24 | mauLuc << 16 | mauXanh << 8 | mauDuc;
   
   return mauSuyNoi;
}


void rutDiemTuDanhSach( DiemGon **dauDanhSachDiem, DiemGon **diemHienTai ) {

   if( (*dauDanhSachDiem != NULL) && (*diemHienTai != NULL) ) {
      // ---- đầu danh sách điểm
      if( (*diemHienTai)->truoc == NULL ) {
         *dauDanhSachDiem = (*diemHienTai)->sau;
         DiemGon *diemSau = (*diemHienTai)->sau;
         free( *diemHienTai );
         *diemHienTai = (*diemHienTai)->sau;
      }
      // ---- cuối danh sách điểm
      else if( (*diemHienTai)->sau == NULL ) {
         DiemGon *diemTruoc = (*diemHienTai)->truoc;
         diemTruoc->sau = NULL;
         free( *diemHienTai );
         *diemHienTai = NULL;
      }
      // ---- giữa danh sách điểm
      else {
         DiemGon *diemTruoc = (*diemHienTai)->truoc;
         diemTruoc->sau = (*diemHienTai)->sau;
         free( *diemHienTai );
         *diemHienTai = diemTruoc->sau;
         (*diemHienTai)->truoc = diemTruoc;
      }
   }
}


DiemGon *timDiemTiep( DiemGon **dauDanhSachDiem, unsigned int cachXaToiDaBinh ) {

   if( *dauDanhSachDiem != NULL ) {
      unsigned short chiSoDiem = 0;
      
      // ---- rút điểm đề tiên trong mảng danh sách điểm
      DiemGon *diemDauNet = *dauDanhSachDiem;
      diemDauNet->chiSo = chiSoDiem;
      chiSoDiem++;

      if( (*dauDanhSachDiem)->sau != NULL ) {
         *dauDanhSachDiem = (*dauDanhSachDiem)->sau;
         (*dauDanhSachDiem)->truoc = NULL;
      }
      // ---- nếu danh sách điểm chỉ có một điểm
      else {
         *dauDanhSachDiem = NULL;
         return NULL;
      }

      DiemGon *diemCuoiNet = diemDauNet;
      diemCuoiNet->truoc = NULL;
      diemCuoiNet->sau = NULL;

      // ---- tìm cùng chế độ của điểm bắt đầu
      unsigned char cucDoanDangTim = diemDauNet->cucDoan;
      
      unsigned char soBuocCat = 0;
      
      unsigned char chuaXong = kDUNG;
      while( chuaXong ) {
         DiemGon *diemGanNhat = NULL;
         unsigned int cachXaCuaGanNhatBinh = cachXaToiDaBinh;
         
         DiemGon *diemHienTai = *dauDanhSachDiem;
         
         while( diemHienTai != NULL ) {

            // ---- chỉ kiểm tra điểm cùng cực đoạn
            if( diemHienTai->cucDoan == cucDoanDangTim ) {
               short x = diemHienTai->x;
               short y = diemHienTai->y;
               short cachX = diemCuoiNet->x - x;
               short cachY = diemCuoiNet->y - y;
               unsigned int cachBinh = cachX*cachX + cachY*cachY;
               
               if( cachBinh < cachXaCuaGanNhatBinh ) {
                  cachXaCuaGanNhatBinh = cachBinh;
                  diemGanNhat = diemHienTai;
               }
            }
            
            diemHienTai = diemHienTai->sau;
         }
         
         // ---- nếu có điểm, rút từ danh sách điểm và kết nối trong nét
         if( diemGanNhat != NULL ) {
            // ---- kết nối điểm trước và sau điểm gần nhất
            DiemGon *diemTruocGanNhat = diemGanNhat->truoc;
            DiemGon *diemSauGanNhat = diemGanNhat->sau;
            
//            printf( "   diemTruocGanNhat %p  diemSauGanNhat %p\n", diemTruocGanNhat, diemSauGanNhat );
            // NULL <---- *0 ----> NULL =====> dauDanhSach = NULL
            // NULL <---- *0 ----> *1   =====> dauDanhSach = *1
            // *0 <---- *1 ----> NULL  =====> *0 ----> NULL
            // *0 <---- *1 ----> *2 ====> *0 ----> *2
            
            // ---- xem nếu điểm gần nhất là điểm cuối cùng (không còn điểm nào nữa) trong danh sách
            if( (diemTruocGanNhat == NULL) && (diemSauGanNhat == NULL) )
               *dauDanhSachDiem = NULL;
            
            // ---- xem nếu điểm gần nhất là điểm đầu trong danh sách
            else if( (diemTruocGanNhat == NULL) && (diemSauGanNhat != NULL) ) {
               *dauDanhSachDiem = diemSauGanNhat;
               diemSauGanNhat->truoc = NULL;
            }
            
            // ---- xem nếu điểm gần nhất là điểm cuối (nhưng còn điểm) trong danh sách
            else if( (diemTruocGanNhat != NULL) && (diemSauGanNhat == NULL) ) {
               diemTruocGanNhat->sau = NULL;
            }
            
            // ---- giữa danh sách
            else {
               diemTruocGanNhat->sau = diemSauGanNhat;
               diemSauGanNhat->truoc = diemTruocGanNhat;
            }
            
            diemGanNhat->chiSo = chiSoDiem;
            chiSoDiem++;

            // ---- kèm điểm gần nhất vào nét
//            printf( "0: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            diemGanNhat->truoc = diemCuoiNet;
//            printf( "0a: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            diemGanNhat->sau = NULL;
//            printf( "0b: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            diemCuoiNet->sau = diemGanNhat;
//            printf( "0c: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            
            // ---- điểm mới bỏ và nét là điểm cuối mới
            diemCuoiNet = diemGanNhat;
//            printf( "0d: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            
         }
         else {
            chuaXong = kSAI;
         }
      }
//      printf( "  ---> diemDauNet %p  truoc %p  sau %p\n", diemDauNet, diemDauNet->truoc, diemDauNet->sau  );
      return diemDauNet;
   }
   else // ---- nếu đầu danh sách == NULL
      return NULL;
}

// Tính chuữ nhật bao bì cho nét
// Để tính diận tích và tâm chữ nhật, giúp biết nét ở đầu và cỡ kích
ChuNhat tinhChuNhatChoNet( DiemGon *danhSachDiem ) {
   
   DiemGon *diemDau = danhSachDiem;
   short xCucTieu = diemDau->x;
   short xCucDai = xCucTieu;
   short yCucTieu = diemDau->y;
   short yCucDai = yCucTieu;
   
   DiemGon *diemHienTai = diemDau;
   while( diemHienTai != NULL ) {
      short x = diemHienTai->x;
      short y = diemHienTai->y;

      if( x < xCucTieu )
         xCucTieu = x;
      else if( x > xCucDai )
         xCucDai = x;
      
      if( y < yCucTieu )
         yCucTieu = y;
      else if( y > yCucDai )
         yCucDai = y;

      diemHienTai = diemHienTai->sau;
   }
   
   // ---- tính chữ nhật nét
   ChuNhat chuNhatNet;
   chuNhatNet.trai = xCucTieu;
   chuNhatNet.phai = xCucDai;
   
   chuNhatNet.duoi = yCucTieu;
   chuNhatNet.tren = yCucDai;
   
   return chuNhatNet;
}


#pragma mark ---- Đặt Cấp Nét
void datCapNetChoHuong( Vecto diemGoc, Vecto huong, Net *mangNet, unsigned char soLuongNet, char capNet );
void xoaXuLyMangNetTruNetCapCao( Net *mangNet, unsigned char soLuongNet, unsigned char capCao );

// 8 phương
void timCapChoNetXungQuanhNet( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned int beRong, unsigned int beCao,
                              Net *mangNet, unsigned char soLuongNet, short tamPhatTia_x, short tamPhatTia_y, Diem gocAnh, unsigned char capCao, unsigned char huongTimNet ) {

   // ----
   Vecto diemGoc;
   Vecto huong;
   diemGoc.x = tamPhatTia_x;
   diemGoc.y = tamPhatTia_y;
   
   Diem diemDau;
   Diem diemCuoi;
   diemDau.x = tamPhatTia_x + gocAnh.x;
   diemDau.y = tamPhatTia_y + gocAnh.y;
   
   // ---- ↙︎
   if( huongTimNet & kHUONG__TRAI_DUOI ) {
      huong.x = -tamPhatTia_x;
      huong.y = -tamPhatTia_y;

      diemCuoi.x = gocAnh.x;
      diemCuoi.y = gocAnh.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x00a0ffff );
      
      datCapNetChoHuong( diemGoc, huong, mangNet, soLuongNet, capCao - 1);
      xoaXuLyMangNetTruNetCapCao( mangNet, soLuongNet, capCao );
   }
   
   // ---- ↓
   if( huongTimNet & kHUONG__DUOI ) {
      huong.x = 0.0f;
      huong.y = -tamPhatTia_y;
      diemCuoi.x = tamPhatTia_x + gocAnh.x;
      diemCuoi.y = gocAnh.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x00a0ffff );
      
      datCapNetChoHuong( diemGoc, huong, mangNet, soLuongNet, capCao - 1);
      xoaXuLyMangNetTruNetCapCao( mangNet, soLuongNet, capCao );
   }
   
   // ---- ↘︎
   if( huongTimNet & kHUONG__PHAI_DUOI ) {
      huong.x = beRong-1 - tamPhatTia_x;
      huong.y = -tamPhatTia_y;
      
      diemCuoi.x = (beRong-1) + gocAnh.x;
      diemCuoi.y = gocAnh.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x00a0ffff );
      
      datCapNetChoHuong( diemGoc, huong, mangNet, soLuongNet, capCao - 1);
      xoaXuLyMangNetTruNetCapCao( mangNet, soLuongNet, capCao );
   }
   
   // ---- →
   if( huongTimNet & kHUONG__PHAI ) {
      huong.x = beRong-1 - tamPhatTia_x;
      huong.y = 0.0f;
      
      diemCuoi.x = (beRong-1) + gocAnh.x;
      diemCuoi.y = tamPhatTia_y + gocAnh.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x00a0ffff );
      
      datCapNetChoHuong( diemGoc, huong, mangNet, soLuongNet, capCao - 1);
      xoaXuLyMangNetTruNetCapCao( mangNet, soLuongNet, capCao );
   }
   
   // ---- ↗︎
   if( huongTimNet & kHUONG__PHAI_TREN ) {
      huong.x = beRong-1 -tamPhatTia_x;
      huong.y = beCao-1 -tamPhatTia_y;
      
      diemCuoi.x = (beRong-1) + gocAnh.x;
      diemCuoi.y = (beCao-1) + gocAnh.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x00a0ffff );
      
      datCapNetChoHuong( diemGoc, huong, mangNet, soLuongNet, capCao - 1);
      xoaXuLyMangNetTruNetCapCao( mangNet, soLuongNet, capCao );
   }
   
   // ---- ↑
   if( huongTimNet & kHUONG__TREN ) {
      huong.x = 0.0f;
      huong.y = beCao-1 -tamPhatTia_y;
      
      diemCuoi.x = tamPhatTia_x + gocAnh.x;
      diemCuoi.y = (beCao-1) + gocAnh.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x00a0ffff );
      
      datCapNetChoHuong( diemGoc, huong, mangNet, soLuongNet, capCao - 1);
      xoaXuLyMangNetTruNetCapCao( mangNet, soLuongNet, capCao );
   }
   
   // ---- ↖︎
   if( huongTimNet & kHUONG__TRAI_TREN ) {
      huong.x = -tamPhatTia_x;
      huong.y = beCao-1 -tamPhatTia_y;
      
      diemCuoi.x = gocAnh.x;
      diemCuoi.y = (beCao-1) + gocAnh.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x00a0ffff );
      
      datCapNetChoHuong( diemGoc, huong, mangNet, soLuongNet, capCao - 1);
      xoaXuLyMangNetTruNetCapCao( mangNet, soLuongNet, capCao );
   }
   
   // ---- ←
   if( huongTimNet & kHUONG__TRAI_TREN ) {
      huong.x = -tamPhatTia_x;
      huong.y = 0.0f;
      
      diemCuoi.x = gocAnh.x;
      diemCuoi.y = tamPhatTia_y + gocAnh.y;
      veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, 0x00a0ffff );
      
      datCapNetChoHuong( diemGoc, huong, mangNet, soLuongNet, capCao - 1);
   }
}


/* Tìm điểm hai đường thẳng cắt nhau
 ∆x = x_1 – x_0
 ∆y = y_1 – y_0
 
 ∆X = X_1 – X_0
 ∆Y = Y_1 – Y_0
 
 x(t) = x_0 + ∆x•t  // đoạn nét giữa hai điểm
 y(t) = y_0 + ∆y•t
 
 X(u) = X_0 + ∆X•u  // tia phát từ điểm gốc
 Y(u) = Y_0 + ∆Y•u
 
 x_0 + ∆x•t = X_0 + ∆X•u
 ∆x•t = (X_0 - x_0) + ∆X•u
 t = [(X_0 – x_0) + ∆X•u] / ∆x
 
 y_0 + ∆y•t = Y_0 + ∆Y•u
 t = [(Y_0 – y_0) + ∆Y•u] / ∆y
 
 [(X_0 – x_0) + ∆X•u] / ∆x =  [(Y_0 – y_0) + ∆Y•u] / ∆y
 
 [(X_0 – x_0) + ∆X•u] ∆y =  [(Y_0 – y_0) + ∆Y•u] ∆x
 (X_0 – x_0)•∆y + ∆X ∆y • u = (Y_0 – y_0)•∆x + ∆Y ∆x • u
 (∆X ∆y – ∆Y ∆x) • u = (Y_0 – y_0)•∆x – (X_0 – x_0)•∆y
 u = [(Y_0 – y_0)•∆x – (X_0 – x_0)•∆y] / (∆X ∆y – ∆Y ∆x)
 
 tính t và nếu 0 ≤ thì ≤ 1, cắt nhau
*/
void datCapNetChoHuong( Vecto diemGoc, Vecto huong, Net *mangNet, unsigned char soLuongNet, char capNet ) {

   // ---- tìm nét gần nhất
   unsigned char xong = kSAI;

   while( !xong ) {
      float cachXaGanNhat = kVO_CUC;
      char chiSoNetGanNhat = -1;
      
      unsigned char chiSoNet = 0;
      while( chiSoNet < soLuongNet ) {
         if( !mangNet[chiSoNet].bo && !mangNet[chiSoNet].xuLyRoi ) {
            DiemGon *diemHienTai = mangNet[chiSoNet].mangDiem;
            while( diemHienTai->sau != NULL ) {
               DiemGon diemNet0;
               DiemGon diemNet1;
               
               diemNet0.x = diemHienTai->x;
               diemNet0.y = diemHienTai->y;
               diemNet1.x = diemHienTai->sau->x;
               diemNet1.y = diemHienTai->sau->y;
               float cachNet_x = diemNet1.x - diemNet0.x;
               float cachNet_y = diemNet1.y - diemNet0.y;

               float u = ((diemGoc.y - diemNet0.y)*cachNet_x - (diemGoc.x - diemNet0.x)*cachNet_y)/(huong.x*cachNet_y - huong.y*cachNet_x);
               float t;
               if( cachNet_x != 0.0f )
                  t = (diemGoc.x - diemNet0.x + huong.x*u) / cachNet_x;
               else
                  t = (diemGoc.y - diemNet0.y + huong.y*u) / cachNet_y;
               
      //         printf( "chiSoNet %d  u %5.3f  t %5.3f  cachXaGanNhat %5.3f\n", chiSoNet, u, t, cachXaGanNhat );
               if( (t > 0.0f) && (t < 1.0f) ) {

                  if( (u > 0.0f) && (u < cachXaGanNhat) ) {
                     cachXaGanNhat = u;
                     chiSoNetGanNhat = chiSoNet;
                  }
               }
               diemHienTai = diemHienTai->sau;
            }
         }

         chiSoNet++;
      }
      
      if( cachXaGanNhat < kVO_CUC ) {
         mangNet[chiSoNetGanNhat].xuLyRoi = kDUNG;
         mangNet[chiSoNetGanNhat].cap = capNet;
   //      printf( "cachXaGanNhat %5.3f  chiSoNetGanNhat %d  capNet %d\n", cachXaGanNhat, chiSoNetGanNhat, capNet );
         capNet--;
      }
      else {
         xong = kDUNG;
      }

   }
}

void xoaXuLyMangNetTruNetCapCao( Net *mangNet, unsigned char soLuongNet, unsigned char capCao ) {
   
   unsigned char soNet = 0;
   while( soNet < soLuongNet ) {
      if( mangNet[soNet].cap != capCao )
         mangNet[soNet].xuLyRoi = kSAI;
      soNet++;
   }
}


#pragma mark ---- Tô Màu
void tinhMotBuocLanRong( float *mangFloat0, float *mangFloat1, unsigned int beRong, unsigned int beCao );
void timGiaTriSangCucTieuDai( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char *giaTriCucTieu, unsigned char *giaTriCucDai );
void toMauTranDayBatDauTuDiemTamNNetCaoNhat( float *anhFloat, unsigned int beRong, unsigned int beCao, DiemGon diemPhatToMau, float capCao, unsigned char huong );
void toCanhAnh( unsigned char *anh, float *anhFloat0, unsigned int beRong, unsigned int beCao, unsigned char doSangCucTieu, unsigned char doSangCucDai, DiemGon diemPhatToMau );

void toAnh( unsigned char *anhXuat, unsigned int beRongAnhXuat, unsigned int beCaoAnhXuat, unsigned char *anh, unsigned int beRong, unsigned int beCao,
           Net *mangNet, unsigned char soLuongNet, Diem gocAnh, unsigned char chiSoCapCaoNhat, unsigned char huongToMau ) {

   unsigned char doSangCucTieu;
   unsigned char doSangCucDai;
   timGiaTriSangCucTieuDai( anh, beRong, beCao, &doSangCucTieu, &doSangCucDai );
   printf( "ToMauAnh: ToAnh: giaTriCucTieu %d  giaTriCucDai %d\n", doSangCucTieu, doSangCucDai );
   
   // ---- vẽ nét vả tìm cấp thấp nhất
   unsigned char capThapNhat = 255;
   unsigned char chiSoNet = 0;
   while( chiSoNet < soLuongNet ) {
      
      if( !mangNet[chiSoNet].bo ) {
         DiemGon *diemHienTai = mangNet[chiSoNet].mangDiem;
         unsigned char capNet = mangNet[chiSoNet].cap;
         if( capNet < capThapNhat )
            capThapNhat = capNet;
         

         while( diemHienTai->sau != NULL ) {
            unsigned int mauNet = 0xff;
            
            Diem diemDau;
            diemDau.x = diemHienTai->x + gocAnh.x;
            diemDau.y = diemHienTai->y + gocAnh.y;
            Diem diemCuoi;
            diemCuoi.x = diemHienTai->sau->x + gocAnh.x;
            diemCuoi.y = diemHienTai->sau->y + gocAnh.y;
            veDuong( anhXuat, beRongAnhXuat, beCaoAnhXuat, diemDau, diemCuoi, mauNet );
            
            short x = (diemDau.x + diemCuoi.x) >> 1;
            short y = (diemDau.y + diemCuoi.y) >> 1;
            x += 10;
            y += 10;
            char xauSoDiem[256];
            sprintf( xauSoDiem, "%d", capNet );
            veSoCaiNho( xauSoDiem, x, y, anhXuat, beRongAnhXuat, beCaoAnhXuat );
            
            diemHienTai = diemHienTai->sau;
         }
      }
      chiSoNet++;
   }

   // ---- bất một cho tiêu chuẩn cho giá trị số không, giúp đỡ tô màu cho giá tri trong ảnh thấp hơn nét thấp nhất
   capThapNhat--;
   
   // ---- tạo ảnh float để
   float *anhFloat0 = calloc( beRong*beCao, sizeof( float ) );
   unsigned int diaChiAnhFloat = 0;
   unsigned int diaChiAnhFloatCuoi = beRong*beCao;
   while( diaChiAnhFloat < diaChiAnhFloatCuoi ) {
      anhFloat0[diaChiAnhFloat] = -1;
      diaChiAnhFloat++;
   }
      
   
 //  float *anhFloat1 = calloc( beRong*beCao, sizeof( float ) );

    {
      // ---- vẽ nét trong ảnh float
      chiSoNet = 0;
      while( chiSoNet < soLuongNet ) {
         
         if( !mangNet[chiSoNet].bo ) {
            DiemGon *diemHienTai = mangNet[chiSoNet].mangDiem;
            unsigned char capNet = mangNet[chiSoNet].cap;
            
            while( diemHienTai->sau != NULL ) {
               unsigned int mauNet = 0xff;
               
               Diem diemDau;
               diemDau.x = diemHienTai->x;
               diemDau.y = diemHienTai->y;
               Diem diemCuoi;
               diemCuoi.x = diemHienTai->sau->x;
               diemCuoi.y = diemHienTai->sau->y;
               veDuongCap( anhFloat0, beRong, beCao, diemDau, diemCuoi, capNet - capThapNhat );
               
               diemHienTai = diemHienTai->sau;
            }
            
            // ---- nếu nét không kết nối (vòng tròn)
            if( mangNet[chiSoNet].ranh == kRANH__KHONG_KET_NOI ) {
               Diem diemDau;
               diemDau.x = diemHienTai->x;
               diemDau.y = diemHienTai->y;
               Diem diemCuoi;
               diemCuoi.x = mangNet[chiSoNet].mangDiem->x;
               diemCuoi.y = mangNet[chiSoNet].mangDiem->y;
               //         printf( "%d %d --> %d %d\n", diemDau.x, diemDau.y, diemCuoi.x, diemCuoi.y );
               veDuongCap( anhFloat0, beRong, beCao, diemDau, diemCuoi, capNet - capThapNhat );
            }
         }
         chiSoNet++;
      }
  
       //----- TÔ TRÀN ĐẦY
       DiemGon diemPhatToMau;  // điểm phát tia để tô tràn đầy

       if( mangNet[chiSoCapCaoNhat].ranh >= kRANH__NET_NOI_CUNG__TRAI ) {
          diemPhatToMau.x = mangNet[chiSoCapCaoNhat].tamChuNhatX;
          diemPhatToMau.y =  mangNet[chiSoCapCaoNhat].tamChuNhatY;
          toMauTranDayBatDauTuDiemTamNNetCaoNhat( anhFloat0, beRong, beCao, diemPhatToMau, mangNet[chiSoCapCaoNhat].cap - capThapNhat, huongToMau );

       }
       else if( mangNet[chiSoCapCaoNhat].ranh == kRANH__NET_NOI_KE__TRAI_DUOI ) {
          diemPhatToMau.x = 0;
          diemPhatToMau.y = 0;
          toMauTranDayBatDauTuDiemTamNNetCaoNhat( anhFloat0, beRong, beCao, diemPhatToMau, mangNet[chiSoCapCaoNhat].cap - capThapNhat, huongToMau );
       }
       else if( mangNet[chiSoCapCaoNhat].ranh == kRANH__NET_NOI_KE__TRAI_TREN ) {
          diemPhatToMau.x = 0;
          diemPhatToMau.y = beCao-1;
          toMauTranDayBatDauTuDiemTamNNetCaoNhat( anhFloat0, beRong, beCao, diemPhatToMau, mangNet[chiSoCapCaoNhat].cap - capThapNhat, huongToMau );
       }
       else if( mangNet[chiSoCapCaoNhat].ranh == kRANH__NET_NOI_KE__PHAI_DUOI ) {
          diemPhatToMau.x = beRong-1;
          diemPhatToMau.y = 0;
          toMauTranDayBatDauTuDiemTamNNetCaoNhat( anhFloat0, beRong, beCao, diemPhatToMau, mangNet[chiSoCapCaoNhat].cap - capThapNhat, huongToMau );
       }
       else if( mangNet[chiSoCapCaoNhat].ranh == kRANH__NET_NOI_KE__PHAI_TREN ) {
          diemPhatToMau.x = beRong-1;
          diemPhatToMau.y = beCao-1;
          toMauTranDayBatDauTuDiemTamNNetCaoNhat( anhFloat0, beRong, beCao, diemPhatToMau, mangNet[chiSoCapCaoNhat].cap - capThapNhat, huongToMau );
       }
       
       // ----
       toCanhAnh( anh, anhFloat0, beRong, beCao, doSangCucTieu, doSangCucDai, diemPhatToMau );
      
     // ---- phân phối giá trị
//     tinhMotBuocLanRong( anhFloat0, anhFloat1, beRong, beCao );
      
      // ---- trao đổi hai ảnh
//      float *conTroAnh = anhFloat0;
//      anhFloat0 = anhFloat1;
//      anhFloat1 = conTroAnh;
      
   }
  
   // ---- tô ảnh nhờ ảnh float
   diaChiAnhFloat = 0;
   unsigned int soHang = 0;
   while( soHang < beCao ) {
      unsigned int soCot = 0;
      unsigned int diaChiAnhXuat = ((soHang + gocAnh.y)*beRongAnhXuat + gocAnh.x) << 2;
      while( soCot < beRong ) {
         // ---- lấy gaí trị
         float giaTriTo = anhFloat0[diaChiAnhFloat];
         // ---- tính màu từ giá trị
         unsigned int mauDiemAnh = mauChoSoThuc( giaTriTo );
         // ---- tô điểm ảnh
         anhXuat[diaChiAnhXuat] = (mauDiemAnh >> 24) & 0xff;
         anhXuat[diaChiAnhXuat+1] = (mauDiemAnh >> 16) & 0xff;
         anhXuat[diaChiAnhXuat+2] = (mauDiemAnh >> 8) & 0xff;
         anhXuat[diaChiAnhXuat+3] = mauDiemAnh & 0xff;

         diaChiAnhFloat++;
         diaChiAnhXuat += 4;
         soCot++;
      }
      soHang++;
   }
   
   free( anhFloat0 );
//   free( anhFloat1 );
}

#pragma mark ---- Tìm Giá Trị Sáng Cực Trong Ảnh
void timGiaTriSangCucTieuDai( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned char *giaTriCucTieu, unsigned char *giaTriCucDai ) {
   // ---- độ sáng cực tiểu và đại
   *giaTriCucTieu = 255;
   *giaTriCucDai = 0;
   
   unsigned int diaChiAnh  = 0;
   unsigned int diaChiAnhCuoi = beRong*beCao << 2;
   while( diaChiAnh < diaChiAnhCuoi ) {
      unsigned char giaTri = anh[diaChiAnh];
      if( giaTri < *giaTriCucTieu )
         *giaTriCucTieu = giaTri;
      else if( giaTri > *giaTriCucDai )
         *giaTriCucDai = giaTri;
      diaChiAnh += 4;
   }
}

// CỘNG THỨC NHIẾT
//            [i;j+1]
//               +
//               |
//               |[i;j]
// [i-1;j] +-----+-----+ [i+1;j]
//               |
//               |
//               +
//            [i;j-1]

//

// u[i;j;n+1] - u[i;j;n] = (u[i-1;j;n] - 2u[i;j;n] + u[i+1;j;n])∆t/∆x² + (u[i;j-1;n] - 2u[i;j;n] + u[i;j+1;j;n])∆t/∆y²
//  u[i;j;n+1] = u[i;j;n]•(1 - 2∆t/∆x² - 2∆t/∆y²) + (u[i-1;j;n] + u[i+1;j;n])•∆t/∆x² + ((u[i;j-1;n] + u[i;j+1;j;n])•∆t/∆y²
// Nếu ∆x² = ∆y²
//  u[i;j;n+1] = u[i;j;n]•(1 - 4∆t/∆x²) + (u[i-1;j;n] + u[i+1;j;n])•∆t/∆x² + ((u[i;j-1;n] + u[i;j+1;j;n])•∆t/∆x²

// 1/4 ≥ ∆t/∆x²

// u[i+1;j;n] = u[i-1;j;n] - 2•f(i;j;n)  <---- hàm tại ranh giới

// -----

// u[i;j;n+1] - u[i;j;n] = (u[i-1;j;n+1] - 2u[i;j;n+1] + u[i+1;j;n+1])∆t/∆x² + (u[i;j-1;n+1] - 2u[i;j;n+1] + u[i;j+1;j;n+1])∆t/∆y²
//  u[i;j;n+1]•(1 + 2∆t/∆x² + 2∆t/∆y²) - u[i-1;j;n+1]•∆t/∆x² - u[i+1;j;n+1]•∆t/∆x² - u[i-1;j;n+1]•∆t/∆y² - u[i+1;j;n+1]•∆t/∆y² = u[i;j;n]

// Nếu ∆x² = ∆y²


//  u[i;j;n+1]•(1 + 4∆t/∆x²) - u[i-1;j;n+1]•∆t/∆x² - u[i+1;j;n+1]•∆t/∆x² - u[i-1;j;n+1]•∆t/∆x² - u[i+1;j;n+1]•∆t/∆x² = u[i;j;n]
//  u[i;j;n+1]•(1 + 4∆t/∆x²) - (u[i-1;j;n+1] - u[i+1;j;n+1] - u[i-1;j;n+1] - u[i+1;j;n+1])•∆t/∆x² = u[i;j;n]

/*
#define kBUOC_THOI_GIAN 0.20f   // chỉ ổn định cho giá trị ≤ 0.25f
void tinhMotBuocLanRong( float *mangFloat0, float *mangFloat1, unsigned int beRong, unsigned int beCao ) {
   
   float hangSo = (1.0f - 4.0f*kBUOC_THOI_GIAN);  // (1 + 4∆t/∆x²)    ∆x = 1.0f
   unsigned int soHang = 1;
   while( soHang < beCao - 1 ) {
      unsigned int soCot = 1;
      unsigned int diaChi = beRong*soHang + soCot;
      while( soCot < beRong - 1 ) {
         mangFloat1[diaChi] = mangFloat0[diaChi]*hangSo + (mangFloat0[diaChi-1] + mangFloat0[diaChi+1] + mangFloat0[diaChi-beRong] + mangFloat0[diaChi+beRong])*kBUOC_THOI_GIAN;
         
     //    if( soHang == 1 )
     //       printf( )
         soCot++;
         diaChi++;
      }
      soHang++;
   }
} */

// Tô Màu Tràn Đầy Từ Điểm Tâm Của Nét Cao Nhất
//   hướng tô màu là hướng cho phát tia đề tô hết khu vực của ảnh, các hướng cần kiểm tra tùy loại (hình dạng) nét có cấp cao nhất
//   bây giờ chỉ có 8 hướng: 4 hướng trái, phải, xuống, lên, và đến 4 góc ảnh
#define kBUOC_KIEM_TRA 5   // điểm ảnh

void toMauTranDayBatDauTuDiemTamNNetCaoNhat( float *anhFloat, unsigned int beRong, unsigned int beCao, DiemGon diemPhatToMau, float capCao, unsigned char huongToMau ) {

   float cap = capCao;
   toTranDay( anhFloat, beRong, beCao, diemPhatToMau.x, diemPhatToMau.y, cap );
   cap--;
   printf( "ToMauDay: capCao %5.3f\n", capCao );
   // -------->
   DiemGon diemKiemTra;
   diemKiemTra.x = diemPhatToMau.x;
   diemKiemTra.y = diemPhatToMau.y;
   unsigned int diaChiAnh = diemKiemTra.x + diemKiemTra.y*beRong;
   while(  diemKiemTra.x < beRong ) {
      // ---- lấy giá trị điểm ảnh
      float giaTriDiemAnh = anhFloat[diaChiAnh];
//      printf( " →giaTriDiemAnh %5.3f  cap %5.3f   diemKiemTra %d; %d   beRong %d  beCao %d\n", giaTriDiemAnh, cap, diemKiemTra.x, diemKiemTra.y, beRong, beCao );
      if( giaTriDiemAnh == -1.0f  )
         toTranDay( anhFloat, beRong, beCao, diemKiemTra.x, diemKiemTra.y, cap );
      else
         cap = giaTriDiemAnh - 1;

      diemKiemTra.x++;
      diaChiAnh++;
   }

   // ^
   // |
   // |
   // |
   diemKiemTra.x = diemPhatToMau.x;
   diemKiemTra.y = diemPhatToMau.y;
   diaChiAnh = diemKiemTra.x + diemKiemTra.y*beRong;
   while(  diemKiemTra.y < beCao ) {
      // ---- lấy giá trị điểm ảnh
      float giaTriDiemAnh = anhFloat[diaChiAnh];
//      printf( " ↑giaTriDiemAnh %5.3f  cap %5.3f   diemKiemTra %d; %d   beRong %d  beCao %d\n", giaTriDiemAnh, cap, diemKiemTra.x, diemKiemTra.y, beRong, beCao );
      if( giaTriDiemAnh == -1.0f  )
         toTranDay( anhFloat, beRong, beCao, diemKiemTra.x, diemKiemTra.y, cap );
      else
         cap = giaTriDiemAnh - 1;

      diemKiemTra.y++;
      diaChiAnh += beRong;
   }

   // <----------
   diemKiemTra.x = diemPhatToMau.x;
   diemKiemTra.y = diemPhatToMau.y;
   diaChiAnh = diemKiemTra.x + diemKiemTra.y*beRong;
   while(  diemKiemTra.x > -1 ) {
      
      float giaTriDiemAnh = anhFloat[diaChiAnh];
//      printf( " ←giaTriDiemAnh %5.3f  cap %5.3f   diemKiemTra %d; %d   beRong %d  beCao %d\n", giaTriDiemAnh, cap, diemKiemTra.x, diemKiemTra.y, beRong, beCao );
      if( giaTriDiemAnh == -1.0f  )
         toTranDay( anhFloat, beRong, beCao, diemKiemTra.x, diemKiemTra.y, cap );
      else
         cap = giaTriDiemAnh - 1;

      diemKiemTra.x--;
      diaChiAnh--;
   }

   // |
   // |
   // |
   // v
  diemKiemTra.x = diemPhatToMau.x;
   diemKiemTra.y = diemPhatToMau.y;
   diaChiAnh = diemKiemTra.x + diemKiemTra.y*beRong;
   while(  diemKiemTra.y > -1 ) {
      // ---- lấy giá trị điểm ảnh
      float giaTriDiemAnh = anhFloat[diaChiAnh];
//      printf( " ↓giaTriDiemAnh %5.3f  cap %5.3f   diemKiemTra %d; %d   beRong %d  beCao %d\n", giaTriDiemAnh, cap, diemKiemTra.x, diemKiemTra.y, beRong, beCao );
      if( giaTriDiemAnh == -1.0f  )
         toTranDay( anhFloat, beRong, beCao, diemKiemTra.x, diemKiemTra.y, cap );
      else
         cap = giaTriDiemAnh - 1;

      diemKiemTra.y--;
      diaChiAnh -= beRong;
   }


   // ---- Phương pháp xài cho đườn chèo không nhan, không hiệu qủa nhưng đơn giản
   // ↙︎
   float cachX = diemPhatToMau.x;
   float cachY = diemPhatToMau.y;
   float doLon = sqrt( cachX*cachX + cachY*cachY );
   if( doLon > 0.0f ) {
      cachX /= doLon;
      cachY /= doLon;
      float xFloat = diemPhatToMau.x;
      float yFloat = diemPhatToMau.y;

      while( (xFloat > 0.0f) && (yFloat > 0.0f) ) {
         diemKiemTra.x = xFloat;
         diemKiemTra.y = yFloat;
         diaChiAnh = diemKiemTra.x + diemKiemTra.y*beRong;
         float giaTriDiemAnh = anhFloat[diaChiAnh];
         if( giaTriDiemAnh == -1.0f  ) {
            toTranDay( anhFloat, beRong, beCao, diemKiemTra.x, diemKiemTra.y, cap );
         }
         else
            cap = giaTriDiemAnh - 1;
         
         xFloat -= cachX*kBUOC_KIEM_TRA;
         yFloat -= cachY*kBUOC_KIEM_TRA;
 //        printf( " (%5.3f; %5.3f)  giaTriDiemAnh %5.3f   diemKiemTra %d; %d   beRong %d  beCao %d\n", xFloat, yFloat, giaTriDiemAnh, diemKiemTra.x, diemKiemTra.y, beRong, beCao );
      }
   }
  
   // ↘︎
   cachX = beRong - 1 - diemPhatToMau.x;
   cachY = diemPhatToMau.y;
   doLon = sqrt( cachX*cachX + cachY*cachY );
   if( doLon > 0.0f ) {
      cachX /= doLon;
      cachY /= doLon;
      float xFloat = diemPhatToMau.x;
      float yFloat = diemPhatToMau.y;

      while( (xFloat < beRong) && (yFloat > 0.0f) ) {
         diemKiemTra.x = xFloat;
         diemKiemTra.y = yFloat;
         diaChiAnh = diemKiemTra.x + diemKiemTra.y*beRong;
         float giaTriDiemAnh = anhFloat[diaChiAnh];
         if( giaTriDiemAnh == -1.0f  ) {
            toTranDay( anhFloat, beRong, beCao, diemKiemTra.x, diemKiemTra.y, cap );
         }
         else
            cap = giaTriDiemAnh - 1;
         
         xFloat += cachX*kBUOC_KIEM_TRA;
         yFloat -= cachY*kBUOC_KIEM_TRA;
//         printf( " %5.3f; %5.3f  diemKiemTra %d; %d   beRong %d  beCao %d\n", xFloat, yFloat, diemKiemTra.x, diemKiemTra.y, beRong, beCao );
      }
   }

   // ↗︎
   cachX = beRong - 1 - diemPhatToMau.x;
   cachY = beCao - 1 - diemPhatToMau.y;
   doLon = sqrt( cachX*cachX + cachY*cachY );
   if( doLon > 0.0f ) {
      cachX /= doLon;
      cachY /= doLon;
      float xFloat = diemPhatToMau.x;
      float yFloat = diemPhatToMau.y;

      while( (xFloat < beRong) && (yFloat < beCao) ) {
         diemKiemTra.x = xFloat;
         diemKiemTra.y = yFloat;
         diaChiAnh = diemKiemTra.x + diemKiemTra.y*beRong;
         float giaTriDiemAnh = anhFloat[diaChiAnh];
         if( giaTriDiemAnh == -1.0f  ) {
            toTranDay( anhFloat, beRong, beCao, diemKiemTra.x, diemKiemTra.y, cap );
         }
         else
            cap = giaTriDiemAnh - 1;
         
         xFloat += cachX*kBUOC_KIEM_TRA;
         yFloat += cachY*kBUOC_KIEM_TRA;
//         printf( " %5.3f; %5.3f  diemKiemTra %d; %d   beRong %d  beCao %d\n", xFloat, yFloat, diemKiemTra.x, diemKiemTra.y, beRong, beCao );
      }
   }
   
   // ↖︎
   cachX = diemPhatToMau.x;
   cachY = beCao - 1 - diemPhatToMau.y;
   doLon = sqrt( cachX*cachX + cachY*cachY );
   if( doLon > 0.0f ) {
      cachX /= doLon;
      cachY /= doLon;
      float xFloat = diemPhatToMau.x;
      float yFloat = diemPhatToMau.y;
      
      while( (xFloat > 0.0f) && (yFloat < beCao) ) {
         diemKiemTra.x = xFloat;
         diemKiemTra.y = yFloat;
         diaChiAnh = diemKiemTra.x + diemKiemTra.y*beRong;
         float giaTriDiemAnh = anhFloat[diaChiAnh];
         if( giaTriDiemAnh == -1.0f  ) {
            toTranDay( anhFloat, beRong, beCao, diemKiemTra.x, diemKiemTra.y, cap );
         }
         else
            cap = giaTriDiemAnh - 1;
         
         xFloat -= cachX*kBUOC_KIEM_TRA;
         yFloat += cachY*kBUOC_KIEM_TRA;
//         printf( " %5.3f; %5.3f  diemKiemTra %d; %d   beRong %d  beCao %d\n", xFloat, yFloat, diemKiemTra.x, diemKiemTra.y, beRong, beCao );
      }
   }
}

#pragma mark ---- Tô Cảnh Ảnh
unsigned char quetNgangVaTimSuKhacBiet( unsigned char *mangDoSang, float *mangFloat, unsigned short *mangSoCot,
                                       unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned int soHang );
unsigned char quetDocVaTimSuKhacBiet( unsigned char *mangDoSang, float *mangFloat, unsigned short *mangSoCot,
                                     unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned int soCot);
void suaGiaTrDauVaCuoiTuyDoSang( float *mangFloat, unsigned char soLuongDiem );
float tinhGiaTriFloatGocAnh( unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao,
                           short *mangDiemX, short *mangDiemY, DiemGon goc, DiemGon diemPhatToMau, unsigned doSangCucTieu, unsigned char doSangCucDai );
void toMauHang( unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned short soHang,
               float *mangFloat, unsigned char *mangDoSang, unsigned short *mangSoCot, unsigned char soLuongDiem, unsigned char doSangCucTieu, unsigned char doSangCucDai );
void toMauCot( unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned short soCot,
              float *mangFloat, unsigned char *mangDoSang, unsigned short *mangSoHang, unsigned char soLuongDiem, unsigned char doSangCucTieu, unsigned char doSangCucDai );

void toCanhAnh( unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned char doSangCucTieu, unsigned char doSangCucDai, DiemGon diemPhatToMau ) {
   
   // ==== quét ngang - dưới
   unsigned char mangDoSangNetDuoi[kSO_LUONG__NET_TOI_DA+2];  // xộng hai cho góc trái và phải ảnh
   unsigned short mangSoCotNetDuoi[kSO_LUONG__NET_TOI_DA+2];
   float mangFloatNetDuoi[kSO_LUONG__NET_TOI_DA+2];  // xộng hai cho góc trái và phải ảnh
   unsigned char soLuongDiemThichThuDuoi = quetNgangVaTimSuKhacBiet( mangDoSangNetDuoi, mangFloatNetDuoi, mangSoCotNetDuoi, anh, anhFloat, beRong, beCao, 0 );
   
   // ==== quét hàng trên
   unsigned char mangDoSangNetTren[kSO_LUONG__NET_TOI_DA+2];  // cxộng hai cho góc trái và phải ảnh
   unsigned short mangSoCotNetTren[kSO_LUONG__NET_TOI_DA+2];
   float mangFloatNetTren[kSO_LUONG__NET_TOI_DA+2];  // xộng hai cho góc trái và phải ảnh
   unsigned char soLuongDiemThichThuTren = quetNgangVaTimSuKhacBiet( mangDoSangNetTren, mangFloatNetTren, mangSoCotNetTren, anh, anhFloat, beRong, beCao, beCao-1 );

   // ==== quét cột trái
   unsigned char mangDoSangNetTrai[kSO_LUONG__NET_TOI_DA+2];  // cxộng hai cho góc trái và phải ảnh
   unsigned short mangSoHangNetTrai[kSO_LUONG__NET_TOI_DA+2];
   float mangFloatNetTrai[kSO_LUONG__NET_TOI_DA+2];  // xộng hai cho góc trái và phải ảnh
   unsigned char soLuongDiemThichThuTrai = quetDocVaTimSuKhacBiet( mangDoSangNetTrai, mangFloatNetTrai, mangSoHangNetTrai, anh, anhFloat, beRong, beCao, 0 );
   
   // ==== quét cột phải
   unsigned char mangDoSangNetPhai[kSO_LUONG__NET_TOI_DA+2];  // cxộng hai cho góc trái và phải ảnh
   unsigned short mangSoHangNetPhai[kSO_LUONG__NET_TOI_DA+2];
   float mangFloatNetPhai[kSO_LUONG__NET_TOI_DA+2];  // xộng hai cho góc trái và phải ảnh
   unsigned char soLuongDiemThichThuPhai = quetDocVaTimSuKhacBiet( mangDoSangNetPhai, mangFloatNetPhai, mangSoHangNetPhai, anh, anhFloat, beRong, beCao, beRong-1 );
   
   // ==== TÔ ẢNH
   // ---- họn một bên để bắt đầu tô cạnh
   unsigned char doSangTrungBinh = (doSangCucTieu + doSangCucDai) >> 1;
   float chenhLechCuc = (float)(doSangCucDai - doSangCucTieu);
   unsigned char benBatDauTo;
   
   // ---- phải có nét cắt ít nhất một cạnh (nét cuổi ranh),
   unsigned netKhongCatBen = 0;
   if( soLuongDiemThichThuDuoi > 2 )
      suaGiaTrDauVaCuoiTuyDoSang( mangFloatNetDuoi, soLuongDiemThichThuDuoi );
      
   if( soLuongDiemThichThuTren > 2 )
      suaGiaTrDauVaCuoiTuyDoSang( mangFloatNetTren, soLuongDiemThichThuDuoi );
   
   if( soLuongDiemThichThuTrai > 2 )
      suaGiaTrDauVaCuoiTuyDoSang( mangFloatNetTrai, soLuongDiemThichThuDuoi );
   
   if( soLuongDiemThichThuPhai > 2 )
      suaGiaTrDauVaCuoiTuyDoSang( mangFloatNetPhai, soLuongDiemThichThuDuoi );
   

   printf( "ToCanhAnh: soLuongDiemThichThuDuoi %d   netKhongCatBen %d\n", soLuongDiemThichThuDuoi, netKhongCatBen );
   // ---- Nếu không có nét nào
   if( netKhongCatBen == 0xf ) {
      printf( "Tô màu, không có nét để tô ảnh" );
      return;
   }
   
   // ---- tính gá trị cho bốn góc ảnh
   short *mangDiemX = malloc( beRong*sizeof(short) );
   short *mangDiemY = malloc( beRong*sizeof(short) );

   DiemGon goc;

   
   // ---- trái dưới
   goc.x = 0;
   goc.y = 0;
   float giaTriTraiDuoi = tinhGiaTriFloatGocAnh( anh, anhFloat, beRong, beCao, mangDiemX, mangDiemY, goc, diemPhatToMau, doSangCucTieu, doSangCucDai );
   
   // ---- phải dưới
   goc.x = beRong-1;
//   goc.y = 0;
   float giaTriPhaiDuoi = tinhGiaTriFloatGocAnh( anh, anhFloat, beRong, beCao, mangDiemX, mangDiemY, goc, diemPhatToMau, doSangCucTieu, doSangCucDai );
   
   // ---- trái trên
   goc.x = 0;
   goc.y = beCao-1;
   float giaTriTraiTren = tinhGiaTriFloatGocAnh( anh, anhFloat, beRong, beCao, mangDiemX, mangDiemY, goc, diemPhatToMau, doSangCucTieu, doSangCucDai );

   
   // ---- phải trên
   goc.x = beRong-1;
//   goc.y = beCao-1;
   float giaTriPhaiTren = tinhGiaTriFloatGocAnh( anh, anhFloat, beRong, beCao, mangDiemX, mangDiemY, goc, diemPhatToMau, doSangCucTieu, doSangCucDai );
   
//   printf( "ToMauAnh: ToCanhAnh: giaTriGoc  %5.3f  %5.3f  %5.3f  %5.3f\n", giaTriTraiDuoi, giaTriPhaiDuoi, giaTriTraiTren, giaTriPhaiTren );
   mangFloatNetDuoi[0] = giaTriTraiDuoi;
   mangFloatNetDuoi[soLuongDiemThichThuDuoi-1] = giaTriPhaiDuoi;
   
   mangFloatNetTren[0] = giaTriTraiTren;
   mangFloatNetTren[soLuongDiemThichThuTren-1] = giaTriPhaiTren;
   
   mangFloatNetTrai[0] = giaTriTraiDuoi;
   mangFloatNetTrai[soLuongDiemThichThuTrai-1] = giaTriTraiTren;
   
   mangFloatNetPhai[0] = giaTriPhaiDuoi;
   mangFloatNetPhai[soLuongDiemThichThuPhai-1] = giaTriPhaiTren;

   // ---- in giá trị để xem
   unsigned char chiSo = 0;
   while( chiSo < soLuongDiemThichThuDuoi ) {
      printf( "  DUOI:  %d  doSang %d   giaTriFloat %5.3f  soCot %d\n", chiSo, mangDoSangNetDuoi[chiSo], mangFloatNetDuoi[chiSo], mangSoCotNetDuoi[chiSo]  );
      chiSo++;
   }
   
   printf( "ToCanhAnh: soLuongDiemThichThuTren %d\n", soLuongDiemThichThuTren );
   chiSo = 0;
   while( chiSo < soLuongDiemThichThuTren ) {
      printf( "  TREN:  %d  doSang %d   giaTriFloat %5.3f  soCot %d\n", chiSo, mangDoSangNetTren[chiSo], mangFloatNetTren[chiSo], mangSoCotNetTren[chiSo]  );
      chiSo++;
   }
   
   printf( "ToCanhAnh: soLuongDiemThichThuTrai %d\n", soLuongDiemThichThuTrai );
   chiSo = 0;
   while( chiSo < soLuongDiemThichThuTrai ) {
      printf( "  TRÁI %d  doSang %d   giaTriFloat %5.3f  soHang %d\n", chiSo, mangDoSangNetTrai[chiSo], mangFloatNetTrai[chiSo], mangSoHangNetTrai[chiSo]  );
      chiSo++;
   }
   
   printf( "ToCanhAnh: soLuongDiemThichThuPhai %d\n", soLuongDiemThichThuPhai );
   chiSo = 0;
   while( chiSo < soLuongDiemThichThuPhai ) {
      printf( "  PHẢI %d  doSang %d   giaTriFloat %5.3f  soHang %d\n", chiSo, mangDoSangNetPhai[chiSo], mangFloatNetPhai[chiSo], mangSoHangNetPhai[chiSo]  );
      chiSo++;
   }

   // ----- tô cảnh dưới
   toMauHang( anh, anhFloat, beRong, beCao, 0, mangFloatNetDuoi, mangDoSangNetDuoi, mangSoCotNetDuoi, soLuongDiemThichThuDuoi, doSangCucTieu, doSangCucDai );

   // ----- tô cảnh trên
   toMauHang( anh, anhFloat, beRong, beCao, beCao-1, mangFloatNetTren, mangDoSangNetTren, mangSoCotNetTren, soLuongDiemThichThuTren, doSangCucTieu, doSangCucDai );

   // ----- tô cảnh trái
   toMauCot( anh, anhFloat, beRong, beCao, 0, mangFloatNetTrai, mangDoSangNetTrai, mangSoHangNetTrai, soLuongDiemThichThuTrai, doSangCucTieu, doSangCucDai );
   
   // ----- tô cảnh phải
   toMauCot( anh, anhFloat, beRong, beCao, beRong-1, mangFloatNetPhai, mangDoSangNetPhai, mangSoHangNetPhai, soLuongDiemThichThuPhai, doSangCucTieu, doSangCucDai );

}

unsigned char quetNgangVaTimSuKhacBiet( unsigned char *mangDoSang, float *mangFloat, unsigned short *mangSoCot,
                                       unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned int soHang ) {
   if( soHang >= beCao )
      soHang = beCao - 1;

   // ---- phía trái
   mangDoSang[0] = anh[soHang*beRong << 2];
   mangFloat[0] = anhFloat[soHang*beRong];
   mangSoCot[0] = 0;
   unsigned char soLuongDiemThichThu = 1;
   
   // ---- tìm các điểm
   unsigned short soCot = 1;
   unsigned int diaChiAnh = soHang*beRong + soCot;
   while( soCot < beRong ) {
      float giaTri = anhFloat[diaChiAnh];
      
      if( giaTri != mangFloat[soLuongDiemThichThu-1] ) {
         mangDoSang[soLuongDiemThichThu] = anh[diaChiAnh << 2];
         mangSoCot[soLuongDiemThichThu] = soCot;
         mangFloat[soLuongDiemThichThu] = giaTri;
         soLuongDiemThichThu++;
      }
      
      diaChiAnh++;
      soCot++;
   }
   
   // ---- phía phải
   mangDoSang[soLuongDiemThichThu] = anh[(diaChiAnh-1) << 2];
   mangSoCot[soLuongDiemThichThu] = beRong-1;
   mangFloat[soLuongDiemThichThu] = anhFloat[diaChiAnh - 1];
   soLuongDiemThichThu++;
   
   return soLuongDiemThichThu;
}

unsigned char quetDocVaTimSuKhacBiet( unsigned char *mangDoSang, float *mangFloat, unsigned short *mangSoHang,
                                     unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned int soCot) {
   if( soCot >= beRong )
      soCot = beRong - 1;
   
   // ---- phía dưới
   mangDoSang[0] = anh[soCot << 2];
   mangSoHang[0] = 0;
   mangFloat[0] = anhFloat[soCot];
   unsigned char soLuongDiemThichThu = 1;
   
   // ---- tìm các điểm phải
   unsigned short soHang = 1;
   unsigned int diaChiAnh = soCot;
   while( soHang < beCao ) {
      float giaTri = anhFloat[diaChiAnh];
      if( giaTri != mangFloat[soLuongDiemThichThu-1] ) {
         mangDoSang[soLuongDiemThichThu] = anh[diaChiAnh << 2];
         mangSoHang[soLuongDiemThichThu] = soHang;
         mangFloat[soLuongDiemThichThu] = giaTri;
         soLuongDiemThichThu++;
      }
      diaChiAnh += beRong;
      soHang++;
   }

//   printf( "ToCanhAnh: soCot %d soLuongDiemThichThu %d\n", soCot, soLuongDiemThichThu );
   diaChiAnh -= beRong;

   // ---- phía trên
   mangDoSang[soLuongDiemThichThu] = anh[diaChiAnh << 2];
   mangSoHang[soLuongDiemThichThu] = beCao-1;
   mangFloat[soLuongDiemThichThu] = anhFloat[diaChiAnh];
   soLuongDiemThichThu++;
   
   return soLuongDiemThichThu;
}


void suaGiaTrDauVaCuoiTuyDoSang( float *mangFloat, unsigned char soLuongDiem ) {
   
   // ==== sửa gía trị số
   //      Khi tìm sự đồi giát rị float, nó lữu gía trí không đúng cho nét sau giạ trị giảm lại. Ví dụ:
   //    222222222333333333344444444443333332222222   <---- các giá trị trong ảnhloat
   //    2        3         4         3     2     2   <---- các giá trị trong mảngFloat
   //    phải sữa lại thành:
   //    2        3         4         4     3     2 <--- không quan tâm giá trị cuối này, hàm tinhGiaTriFloatGocAnh() tính giá trị dầu và cuối sẽ sửa nó
   unsigned char chiSo = 1;
   while( chiSo < soLuongDiem-1 ) {  // đừng quan tâm điểm cuối, lần nào hai giá trị cuối bằng nhau
      if( mangFloat[chiSo-1] > mangFloat[chiSo] )
         break;
      chiSo++;
   }

   while( chiSo < soLuongDiem-1 ) {  // đừng quan tâm điểm cuối, lần nào hai giá trị cuối bằng nhau
      mangFloat[chiSo] += 1.0f;
      chiSo++;
   }
}

// ---- Hàm này giả sự ảnhFloat có ảnh nét, được tô tràn đụng giá trị giữa cấp nét,
//      Chỉ cần tính giá trị float tương đối với nét gần nhất
float tinhGiaTriFloatGocAnh( unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao,
                           short *mangDiemX, short *mangDiemY, DiemGon goc, DiemGon diemPhatToMau, unsigned doSangCucTieu, unsigned char doSangCucDai ) {

   unsigned char doSangTrungBinh = (doSangCucTieu + doSangCucDai) >> 1;
   float chenhLechCuc = doSangCucDai - doSangCucTieu;
//   printf( "   doSangCucTieu %d  doSangCucDai %d  chenhLechCuc %5.3f  doSangTrungBinh %d\n", doSangCucTieu, doSangCucDai, chenhLechCuc, doSangTrungBinh );


   short soLuongDiemQuet = tinhDiemHaiDiem( goc, diemPhatToMau, mangDiemX, mangDiemY );
   float giaTriFloatGoc = anhFloat[goc.x + goc.y*beRong];
   float giaTriFloatNet;
   unsigned char doSangGoc = anh[(goc.x + goc.y*beRong) << 2];
   

//   printf( " giaTriFloatGoc (khoiDau) %5.3f   soLuongDiemQuet %d   goc %d;  %d\n", giaTriFloatGoc, soLuongDiemQuet, goc.x, goc.y  );
   unsigned char doSangNet;
   short chiSoDiem = 0;
   while( chiSoDiem < soLuongDiemQuet ) {
      short x = mangDiemX[chiSoDiem];
      short y = mangDiemY[chiSoDiem];
      float giaTriFloat = anhFloat[x + y*beRong];
      //      printf( "TRAI DUOI %d  (%d; %d)  giaTri %5.3f   doSang %d  DC %d\n", chiSoDiem, x, y, giaTriFloat, anh[(x + y*beRong) << 2], x + y*beRong );
      
      if( giaTriFloat != giaTriFloatGoc ) {
         giaTriFloatNet = giaTriFloat;
         doSangNet = anh[(x + y*beRong) << 2];
//         printf("doSangGoc %d    doSangNet %d\n", anh[(goc.x + goc.y*beRong) << 2], anh[(x + y*beRong) << 2] );
         break;
      }
      chiSoDiem++;
   }
   
   // ==== sửa giá trị
   
   if( doSangGoc < doSangNet ) {
      float phanSo = (doSangGoc - doSangCucTieu)/chenhLechCuc;
      // ---- nếu giá trị tăng
      if( giaTriFloatGoc < giaTriFloatNet )
         giaTriFloatGoc += phanSo;
      // ---- nếu giá trị giảm
      else
         giaTriFloatGoc -= phanSo;
   }
   else {
      float phanSo = (doSangCucDai-doSangGoc)/chenhLechCuc;
      // ---- nếu giá trị tăng
      if( giaTriFloatGoc < giaTriFloatNet )
         giaTriFloatGoc += phanSo;
      // ---- nếu giá trị giảm
      else
         giaTriFloatGoc -= phanSo;
      
   }
   
//   printf( "--> giaTriFloatGoc (sua lai) %5.3f  doSangGoc %d\n", giaTriFloatGoc, doSangGoc );

   return giaTriFloatGoc;
}


#pragma mark ---- Tô Màu Hàng
void toMauHang( unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned short soHang,
           float *mangFloat, unsigned char *mangDoSang, unsigned short *mangSoCot, unsigned char soLuongDiem, unsigned char doSangCucTieu, unsigned char doSangCucDai ) {
   
   if( soHang >= beCao )
      soHang = beCao-1;

   unsigned doSangTrungBinh = (doSangCucTieu + doSangCucDai) >> 1;
   float chenhLechCuc = doSangCucDai - doSangCucTieu;
   unsigned int diaChiHang = beRong*soHang;
   
   unsigned char chiSoDiem = 1;
   while( chiSoDiem < soLuongDiem ) {
      float giaTriDau = mangFloat[chiSoDiem-1];
      float giaTriCuoi = mangFloat[chiSoDiem];
      unsigned short soCotDau = mangSoCot[chiSoDiem-1];
      unsigned short soCotCuoi = mangSoCot[chiSoDiem];
      float buoc = (giaTriCuoi - giaTriDau)/(float)(soCotCuoi - soCotDau);

      // ---- tô đoàn
      if( giaTriDau != giaTriCuoi ) {
         unsigned chiSoDiemAnh = soCotDau;
         while( chiSoDiemAnh < mangSoCot[chiSoDiem] ) {
            printf( "chiSoDiemAnh %d/%d  beRong %d  chiSoDiemAnh + diaChiHang %d/%d  chiSoDiem %d/%d\n", chiSoDiemAnh, mangSoCot[chiSoDiem], beRong, chiSoDiemAnh + diaChiHang,
                   beRong*beCao, chiSoDiem, soLuongDiem );
            anhFloat[chiSoDiemAnh + diaChiHang] = giaTriDau;
            giaTriDau += buoc;
            chiSoDiemAnh++;
         }
      }
      // ---- đoàn này là đất thủng lung hay đỉnh núi, xài parabol đề tính màu
      else {
         // ---- tính số cột giữa
         unsigned short soCotGiua = (soCotDau + soCotCuoi) >> 1;
         unsigned char doSangGiua = anh[(diaChiHang + soCotGiua) << 2];

         float giaTriGiua = giaTriDau;  // giá trị cơ bản
         float giaTriNetTruoc = mangFloat[chiSoDiem-2];  // cho biết điểm là cực tiểu hay cực đại (đấy thủng lung hay đỉnh núi)
         if( mangDoSang[chiSoDiem] > doSangTrungBinh ) {

            float phanSo = (float)(doSangGiua - doSangCucTieu)/chenhLechCuc;
 //           printf("0: %5.3f  doSangCucDai %d  doSangGiua %d\n", phanSo, doSangCucDai, doSangGiua );
            // ---- nếu giá trị tăng
            if( giaTriGiua < giaTriNetTruoc )
               giaTriGiua -= phanSo;
            // ---- nếu giá trị giảm
            else
               giaTriGiua += phanSo;
         }
         else {
            float phanSo = (float)(doSangCucDai-doSangGiua)/chenhLechCuc;
 //           printf("1: %5.3f  doSangCucDai %d  doSangGiua %d\n", phanSo, doSangCucDai, doSangGiua );
            // ---- nếu giá trị tăng
            if( giaTriGiua < giaTriNetTruoc )
               giaTriGiua -= phanSo;
            // ---- nếu giá trị giảm
            else
               giaTriGiua += phanSo;
            
         }

         // ---- tính giá trị cho ma trận, dùng parabol đề tô màu đoàn này
         float x0 = (float)soCotDau/(float)beRong;
         float x1 = (float)soCotGiua/(float)beRong;
         float x2 = (float)soCotCuoi/(float)beRong;

         float maTran[9];
         float maTranNghichDao[9];
         maTran[0] = x0*x0;
         maTran[1] = x0;
         maTran[2] = 1.0f;
         maTran[3] = x1*x1;
         maTran[4] = x1;
         maTran[5] = 1.0f;
         maTran[6] = x2*x2;
         maTran[7] = x2;
         maTran[8] = 1.0f;
         chieuMaTran( maTran, 3, 3 );
         maTranNghichDao3x3( maTran, maTranNghichDao );
         chieuMaTran( maTranNghichDao, 3, 3 );
         
         // ---- tính hệ số cho cộng thức parabol
         float a = maTranNghichDao[0]*giaTriDau + maTranNghichDao[1]*giaTriGiua + maTranNghichDao[2]*giaTriCuoi;
         float b = maTranNghichDao[3]*giaTriDau + maTranNghichDao[4]*giaTriGiua + maTranNghichDao[5]*giaTriCuoi;
         float c = maTranNghichDao[6]*giaTriDau + maTranNghichDao[7]*giaTriGiua + maTranNghichDao[8]*giaTriCuoi;
//         printf( "giaTriDau %5.3f  giaTriGiua %5.3f  giaTriCuoi %5.3f\n", giaTriDau, giaTriGiua, giaTriCuoi );
         
         // ---- xài parabol để tô màu
         unsigned chiSoDiemAnh = soCotDau;
         while( chiSoDiemAnh < soCotCuoi ) {
            float x = (float)chiSoDiemAnh/(float)beRong;
            anhFloat[chiSoDiemAnh + diaChiHang] = a*x*x + b*x + c;
            giaTriDau += buoc;
            chiSoDiemAnh++;
         }
      }
      
      chiSoDiem++;
   }
}


#pragma mark ---- Tô Màu Cột
void toMauCot( unsigned char *anh, float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned short soCot,
               float *mangFloat, unsigned char *mangDoSang, unsigned short *mangSoHang, unsigned char soLuongDiem, unsigned char doSangCucTieu, unsigned char doSangCucDai ) {
   
   if( soCot >= beRong )
      soCot = beRong-1;
   
   unsigned doSangTrungBinh = (doSangCucTieu + doSangCucDai) >> 1;
   float chenhLechCuc = doSangCucDai - doSangCucTieu;
   
   unsigned int diaChiCot = soCot;
   unsigned char chiSoDiem = 1;

   while( chiSoDiem < soLuongDiem ) {
      float giaTriDau = mangFloat[chiSoDiem-1];
      float giaTriCuoi = mangFloat[chiSoDiem];
      unsigned short soHangDau = mangSoHang[chiSoDiem-1];
      unsigned short soHangCuoi = mangSoHang[chiSoDiem];
      float buoc = (giaTriCuoi - giaTriDau)/(float)(soHangCuoi - soHangDau);
      // ---- tô đoàn
      if( giaTriDau != giaTriCuoi ) {
         unsigned chiSoDiemAnh = soHangDau;
         while( chiSoDiemAnh < soHangCuoi ) {
            anhFloat[diaChiCot] = giaTriDau;
            giaTriDau += buoc;
            chiSoDiemAnh++;
            diaChiCot += beRong;
         }
      }
      // ---- đoàn này là đất thủng lung hay đỉnh núi, xài parabol đề tính màu
      else {
         // ---- tính số cột giữa
         unsigned short soHangGiua = (soHangDau + soHangCuoi) >> 1;
         unsigned char doSangGiua = anh[(soCot + soHangGiua*beRong) << 2];
         
         float giaTriGiua = giaTriDau;  // giá trị cơ bản
         float giaTriNetTruoc = mangFloat[chiSoDiem-2];  // cho biết điểm là cực tiểu hay cực đại (đấy thủng lung hay đỉnh núi)
         if( mangDoSang[chiSoDiem] > doSangTrungBinh ) {
            
            float phanSo = (float)(doSangGiua - doSangCucTieu)/chenhLechCuc;
            //           printf("0: %5.3f  doSangCucDai %d  doSangGiua %d\n", phanSo, doSangCucDai, doSangGiua );
            // ---- nếu giá trị tăng
            if( giaTriGiua < giaTriNetTruoc )
               giaTriGiua -= phanSo;
            // ---- nếu giá trị giảm
            else
               giaTriGiua += phanSo;
         }
         else {
            float phanSo = (float)(doSangCucDai-doSangGiua)/chenhLechCuc;
            //           printf("1: %5.3f  doSangCucDai %d  doSangGiua %d\n", phanSo, doSangCucDai, doSangGiua );
            // ---- nếu giá trị tăng
            if( giaTriGiua < giaTriNetTruoc )
               giaTriGiua -= phanSo;
            // ---- nếu giá trị giảm
            else
               giaTriGiua += phanSo;
            
         }
         
         // ---- tính giá trị cho ma trận, dùng parabol đề tô màu đoàn này
         float x0 = (float)soHangDau/(float)beCao;
         float x1 = (float)soHangGiua/(float)beCao;
         float x2 = (float)soHangCuoi/(float)beCao;
         
         float maTran[9];
         float maTranNghichDao[9];
         maTran[0] = x0*x0;
         maTran[1] = x0;
         maTran[2] = 1.0f;
         maTran[3] = x1*x1;
         maTran[4] = x1;
         maTran[5] = 1.0f;
         maTran[6] = x2*x2;
         maTran[7] = x2;
         maTran[8] = 1.0f;
         chieuMaTran( maTran, 3, 3 );
         maTranNghichDao3x3( maTran, maTranNghichDao );
         chieuMaTran( maTranNghichDao, 3, 3 );
         
         // ---- tính hệ số cho cộng thức parabol
         float a = maTranNghichDao[0]*giaTriDau + maTranNghichDao[1]*giaTriGiua + maTranNghichDao[2]*giaTriCuoi;
         float b = maTranNghichDao[3]*giaTriDau + maTranNghichDao[4]*giaTriGiua + maTranNghichDao[5]*giaTriCuoi;
         float c = maTranNghichDao[6]*giaTriDau + maTranNghichDao[7]*giaTriGiua + maTranNghichDao[8]*giaTriCuoi;
         //         printf( "giaTriDau %5.3f  giaTriGiua %5.3f  giaTriCuoi %5.3f\n", giaTriDau, giaTriGiua, giaTriCuoi );
         
         // ---- xài parabol để tô màu
         unsigned chiSoDiemAnh = soHangDau;
         while( chiSoDiemAnh < soHangCuoi ) {
            float x = (float)chiSoDiemAnh/(float)beCao;
            anhFloat[diaChiCot] = a*x*x + b*x + c;
            giaTriDau += buoc;
            chiSoDiemAnh++;
            diaChiCot += beRong;
         }
      }
      
      chiSoDiem++;
   }
}
