/*  TôMàuẢnh.c */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "../HangSo.h"
#include "../ChuNhat.h"
#include "Diem.h"
#include "../TimNet/Bezier.h"
#include "../TimNet/Net.h"
#include "../TimNet/TimNet.h"
#include "../VeVatThe/VeSoCai.h"
#include "../VeVatThe/VeDuong.h"
#include "../VeVatThe/VeVongTron.h"
#include "../VeVatThe/VeChuNhat.h"
#include "../VeVatThe/ChepAnh.h"
#include "DanhSachMau.h"


#pragma mark ---- Tô Màu

typedef struct {
   char chiSo;
   char trai;
   char giua;
   char phai;
} GiaoDiemNet;

/* Tìm Đường */

void veNetVaSo( unsigned char *anhToMau, unsigned short beRong, unsigned short beCao, Net *mangNet, unsigned char soLuongNet, short dichX, short dichY );
void veKhungVaToaDo( unsigned char *anhToMau, unsigned short beRong, unsigned short beCao, ChuNhat khung, unsigned short cachNet );
void veNetCap( float *anhFloat, unsigned short beRong, unsigned short beCao, Net *mangNet, unsigned char soLuongNet );
void veThanhMau( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned short x, unsigned short y );

unsigned int doXamChoSoThuc( float so );
unsigned int mauChoSoThuc( float so );

char *xauChoSo( float cap );
void toGiuaNet( unsigned char *anhDoSang, unsigned char *anhToMau, float *anhGiupToMau, unsigned int beRong, unsigned int beCao );
void toGiuaNet2( unsigned char *anhDoSang, unsigned char *anhToMau, unsigned int beRong, unsigned int beCao, Net *mangNet, unsigned char soLuongNet );

// ----
void rutDiemTuDanhSach( DiemGon **dauDanhSachDiem, DiemGon **diemHienTai );
DiemGon *timDiemTiep( DiemGon **dauDanhSachDiem, unsigned int cachXaToiDaBinh );
//void chonHuongDi( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem diemThichThu, short *huongX, short *huongY, unsigned char cachXa );

#define kSO_LAN__CAT_NGANG 15
#define kSO_LAN__CAT_DOC   30
#define kSO_LUONG_DIEM_QUET_TOI_DA   32    // số lượng điểm tối đa được kiếm trong

#define kCACH_XA__PHAP_TUYEN 15
#define kGIOI_HAN__PHAP_TUYEN 0.93f

#define kSO_LUONG__NET_TOI_DA 32

unsigned char *toMauAnh( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int *beRongAnhXuat, unsigned int *beCaoAnhXuat ) {
   
   *beRongAnhXuat = beRong + kLE_TRAI__ANH_TO + kLE_PHAI__ANH_TO;
   *beCaoAnhXuat = beCao + kLE_DUOI__ANH_TO + kLE_TREN__ANH_TO;
   
   printf( "  toMauAnh: anh  %d x %d   anhXuat %d x %d\n", beRong, beCao, *beRongAnhXuat, *beCaoAnhXuat );
   
   // ==== ảnh để tô màu
   unsigned char *anhToMau = malloc( beRong * beCao << 2 );
   
   float *anhGiupToMau = malloc( beRong * beCao * sizeof(float) );
   
   // ---- ảnh xuất, có khung, số nét, và tọa độ
   unsigned char *anhXuat = malloc( *beRongAnhXuat * *beCaoAnhXuat << 2 );
   
   if( (anhToMau != NULL) && (anhGiupToMau != NULL) && (anhXuat != NULL) ) {
      // ---- xóa ảnh tô
      unsigned int diaChiAnh = 0;
      while( diaChiAnh < (beRong*beCao << 2) ) {
         anhToMau[diaChiAnh] = 255;
         anhToMau[diaChiAnh+1] = 255;
         anhToMau[diaChiAnh+2] = 0;
         anhToMau[diaChiAnh+3] = 255;
         diaChiAnh += 4;
      }
      
      // ---- xóa ảnh giúp tô màu
      diaChiAnh = 0;
      while( diaChiAnh < beRong*beCao ) {
         anhGiupToMau[diaChiAnh] = -1.0f;
         diaChiAnh++;
      }
      
      // ---- xóa ảnh xuất
      diaChiAnh = 0;
      while( diaChiAnh < (*beRongAnhXuat * *beCaoAnhXuat << 2) ) {
         anhXuat[diaChiAnh] = 255;
         anhXuat[diaChiAnh+1] = 255;
         anhXuat[diaChiAnh+2] = 255;
         anhXuat[diaChiAnh+3] = 255;
         diaChiAnh += 4;
      }
      
      // ==== chuẩn bị quét ngang và dộc để kiếm điểm thích thú (gíá trị cực đoạn)
      unsigned short buocCot = beRong/(kSO_LAN__CAT_DOC - 1);
      unsigned short buocHang = beCao/(kSO_LAN__CAT_NGANG - 1);
      
      DiemGon *dauDanhSachDiem = NULL;
      DiemGon *cuoiDanhSachDiem = NULL;

      // ==== tìm các điểm
      // ---- quét ngang
      unsigned char soBuocCat = 0;
      unsigned int soHang = 0;
      while( soBuocCat < kSO_LAN__CAT_NGANG ) {
         if( dauDanhSachDiem == NULL )
            cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetNgang( &dauDanhSachDiem, anh, beRong, beCao, soHang );
         else
            cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetNgang( &cuoiDanhSachDiem, anh, beRong, beCao, soHang );
   
         soHang += buocHang;
         soBuocCat++;
      }
   
      // ---- quét dộc
      soBuocCat = 0;
      unsigned short soCot = 0;
      while( soBuocCat < kSO_LAN__CAT_DOC ) {
         if( dauDanhSachDiem == NULL )
            cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetDoc( &dauDanhSachDiem, anh, beRong, beCao, soCot );
         else
            cuoiDanhSachDiem = taoDanhSachDiemThichThu_quetDoc( &cuoiDanhSachDiem, anh, beRong, beCao, soCot );

         soCot += buocCot;
         soBuocCat++;
      }
 
     // ==== khử điểm hết điểm pháp tuyến < kGIOI_HAN__PHAP_TUYEN
      unsigned short soLuongDiem = 0;
      unsigned short soLuongDiemTot = 0;
      DiemGon *diemHienTai = dauDanhSachDiem;
      while( diemHienTai != NULL ) {
         // ---- tính pháp tuyến
         Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anh, beRong, beCao, diemHienTai->x, diemHienTai->y, kCACH_XA__PHAP_TUYEN );

         // ---- bỏ
         if( phapTuyen.z < kGIOI_HAN__PHAP_TUYEN )
            rutDiemTuDanhSach( &dauDanhSachDiem, &diemHienTai );
         else
            diemHienTai = diemHienTai->sau;
         
         soLuongDiem++;
      }


      // ---- vẽ điểm từ quét trên sơ đồ
      soLuongDiem = 0;
      diemHienTai = dauDanhSachDiem;
      while( diemHienTai != NULL ) {

         // ---- tính pháp tuyến
         Vecto phapTuyen = tinhPhapTuyenMatPhangToiUu( anh, beRong, beCao, diemHienTai->x, diemHienTai->y, kCACH_XA__PHAP_TUYEN );

         soLuongDiem++;
         if( phapTuyen.z > kGIOI_HAN__PHAP_TUYEN )
            soLuongDiemTot++;
         
         // ---- chọn màu
         unsigned int mauDiem;
         if( diemHienTai->cucDoan == kDIEM_SANG )
            mauDiem = 0x0000ffff;
         else
            mauDiem = 0xff0000ff;
         
         // ---- vẽ pháp tuyến - tính điểm đầu va điểm cuối để vẽ phép tuyến
         Diem diemDau;
         diemDau.x = diemHienTai->x + kLE_TRAI__ANH_TO;
         diemDau.y = diemHienTai->y + kLE_DUOI__ANH_TO;
         Diem diemCuoi;
         diemCuoi.x = diemDau.x + 50*phapTuyen.x;
         diemCuoi.y = diemDau.y + 50*phapTuyen.y;
         veDuong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau, diemCuoi, mauDiem );
         
         short x = diemHienTai->x + kLE_TRAI__ANH_TO;
         short y = diemHienTai->y + kLE_DUOI__ANH_TO;
         veVongTron( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, x, y, 7, mauDiem );
         
         diemHienTai = diemHienTai->sau;
      }

      // ==== kết nối điểm - tìm nét
      unsigned int cachXaToiDa = buocHang + buocCot;
      unsigned int cachXaToiDaBinh = cachXaToiDa * cachXaToiDa;
      
      // ----
      Net *mangNet = malloc( sizeof( Net )*kSO_LUONG__NET_TOI_DA );
      unsigned char chiSoTimNet = 0;
      
      while( (chiSoTimNet < kSO_LUONG__NET_TOI_DA) && (dauDanhSachDiem != NULL) ) {

         mangNet[chiSoTimNet].mangDiem = timDiemTiep( &dauDanhSachDiem, cachXaToiDaBinh );
         
         // ----- chỉ vẽ nét nếu có nét để vẽ
         if( mangNet[chiSoTimNet].mangDiem != NULL ) {
            
            diemHienTai = mangNet[chiSoTimNet].mangDiem;
            while( diemHienTai->sau != NULL ) {
               
               Diem diemDau;
               diemDau.x = diemHienTai->x + kLE_TRAI__ANH_TO;
               diemDau.y = diemHienTai->y + kLE_DUOI__ANH_TO;
               Diem diemCuoi;
               diemCuoi.x = diemHienTai->sau->x + kLE_TRAI__ANH_TO;
               diemCuoi.y = diemHienTai->sau->y + kLE_DUOI__ANH_TO;
               //         printf( "%d %d --> %d %d\n", diemDau.x, diemDau.y, diemCuoi.x, diemCuoi.y );
               veDuong( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, diemDau, diemCuoi, 0x7f7f7fff );
               
               veSoThapPhan( chiSoTimNet, diemDau.x + 16, diemDau.y + 16, anhXuat, *beRongAnhXuat, *beCaoAnhXuat );
               
               diemHienTai = diemHienTai->sau;
            }
            
            chiSoTimNet++;
         }
      }
   

      // ---- vẽ khung quanh ảnh
      ChuNhat khung;
      khung.trai = kLE_TRAI__ANH_TO;
      khung.phai = *beRongAnhXuat - 1 - kLE_PHAI__ANH_TO;
      khung.duoi = kLE_DUOI__ANH_TO;
      khung.tren = *beCaoAnhXuat - 1 - kLE_TREN__ANH_TO;
      
      printf( "  toMauAnh: veKhungVaToaDo\n" );
      veKhungVaToaDo( anhXuat, *beRongAnhXuat, *beCaoAnhXuat, khung, 200 );

         /*
      
      if( soLuongDiemThichThu ) {
         Net *mangNet  = malloc( 512*sizeof( Net ) );
         unsigned short soLuongNet = timCacNet( anh, beRong, beCao, 10, mangDiemThichThu, soLuongDiemThichThu, mangNet );
         
         printf( "  toMauAnh: soLuongNet %d \n", soLuongNet );
         // ---- vẽ nét cập trong giúp tô màu
         veNetCap( anhGiupToMau, beRong, beCao, mangNet, soLuongNet );
         
         // ---- tô màu
         printf( "  toMauAnh: toMau\n" );
         toGiuaNet( anh, anhToMau, anhGiupToMau, beRong, beCao );
         
         // ---- chép vào ảnh xuất
         printf( "  toMauAnh: chepAnh\n" );
         chepAnhVaoAnh( anhToMau, beRong, beCao, anhXuat, *beRongXuat, *beCaoXuat, kLE_TRAI__ANH_TO, kLE_DUOI__ANH_TO );
         
         // ---- vẽ nét trắng và số
         printf( "  toMauAnh: veNet\n" );
         veNetVaSo( anhXuat, *beRongXuat, *beCaoXuat, mangNet, soLuongNet, kLE_TRAI__ANH_TO, kLE_DUOI__ANH_TO );
         
         // ---- vẽ thanh màu
         veThanhMau( anhXuat, *beRongXuat, *beCaoXuat, kLE_TRAI__ANH_TO - 100, kLE_DUOI__ANH_TO + 200 );
         
         // ---- vẽ khung quanh ảnh
         ChuNhat khung;
         khung.trai = kLE_TRAI__ANH_TO;
         khung.phai = *beRongXuat - 1 - kLE_PHAI__ANH_TO;
         khung.duoi = kLE_DUOI__ANH_TO;
         khung.tren = *beCaoXuat - 1 - kLE_TREN__ANH_TO;
         
         printf( "  toMauAnh: veKhungVaToaDo\n" );
         veKhungVaToaDo( anhXuat, *beRongXuat, *beCaoXuat, khung, 200 );
         //      printf( "toMauAnh: xong\n" );
         free( anhGiupToMau );
         free( anhToMau );
         free( mangDiemThichThu );
      }
      else {
         printf( "  toMauAnh: không thể tìm nét để vẽ ảnh\n" );
         free( mangDiemThichThu );
         exit(0);
      }
      */

   }
   else {
      printf( "TôMàuẢnh: vấn đề tạo ảnh tô màu\n" );
      exit(0);
   }
   
   return anhXuat;
}

/*
void veNetVaSo( unsigned char *anhToMau, unsigned short beRong, unsigned short beCao, Net *mangNet, unsigned char soLuongNet, short dichX, short dichY ) {
   
   unsigned char chiSoNet = 0;
   while( chiSoNet < soLuongNet ) {
      
      if( mangNet[chiSoNet].docTrungBinh < 5.0f ) {
         // ---- vẽ nét
         unsigned char chiSoDiem = 1;
         unsigned short soLuongDiem = mangNet[chiSoNet].soLuongDiem;
         while( chiSoDiem < soLuongDiem ) {
            Diem diem0 = mangNet[chiSoNet].mangDiem[chiSoDiem];
            Diem diem1 = mangNet[chiSoNet].mangDiem[chiSoDiem-1];
            diem0.x += dichX;
            diem0.y += dichY;
            diem1.x += dichX;
            diem1.y += dichY;
            veDuong( anhToMau, beRong, beCao, diem0, diem1, 0xff );
            chiSoDiem++;
         }
         
         // --- vẽ số cấp của nét
         short x = mangNet[chiSoNet].mangDiem[0].x - 24 + dichX;
         short y = mangNet[chiSoNet].mangDiem[0].y + 20 + dichY;
         veSoCai( xauChoSo( mangNet[chiSoNet].cap ), x, y, anhToMau, beRong, beCao );
      }
      
      chiSoNet++;
   }
}*/

void veKhungVaToaDo( unsigned char *anhToMau, unsigned short beRong, unsigned short beCao, ChuNhat khung, unsigned short cachNet ) {
   
   // ---- vẽ khung
   Diem netKhung0;
   Diem netKhung1;
   netKhung0.x = khung.trai;
   netKhung0.y = khung.duoi;
   netKhung1.x = khung.phai;
   netKhung1.y = khung.duoi;
   veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
   netKhung0.y = khung.tren;
   netKhung1.y = khung.tren;
   veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
   
   netKhung0.x = khung.trai;
   netKhung0.y = khung.duoi;
   netKhung1.x = khung.trai;
   netKhung1.y = khung.tren;
   veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
   netKhung0.x = khung.phai;
   netKhung1.x = khung.phai;
   veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
   
   // ---- vẽ nét tọa độ ở trên
   netKhung0.y = khung.tren - 20;
   netKhung1.y = khung.tren;
   netKhung0.x = khung.trai;
   netKhung1.x = khung.trai;
   
   while( netKhung0.x < khung.phai ) {
      veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
      netKhung0.x += cachNet;
      netKhung1.x += cachNet;
   }
   
   // ---- vẽ nét tọa độ ở dưới
   netKhung0.y = khung.duoi;
   netKhung1.y = khung.duoi + 20;
   netKhung0.x = khung.trai;
   netKhung1.x = khung.trai;
   
   while( netKhung0.x < khung.phai ) {
      veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
      netKhung0.x += cachNet;
      netKhung1.x += cachNet;
   }
   
   // ---- vẽ nét tọa độ phía trái
   netKhung0.y = khung.duoi;
   netKhung1.y = khung.duoi;
   netKhung0.x = khung.trai;
   netKhung1.x = khung.trai + 20;
   
   while( netKhung0.y < khung.tren ) {
      veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
      netKhung0.y += cachNet;
      netKhung1.y += cachNet;
   }
   
   // ---- vẽ nét tọa độ phía phải
   netKhung0.y = khung.duoi;
   netKhung1.y = khung.duoi;
   netKhung0.x = khung.phai - 20;
   netKhung1.x = khung.phai;
   
   while( netKhung0.y < khung.tren ) {
      veDuong( anhToMau, beRong, beCao, netKhung0, netKhung1, 0xff );
      netKhung0.y += cachNet;
      netKhung1.y += cachNet;
   }
   
   // ----
   Diem diemNgang0;
   Diem diemNgang1;
   Diem diemDoc0;
   Diem diemDoc1;
   diemNgang0.y = khung.duoi + cachNet;
   diemNgang1.y = khung.duoi + cachNet;
   while( diemNgang0.y < khung.tren ) {
      diemNgang0.x = khung.trai + cachNet - 20;
      diemNgang1.x = khung.trai + cachNet + 20;
      
      diemDoc0.x = khung.trai + cachNet;
      diemDoc1.x = khung.trai + cachNet;
      diemDoc0.y = diemNgang0.y - 20;
      diemDoc1.y = diemNgang0.y + 20;
      while( diemDoc0.x < khung.phai ) {
         veDuong( anhToMau, beRong, beCao, diemNgang0, diemNgang1, 0xff );
         veDuong( anhToMau, beRong, beCao, diemDoc0, diemDoc1, 0xff );
         diemNgang0.x += cachNet;
         diemNgang1.x += cachNet;
         diemDoc0.x += cachNet;
         diemDoc1.x += cachNet;
      }
      
      diemNgang0.y += cachNet;
      diemNgang1.y += cachNet;
   }
}


/*
void veNetCap( float *anhFloat, unsigned short beRong, unsigned short beCao, Net *mangNet, unsigned char soLuongNet ) {
   
   unsigned char chiSoNet = 0;
   while( chiSoNet < soLuongNet ) {
      if( mangNet[chiSoNet].docTrungBinh < 5.0f ) {
         // ---- vẽ nét
         unsigned char chiSoDiem = 1;
         unsigned short soLuongDiem = mangNet[chiSoNet].soLuongDiem;
         while( chiSoDiem < soLuongDiem ) {
            //               veDuong( anhToMau, beRong, beCao, mangNetCao[chiSoNet].mangDiem[chiSoDiem], mangNetCao[chiSoNet].mangDiem[chiSoDiem-1],
            //                       mau );
            veDuongCap( anhFloat, beRong, beCao, mangNet[chiSoNet].mangDiem[chiSoDiem], mangNet[chiSoNet].mangDiem[chiSoDiem-1],
                       mangNet[chiSoNet].cap );
            chiSoDiem++;
         }
         
      }
      
      chiSoNet++;
   }
} */


#define kTHANH_MAU__BE_RONG    50
#define kTHANH_MAU__BE_CAO    500

void veThanhMau( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned short x, unsigned short y ) {
   
   if( (x + kTHANH_MAU__BE_RONG < beRong) && (y + kTHANH_MAU__BE_CAO < beCao) ) {
      
      // ---- thanh màu
      unsigned short soHang = 0;
      float toaDoMau = 0.0f;
      float buocMau = 10.0f/kTHANH_MAU__BE_CAO;
      
      while( soHang < kTHANH_MAU__BE_CAO ) {
         unsigned int mau = mauChoSoThuc( toaDoMau );
         unsigned int diaChiAnh = ((soHang + y)*beRong + x) << 2;
         unsigned short soCot = 0;
         while( soCot < kTHANH_MAU__BE_RONG ) {
            anh[diaChiAnh] = mau >> 24;
            anh[diaChiAnh+1] = mau >> 16;
            anh[diaChiAnh+2] = mau >> 8;
            soCot++;
            diaChiAnh += 4;
         }
         toaDoMau += buocMau;
         soHang++;
      }
   }
   
   // ---- số, dùng vị trí của điểm đầu nét làm vị trí cho số
   //      đụ đoán là nét bắt đầu ở cạnh phía trên
   unsigned short so_viTriX = x - 70;
   unsigned short so_viTriY = y - 8;
   
   veSoCai( xauChoSo( 0.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 1.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 2.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 3.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 4.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 5.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 6.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 7.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 8.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriY += 50;
   veSoCai( xauChoSo( 9.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   so_viTriX -= 16;
   so_viTriY += 50;
   veSoCai( xauChoSo( 10.0f ), so_viTriX, so_viTriY, anh, beRong, beCao );
   
   // ---- khung
   Diem dauNet;
   Diem cuoiNet;
   // ---- trái
   dauNet.x = x;
   dauNet.y = y;
   cuoiNet.x = x;
   cuoiNet.y = y + kTHANH_MAU__BE_CAO;
   veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
   // ---- phải
   dauNet.x += kTHANH_MAU__BE_RONG;
   cuoiNet.x += kTHANH_MAU__BE_RONG;
   veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
   // ---- dưới
   dauNet.x = x;
   cuoiNet.y = y;
   veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
   // ---- trên
   dauNet.y += kTHANH_MAU__BE_CAO;
   cuoiNet.y += kTHANH_MAU__BE_CAO;
   veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
   
   
   // ---- nét
   
   dauNet.x = x - 15;
   dauNet.y = y;
   cuoiNet.x = x;
   cuoiNet.y = y;
   
   unsigned char soNet = 0;
   while( soNet < 11 ) {
      veDuong( anh, beRong, beCao, dauNet, cuoiNet, 0xff );
      dauNet.y += 50;
      cuoiNet.y += 50;
      soNet++;
   }
   
}




void toGiuaNet( unsigned char *anhDoSang, unsigned char *anhToMau, float *anhGiupToMau, unsigned int beRong, unsigned int beCao ) {
   
   unsigned int soHang = 0;
   
   while( soHang < beCao ) {
      // ---- quét ngang kiếm độ sáng tại điểm nét
      unsigned char gapNet = kSAI;
      unsigned short mangSoCotNet[64];
      unsigned char mangDoSang[64];
      float mangCap[64];
      
      unsigned int diaChiAnh = soHang*beRong;
      
      unsigned char chiSoNet = 0;
      unsigned short soCot = 0;
      unsigned char moiGapNet = kSAI;
      while( soCot < beRong ) {
         float cap = anhGiupToMau[diaChiAnh];
         
         if( cap > -1.0f ) {
            if( !moiGapNet ) {
               mangSoCotNet[chiSoNet] = soCot;
               mangDoSang[chiSoNet] = anhDoSang[diaChiAnh << 2];
               mangCap[chiSoNet] = cap;
               chiSoNet++;
               moiGapNet = kDUNG;
            }
         }
         else {
            moiGapNet = kSAI;
         }
         soCot++;
         diaChiAnh++;
      }
      
      unsigned char soLuongNet = chiSoNet;
      
      // ==== từ cạnh trái đến nét đầu
      unsigned char doSangDau = mangDoSang[1];  // dùng độ sáng của nét tiếp để làm chuẩn để tính độ sáng của ranh ảnh
      unsigned char doSangNet = mangDoSang[0];
      float chenhLechDoSang = doSangDau - doSangNet;
      diaChiAnh = soHang*beRong << 2;
      float capNet = mangCap[0];
      
      soCot = 0;
      unsigned short soCotCuoi = mangSoCotNet[0];
      
      while( soCot < soCotCuoi ) {
         float cap = capNet - 0.5f*(anhDoSang[diaChiAnh] - doSangNet)/chenhLechDoSang;
         if( cap < 0.0f )
            cap = 0.0f;
         unsigned int mauTo = doXamChoSoThuc( cap );
         anhToMau[diaChiAnh] = mauTo >> 24;
         anhToMau[diaChiAnh+1] = mauTo >> 16;
         anhToMau[diaChiAnh+2] = mauTo >> 8;
         diaChiAnh += 4;
         soCot++;
      }
      
      // ==== tô màu cho các chổ giữa nét
      chiSoNet = 0;
      while( chiSoNet < soLuongNet - 1 ) {
         
         // ---- tô giữa hai nét
         unsigned short soCotDau = mangSoCotNet[chiSoNet];
         unsigned short soCotCuoi = mangSoCotNet[chiSoNet+1];
         float capDau = mangCap[chiSoNet];
         float capCuoi = mangCap[chiSoNet+1];
         
         unsigned int diaChiAnh = (beRong * soHang + soCotDau) << 2;
         
         // ---- hai cấp khác nhau
         if( capDau != capCuoi ) {
            float cap = capDau;
            float buocCap = (capCuoi - capDau)/(soCotCuoi - soCotDau);
            unsigned short soCot = soCotDau;
            while( soCot < soCotCuoi ) {
               unsigned int mauTo = doXamChoSoThuc( cap );
               anhToMau[diaChiAnh] = mauTo >> 24;
               anhToMau[diaChiAnh+1] = mauTo >> 16;
               anhToMau[diaChiAnh+2] = mauTo >> 8;
               
               cap += buocCap;
               soCot++;
               diaChiAnh += 4;
            }
            
         }
         else {  // capDau == capCuoi
            unsigned short soCotDau = mangSoCotNet[chiSoNet];
            unsigned short soCotCuoi = mangSoCotNet[chiSoNet+1];
            float capDau = mangCap[chiSoNet];
            
            // ---- dùng sự khác biệt giữa nét trước để đoán màu cho vùng giuữa hai nét cùng cấp
            doSangDau = mangDoSang[chiSoNet - 1];  // dùng độ sáng của nét tiếp để làm chuẩn để tính độ sáng của ranh ảnh
            doSangNet = mangDoSang[chiSoNet];
            chenhLechDoSang = doSangDau - doSangNet;
            
            // ---- tìm giá trị cực giữa hai nét, muốn xem nó có chênh lệch hơn độSángNét, muốn dùng giá trị lớn nhất làm mẫy số cho màu
            diaChiAnh = (soHang*beRong + soCotDau) << 2;
            soCot = soCotDau;
            unsigned char giaTriCuc;
            float chenhLechCuc;
            // ---- giá trị đầu nhỏ hơn
            if( doSangDau < doSangNet ) {
               giaTriCuc = 255;
               while( soCot < soCotCuoi ) {
                  if( anhDoSang[diaChiAnh] < giaTriCuc )
                     giaTriCuc = anhDoSang[diaChiAnh];
                  //                   printf(" soCot %d doSang %d  giaTriCuc %d\n", soCot, anhDoSang[diaChiAnh], giaTriCuc );
                  soCot++;
                  diaChiAnh += 4;
               }
               chenhLechCuc = giaTriCuc - doSangNet;
            }
            // ---- giá trị đầu lớn hơn
            else {
               giaTriCuc = 0;
               while( soCot < soCotCuoi ) {
                  if( anhDoSang[diaChiAnh] > giaTriCuc )
                     giaTriCuc = anhDoSang[diaChiAnh];
                  //                   printf(" soCot %d doSang %d  giaTriCuc %d\n", soCot, anhDoSang[diaChiAnh], giaTriCuc );
                  soCot++;
                  diaChiAnh +=4;
               }
               chenhLechCuc = giaTriCuc - doSangNet;
               
            }
            
            float capNet = mangCap[chiSoNet];
            
            soCot = soCotDau;
            
            //           printf( "  doSangDau %d  doSangNet %d  giaTriCuc %d  chenhLechCuc %5.3f  chenhLechDoSang %5.3f\n", doSangDau, doSangNet, giaTriCuc, chenhLechCuc, chenhLechDoSang );
            
            // ---- chênh lệch lớn nhất
            float chenhLechDoSangTuyetDoi = chenhLechDoSang;
            if( chenhLechDoSang < 0.0f )
               chenhLechDoSangTuyetDoi = -chenhLechDoSangTuyetDoi;
            float chenhLechCucTuyetDoi = chenhLechCuc;
            if( chenhLechCuc < 0.0f )
               chenhLechCucTuyetDoi = -chenhLechCucTuyetDoi;
            
            if( chenhLechCucTuyetDoi > chenhLechDoSangTuyetDoi )
               chenhLechDoSang = chenhLechCuc;
            
            diaChiAnh = (soHang*beRong + soCotDau) << 2;
            // ---- hai cấp bằng nhau, nhờ độ sáng ảnh giúp tô màu
            while( soCot < soCotCuoi ) {
               // ---- tính phần số giữa hai nét
               float phanSo = (float)(anhDoSang[diaChiAnh] - doSangNet)/chenhLechDoSang;
               // ==== BẬC MỘT HÓA ĐỘ SÁNG
               // ---- hạn chế giá trị cho hàm acosf()
               if( phanSo > 1.0f )
                  phanSo = 1.0f;
               else if( phanSo < 0.0f )
                  phanSo = 0.0f;
               // ---- bậc một hóa
               float bacMotHoa = 1.0f - acosf( phanSo )/1.5708f;   // chia π/2 cho giữ trong phạm vi ±1
               //               printf( " %d  %5.3f  bacMotHoa %5.3f  capNet %5.3f  = %5.3f  chenhLechDoSang %5.3f\n", anhDoSang[diaChiAnh], phanSo, bacMotHoa, capNet, bacMotHoa + capNet, chenhLechDoSang );
               float cap = capNet + 0.5f*bacMotHoa;
               if( cap < 0.0f )
                  cap = 0.0f;
               //                 printf( "%d/%d cap %5.3f\n", soCot, soCotCuoi, cap );
               unsigned int mauTo = doXamChoSoThuc( cap );
               anhToMau[diaChiAnh] = mauTo >> 24;
               anhToMau[diaChiAnh+1] = mauTo >> 16;
               anhToMau[diaChiAnh+2] = mauTo >> 8;
               diaChiAnh += 4;
               soCot++;
            }
            //       exit(0);
         }
         
         // ==== từ cạnh trái đến nét đầu
         doSangDau = mangDoSang[soLuongNet - 2];  // dùng độ sáng của nét tiếp để làm chuẩn để tính độ sáng của ranh ảnh
         doSangNet = mangDoSang[soLuongNet - 1];
         chenhLechDoSang = doSangDau - doSangNet;
         
         float capNet = mangCap[soLuongNet - 1];
         
         soCot = mangSoCotNet[soLuongNet - 1];
         soCotCuoi = beRong;
         diaChiAnh = (soHang*beRong + soCot) << 2;
         
         while( soCot < soCotCuoi ) {
            float cap = capNet + 0.5f*(doSangNet - anhDoSang[diaChiAnh])/chenhLechDoSang;
            if( cap < 0.0f )
               cap = 0.0f;
            //             printf( " cap %5.3f\n", cap );
            unsigned int mauTo = doXamChoSoThuc( cap );
            anhToMau[diaChiAnh] = mauTo >> 24;
            anhToMau[diaChiAnh+1] = mauTo >> 16;
            anhToMau[diaChiAnh+2] = mauTo >> 8;
            diaChiAnh += 4;
            soCot++;
         }
         //      exit(0);
         
         //    printf( "%d  soCot %d  cap %5.3f  doSang %d\n", chiSoNet, mangSoCotNet[chiSoNet], mangCap[chiSoNet], mangDoSang[chiSoNet] );
         
         chiSoNet++;
      }
      soHang++;
   }
   
}

#define kNUA_BE_RONG_VUONG 50
/*
void toGiuaNet2( unsigned char *anhDoSang, unsigned char *anhToMau, unsigned int beRong, unsigned int beCao, Net *mangNet, unsigned char soLuongNet ) {
   
   unsigned char soNet = 0;
   while( soNet < soLuongNet ) {
      printf( "%d  xuLyRoi %d\n", soNet, mangNet[soNet].xuLyRoi );
      Diem *mangDiem = mangNet[soNet].mangDiem;
      unsigned short soLuongDiem = mangNet[soNet].soLuongDiem;
      unsigned short soDiem = 0;
      unsigned int mauChuNhat = mauChoSoThuc( mangNet[soNet].cap );
      while( soDiem < soLuongDiem ) {
         Diem diem = mangDiem[soDiem];
         ChuNhat chuNhat;
         chuNhat.trai = diem.x - kNUA_BE_RONG_VUONG;
         chuNhat.phai = diem.x + kNUA_BE_RONG_VUONG;
         chuNhat.duoi = diem.y - kNUA_BE_RONG_VUONG;
         chuNhat.tren = diem.y + kNUA_BE_RONG_VUONG;
         veChuNhat( anhToMau, beRong, beCao, chuNhat, mauChuNhat );
         soDiem++;
      }
      soNet++;
   }
   
} */

unsigned int doXamChoSoThuc( float so ) {
   
   unsigned char chiSoMau = floorf( so );
   float phanSo = (so - chiSoMau);
   float nghichPhanSo = 1.0f - phanSo;
   // ---- nhân 4 vì mỗi màu có 4 thành phần
   chiSoMau <<= 2;
   
   unsigned char mauDo = danhSachMau[chiSoMau]*nghichPhanSo + danhSachMau[chiSoMau + 4]*phanSo;
   unsigned char mauLuc = danhSachMau[chiSoMau + 1]*nghichPhanSo + danhSachMau[chiSoMau + 5]*phanSo;
   unsigned char mauXanh = danhSachMau[chiSoMau + 2]*nghichPhanSo + danhSachMau[chiSoMau + 6]*phanSo;
   unsigned char doDuc = danhSachMau[chiSoMau + 3]*nghichPhanSo + danhSachMau[chiSoMau + 7]*phanSo;
   
   /*
    unsigned char mauDo = so*32.0f;
    unsigned char mauLuc = so*128.0f;
    unsigned char mauXanh = so*2047.0f;
    unsigned char mauDuc = 0xff;
    */
   
   unsigned int mauSuyNoi = mauDo << 24 | mauLuc << 16 | mauXanh << 8 | doDuc;
   //    printf( "chiSoMau %d  mau %x  soPhan %5.3f\n", chiSoMau, mauSuyNoi, phanSo );
   return mauSuyNoi;
}

unsigned int mauChoSoThuc( float so ) {
   
   unsigned char chiSoMau = floorf( so );
   float phanSo = (so - chiSoMau);
   chiSoMau <<= 2;

   unsigned char mauDo = danhSachMau[chiSoMau]*(1.0f - phanSo) + danhSachMau[chiSoMau+4]*phanSo;
   unsigned char mauLuc = danhSachMau[chiSoMau+1]*(1.0f - phanSo) + danhSachMau[chiSoMau+5]*phanSo;
   unsigned char mauXanh = danhSachMau[chiSoMau+2]*(1.0f - phanSo) + danhSachMau[chiSoMau+6]*phanSo;
   unsigned char mauDuc = danhSachMau[chiSoMau+3]*(1.0f - phanSo) + danhSachMau[chiSoMau+7]*phanSo;
   
   unsigned int mauSuyNoi = mauDo << 24 | mauLuc << 16 | mauXanh << 8 | mauDuc;
   
   return mauSuyNoi;
}
/*
void chonHuongDi( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem diemThichThu, short *huongX, short *huongY, unsigned char cachXa ) {

   short soCotDau = diemThichThu.x - cachXa;
   short soCotCuoi = diemThichThu.x + cachXa + 1;
   short soHangDau = diemThichThu.y - cachXa;
   short soHangCuoi = diemThichThu.y + cachXa + 1;
   
   if( soCotDau < 0 )
      soCotDau = 0;
   if( soCotCuoi >= beRong )
      soCotCuoi = beRong - 1;
   if( soHangDau < 0 )
      soHangDau = 0;
   if( soHangCuoi >= beCao )
      soHangCuoi = beCao - 1;

   // ---- xem điểm ảnh quanh

   // +-------->
   unsigned short soCot = soCotDau;
   unsigned short soHang = soHangDau;
   unsigned int diaChiAnh = (soCot + soHang*beRong) << 2;
   while( soCot < soCotCuoi ) {
      unsigned char doSang = anh[diaChiAnh];
      printf( "duoi: →(%d; %d) %d\n", soCot, soHang, doSang );
      soCot += 5;
      diaChiAnh += 20;
   }
   
   // ^
   // |
   // |
   // +
   soCot = soCotCuoi - 1;
   diaChiAnh = (soCot + soHang*beRong) << 2;
   while( soHang < soHangCuoi ) {
      unsigned char doSang = anh[diaChiAnh];
      printf( "phai ↑(%d; %d) %d  dc %d\n", soCot, soHang, doSang, diaChiAnh );
      soHang += 5;
      diaChiAnh += 5*beRong << 2;
   }

   // +-------->
   soCot = soCotDau;
   soHang = soHangCuoi - 1;
   diaChiAnh = (soCot + soHang*beRong) << 2;
   printf( "soHang %d  soCot %d  beRong %d  soHang*beRong %d\n", soHang, soCot, beRong, soHang*beRong );
   while( soCot < soCotCuoi ) {
      unsigned char doSang = anh[diaChiAnh];
      printf( "tren →(%d; %d) %d  dc %d\n", soCot, soHang, doSang, diaChiAnh );
      soCot += 5;
      diaChiAnh += 20;
   }
   
   // ^
   // |
   // |
   // +
   soCot = soCotDau;
   soHang = soHangDau;
   diaChiAnh = (soCot + soHang*beRong) << 2;
   while( soHang < soHangCuoi ) {
      unsigned char doSang = anh[diaChiAnh];
      printf( "phai ↑(%d; %d) %d\n", soCot, soHang, doSang );
      soHang += 5;
      diaChiAnh += 5*beRong << 2;
   }
}
*/


void rutDiemTuDanhSach( DiemGon **dauDanhSachDiem, DiemGon **diemHienTai ) {

   if( (*dauDanhSachDiem != NULL) && (*diemHienTai != NULL) ) {
      // ---- đầu danh sách điểm
      if( (*diemHienTai)->truoc == NULL ) {
         *dauDanhSachDiem = (*diemHienTai)->sau;
         DiemGon *diemSau = (*diemHienTai)->sau;
         free( *diemHienTai );
         *diemHienTai = (*diemHienTai)->sau;
      }
      // ---- cuối danh sách điểm
      else if( (*diemHienTai)->sau == NULL ) {
         DiemGon *diemTruoc = (*diemHienTai)->truoc;
         diemTruoc->sau = NULL;
         free( *diemHienTai );
         *diemHienTai = NULL;
      }
      // ---- giữa danh sách điểm
      else {
         DiemGon *diemTruoc = (*diemHienTai)->truoc;
         diemTruoc->sau = (*diemHienTai)->sau;
         free( *diemHienTai );
         *diemHienTai = diemTruoc->sau;
         (*diemHienTai)->truoc = diemTruoc;
      }
   }
}


DiemGon *timDiemTiep( DiemGon **dauDanhSachDiem, unsigned int cachXaToiDaBinh ) {

   if( *dauDanhSachDiem != NULL ) {
      // ---- rút điểm đề tiên trong mảng danh sách điểm
      DiemGon *diemDauNet = *dauDanhSachDiem;
      printf( ":::: dauDanhSachDiem %p  truoc %p  sau %p\n", *dauDanhSachDiem, (*dauDanhSachDiem)->truoc, (*dauDanhSachDiem)->sau );

      if( (*dauDanhSachDiem)->sau != NULL ) {
         *dauDanhSachDiem = (*dauDanhSachDiem)->sau;
         (*dauDanhSachDiem)->truoc = NULL;
      }
      // ---- nếu danh sách điểm chỉ có một điểm
      else {
         *dauDanhSachDiem = NULL;
         return NULL;
      }


      printf( "     dauDanhSachDiem %p  truoc %p  sau %p\n", *dauDanhSachDiem, (*dauDanhSachDiem)->truoc, (*dauDanhSachDiem)->sau );
      DiemGon *diemCuoiNet = diemDauNet;
      diemCuoiNet->truoc = NULL;
      diemCuoiNet->sau = NULL;

      // ---- tìm cùng chế độ của điểm bắt đầu
      unsigned char cucDoanDangTim = diemDauNet->cucDoan;
      
      unsigned char soBuocCat = 0;
      
      unsigned char chuaXong = kDUNG;
      while( chuaXong ) {
         DiemGon *diemGanNhat = NULL;
         printf( "\n   diemGanNhat %p  dauDanhSachDiem %p\n", diemGanNhat, *dauDanhSachDiem );
         unsigned int cachXaCuaGanNhatBinh = cachXaToiDaBinh << 1;
         
         DiemGon *diemHienTai = *dauDanhSachDiem;
         
         while( diemHienTai != NULL ) {
            printf( "     diemHienTai %p    truoc %p   sau %p\n", diemHienTai, diemHienTai->truoc, diemHienTai->sau );
            // ---- chỉ kiểm tra điểm cùng cực đoạn
            if( diemHienTai->cucDoan == cucDoanDangTim ) {
               short x = diemHienTai->x;
               short y = diemHienTai->y;
               short cachX = diemCuoiNet->x - x;
               short cachY = diemCuoiNet->y - y;
               unsigned int cachBinh = cachX*cachX + cachY*cachY;
               
               if( cachBinh < cachXaCuaGanNhatBinh ) {
                  cachXaCuaGanNhatBinh = cachBinh;
                  diemGanNhat = diemHienTai;
               }
            }
            
            diemHienTai = diemHienTai->sau;
         }
         
         // ---- nếu có điểm, rút từ danh sách điểm và kết nối trong nét
         if( diemGanNhat != NULL ) {
            // ---- kết nối điểm trước và sau điểm gần nhất
            DiemGon *diemTruocGanNhat = diemGanNhat->truoc;
            DiemGon *diemSauGanNhat = diemGanNhat->sau;
            
            printf( "   diemTruocGanNhat %p  diemSauGanNhat %p\n", diemTruocGanNhat, diemSauGanNhat );
            // NULL <---- *0 ----> NULL =====> dauDanhSach = NULL
            // NULL <---- *0 ----> *1   =====> dauDanhSach = *1
            // *0 <---- *1 ----> NULL  =====> *0 ----> NULL
            // *0 <---- *1 ----> *2 ====> *0 ----> *2
            
            // ---- xem nếu điểm gần nhất là điểm cuối cùng (không còn điểm nào nữa) trong danh sách
            if( (diemTruocGanNhat == NULL) && (diemSauGanNhat == NULL) )
               *dauDanhSachDiem = NULL;
            
            // ---- xem nếu điểm gần nhất là điểm đầu trong danh sách
            else if( (diemTruocGanNhat == NULL) && (diemSauGanNhat != NULL) ) {
               *dauDanhSachDiem = diemSauGanNhat;
               diemSauGanNhat->truoc = NULL;
            }
            
            // ---- xem nếu điểm gần nhất là điểm cuối (nhưng còn điểm) trong danh sách
            else if( (diemTruocGanNhat != NULL) && (diemSauGanNhat == NULL) ) {
               diemTruocGanNhat->sau = NULL;
            }
            
            // ---- giữa danh sách
            else {
               diemTruocGanNhat->sau = diemSauGanNhat;
               diemSauGanNhat->truoc = diemTruocGanNhat;
            }
            
            // ---- kèm điểm gần nhất vào nét
            printf( "0: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            diemGanNhat->truoc = diemCuoiNet;
            printf( "0a: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            diemGanNhat->sau = NULL;
            printf( "0b: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            diemCuoiNet->sau = diemGanNhat;
            printf( "0c: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            
            // ---- điểm mới bỏ và nét là điểm cuối mới
            diemCuoiNet = diemGanNhat;
            printf( "0d: diemGanNhat %p   (%d; %d)  truoc %p  sau %p  diemCuoiNet %p  truoc %p  sau %p\n", diemGanNhat, diemGanNhat->x, diemGanNhat->y, diemGanNhat->truoc, diemGanNhat->sau, diemCuoiNet, diemCuoiNet->truoc, diemCuoiNet->sau );
            
         }
         else {
            chuaXong = kSAI;
         }
      }
      printf( "  ---> diemDauNet %p  truoc %p  sau %p\n", diemDauNet, diemDauNet->truoc, diemDauNet->sau  );
      return diemDauNet;
   }
   else // ---- nếu đầu danh sách == NULL
      return NULL;
}
