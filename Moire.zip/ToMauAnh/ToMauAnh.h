/* TôMàuẢnh.h */


#pragma once

unsigned char *toMauAnh( unsigned char *anh, unsigned int beRong, unsigned int beCao, unsigned int *beRongXuat, unsigned int *beCaoXuat );
