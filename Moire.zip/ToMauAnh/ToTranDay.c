/* TôTrànĐầy.c */

#include "ToTranDay.h"

/* tô tràn đầy - 4 hướng */
void toTranDay( float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned short viTriX, unsigned short viTriY, float giaTriTo ) {
   
   unsigned short danhSachDauX[2048];
   unsigned short danhSachDauY[2048];
   unsigned short danhSachCuoiX[2048];
   unsigned short danhSachCuoiY[2048];
   unsigned short soLuongDiemKiemTra = 0;
   
   float giaTriDiemAnh = anhFloat[viTriX + viTriY*beRong];
   
   if( giaTriDiemAnh == giaTriTo )
      return;
   
   // ---- giữ giá trị cho điểm khởi đều
   float giaTriKhoiDau = giaTriDiemAnh;
   int xTrai = viTriX;
   int xPhai = viTriX;
   
   // ---- quét trái
   unsigned int diaChiAnh;
   if( xTrai > 0 ) {
      diaChiAnh = xTrai + viTriY*beRong;
      
      while( (anhFloat[diaChiAnh] == giaTriKhoiDau) && (xTrai > 0) ) {
         xTrai--;
         diaChiAnh--;
      }
      xTrai++;
   }
   
   // ---- quét phải
   if( xPhai < beRong-1 ) {
      diaChiAnh = xPhai + viTriY*beRong;
      while( (anhFloat[diaChiAnh] == giaTriKhoiDau) && (xPhai < beRong-1) ) {
         xPhai++;
         diaChiAnh++;
      }
   }
   
   danhSachDauX[0] = xTrai;
   danhSachDauY[0] = viTriY;
   danhSachCuoiX[0] = xPhai;
   danhSachCuoiY[0] = viTriY;
   soLuongDiemKiemTra++;
   
   //   printf( "ToTranDay: xTrai %d  viTriY %d  xPhai %d  viTriY %d  soLuongDiemKiemTra %d\n", xTrai, viTriY, xPhai, viTriY, soLuongDiemKiemTra );
   
   unsigned short soLan = 0;
   while( soLuongDiemKiemTra ) {
      
      // ---- rút điểm ảnh từ danh sách
      soLuongDiemKiemTra--;
      int dauX = danhSachDauX[soLuongDiemKiemTra];
      int dauY = danhSachDauY[soLuongDiemKiemTra];
      int cuoiX = danhSachCuoiX[soLuongDiemKiemTra];
      int cuoiY = danhSachCuoiY[soLuongDiemKiemTra];
      //printf( "--- soLan %d  dau (%d; %d)  cuoi (%d; %d)\n", soLan, dauX, dauY, cuoiX, cuoiY );
      // ---- xem có điểm để tô phía trước và phía sau
      //      ooooooooooooooooooooooooooooooooooo    <--- hàng tô
      //   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  <--- chưa tô
      diaChiAnh = dauX + dauY*beRong;
      while( (dauX > 0) && (anhFloat[diaChiAnh - 1] == giaTriKhoiDau) ) {
         dauX--;
         diaChiAnh--;
      }
      diaChiAnh = cuoiX + dauY*beRong;
      while( (cuoiX < beRong ) && (anhFloat[diaChiAnh] == giaTriKhoiDau) ) {
         cuoiX++;
         diaChiAnh++;
      }
      
      //      printf( "--- soLan %d  dau (%d; %d)  cuoi (%d; %d)\n", soLan, dauX, dauY, cuoiX, cuoiY );
      
      unsigned int lienTiepTren = 0;
      unsigned int lienTiepDuoi = 0;
      
      // ----
      diaChiAnh = dauX + dauY*beRong;
      
      while( dauX < cuoiX ) {
         
         // ---- tô điểm ảnh
         anhFloat[diaChiAnh] = giaTriTo;
         
         // ---- xem hàng dưới
         if( dauY > 0 ) {
            if( anhFloat[diaChiAnh - beRong] == giaTriKhoiDau ) {
               lienTiepDuoi++;
            }
            // ---- nếu == không, bỏ đoạn điểm ảnh và danh sach nếu li
            else if( lienTiepDuoi ) {
               danhSachDauX[soLuongDiemKiemTra] = dauX - lienTiepDuoi;
               danhSachDauY[soLuongDiemKiemTra] = dauY - 1;
               danhSachCuoiX[soLuongDiemKiemTra] = dauX;
               danhSachCuoiY[soLuongDiemKiemTra] = dauY - 1;
               soLuongDiemKiemTra++;
               lienTiepDuoi = 0;
            }
         }
         
         if( dauY < beCao - 1 ) {
            if( anhFloat[diaChiAnh + beRong] == giaTriKhoiDau ) {
               lienTiepTren++;
            }
            // ---- nếu không, bỏ đoạn điểm ảnh và danh sach nếu li
            else if( lienTiepTren ) {
               danhSachDauX[soLuongDiemKiemTra] = dauX - lienTiepTren;
               danhSachDauY[soLuongDiemKiemTra] = dauY + 1;
               danhSachCuoiX[soLuongDiemKiemTra] = dauX;
               danhSachCuoiY[soLuongDiemKiemTra] = dauY - 1;
               soLuongDiemKiemTra++;
               lienTiepTren = 0;
            }
         }
         
         //         printf( "soLan %d  dauX %d y %d lienTiepDuoi %d  Tren %d  soLuongDiemKiemTra %d\n", soLan, dauX, dauY, lienTiepDuoi, lienTiepTren, soLuongDiemKiemTra );
         diaChiAnh++;
         dauX++;
         
         // ---- xem nếu đến hết đoạn mà còn có điểm ảnh ở dưới và trên để tô
         if( dauX == cuoiX ) {
            if( lienTiepDuoi ) {
               danhSachDauX[soLuongDiemKiemTra] = dauX - lienTiepDuoi;
               danhSachDauY[soLuongDiemKiemTra] = dauY - 1;
               danhSachCuoiX[soLuongDiemKiemTra] = dauX;
               danhSachCuoiY[soLuongDiemKiemTra] = dauY - 1;
               soLuongDiemKiemTra++;
            }
            if( lienTiepTren ) {
               danhSachDauX[soLuongDiemKiemTra] = dauX - lienTiepTren;
               danhSachDauY[soLuongDiemKiemTra] = dauY + 1;
               danhSachCuoiX[soLuongDiemKiemTra] = dauX;
               danhSachCuoiY[soLuongDiemKiemTra] = dauY - 1;
               soLuongDiemKiemTra++;
            }
         }
      }
      
   }
   
}
