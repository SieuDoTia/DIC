/*  TôTrànĐầy.h  */

#pragma once

void toTranDay( float *anhFloat, unsigned int beRong, unsigned int beCao, unsigned short viTriX, unsigned short viTriY, float giaTriTo );
