/* ChépẢnh.c */

#include "ChepAnh.h"
#include "../HangSo.h"


void chepAnhVaoAnh( unsigned char *anhChep, unsigned int beRongAnhChep, unsigned int beCaoAnhChep,
                   unsigned char *anhXuat, unsigned int beRongXuat, unsigned int beCaoXuat, unsigned short dichX, unsigned short dichY ) {
   
   // ---- nếu ở ngoài phạm vi ảnh, không cần vẽ gì
   if( dichX >= beRongXuat )
      return;
   if( dichY >= beCaoXuat )
      return;
   
   // ---- nếu một phần ở ngoài phạm vi ảnh, không cần vẽ phần đó
   unsigned int soCotCuoi = beRongAnhChep;
   if( beRongAnhChep + dichX > beRongXuat )
      soCotCuoi = beRongXuat - dichX;
   
   unsigned int soHangCuoi = beCaoAnhChep;
   if( beCaoAnhChep + dichY > beCaoXuat )
      soHangCuoi = beCaoXuat - dichY;

   // ---- chép
   unsigned int diaChiAnhChep = 0;
   
   unsigned short soHangAnhChep = 0;
   while( soHangAnhChep < soHangCuoi ) {
      unsigned int diaChiAnhXuat = ((dichY + soHangAnhChep)*beRongXuat + dichX) << 2;
      unsigned soCotAnhChep = 0;
      while( soCotAnhChep < soCotCuoi ) {
         
         anhXuat[diaChiAnhXuat] = anhChep[diaChiAnhChep];
         anhXuat[diaChiAnhXuat+1] = anhChep[diaChiAnhChep+1];
         anhXuat[diaChiAnhXuat+2] = anhChep[diaChiAnhChep+2];
         anhXuat[diaChiAnhXuat+3] = anhChep[diaChiAnhChep+3];
         diaChiAnhChep += 4;
         diaChiAnhXuat += 4;
         soCotAnhChep++;
      }
      
      soHangAnhChep++;
   }
}

//     1 x 4     4 x 4       4 x 4        1 x 4
//  [ Vectơ ] [         ] [         ]   [ Vectơ ]
//            [ ma trận ] [ ma trận ] =
//            [         ] [         ]
//            [         ] [         ]
void chepAnhVaoAnhVoiMaTran( unsigned char *anhDoSang, unsigned char *anhChep, unsigned int beRongAnhChep, unsigned int beCaoAnhChep,
               unsigned char *anhXuat, unsigned int beRongXuat, unsigned int beCaoXuat,
                            unsigned short dichX, unsigned short dichY, float *maTran ) {

   // ---- chép

   
   short soHangAnhChep = beCaoAnhChep - 1;
   while( soHangAnhChep > -1 ) {
      unsigned int diaChiAnhChep = soHangAnhChep*beRongAnhChep << 2;
      unsigned int diaChiAnhXuat = ((dichY + soHangAnhChep)*beRongXuat + dichX) << 2;
      unsigned soCotAnhChep = 0;
      while( soCotAnhChep < beRongAnhChep ) {
         
         // ---- nhân ma trận
         short x = soCotAnhChep*maTran[0] + soHangAnhChep*maTran[4] + anhDoSang[diaChiAnhChep]*maTran[8] + dichX;
         short y = soCotAnhChep*maTran[1] + soHangAnhChep*maTran[5] + anhDoSang[diaChiAnhChep]*maTran[9] + dichY;
         short z = soCotAnhChep*maTran[2] + soHangAnhChep*maTran[6] + anhDoSang[diaChiAnhChep]*maTran[10];
         
 //        printf( "  chep anh (%d; %d)\n", x, y);
         
         // ---- tô điểm ảnh
         unsigned char veDiemAnh = kDUNG;
         if( x < 0 )
            veDiemAnh = kSAI;
         else if( x >= beRongXuat )
            veDiemAnh = kSAI;
         else if( y < 0 )
            veDiemAnh = kSAI;
         else if( y >= beCaoXuat )
            veDiemAnh = kSAI;
         
         if( veDiemAnh ) {
            unsigned int diaChiAnhXuat = (x + beRongXuat*(y)) << 2;
            anhXuat[diaChiAnhXuat] = anhChep[diaChiAnhChep];
            anhXuat[diaChiAnhXuat+1] = anhChep[diaChiAnhChep+1];
            anhXuat[diaChiAnhXuat+2] = anhChep[diaChiAnhChep+2];
            anhXuat[diaChiAnhXuat+3] = anhChep[diaChiAnhChep+3];
         }
         diaChiAnhChep += 4;

         soCotAnhChep++;
      }
      
      soHangAnhChep--;
   }
}
