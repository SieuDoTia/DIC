/* ChépẢnh.c */

#include "ChepAnh.h"
#include "../HangSo.h"


void chepAnhVaoAnh( unsigned char *anhChep, unsigned int beRongAnhChep, unsigned int beCaoAnhChep,
                   unsigned char *anhXuat, unsigned int beRongXuat, unsigned int beCaoXuat, unsigned short dichX, unsigned short dichY ) {
   
   // ---- nếu ở ngoài phạm vi ảnh, không cần vẽ gì
   if( dichX >= beRongXuat )
      return;
   if( dichY >= beCaoXuat )
      return;
   
   // ---- nếu một phần ở ngoài phạm vi ảnh, không cần vẽ phần đó
   unsigned int soCotCuoi = beRongAnhChep;
   if( beRongAnhChep + dichX > beRongXuat )
      soCotCuoi = beRongXuat - dichX;
   
   unsigned int soHangCuoi = beCaoAnhChep;
   if( beCaoAnhChep + dichY > beCaoXuat )
      soHangCuoi = beCaoXuat - dichY;

   
//   printf( "beRongAnhChep %d  beCaoAnhChep %d\n", beRongAnhChep, beCaoAnhChep );
   
   // ---- chép
   unsigned int diaChiAnhChep = 0;
   
   unsigned short soHangAnhChep = 0;
   while( soHangAnhChep < soHangCuoi ) {
      unsigned int diaChiAnhXuat = ((dichY + soHangAnhChep)*beRongXuat + dichX) << 2;
      
      // ---- phải tính địa chỉ mỗi hàng vì có thể không đủ ảnh xuất cột để chép hết hàng
      unsigned int diaChiAnhChep = soHangAnhChep*beRongAnhChep << 2;

      unsigned soCotAnhChep = 0;
      while( soCotAnhChep < soCotCuoi ) {
         
         anhXuat[diaChiAnhXuat] = anhChep[diaChiAnhChep];
         anhXuat[diaChiAnhXuat+1] = anhChep[diaChiAnhChep+1];
         anhXuat[diaChiAnhXuat+2] = anhChep[diaChiAnhChep+2];
         anhXuat[diaChiAnhXuat+3] = anhChep[diaChiAnhChep+3];
         diaChiAnhChep += 4;
         diaChiAnhXuat += 4;
         soCotAnhChep++;
      }
      
      soHangAnhChep++;
   }
}

//     1 x 4     4 x 4       4 x 4        1 x 4
//  [ Vectơ ] [         ] [         ]   [ Vectơ ]
//            [ ma trận ] [ ma trận ] =
//            [         ] [         ]
//            [         ] [         ]
void chepAnhVaoAnhVoiMaTran_dungDoSangChoZ( unsigned char *anhDoSang, unsigned char *anhChep, unsigned int beRongAnhChep, unsigned int beCaoAnhChep,
               unsigned char *anhXuat, unsigned int beRongXuat, unsigned int beCaoXuat,
                            unsigned short dichX, unsigned short dichY, float *maTran ) {

   // ---- vẽ bề mặt trên
   short soHangAnhChep = beCaoAnhChep - 1;
   while( soHangAnhChep > -1 ) {
      unsigned int diaChiAnhChep = soHangAnhChep*beRongAnhChep << 2;
      unsigned int diaChiAnhXuat = ((dichY + soHangAnhChep)*beRongXuat + dichX) << 2;
      unsigned soCotAnhChep = 0;
      while( soCotAnhChep < beRongAnhChep ) {
         
         // ---- nhân ma trận
         short x = soCotAnhChep*maTran[0] + soHangAnhChep*maTran[4] + anhDoSang[diaChiAnhChep]*maTran[8] + dichX;
         short y = soCotAnhChep*maTran[1] + soHangAnhChep*maTran[5] + anhDoSang[diaChiAnhChep]*maTran[9] + dichY;
 //        short z = soCotAnhChep*maTran[2] + soHangAnhChep*maTran[6] + anhDoSang[diaChiAnhChep]*maTran[10];
         
 //        printf( "  chep anh (%d; %d)\n", x, y);
         
         // ---- tô điểm ảnh
         unsigned char veDiemAnh = kDUNG;
         if( x < 0 )
            veDiemAnh = kSAI;
         else if( x >= beRongXuat )
            veDiemAnh = kSAI;
         else if( y < 0 )
            veDiemAnh = kSAI;
         else if( y >= beCaoXuat )
            veDiemAnh = kSAI;
         
         if( veDiemAnh ) {
            unsigned int diaChiAnhXuat = (x + beRongXuat*(y)) << 2;
            anhXuat[diaChiAnhXuat] = anhChep[diaChiAnhChep];
            anhXuat[diaChiAnhXuat+1] = anhChep[diaChiAnhChep+1];
            anhXuat[diaChiAnhXuat+2] = anhChep[diaChiAnhChep+2];
            anhXuat[diaChiAnhXuat+3] = anhChep[diaChiAnhChep+3];
         }
         diaChiAnhChep += 4;

         soCotAnhChep++;
      }
      
      soHangAnhChep--;
   }
   
   // ---- vẽ bề mặt trước
   unsigned int diaChiAnhDoSang = 0;
   unsigned short soCotAnhDoSang = 0;
   while( soCotAnhDoSang < beRongAnhChep ) {
      unsigned short doSang = anhDoSang[diaChiAnhDoSang];
      unsigned short doCao = 0;
      while( doCao < doSang ) {
         
         // ---- nhân ma trận
         short x = soCotAnhDoSang*maTran[0] + doCao*maTran[8] + dichX;
         short y = soCotAnhDoSang*maTran[1] + doCao*maTran[9] + dichY;

         // ---- tô điểm ảnh
         unsigned char veDiemAnh = kDUNG;
         if( x < 0 )
            veDiemAnh = kSAI;
         else if( x >= beRongXuat )
            veDiemAnh = kSAI;
         else if( y < 0 )
            veDiemAnh = kSAI;
         else if( y >= beCaoXuat )
            veDiemAnh = kSAI;
         
         if( veDiemAnh ) {
            unsigned int diaChiAnhXuat = (x + beRongXuat*(y)) << 2;
            anhXuat[diaChiAnhXuat] = doCao << 3;
            anhXuat[diaChiAnhXuat+1] = doCao;
            anhXuat[diaChiAnhXuat+2] = doCao << 1;
            anhXuat[diaChiAnhXuat+3] = 0xff;
         }
         
         doCao++;
      }
      diaChiAnhDoSang += 4;
      soCotAnhDoSang++;
   }
   
   
   // ---- vẽ bề mặt phải
   diaChiAnhDoSang = (beRongAnhChep - 1) << 2;
   soCotAnhDoSang = (beRongAnhChep - 1);
   unsigned short soHangAnhDoSang = 0;
   while( soHangAnhDoSang < beCaoAnhChep ) {
      unsigned short doSang = anhDoSang[diaChiAnhDoSang];
      unsigned short doCao = 0;
      while( doCao < doSang ) {
         
         // ---- nhân ma trận
         short x = soCotAnhDoSang*maTran[0] + soHangAnhDoSang*maTran[4] + doCao*maTran[8] + dichX;
         short y = soCotAnhDoSang*maTran[1] + soHangAnhDoSang*maTran[5] + doCao*maTran[9] + dichY;
         
         // ---- tô điểm ảnh
         unsigned char veDiemAnh = kDUNG;
         if( x < 0 )
            veDiemAnh = kSAI;
         else if( x >= beRongXuat )
            veDiemAnh = kSAI;
         else if( y < 0 )
            veDiemAnh = kSAI;
         else if( y >= beCaoXuat )
            veDiemAnh = kSAI;
         
         if( veDiemAnh ) {
            unsigned int diaChiAnhXuat = (x + beRongXuat*(y)) << 2;
            anhXuat[diaChiAnhXuat] = doCao << 3;
            anhXuat[diaChiAnhXuat+1] = doCao;
            anhXuat[diaChiAnhXuat+2] = doCao << 1;
            anhXuat[diaChiAnhXuat+3] = 0xff;
         }
         
         doCao++;
      }
      diaChiAnhDoSang += beRongAnhChep << 2;
      soHangAnhDoSang++;
   }

}

/*
void chepAnhVaoAnhVoiMaTran( unsigned char *anhChep, unsigned int beRongAnhChep, unsigned int beCaoAnhChep,
                            unsigned char *anhXuat, unsigned int beRongXuat, unsigned int beCaoXuat,
                            unsigned short dichX, unsigned short dichY, float *maTran ) {
   
   // ---- chép
   short soHangAnhChep = beCaoAnhChep - 1;
   while( soHangAnhChep > -1 ) {
      unsigned int diaChiAnhChep = soHangAnhChep*beRongAnhChep << 2;
      unsigned int diaChiAnhXuat = ((dichY + soHangAnhChep)*beRongXuat + dichX) << 2;
      unsigned soCotAnhChep = 0;
      while( soCotAnhChep < beRongAnhChep ) {
         
         // ---- nhân ma trận
         short x = soCotAnhChep*maTran[0] + soHangAnhChep*maTran[4] + dichX;
         short y = soCotAnhChep*maTran[1] + soHangAnhChep*maTran[5] + dichY;
   //      short z = soCotAnhChep*maTran[2] + soHangAnhChep*maTran[6];
         
         printf( "  chep anh (%d; %d)   beRongXuat %d beCaoXuat %d\n", x, y, beRongXuat, beCaoXuat );
         
         // ---- tô điểm ảnh
         unsigned char veDiemAnh = kDUNG;
         if( x < 0 )
            veDiemAnh = kSAI;
         else if( x >= beRongXuat )
            veDiemAnh = kSAI;
         else if( y < 0 )
            veDiemAnh = kSAI;
         else if( y >= beCaoXuat )
            veDiemAnh = kSAI;
         
         if( veDiemAnh ) {
            unsigned int diaChiAnhXuat = (x + beRongXuat*(y)) << 2;
            anhXuat[diaChiAnhXuat] = anhChep[diaChiAnhChep];
            anhXuat[diaChiAnhXuat+1] = anhChep[diaChiAnhChep+1];
            anhXuat[diaChiAnhXuat+2] = anhChep[diaChiAnhChep+2];
            anhXuat[diaChiAnhXuat+3] = anhChep[diaChiAnhChep+3];
         }
         diaChiAnhChep += 4;
         
         soCotAnhChep++;
      }
      
      soHangAnhChep--;
   }
} */
