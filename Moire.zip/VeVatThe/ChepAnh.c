/* ChépẢnh.c */

#include "ChepAnh.h"


void chepAnhVaoAnh( unsigned char *anhToMau, unsigned int beRongAnhTo, unsigned int beCaoAnhTo,
                   unsigned char *anhXuat, unsigned int beRongXuat, unsigned int beCaoXuat, unsigned short dichX, unsigned short dichY ) {
   
   // ---- nếu ở ngoài phạm vi ảnh, không cần vẽ gì
   if( dichX >= beRongXuat )
      return;
   if( dichY >= beCaoXuat )
      return;
   
   // ---- nếu một phần ở ngoài phạm vi ảnh, không cần vẽ phần đó
   unsigned int soCotCuoi = beRongAnhTo;
   if( beRongAnhTo + dichX > beRongXuat )
      soCotCuoi = beRongXuat - dichX;
   
   unsigned int soHangCuoi = beCaoAnhTo;
   if( beCaoAnhTo + dichY > beCaoXuat )
      soHangCuoi = beCaoXuat - dichY;

   // ---- chép
   unsigned int diaChiAnhToMau = 0;
   
   unsigned short soHangAnhTo = 0;
   while( soHangAnhTo < soHangCuoi ) {
      unsigned int diaChiAnhXuat = ((dichY + soHangAnhTo)*beRongXuat + dichX) << 2;
      unsigned soCotAnhTo = 0;
      while( soCotAnhTo < soCotCuoi ) {
         
         anhXuat[diaChiAnhXuat] = anhToMau[diaChiAnhToMau];
         anhXuat[diaChiAnhXuat+1] = anhToMau[diaChiAnhToMau+1];
         anhXuat[diaChiAnhXuat+2] = anhToMau[diaChiAnhToMau+2];
         anhXuat[diaChiAnhXuat+3] = anhToMau[diaChiAnhToMau+3];
         diaChiAnhToMau += 4;
         diaChiAnhXuat += 4;
         soCotAnhTo++;
      }
      
      soHangAnhTo++;
   }
}
