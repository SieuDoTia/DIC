/* ChépẢnh.h */

#pragma once

void chepAnhVaoAnh( unsigned char *anhToMau, unsigned int beRongAnhTo, unsigned int beCaoAnhTo,
                   unsigned char *anhXuat, unsigned int beRongXuat, unsigned int beCaoXuat, unsigned short dichX, unsigned short dichY );

void chepAnhVaoAnhVoiMaTran( unsigned char *anhDoSang, unsigned char *anhChep, unsigned int beRongAnhChep, unsigned int beCaoAnhChep,
                            unsigned char *anhXuat, unsigned int beRongXuat, unsigned int beCaoXuat,
                            unsigned short dichX, unsigned short dichY, float *maTran );
