/* UTF8_UTF32.c */

#include <stdio.h>
#include "UTF8_UTF32.h"


unsigned int UTF8_sang_UTF32( char *xau, unsigned char *soLuongByte ) {
   
   unsigned char byte0;   // byte 0
   unsigned char byte1;   // byte 1 (nếu cần)
   unsigned char byte2;   // byte 2 (nếu cần)
   unsigned char byte3;   // byte 3 (nếu cần)
   
   if( xau == NULL ) {
      printf( "UTF8_sang_UTF32: SAI LẦM vấn đề xâu\n" );
      *soLuongByte = 0;
      return kKY_TU_SAI_LAM;
   }
   
   // ---- lấy byte đầu
   byte0 = *xau;
   xau++;

   if( byte0 < 0x80 ) {
      *soLuongByte = 1;
      return byte0;
   }
   else if( (byte0 > 0xc1) && (byte0 < 0xe0) ) { // dãy hai byte
      byte1 = *xau;

      if( (byte1 > 0x7f) && (byte1 < 0xc0 ) ) {
         *soLuongByte = 2;
         return (byte0 & 0x1f) << 6 | (byte1 & 0x3f);
      }
      else {
         printf( "UTF8_sang_UTF32: SAI LẦM phân tích dãy byte UTF8 tại byte thứ 2/2: %x %x\n", byte0, byte1 );
         *soLuongByte = 2;
         return kKY_TU_SAI_LAM;
      }
   }
   else if( (byte0 > 0xdf) && (byte0 < 0xf0) ) { // dãy ba byte
      byte1 = *xau;
      xau++;
      if( (byte1 > 0x7f) && (byte1 < 0xc0 ) ) {
         byte2 = *xau;

         if( (byte2 > 0x7f) && ( byte2 < 0xc0) ) {
            *soLuongByte = 3;
            return (byte0 & 0x0f) << 12 | (byte1 & 0x3f) << 6 | (byte2 & 0x3f);
         }
         else {
            printf( "UTF8_sang_UTF32: SAI LẦM phân tích dãy byte UTF8 tại byte thứ 3/3: %x %x %x\n", byte0, byte1, byte2 );
            *soLuongByte = 3;
            return kKY_TU_SAI_LAM;
         }
      }
      else {
         printf( "UTF8_sang_UTF32: SAI LẦM phân tích dãy byte UTF8 tại byte thứ 2/3: %x %x %x\n", byte0, byte1, byte2 );
         return kKY_TU_SAI_LAM;
      }
   }
   else if( (byte0 > 0xdf) && (byte0 < 0xf0) ) { // dãy bốn byte
      byte1 = *xau;
      xau++;

      if( (byte1 > 0x7f) && (byte1 < 0xc0 ) ) {
         byte2 = *xau;
         xau++;

         if( (byte2 > 0x7f) && ( byte2 < 0xc0) ) {
            byte3 = *xau;

            if( (byte3 > 0x7f) && ( byte3 < 0xc0) ) {
               *soLuongByte = 4;
               return (byte0 & 0x07) << 17 | (byte1 & 0x3f) << 12 | (byte2 & 0x3f) << 6 | (byte3 & 0x3f);
            }
            else {
               printf( "UTF8_sang_UTF32: SAI LẦM phân tích dãy byte UTF8 tại byte thứ 4/4: %x %x %x %x\n", byte0, byte1, byte2, byte3 );
               *soLuongByte = 4;
               return kKY_TU_SAI_LAM;
            }
         }
         else {
            printf( "UTF8_sang_UTF32: SAI LẦM phân tích dãy byte UTF8 tại byte thứ 3/4: %x %x %x %x\n", byte0, byte1, byte2, byte3 );
            *soLuongByte = 4;
            return kKY_TU_SAI_LAM;
         }
      }
      else {
         printf( "UTF8_sang_UTF32: SAI LẦM phân tích dãy byte UTF8 tại byte thứ 2/4: %x %x %x %x\n", byte0, byte1, byte2, byte3 );
         *soLuongByte = 4;
         return kKY_TU_SAI_LAM;
      }
   }
   else {
      printf( "UTF8_sang_UTF32: SAI LẦM phân tích dãy byte UTF8 tại byte thứ 1/1: %x\n", byte0 );
      *soLuongByte = 1;
      return kKY_TU_SAI_LAM;
   }

}
