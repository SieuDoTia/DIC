/* UTF8_UTF32.h */

#pragma once

#define kKY_TU_SAI_LAM  0xfffd    //

unsigned int UTF8_sang_UTF32( char *xau, unsigned char *soLuongByte );
