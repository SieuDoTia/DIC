/* VẽChữNhật.c */

#include <math.h>    // cho hàm floorf()
#include "../ChuNhat.h"
#include "VeChuNhat.h"

void veChuNhat( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, ChuNhat chuNhat, unsigned int mau ) {
   
   // ---- kiểm tra chữ nhật không đi ra ngoài ảnh
   if( chuNhat.trai < 0 )
      chuNhat.trai = 0;
   
   if( chuNhat.phai > beRongAnh )
      chuNhat.phai = beRongAnh;
   
   if( chuNhat.duoi < 0 )
      chuNhat.duoi = 0;
   
   if( chuNhat.tren > beCaoAnh )
      chuNhat.tren = beCaoAnh;
   
   unsigned char mauDo = mau >> 24;
   unsigned char mauLuc = mau >> 16;
   unsigned char mauXanh = mau >> 8;
   unsigned char doDuc = mau;
   
   unsigned short soHang = chuNhat.duoi;
   
   while( soHang < chuNhat.tren ) {
      
      unsigned soCot = chuNhat.trai;
      unsigned int diaChiAnh = (beRongAnh*soHang + soCot) << 2;
      
      while( soCot < chuNhat.phai ) {
         anh[diaChiAnh] = mauDo;
         anh[diaChiAnh + 1] = mauLuc;
         anh[diaChiAnh + 2] = mauXanh;
         
         diaChiAnh += 4;
         soCot++;
      }
      
      soHang++;
   }
}
