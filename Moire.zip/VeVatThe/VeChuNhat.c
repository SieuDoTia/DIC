/* VẽChữNhật.c */

#include <math.h>    // cho hàm floorf()
#include "../ChuNhat.h"
#include "VeChuNhat.h"

void veChuNhat( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, ChuNhat chuNhat, unsigned int mau ) {
   
   // ---- kiểm tra chữ nhật không đi ra ngoài ảnh
   if( chuNhat.trai < 0 )
      chuNhat.trai = 0;
   
   if( chuNhat.phai > beRongAnh )
      chuNhat.phai = beRongAnh;
   
   if( chuNhat.duoi < 0 )
      chuNhat.duoi = 0;
   
   if( chuNhat.tren > beCaoAnh )
      chuNhat.tren = beCaoAnh;
   
   unsigned char mauDo = mau >> 24;
   unsigned char mauLuc = mau >> 16;
   unsigned char mauXanh = mau >> 8;
   unsigned char doDuc = mau;
   unsigned char nghichDoDuc = 255 - mau;
   
   unsigned short soHang = chuNhat.duoi;
   
   while( soHang < chuNhat.tren ) {
      
      unsigned soCot = chuNhat.trai;
      unsigned int diaChiAnh = (beRongAnh*soHang + soCot) << 2;
      
      while( soCot < chuNhat.phai ) {
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;;
         anh[diaChiAnh + 1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh + 2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;

         diaChiAnh += 4;
         soCot++;
      }
      
      soHang++;
   }
}
