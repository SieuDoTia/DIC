/* VẽChữNhật.h */

void veChuNhat( unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh, ChuNhat chuNhat, unsigned int mau );
