/* VẽĐường.c */

#include "VeDuong.h"

// Giải thuật Bresenham
void veDuong( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem diem0, Diem diem1, unsigned int mau ) {
   
   unsigned char mauDo = mau >> 24;
   unsigned char mauLuc = mau >> 16;
   unsigned char mauXanh = mau >> 8;
   unsigned char doDuc = mau;
   unsigned char nghichDoDuc = 255 - mau;
   
   short cachX = diem1.x - diem0.x;
   short cachY = diem1.y - diem0.y;
   //   printf( " cach %d %d\n", cachX, cachY );
   
   // ---- ∆x < 0; ∆y < 0 đổi thành ∆x > 0; ∆y > 0
   if( (cachX <= 0) && (cachY <= 0) ) {
      //     printf( " ...dang trao doi\n");
      cachX = -cachX;
      cachY = -cachY;
      short so_x = diem0.x;
      short so_y = diem0.y;
      diem0.x = diem1.x;
      diem0.y = diem1.y;
      diem1.x = so_x;
      diem1.y = so_y;
   }
   else if( (cachX > 0) && (cachY < 0) ) {
      cachX = -cachX;
      cachY = -cachY;
      short so_x = diem0.x;
      short so_y = diem0.y;
      diem0.x = diem1.x;
      diem0.y = diem1.y;
      diem1.x = so_x;
      diem1.y = so_y;
   }
   //   printf( " (sau trao doi) cach %d %d  diem0 %d %d   diem1 %d %d\n", cachX, cachY, diem0.x, diem0.y, diem1.x, diem1.y );
   
   short x = diem0.x;
   short y = diem0.y;
   
   if( (cachX == 0) && (cachY != 0) ) {  // đường dọc
      while( y <= diem1.y ) {
         unsigned int diaChiAnh = (beRong*y + x) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         y++;
      }
   }
   else if( (cachX != 0) && (cachY == 0) ) {  // đường ngang
      while( x <= diem1.x ) {
         unsigned int diaChiAnh = (beRong*y + x) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         x++;
      }
   }
   
   else {
      if( cachX > 0 && cachY > 0 ) {  // ---- ∆x > 0; ∆y > 0
         if( cachY <= cachX ) {
            short saiLam = (cachY << 1) - cachX;
            
            while( x <= diem1.x ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
               anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
               anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
               
               if( saiLam > 0 ) {
                  y++;
                  saiLam -= (cachX << 1);
               }
               saiLam += cachY << 1;
               
               x++;
            }
         }
         else {
            short saiLam = (cachX << 1) - cachY;
            
            while( y <= diem1.y ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
               anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
               anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
               
               if( saiLam > 0 ) {
                  x++;
                  saiLam -= (cachY << 1);
               }
               saiLam += cachX << 1;
               
               y++;
            }
         }
      }
      else {           // ---- ∆x < 0; ∆y > 0
         short cachX_tuyetDoi = -cachX;
         if( cachY <= cachX_tuyetDoi ) {
            short saiLam = (cachY << 1) + cachX;
            
            while( x >= diem1.x ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
               anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
               anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
               
               if( saiLam > 0 ) {
                  y++;
                  saiLam += (cachX << 1);
               }
               saiLam += cachY << 1;
               
               x--;
            }
         }
         else {
            short saiLam = -(cachX << 1) - cachY;
            
            while( y <= diem1.y ) {
               unsigned int diaChiAnh = (beRong*y + x) << 2;
               anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
               anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
               anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
               
               if( saiLam > 0 ) {
                  x--;
                  saiLam -= (cachY << 1);
               }
               saiLam -= cachX << 1;
               
               y++;
               
            }
            
         }
      }
      
   }
}


void veDuongCap( float *anh, unsigned int beRong, unsigned int beCao, Diem diem0, Diem diem1, float cap ) {
   
   short cachX = diem1.x - diem0.x;
   short cachY = diem1.y - diem0.y;
   //   printf( " cach %d %d\n", cachX, cachY );
   
   // ---- ∆x < 0; ∆y < 0 đổi thành ∆x > 0; ∆y > 0
   if( (cachX <= 0) && (cachY <= 0) ) {
      //     printf( " ...dang trao doi\n");
      cachX = -cachX;
      cachY = -cachY;
      short so_x = diem0.x;
      short so_y = diem0.y;
      diem0.x = diem1.x;
      diem0.y = diem1.y;
      diem1.x = so_x;
      diem1.y = so_y;
   }
   else if( (cachX > 0) && (cachY < 0) ) {
      cachX = -cachX;
      cachY = -cachY;
      short so_x = diem0.x;
      short so_y = diem0.y;
      diem0.x = diem1.x;
      diem0.y = diem1.y;
      diem1.x = so_x;
      diem1.y = so_y;
   }
   //   printf( " (sau trao doi) cach %d %d  diem0 %d %d   diem1 %d %d\n", cachX, cachY, diem0.x, diem0.y, diem1.x, diem1.y );
   
   short x = diem0.x;
   short y = diem0.y;
   
   if( (cachX == 0) && (cachY != 0) ) {  // đường dọc
      while( y <= diem1.y ) {
         unsigned int diaChiAnh = beRong*y + x;
         anh[diaChiAnh] = cap;
         y++;
      }
   }
   else if( (cachX != 0) && (cachY == 0) ) {  // đường ngang
      while( x <= diem1.x ) {
         unsigned int diaChiAnh = beRong*y + x;
         anh[diaChiAnh] = cap;
         x++;
      }
   }
   
   else {
      if( cachX > 0 && cachY > 0 ) {  // ---- ∆x > 0; ∆y > 0
         if( cachY <= cachX ) {
            short saiLam = (cachY << 1) - cachX;
            
            while( x <= diem1.x ) {
               unsigned int diaChiAnh = beRong*y + x;
               anh[diaChiAnh] = cap;
               
               if( saiLam > 0 ) {
                  y++;
                  saiLam -= (cachX << 1);
               }
               saiLam += cachY << 1;
               
               x++;
            }
         }
         else {
            short saiLam = (cachX << 1) - cachY;
            
            while( y <= diem1.y ) {
               unsigned int diaChiAnh = beRong*y + x;
               anh[diaChiAnh] = cap;
               
               if( saiLam > 0 ) {
                  x++;
                  saiLam -= (cachY << 1);
               }
               saiLam += cachX << 1;
               
               y++;
            }
         }
      }
      else {           // ---- ∆x < 0; ∆y > 0
         short cachX_tuyetDoi = -cachX;
         if( cachY <= cachX_tuyetDoi ) {
            short saiLam = (cachY << 1) + cachX;
            
            while( x >= diem1.x ) {
               unsigned int diaChiAnh = beRong*y + x;
               anh[diaChiAnh] = cap;
               
               if( saiLam > 0 ) {
                  y++;
                  saiLam += (cachX << 1);
               }
               saiLam += cachY << 1;
               
               x--;
            }
         }
         else {
            short saiLam = -(cachX << 1) - cachY;
            
            while( y <= diem1.y ) {
               unsigned int diaChiAnh = beRong*y + x;
               anh[diaChiAnh] = cap;
               
               if( saiLam > 0 ) {
                  x--;
                  saiLam -= (cachY << 1);
               }
               saiLam -= cachX << 1;
               
               y++;
               
            }
            
         }
      }
      
   }
}
