/* VẽSốCái.c */

#include <math.h>    // cho hàm floorf()
#include "../HangSo.h"
#include "KyTu.h"
#include "UTF8_UTF32.h"

void chepKyTu( unsigned int *kyTu, unsigned short x, unsigned short y, unsigned char beRong, unsigned char beCao, unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh );

#pragma mark ---- Vẽ Số Và Chữ Cái
void veSoCai( char *xau, unsigned short x, unsigned short y, unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh ) {
   
   // ---- nếu không có xâu vêô nhà sớm
   if( !xau )
      return;

   unsigned char soLuongByteUTF8;
   unsigned int kyTuSo = UTF8_sang_UTF32( xau, &soLuongByteUTF8 );
   xau += soLuongByteUTF8;
   unsigned char chiSoXau = 0;
   
   while( kyTuSo ) {

      if( kyTuSo == '0' )
         chepKyTu( so_0__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '1' )
         chepKyTu( so_1__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '2' )
         chepKyTu( so_2__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '3' )
         chepKyTu( so_3__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '4' )
         chepKyTu( so_4__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '5' )
         chepKyTu( so_5__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '6' )
         chepKyTu( so_6__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '7' )
         chepKyTu( so_7__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '8' )
         chepKyTu( so_8__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '9' )
         chepKyTu( so_9__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == ',' )
         chepKyTu( dauPhay__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == ' ' )
         chepKyTu( dauCach__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '+' )
         chepKyTu( dauCong__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == '-' )
         chepKyTu( dauTru__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x00d7 )
         chepKyTu( dauNhan__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x2194 )
         chepKyTu( _2194__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x2195 )
         chepKyTu( _2195__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x5173 )
         chepKyTu( _5173__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x539f )
         chepKyTu( _539f__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x5c71 )
         chepKyTu( _5c71__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x70b9 )
         chepKyTu( _70b9__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x753b )
         chepKyTu( _753b__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x76f8 )
         chepKyTu( _76f8__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      else if( kyTuSo == 0x7ef4 )
         chepKyTu( _7ef4__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
      // else bỏ

      x += 16;
      
      // ---- ký tự tiếp
      kyTuSo = UTF8_sang_UTF32( xau, &soLuongByteUTF8 );
      xau += soLuongByteUTF8;
   }

}


void chepKyTu( unsigned int *kyTu, unsigned short x, unsigned short y, unsigned char beRong, unsigned char beCao, unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh ) {
   
   // ---- xem phạm vi trước
   if( x >= beRongAnh )
      return;
   if( y >= beCaoAnh )
      return;
   
   // ----
   unsigned char cotCuoi = beRong;
   unsigned char hangCuoi = beCao;
   
   if( x + beRong > beRongAnh )
      cotCuoi = beRongAnh - x;
   
   if( y + beCao > beCaoAnh )
      cotCuoi = beCaoAnh - y;
   
   unsigned char soHang = 0;
   while( soHang < hangCuoi ) {
      unsigned char soCot = 0;
      unsigned int diaChiAnh = (beRongAnh*y + x) << 2;
      unsigned int diaChiKyTu = soHang*beRong;
      while( soCot < cotCuoi ) {
         unsigned int mauKyTu = kyTu[diaChiKyTu];
         
         unsigned char doDuc = mauKyTu & 0xff;
         unsigned char doTrong = 255 - doDuc;
         unsigned char mauDo = (anh[diaChiAnh]*doTrong + (mauKyTu >> 24)*doDuc) >> 8;
         unsigned char mauLuc = (anh[diaChiAnh+1]*doTrong + ((mauKyTu >> 16) & 0xff)*doDuc) >> 8;
         unsigned char mauXanh = (anh[diaChiAnh+2]*doTrong + ((mauKyTu >> 8) & 0xff)*doDuc) >> 8;
         //         printf( "mau %08x   mauDo %d  mauLuc %d  mauXanh %d  doDuc %d  doTrong %d\n", mauKyTu, mauDo, mauLuc, mauXanh, doDuc, doTrong );
         //         printf( "  anh[diaChiAnh] %d  \n", anh[diaChiAnh] );
         //      exit(9);
         
         anh[diaChiAnh] = mauDo;
         anh[diaChiAnh+1] = mauLuc;
         anh[diaChiAnh+2] = mauXanh;
         
         // ---- dùng độ đục cao nhất
         unsigned char doDucAnh = anh[diaChiAnh+3];
         if( doDuc > doDucAnh )
            anh[diaChiAnh+3] = doDuc;
         else
            anh[diaChiAnh+3] = doDucAnh;

         soCot++;
         diaChiKyTu++;
         diaChiAnh += 4;
      }
      y++;
      soHang++;
   }
   
}


char *xauChoSo( float cap ) {
   
   if( cap == 0.0f )
      return "0,0";
   else if( cap == 0.5f )
      return "0,5";
   else if( cap == 1.0f )
      return "1,0";
   else if( cap == 1.5f )
      return "1,5";
   else if( cap == 2.0f )
      return "2,0";
   else if( cap == 2.5f )
      return "2,5";
   else if( cap == 3.0f )
      return "3,0";
   else if( cap == 3.5f )
      return "3,5";
   else if( cap == 4.0f )
      return "4,0";
   else if( cap == 4.5f )
      return "4,5";
   else if( cap == 5.0f )
      return "5,0";
   else if( cap == 5.5f )
      return "5,5";
   else if( cap == 6.0f )
      return "6,0";
   else if( cap == 6.5f )
      return "6,5";
   else if( cap == 7.0f )
      return "7,0";
   else if( cap == 7.5f )
      return "7,5";
   else if( cap == 8.0f )
      return "8,0";
   else if( cap == 8.5f )
      return "8,5";
   else if( cap == 9.0f )
      return "9,0";
   else if( cap == 9.5f )
      return "9,5";
   else if( cap == 10.0f )
      return "10,0";
   else if( cap > 10.0f )
      return "10,0+";
   else
      return "0";  // <-- SAI LẦM
}

void veSoThapPhan( unsigned int soThapPhan, unsigned short x, unsigned short y, unsigned char *anh, unsigned int beRongAnh, unsigned int beCaoAnh ) {
   

   if( soThapPhan == 0 )
      chepKyTu( so_0__16, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
   else {
      unsigned int mangSoCai = 0;
      
      mangSoCai |= ((soThapPhan / 100000) << 20) & 0xf00000 ;
      soThapPhan %= 100000;
      mangSoCai |= ((soThapPhan / 10000) << 16) & 0xf0000 ;
      soThapPhan %= 10000;
      mangSoCai |= ((soThapPhan / 1000) << 12) & 0xf000 ;
      soThapPhan %= 1000;
      mangSoCai |= ((soThapPhan / 100) << 8) & 0xf00 ;
      soThapPhan %= 100;
      mangSoCai |= ((soThapPhan / 10) << 4) & 0xf0 ;
      soThapPhan %= 10;
      mangSoCai |= soThapPhan & 0xf;
      
      unsigned char soBitCon = 24;
      unsigned char daInSoKhacKhong = kSAI;
      
      while( soBitCon ) {
         soBitCon -= 4;
         unsigned char so = (mangSoCai >> soBitCon) & 0xf;
         
         // ---- số cái khác không không
         if( so )
            daInSoKhacKhong = kDUNG;

         unsigned int *mangSo;
         
         if( so == 0x0 )
            mangSo = so_0__16;
         
         else if( so == 0x1 )
            mangSo = so_1__16;
         
         else if( so == 0x2 )
            mangSo = so_2__16;
         
         else if( so == 0x3 )
            mangSo = so_3__16;
         
         else if( so == 0x4 )
            mangSo = so_4__16;
         
         else if( so == 0x5 )
            mangSo = so_5__16;
         
         else if( so == 0x6 )
            mangSo = so_6__16;
         
         else if( so == 0x7 )
            mangSo = so_7__16;
         
         else if( so == 0x8 )
            mangSo = so_8__16;
         
         else if( so == 0x9 )
            mangSo = so_9__16;
         
         // ---- in số, chỉ bắt đầu in số cái đầu tiên khác không
         if( daInSoKhacKhong ) {
            chepKyTu( mangSo, x, y, 16, 16, anh, beRongAnh, beCaoAnh );
            x += 16;
         }
      }
   }
   
}
