/* VẽVòngTròn.c */

#include "VeVongTron.h"

// Giải thuật Bresenham
void veVongTron( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem tam, unsigned int banKinh, unsigned int mau ) {
   
   unsigned char mauDo = mau >> 24;
   unsigned char mauLuc = mau >> 16;
   unsigned char mauXanh = mau >> 8;
   unsigned char doDuc = mau;
   unsigned char nghichDoDuc = 255 - mau;
   
   int x = banKinh-1;
   int y = 0;
   int dx = 1;
   int dy = 1;
   int saiLam = dx - (banKinh << 1);
   int tamX = tam.x;
   int tamY = tam.y;
   
   while (x >= y) {

      // ---- vẽ 8 phân` một lượt
      if( (tamX + x < beRong) && (tamY + y < beCao) ) {
         unsigned int diaChiAnh = (tamX + x + (tamY + y)*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }
 //     printf( " tam %d %d  diaChiAnh %d\n", tamX, tamY, diaChiAnh, beRong*beCao << 2] );
      if( (tamX - x < beRong) && (tamY + y < beCao) ) {
         unsigned int diaChiAnh = (tamX - x + (tamY + y)*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      if( (tamX + y < beRong) && (tamY + x < beCao) ) {
         unsigned int diaChiAnh = (tamX + y + (tamY + x)*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }
      
      if( (tamX - y < beRong) && (tamY + x < beCao) ) {
         unsigned int diaChiAnh = (tamX - y + (tamY + x)*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      if( (tamX - x < beRong) && (tamY - y < beCao) ) {
         unsigned int diaChiAnh = (tamX - x + (tamY - y)*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      if( (tamX - y < beRong) && (tamY - x < beCao) ) {
         unsigned int diaChiAnh = (tamX - y + (tamY - x)*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      if( (tamX + y < beRong) && (tamY - x < beCao) ) {
         unsigned int diaChiAnh = (tamX + y + (tamY - x)*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      if( (tamX + x < beRong) && (tamY - y < beCao) ) {
         unsigned int diaChiAnh = (tamX + x + (tamY - y)*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }
   
      if (saiLam <= 0) {
         y++;
         saiLam += dy;
         dy += 2;
      }
      
      if (saiLam > 0) {
         x--;
         dx += 2;
         saiLam += dx - (banKinh << 1);
      }
   }
}
