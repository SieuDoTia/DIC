/* VẽVòngTròn.c */

#include "VeVongTron.h"

// Giải thuật Bresenham
void veVongTron( unsigned char *anh, unsigned int beRong, unsigned int beCao, short tamX, short tamY, short banKinh, unsigned int mau ) {
   
   // ---- nếu toàn bộ vòng tròn ở ngoài ảnh không vẽ gì đấy!
   if( tamX + banKinh < 0 )
      return;
   if( tamX - banKinh > (int)beRong )
      return;
   if( tamY + banKinh < 0 )
      return;
   if( tamY - banKinh > (int)beCao )
      return;
   
   
   unsigned char mauDo = mau >> 24;
   unsigned char mauLuc = mau >> 16;
   unsigned char mauXanh = mau >> 8;
   unsigned char doDuc = mau;
   unsigned char nghichDoDuc = 255 - mau;
   
   short x = banKinh-1;
   short y = 0;
   int dx = 1;
   int dy = 1;
   int saiLam = dx - (banKinh << 1);
   
   while (x >= y) {
      unsigned short viTriDiemAnh_x = tamX + x;
      unsigned short viTriDiemAnh_y = tamY + y;
      // ---- vẽ 8 phần một lượt
      if( (viTriDiemAnh_x < beRong) && (viTriDiemAnh_y < beCao) ) {
         unsigned int diaChiAnh = (viTriDiemAnh_x + viTriDiemAnh_y*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }
 //     printf( " tam %d %d  diaChiAnh %d\n", tamX, tamY, diaChiAnh, beRong*beCao << 2] );
      viTriDiemAnh_x = tamX - x;
      viTriDiemAnh_y = tamY + y;
      if( (viTriDiemAnh_x < beRong) && (viTriDiemAnh_y < beCao) ) {
         unsigned int diaChiAnh = (viTriDiemAnh_x + viTriDiemAnh_y*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      viTriDiemAnh_x = tamX + y;
      viTriDiemAnh_y = tamY + x;
      if( (viTriDiemAnh_x < beRong) && (viTriDiemAnh_y < beCao) ) {
         unsigned int diaChiAnh = (viTriDiemAnh_x + viTriDiemAnh_y*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }
      
      viTriDiemAnh_x = tamX - y;
      viTriDiemAnh_y = tamY + x;
      if( (viTriDiemAnh_x < beRong) && (viTriDiemAnh_y < beCao) ) {
         unsigned int diaChiAnh = (viTriDiemAnh_x + viTriDiemAnh_y*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      viTriDiemAnh_x = tamX - x;
      viTriDiemAnh_y = tamY - y;
      if( (viTriDiemAnh_x < beRong) && (viTriDiemAnh_y < beCao) ) {
         unsigned int diaChiAnh = (viTriDiemAnh_x + viTriDiemAnh_y*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      viTriDiemAnh_x = tamX - y;
      viTriDiemAnh_y = tamY - x;
      if( (viTriDiemAnh_x < beRong) && (viTriDiemAnh_y < beCao) ) {
         unsigned int diaChiAnh = (viTriDiemAnh_x + viTriDiemAnh_y*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      viTriDiemAnh_x = tamX + y;
      viTriDiemAnh_y = tamY - x;
      if( (viTriDiemAnh_x < beRong) && (viTriDiemAnh_y < beCao) ) {
         unsigned int diaChiAnh = (viTriDiemAnh_x + viTriDiemAnh_y*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }

      viTriDiemAnh_x = tamX + x;
      viTriDiemAnh_y = tamY - y;
      if( (viTriDiemAnh_x < beRong) && (viTriDiemAnh_y < beCao) ) {
         unsigned int diaChiAnh = (viTriDiemAnh_x + viTriDiemAnh_y*beRong) << 2;
         anh[diaChiAnh] = (mauDo*doDuc + anh[diaChiAnh]*nghichDoDuc) >> 8;
         anh[diaChiAnh+1] = (mauLuc*doDuc + anh[diaChiAnh+1]*nghichDoDuc) >> 8;
         anh[diaChiAnh+2] = (mauXanh*doDuc + anh[diaChiAnh+2]*nghichDoDuc) >> 8;
         if( anh[diaChiAnh+3] < doDuc)
            anh[diaChiAnh+3] = doDuc;
      }
   
      if (saiLam <= 0) {
         y++;
         saiLam += dy;
         dy += 2;
      }
      
      if (saiLam > 0) {
         x--;
         dx += 2;
         saiLam += dx - (banKinh << 1);
      }
   }
}
