/* VẽVòngTròn.h */

#pragma once

#include "../ToMauAnh/Diem.h"

void veVongTron( unsigned char *anh, unsigned int beRong, unsigned int beCao, short tamX, short tamY, short banKinh, unsigned int mau );

