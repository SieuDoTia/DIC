/* VẽVòngTròn.h */

#pragma once

#include "../ToMauAnh/Diem.h"

void veVongTron( unsigned char *anh, unsigned int beRong, unsigned int beCao, Diem tam, unsigned int banKinh, unsigned int mau );

